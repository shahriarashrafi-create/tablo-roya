# ساخت APK نسخه ۱۸

1. ZIP را Extract کن و محتویات را در ریشه Repository قرار بده.
2. Push کن یا Workflow `Build Android APK` را در Actions اجرا کن.
3. از Artifacts فایل `shahriar-million-path-v18-apk` را دانلود کن.
