# Gamification v18

Top-half refinement updates:
- Added soft side vignettes to focus attention toward the mountain and center title
- Rebuilt the summit beam into a narrower cinematic light with a brighter core
- Brightened the upper sky area so the peak glow reaches visually toward the top HUD
- Enlarged and softened the upper hero frame, closer to the reference composition
- Repositioned headline, side buttons, world labels, and page dots for better alignment
- Reduced side button size and typography for a more premium, reference-like look
- Subtly refined headline typography and world label styling
- Bumped app version to 0.18 / versionCode 18
