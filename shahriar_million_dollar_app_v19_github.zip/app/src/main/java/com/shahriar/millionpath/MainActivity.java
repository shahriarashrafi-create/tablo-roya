package com.shahriar.millionpath;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private long lastBackPressTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(9, 11, 16));
        getWindow().setNavigationBarColor(Color.rgb(9, 11, 16));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 11, 16));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("if(window.openScreen){window.openScreen('dreams');}", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                String[] accepts = fileChooserParams != null ? fileChooserParams.getAcceptTypes() : null;
                boolean wantsJson = false;
                if (accepts != null) {
                    for (String a : accepts) {
                        if (a != null && (a.contains("json") || a.endsWith(".json"))) {
                            wantsJson = true;
                            break;
                        }
                    }
                }

                Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType(wantsJson ? "application/json" : "image/*");
                boolean allowMultiple = !wantsJson && fileChooserParams != null
                        && fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple);

                Intent chooser = Intent.createChooser(picker, wantsJson ? "انتخاب فایل پشتیبان" : "انتخاب تصویر");
                startActivityForResult(chooser, FILE_CHOOSER_REQUEST_CODE);
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void savePng(String filename, String dataUrl) {
            new Thread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) {
                        base64 = dataUrl.substring(comma + 1);
                    }
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = (filename == null || filename.trim().isEmpty())
                            ? "vision-board.png"
                            : filename.replaceAll("[^a-zA-Z0-9._-]", "-");
                    if (!safeName.toLowerCase().endsWith(".png")) {
                        safeName += ".png";
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MillionPath");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);

                        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new IllegalStateException("Unable to create media file");

                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            if (out == null) throw new IllegalStateException("Unable to open output stream");
                            out.write(bytes);
                            out.flush();
                        }

                        values.clear();
                        values.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, values, null, null);
                        showToast("تابلو در گالری ذخیره شد");
                    } else {
                        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MillionPath");
                        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Unable to create directory");
                        File outFile = new File(dir, safeName);
                        try (FileOutputStream out = new FileOutputStream(outFile)) {
                            out.write(bytes);
                            out.flush();
                        }
                        showToast("تابلو ذخیره شد: " + outFile.getAbsolutePath());
                    }
                } catch (Exception e) {
                    showToast("ذخیره تصویر ناموفق بود");
                }
            }).start();
        }

        @JavascriptInterface
        public void saveJson(String filename, String json) {
            new Thread(() -> {
                try {
                    String safeName = (filename == null || filename.trim().isEmpty())
                            ? "dream-board-backup.json"
                            : filename.replaceAll("[^a-zA-Z0-9._-]", "-");
                    if (!safeName.toLowerCase().endsWith(".json")) safeName += ".json";
                    byte[] bytes = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DreamBoard");
                        values.put(MediaStore.Downloads.IS_PENDING, 1);
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new IllegalStateException("Unable to create backup file");
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            if (out == null) throw new IllegalStateException("Unable to open output stream");
                            out.write(bytes);
                            out.flush();
                        }
                        values.clear();
                        values.put(MediaStore.Downloads.IS_PENDING, 0);
                        getContentResolver().update(uri, values, null, null);
                        showToast("فایل پشتیبان در Downloads ذخیره شد");
                    } else {
                        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "DreamBoard");
                        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Unable to create backup directory");
                        File outFile = new File(dir, safeName);
                        try (FileOutputStream out = new FileOutputStream(outFile)) {
                            out.write(bytes);
                            out.flush();
                        }
                        showToast("فایل پشتیبان ذخیره شد");
                    }
                } catch (Exception e) {
                    showToast("ذخیره فایل پشتیبان ناموفق بود");
                }
            }).start();
        }

        @JavascriptInterface
        public void searchSimilarImage(String dataUrl) {
            new Thread(() -> {
                try {
                    String base64 = dataUrl;
                    int comma = dataUrl.indexOf(',');
                    if (comma >= 0) base64 = dataUrl.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                    File shareDir = new File(getCacheDir(), "image_search");
                    if (!shareDir.exists() && !shareDir.mkdirs()) {
                        throw new IllegalStateException("Unable to create cache directory");
                    }
                    File file = new File(shareDir, "explore-search-" + System.currentTimeMillis() + ".jpg");
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        out.write(bytes);
                        out.flush();
                    }

                    Uri uri = FileProvider.getUriForFile(
                            MainActivity.this,
                            getPackageName() + ".fileprovider",
                            file
                    );

                    runOnUiThread(() -> {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/*");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        send.setPackage("com.google.android.googlequicksearchbox");
                        try {
                            startActivity(send);
                            showToast("عکس برای جستجوی تصویری گوگل ارسال شد");
                        } catch (ActivityNotFoundException e) {
                            Intent fallback = new Intent(Intent.ACTION_SEND);
                            fallback.setType("image/*");
                            fallback.putExtra(Intent.EXTRA_STREAM, uri);
                            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(fallback, "جستجوی عکس مشابه با Google Lens"));
                        }
                    });
                } catch (Exception e) {
                    showToast("جستجوی تصویری انجام نشد");
                }
            }).start();
        }
    }

    private void showToast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST_CODE) return;
        if (filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "(window.getActiveScreen ? window.getActiveScreen() : 'dreams')",
                value -> {
                    String screen = value == null ? "dreams" : value.replace("\"", "").trim();
                    long now = System.currentTimeMillis();

                    if (!"dreams".equals(screen)) {
                        webView.evaluateJavascript("if(window.openScreen){window.openScreen('dreams');}", null);
                        lastBackPressTime = now;
                        return;
                    }

                    if (now - lastBackPressTime <= 2000L) {
                        finish();
                    } else {
                        lastBackPressTime = now;
                        showToast("برای خروج دوباره دکمه برگشت را بزن");
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
