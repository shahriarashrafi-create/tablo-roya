# آپلود نسخه ۱۹ روی GitHub

ZIP را Extract کن، محتویات را در Repository قرار بده و Workflow ساخت APK را اجرا کن. Artifact خروجی: `shahriar-million-path-v19-apk`.
