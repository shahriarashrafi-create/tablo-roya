package com.shahriar.gamify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0C1320)
private val Gold = Color(0xFFF7C948)
private val GoldSoft = Color(0xFFFCE9A7)
private val GoldDeep = Color(0xFFB57B1F)
private val TextSoft = Color(0xFFD0D8E4)
private val TextMuted = Color(0xFFA9B3C0)
private val Divider = Color(0xFF2A3440)
private val Blue = Color(0xFF5CA3FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val coins: Int = 1320,
    val combo: Int = 2
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val ringColors: List<Color>
)

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", Color(0xFF6D3C1D), Color(0xFFF2C56F)),
    RankTier(6, 10, "Explorer", Color(0xFF7D1E1A), Color(0xFFF5CC62)),
    RankTier(11, 15, "Seeker", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value)

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val player = remember { PlayerState() }

    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B1018)) {
                    listOf("خانه", "کارها", "آمار", "تنظیمات").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("🎮", "☑", "▥", "⚙")[i], fontSize = 18.sp) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Color(0xFF2A2412),
                                unselectedIconColor = Color(0xFF8A93A2),
                                unselectedTextColor = Color(0xFF8A93A2)
                            )
                        )
                    }
                }
            }
        ) { pad ->
            if (tab == 0) {
                GameHome(player, Modifier.padding(pad))
            } else {
                Box(
                    Modifier
                        .padding(pad)
                        .fillMaxSize()
                        .background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(listOf("", "کارها", "آمار", "تنظیمات")[tab], color = Color.White, fontSize = 24.sp)
                }
            }
        }
    }
}

@Composable
private fun GameHome(player: PlayerState, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = "World Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xBF08111A),
                            Color(0x4A0A1118),
                            Color(0x250B1118),
                            Color(0x6E091018),
                            Color(0xD00A1018)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            TopGameHud(player)
            Spacer(Modifier.height(10.dp))
            WorldStage(player, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun WorldStage(player: PlayerState, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 4.dp, top = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SideWorldButton(icon = "📜", label = "Quests", badge = "1")
            SideWorldButton(icon = "🗺️", label = "Map")
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 4.dp, top = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SideWorldButton(icon = "✉️", label = "Inbox")
            SideWorldButton(icon = "🧰", label = "Shop")
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 145.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "A BETTER YOU\\nA BRIGHTER WORLD",
                color = Color(0xFFF5E7C6),
                textAlign = TextAlign.Center,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(6.dp))
            Text("◇", color = GoldSoft, fontSize = 13.sp)
        }

        LabelAt("Knowledge", Modifier.align(Alignment.TopStart).offset(x = 88.dp, y = 295.dp))
        LabelAt("Freedom", Modifier.align(Alignment.TopEnd).offset(x = (-88).dp, y = 290.dp))
        LabelAt("Health", Modifier.align(Alignment.TopStart).offset(x = 110.dp, y = 430.dp))
        LabelAt("Discipline", Modifier.align(Alignment.Center).offset(y = 30.dp))
        LabelAt("Wealth", Modifier.align(Alignment.TopEnd).offset(x = (-112).dp, y = 430.dp))

        MissionCard(
            player = player,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 4.dp, vertical = 10.dp)
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 240.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PageDot(active = true)
            PageDot(active = false)
            PageDot(active = false)
        }
    }
}

@Composable
private fun PageDot(active: Boolean) {
    Box(
        modifier = Modifier
            .size(if (active) 10.dp else 8.dp)
            .clip(CircleShape)
            .background(if (active) Gold else Color(0xFF5A606D))
    )
}

@Composable
private fun LabelAt(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        modifier = modifier,
        color = Color.White,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium
    )
}

@Composable
private fun SideWorldButton(icon: String, label: String, badge: String? = null) {
    Box {
        Column(
            modifier = Modifier
                .width(66.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xD90A0F14))
                .border(1.dp, Color(0x3DE5C87A), RoundedCornerShape(18.dp))
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(icon, fontSize = 20.sp)
            Text(label, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
        if (badge != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-2).dp, y = 2.dp)
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEE4B4B)),
                contentAlignment = Alignment.Center
            ) {
                Text(badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MissionCard(player: PlayerState, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x66D8B55E), RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xEE0E141D)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⚔  مأموریت بعدی", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallPill("کلاسیک", Blue)
                    SmallPill("Focus x2", Color(0xFFCF73FF))
                }
            }
            Text("۲۵ دقیقه تمرکز", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("روی مهم‌ترین کار فعلی تمرکز کن؛ بدون حواس‌پرتی.", color = TextSoft, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Reward("+50 XP", Gold)
                Reward("+20 سکه", Color.White)
                Reward("◷ 25 دقیقه", TextSoft)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {},
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("▶   شروع مأموریت", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                Surface(
                    modifier = Modifier.size(width = 84.dp, height = 58.dp),
                    color = Color(0xFF151B24),
                    shape = RoundedCornerShape(18.dp),
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x55F1D487))
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxSize()) {
                        Text("⇄", color = Color.White, fontSize = 21.sp)
                        Text("Change", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallPill(text: String, textColor: Color) {
    Surface(
        color = Color(0x201C2742),
        shape = RoundedCornerShape(50),
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.55f))
    ) {
        Text(
            text = text,
            color = textColor,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun TopGameHud(player: PlayerState) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(RoundedCornerShape(21.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xED0F141C), Color(0xF1080D14))
                    )
                )
                .drawBehind {
                    val stroke = 1.2.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xAAEED68A), Color(0xAAAF7A1E), Color(0xAAF1D57D), Color(0xAA996716))
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0x18FFF4C8), Color.Transparent, Color(0x10FFF4C8))
                        ),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 4.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1.68f), verticalAlignment = Alignment.CenterVertically) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        XpBar(progress)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP",
                            color = Color(0xFFE8EBEF),
                            fontSize = 8.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
                HudDivider()
                Row(modifier = Modifier.weight(1.16f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text("Rank ${player.rank}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 11.sp)
                        Text(rankTier.title, color = rankTier.secondary, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(modifier = Modifier.weight(1.00f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(formatNumber(player.coins), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Coins", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(modifier = Modifier.weight(0.82f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    FlameBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text("x${player.combo}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Combo", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(41.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f
            drawCircle(brush = Brush.sweepGradient(tier.ringColors), radius = radius, style = Stroke(width = stroke))
            drawCircle(color = Color(0xFF10141B), radius = size.minDimension * 0.36f)
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )
            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                drawCircle(
                    color = GoldSoft,
                    radius = dotR,
                    center = Offset(cx + cos(rad).toFloat() * ringR, cy + sin(rad).toFloat() * ringR)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF242B34))
            .border(1.dp, Color(0x805E4A20), RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

private fun DrawScope.starPath(center: Offset, outerRadius: Float, innerRadius: Float, points: Int = 5): Path {
    val path = Path()
    val angle = Math.PI / points
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val theta = i * angle - Math.PI / 2
        val x = center.x + cos(theta).toFloat() * r
        val y = center.y + sin(theta).toFloat() * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                lineTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.80f, h * 0.66f)
                quadraticBezierTo(w * 0.66f, h * 0.87f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.87f, w * 0.20f, h * 0.66f)
                lineTo(w * 0.14f, h * 0.18f)
                close()
            }
            drawPath(shield, brush = Brush.verticalGradient(listOf(tier.secondary.copy(alpha = 0.18f), tier.primary)))
            drawPath(shield, color = tier.secondary, style = Stroke(width = 1.6f))
            val inner = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.77f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.61f)
                quadraticBezierTo(w * 0.61f, h * 0.77f, w * 0.50f, h * 0.83f)
                quadraticBezierTo(w * 0.39f, h * 0.77f, w * 0.28f, h * 0.61f)
                lineTo(w * 0.23f, h * 0.24f)
                close()
            }
            drawPath(inner, color = Color(0x14FFFFFF))
            val star = starPath(Offset(w * 0.50f, h * 0.44f), outerRadius = w * 0.17f, innerRadius = w * 0.07f)
            drawPath(star, color = GoldSoft)
        }
    }
}

@Composable
private fun CoinBadge() {
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFF0B5), Color(0xFFF5C84F), Color(0xFFC88715))), radius = size.minDimension / 2f, center = center)
            drawCircle(color = Color(0x30FFFFFF), radius = size.minDimension * 0.34f, center = Offset(center.x, center.y - 1.dp.toPx()))
            drawCircle(color = Color(0xB9784B0A), radius = size.minDimension / 2f - 0.6.dp.toPx(), center = center, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(color = Color(0xFFFCE9A7), radius = size.minDimension / 2f - 1.4.dp.toPx(), center = center, style = Stroke(width = 0.8.dp.toPx()))
            val star = starPath(center, outerRadius = size.minDimension * 0.18f, innerRadius = size.minDimension * 0.08f)
            drawPath(star, color = Color(0xFF7A4E00))
        }
    }
}

@Composable
private fun FlameBadge() {
    Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))))
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(inner, brush = Brush.verticalGradient(listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))))
        }
    }
}

@Composable
private fun HudDivider() {
    Box(Modifier.width(1.dp).height(31.dp).background(Divider))
}

@Composable
private fun Reward(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
}
