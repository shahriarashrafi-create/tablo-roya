package com.shahriar.nextbeat;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private long lastBackPressed = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(6, 17, 44));
        getWindow().setNavigationBarColor(Color.rgb(6, 17, 44));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setBackgroundColor(Color.rgb(6, 17, 44));
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript("window.appBack ? window.appBack() : false;", value -> {
            String v = value == null ? "false" : value.replace("\"", "");
            if ("true".equalsIgnoreCase(v)) {
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (now - lastBackPressed < 1800) {
                MainActivity.super.onBackPressed();
            } else {
                lastBackPressed = now;
                Toast.makeText(MainActivity.this, "برای خروج دوباره بازگشت را بزنید", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void noop() {}
    }
}
