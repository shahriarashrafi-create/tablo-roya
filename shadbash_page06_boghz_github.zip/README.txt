shadbash - Boghze Taraneh flow

Changes:
- Fonts and shadows returned to the previous softer style.
- Default remains 2 teams.
- Round-one title moved lower.
- Removed the random-card button completely.
- The play icon on round one now starts the included Reza Sadeghi - Boghze Taraneh audio.
- Playback starts near the first vocal line and shows the lyric cue.
- At the blank point, audio pauses and a new 20-second guessing screen opens.
- Guess screen includes Correct / Wrong buttons.
- The separate song-card page has been removed.
- Back behavior remains one step per press; double back on home exits the app.
