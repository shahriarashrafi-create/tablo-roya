# Gamification v50 Progress — Step 1B

## Cleanup and hardening
- Removed retired Mission fields for Deadline and Notes from the active data model and persistence layer.
- Removed the retired onboarding Main Goal field from the active model/storage path while keeping old backups migratable.
- Removed unreachable legacy Challenges and Inbox dialog UI paths without changing currently reachable screens.
- Bumped persistence schema to 11 and automatically removes retired preference keys during migration.
- Hardened backup import by validating and staging the full backup before replacing current data.
- Retired fields are no longer exported in new backups, but older backups remain accepted through migration.

## Repeatable build verification
- Added project-local `gradlew` / `gradlew.bat` launchers pinned to Gradle 8.9.
- Added `gradle/wrapper/gradle-wrapper.properties`.
- Added `scripts/verify-project.sh` for structural checks plus debug APK compilation.
- Added `.github/workflows/android-build.yml` to compile every push/PR and upload the debug APK.
- Version bumped to 0.50 / versionCode 50.

## Next approved step
- Step 2A: define and apply the shared UI/RTL design system primitives.

## v51 — Step 2A: UI / RTL design-system foundation
- Added a centralized `DesignSystem.kt` for app-wide colors, spacing, dimensions, shapes, and Material 3 dark theme tokens.
- Replaced the duplicated text-field palettes with one high-contrast app-wide input palette.
- Switched onboarding and the main app shell to `GamifyTheme` so Material dialogs/controls inherit the same dark/gold visual language.
- Standardized core input minimum heights and field corner radii in Onboarding, Mission Editor, Reward Editor, and Dream Properties.
- Standardized compact Hour/Subtask surfaces to shared design tokens, preventing future clipping regressions.
- Kept gameplay/storage behavior unchanged in this stage; full screen-by-screen RTL/small-screen audit remains Step 2B.

## v52 — Step 2B: full UI / RTL / compact-screen audit
- Applied the shared v51 design tokens to the remaining active dialogs and surfaces instead of screen-specific colors/radii.
- Added responsive horizontal padding and dialog-height helpers for narrow/short Android screens.
- Made Mission Execution adapt its timer, title, spacing, subtask list height and result buttons on compact displays to prevent vertical clipping.
- Standardized Onboarding, Settings, Shop, Mission Editor, Reward Editor, Dream Properties, Mission list/templates, World Progress, Inventory and reset/abandon dialogs.
- Kept Persian Shop and Dream editing surfaces explicitly RTL while preserving LTR for English/numeric HUD areas.
- Increased None/Daily selectors for better readability and kept shared high-contrast input colors for Hour/Subtask and all OutlinedTextFields.
- Updated the System Health release label and app version to 0.52 / versionCode 52.
- Gameplay and persistence behavior are intentionally unchanged in Step 2B.

## Next approved step
- Step 3A: consolidate Mission state transitions (Active / Done / Failed / Later), base position, Daily reset and Subtask state into one Mission Engine.


## v53 — Step 3A: Mission Engine core
- Added a centralized `MissionEngine.kt` for Active / Later / Done / Failed state derivation and mission display ordering.
- Added stable mission IDs and persisted them in missions, timer state, and history so renaming a mission no longer breaks its status/history association.
- Migrated schema to 12; old history entries are linked to migrated missions where possible without deleting history.
- Defined the persisted mission-list order as the canonical base position. Status sorting is derived at runtime: active first, then done, then failed.
- `Later` keeps a mission active, gives no terminal card state, and appends it to the end of the active queue for the current day only. Repeated Later actions move it to the latest active-queue position.
- Subtask progress now keys by stable mission ID; schema migration copies legacy title-based progress forward and keeps fallback support. Daily subtasks naturally reset on the next mission day while one-time mission progress persists.
- Home carousel and Missions list now use the same Mission Engine ordering rules instead of separate sort implementations.
- Mission editing preserves identity; new/template missions receive unique IDs before insertion.
- Version bumped to 0.53 / versionCode 53.

## v54 — Step 3B: session recovery and exact result commits
- Added timer recovery based on the persisted end timestamp, so a running mission resumes accurately after backgrounding or process death and an expired timer reopens at 00:00 ready for a result.
- Added a durable session ID to mission history. Home, Missions and History now resolve the same committed session/result source of truth.
- Added one atomic mission-result commit path: player XP/coins/combo/rank, history, completed-session guard, and timer cleanup are committed together before the UI animates.
- Added duplicate-result protection for rapid taps/re-entry so a single timer session cannot grant rewards twice.
- Result buttons lock immediately after the first selection, while the storage layer still independently rejects duplicate commits.
- Done/Failed/Later state changes are reflected from the committed history list instead of separate UI-only state.
- Later continues to preserve Combo and reward values, and the abandon copy now matches that behavior.
- Daily due-state checks now use the same Mission Engine card state used by Home/Missions.
- History row keys prefer stable session IDs, preventing collisions after fast sequential actions.
- Persistence schema bumped to 13 and app version bumped to 0.54 / versionCode 54.

## v55 — Step 4A: atomic Coin spend + One-time / Termless reward core
- Added `RewardEngine.kt` as the single pure rules layer for personal reward redemption.
- One-time rewards become completed after a successful redemption and cannot charge coins again.
- Termless/reusable rewards stay active after redemption and increment their redemption count without being permanently completed.
- Added `redeemPersonalReward()` as the single Shop spend path. Coin deduction, reward state, and the redemption ledger are committed together in one storage transaction.
- Added a short duplicate-submit guard for rapid repeated taps, including reusable rewards, so one physical action cannot double-charge the wallet.
- Added a durable reward redemption ledger with transaction ID, timestamp, reward identity/title, price, reward mode, and before/after coin balances. The ledger is included in normal backups.
- Reward loading/saving now normalizes invalid prices and guarantees reusable rewards cannot remain in a completed state after old data/edit migrations.
- Shop UI now delegates redemption to the atomic engine rather than directly mutating player coins and reward state.
- Persistence schema bumped to 14 and app version bumped to 0.55 / versionCode 55.

## Next approved step
- Step 4B: finish the Shop UI, ordering, completed/redeemed history presentation, insufficient-coin feedback, and reward-position behavior.

## v56 — Step 4B: Shop ordering, completed view, history and feedback
- Added persistent reward `position` so every personal reward has a stable user-controlled order.
- Added reward placement helpers in `RewardEngine`: insert/update at a chosen position, normalize positions after edits, and compact positions after deletion.
- Existing v55 rewards migrate automatically to sequential positions without losing completion/redeem state.
- One-time completed rewards sort after active rewards and remain hidden by default; the existing bottom switch reveals them on demand.
- Termless rewards never enter the completed bucket and remain available at their configured position after every successful use.
- Reward Editor now includes a compact RTL position selector (`موقعیت: X از Y`) for new and existing rewards.
- Shop cards remain fully RTL, keep a large icon-only check action, and use smaller icon-only Edit/Delete controls.
- Insufficient coin actions remain tappable and now return subtle in-Shop feedback instead of being silently disabled.
- Added a visible redemption-history view showing reward title, spend amount, timestamp, mode, and post-redemption balance from the durable ledger created in v55.
- The app keeps the redemption-history state live after each successful atomic redemption and reloads it after backup restore.
- Persistence schema bumped to 15 and app version bumped to 0.56 / versionCode 56.

## Next approved step
- Step 5A: Dreamboard carousel core, 9:16 image flow, Properties fields, persistent ordering and crop/pan/zoom foundation.

## v57 — Step 5A: Dreamboard core, 9:16 carousel, Properties and image crop
- Moved the Dreamboard UI out of `MainActivity.kt` into `DreamboardScreen.kt`, reducing the main activity/orchestration file by roughly 500 lines.
- Added `DreamboardEngine.kt` as the single pure ordering/normalization layer for dream insertion, editing, movement, deletion, stable IDs and sequential positions.
- Dreamboard remains a horizontal snapping carousel of portrait 9:16 cards; the active card is larger/clearer while neighboring cards are reduced in scale/opacity.
- The carousel itself stays visually clean: no Dreamboard title, top add button, close button, achieved marker, or three-dot menu. The last card is the Add Dream card.
- Long-pressing a dream opens its Properties editor. Properties contains only Image, Title, Year, Price and Position plus Save/Cancel/Delete actions.
- Card overlay layout remains Title on the right, `سال <year>` in the center, and the numeric dollar price with `$` beside/after it on the left.
- Position edits are ID-based rather than source-index-based, preventing edits/deletes from targeting the wrong card after reordering.
- Gallery image selection opens a 9:16 crop surface with one-finger pan and pinch zoom; the saved crop is copied into app-owned storage so the card no longer depends on continued gallery access.
- Replacing/canceling/deleting dreams now cleans unused app-owned crop files, and migration/health-check pruning removes old orphan crop images without touching external URIs.
- Dream data loading/saving now normalizes title/year/price/order consistently and repairs duplicate/blank legacy IDs.
- Persistence schema bumped to 16 and app version bumped to 0.57 / versionCode 57.

## v58 — Step 5B: fullscreen Dreamboard, active-photo backdrop and portable photos
- Tapping a Dreamboard image opens a full-screen, image-first viewer with horizontal swipe navigation across all dreams; the main long-press Properties behavior stays unchanged.
- Both the main Dreamboard and fullscreen viewer derive a soft, darkened background from the active image using a cross-version downsample/upsample blur that works back to minSdk 26.
- Added a compact `current/total` indicator (for example `4/12`) instead of dot rows, keeping the Dreamboard surface visually minimal.
- Fullscreen keeps the same 9:16 image presentation and bottom metadata overlay: price left, `سال <year>` center, title right.
- Manual Export now creates a portable `.gamify.zip` bundle containing app data plus the actual Dreamboard photo bytes; Restore remaps every bundled image to a new app-private file path.
- Legacy JSON backups are still accepted. ZIP imports validate paths/count/size before applying data and ignore unsafe archive paths.
- App-private Dreamboard files are now included in Android Auto Backup and device-to-device transfer rules.
- Dream loading repairs stale file URIs by matching the restored app-private filename where possible.
- Persistence schema bumped to 17 and app version bumped to 0.58 / versionCode 58.

## Next approved step
- Step 6A: centralize XP / Level / Rank / Combo progression rules in one Progression Engine.
