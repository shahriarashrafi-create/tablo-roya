# Gamification architecture

This file records the structure introduced in Step 1A.

- `MainActivity.kt` — Compose UI, navigation/orchestration, dialogs and visual components.
- `Models.kt` — application/domain state models shared by UI and persistence.
- `GameStorage.kt` — SharedPreferences persistence, migrations, backup/import, mission/timer state, Dreamboard image persistence and non-UI helpers.
- `TimerFinishReceiver.kt` — Android timer-finished broadcast receiver.
- `GamifyWidgetProvider.kt` — Android home-screen widget provider.

Step 1B is intentionally reserved for deleting legacy code, tightening migrations, and adding a reproducible Gradle build check.


## Step 1B build and migration guardrails
- Active models no longer carry retired Deadline, Notes, or Main Goal fields.
- Schema 11 removes retired preference keys but old backup files remain importable.
- Backup restoration validates input before clearing live preferences.
- `./scripts/verify-project.sh` is the canonical build verification command.
- CI runs the same verification against Android SDK 35 and Java 17.

## Design system
`DesignSystem.kt` is now the single source of truth for core visual tokens (`GamifyColors`, `GamifySpacing`, `GamifyDimens`, `GamifyShapes`) and the app Material theme. New screens should consume these tokens instead of introducing new hard-coded input colors/radii. Step 2B will migrate the remaining legacy hard-coded UI values and perform the full RTL/small-screen pass.

## v52 UI boundary
`DesignSystem.kt` is now the source of shared visual tokens plus compact-screen helpers. New UI should not introduce fixed dialog heights or local text-field palettes unless a documented exception is necessary. Persian feature surfaces should explicitly provide RTL at their boundary; mixed numeric/HUD surfaces can remain LTR.


## v53 Mission Engine boundary
`MissionEngine.kt` owns mission identity, current-day state, Later ordering, and visible mission ordering. The persisted mission list remains the canonical base position selected by the user. `GameStorage.kt` persists mission IDs, history IDs, timer mission identity and subtask progress, while UI screens consume the engine instead of duplicating sorting/state rules.


## v54 Mission session boundary
`GameStorage.finalizeActiveMissionSession()` is the single write path for a timer result. It atomically persists progression, history, the completed-session guard and timer cleanup. `recoverActiveTimer()` restores running/paused/expired sessions from persisted timestamps. UI code must not directly grant mission XP/coins or append mission history outside this boundary.

## v55 Reward / Coin spend boundary
`RewardEngine.kt` owns One-time vs Termless redemption rules. `GameStorage.redeemPersonalReward()` is the only Shop coin-spend write path and commits wallet balance, reward state, duplicate-submit guard metadata, and the redemption ledger together. UI code should consume the returned commit instead of editing coins or reward completion directly.


## v56 Shop ordering / history boundary
`PersonalReward.position` is the canonical base order for active personal rewards. `RewardEngine` owns position normalization/upsert/removal, while the Shop derives completed-last presentation at render time without destroying the base order. Redemption history is read from the durable ledger written by `GameStorage.redeemPersonalReward()`; the UI never synthesizes or edits ledger entries.

## v57 Dreamboard boundary
`DreamboardEngine.kt` owns dream identity sanitation and canonical position ordering. `DreamboardScreen.kt` owns the 9:16 carousel, long-press Properties editor and crop/pan/zoom interaction. `GameStorage.kt` persists normalized dream metadata and owns app-private crop-file lifecycle. `MainActivity.kt` only coordinates the observable Dreamboard list and delegates add/update/delete to the engine.


## v58 Dreamboard viewing / image-backup boundary
`DreamboardScreen.kt` now owns both the compact carousel and the image-only fullscreen swipe viewer. The active dream image also drives the soft/dark backdrop and the compact `current/total` indicator. `GameStorage.kt` owns portable Dreamboard image packaging: new manual backups are ZIP bundles containing `backup.json` plus the referenced Dreamboard image bytes, while legacy JSON backups remain importable. Restored images are copied into app-private storage and Dream `imageUri` values are rewritten to the new local files. Android Auto Backup/device-transfer rules also include the app-private `dreamboard/` directory.
