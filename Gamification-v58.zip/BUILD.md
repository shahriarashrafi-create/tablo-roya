# Build verification

This project is pinned to Java 17, Android SDK 35, and Gradle 8.9.

## Local
Run:

```sh
./scripts/verify-project.sh
```

The project-local `gradlew` launcher downloads the pinned Gradle distribution on first use and then runs `:app:assembleDebug`.

## CI
`.github/workflows/android-build.yml` installs Android SDK 35 and Java 17, runs the same verification script, and uploads `app-debug.apk`.

The launcher is intentionally self-contained so ZIP snapshots build without requiring a preinstalled Gradle executable.


## v52 verification note
The project structure and Kotlin delimiter balance were checked after the Step 2B UI audit. Full local Gradle compilation could not run in this environment because `services.gradle.org` DNS resolution is unavailable; the repository wrapper and CI workflow remain the authoritative build check.

## v54 verification note
Step 3B was checked with Kotlin delimiter validation and a standalone MissionEngine behavior test covering Active/Later/Done ordering. Full Android Gradle compilation is still unavailable in this execution environment because `services.gradle.org` cannot be resolved here; CI remains the full APK build check.

## v55 verification note
Step 4A adds a pure `RewardEngine` that was behavior-tested independently with Kotlin 1.9 for One-time success/blocking, Termless repeatability, balance deduction, and insufficient-coin rejection. The full Android build could not run here because `services.gradle.org` DNS resolution is unavailable; the project Gradle wrapper/CI remains the full APK build check.


## v56 verification note
Step 4B extends the pure RewardEngine with deterministic position normalization/upsert/removal behavior and keeps coin spending on the same atomic storage path. Structural Kotlin checks and standalone reward-order behavior tests are run before packaging. Full Android Gradle compilation may still require network access to the pinned Gradle distribution/Android dependencies when not already cached.

## v57 verification note
Step 5A extracted the Dreamboard UI and added a pure `DreamboardEngine`. The engine was compiled and behavior-tested independently for insert/move/remove ordering, position normalization, metadata sanitation and duplicate-ID repair. Kotlin parser passes found no syntax errors in the edited Android files; full Android compilation still requires the Gradle/Android dependency set to be available in the build environment.


## v58 verification note
Step 5B was checked with Kotlin syntax/error scanning on the edited files, ZIP/XML structural validation, and static checks for the new Dreamboard backup bundle paths. Full Android Gradle compilation was attempted, but this execution environment cannot resolve `services.gradle.org`, so the pinned Gradle distribution and Android dependencies could not be downloaded here.
