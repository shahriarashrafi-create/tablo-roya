# Gamification v36 Progress

- Added first-run onboarding with player name, main goal, active hours, and selectable starter mission templates.
- Existing users upgrading from previous schemas skip onboarding automatically; Reset All Data returns to onboarding.
- Added runtime data-health repair: mission value sanitizing, history/notification de-duplication, player/settings repair, and widget refresh.
- Backup schema upgraded to v6 and onboarding data is included automatically in JSON Backup/Restore.
- Added release hardening configuration for the Android release build, ProGuard baseline, splash theme, launcher icon, and cloud/device-transfer backup rules.
- Added native Android home-screen widget showing player name, Level, Rank, Coins, and Combo; it refreshes when player state changes.
- Added Calendar integration using the system Calendar event composer for the next mission (no calendar permission required).
- Added Personal League status based on weekly completed missions.
- Enabled Android Auto Backup/device transfer as the cloud-restore foundation; true real-time account sync and online leaderboards still require a backend service.
- App version bumped to 0.36 (versionCode 36).


## v37 build fix
- Fixed Android 12+ resource linking failure caused by invalid `android:postSplashScreenTheme` attribute in `values-v31/styles.xml`.
- Kept native Android splash screen background and animated icon attributes.
- Bumped app version to 0.37 / versionCode 37.

## v38 home/card cleanup
- Removed the World Region / level chip from the center of the Home background.
- Removed the center Challenges progress chip and Login Streak chip so the motivational quote is the only center-world text.
- Simplified mission cards to exactly three visual rows: title, XP/Coin/time, and Start Mission.
- Removed category, recurrence, due/done status, rank/link tags, mission icon, and visible manage menu from the mission card.
- Card remains manageable by tapping the card surface outside the Start button.
- Made mission and Add Mission cards more compact.
- Moved the card pager upward and attached the page dots closely beneath it so both move as one visual group.
- App version bumped to 0.38 / versionCode 38.


## v39
- Simplified onboarding header: removed the setup subtitle and removed Main Goal selection.
- Reworked onboarding profile fields so PLAYER and ACTIVE HOURS stay on one line with their values.
- Increased text-field contrast across the app (typed text, cursor, borders, labels and field background).
- Replaced starter missions with the 12 requested missions; all are Daily and enabled by default.
- Updated release metadata to 0.39.

# Gamification v40 Progress
- Simplified Mission Edit: Rank Mission is now a clean toggle with no explanatory copy.
- Removed mission Icon, Category, Card Color, and After Done controls/data from the mission model and editor.
- Rank missions show the gold star marker on the card; non-rank missions have no mission icon.
- Repeat Schedule is now only None or Daily.
- Daily missions can optionally use a simple hour-only Reminder Time field.
- Replaced Card Position arrows with a compact dropdown position selector.
- Mission card colors are now status-driven only: gold/yellow active, green completed, red not completed.
- Completed/failed cards use strikethrough titles, lose the Start Mission button, and are sorted after active cards.
- Active card order remains based on the saved Card Position; daily cards return to their saved position on a new day.
- Completed cards are grouped before failed cards at the end of the carousel.
- Old recurring schedule values migrate to Daily; obsolete mission styling/category/link fields are ignored.
- Schema version advanced to 7 and app version to 0.40.
