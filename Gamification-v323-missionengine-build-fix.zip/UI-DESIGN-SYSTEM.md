# Gamification UI Design System — v52

Step 2 is now applied across the active product surfaces.

## Core rules
- Dark cinematic background with gold as the single primary accent.
- Primary text is near-white; secondary/placeholder text remains visibly separated from input backgrounds.
- Standard input minimum height: 52dp.
- Compact time/control height: 42dp.
- Standard button height: 52dp.
- Minimum interactive target token: 48dp where layout permits.
- Standard field radius: 14dp; card radius: 20dp; dialog radius: 24dp.
- Standard spacing scale: 4 / 8 / 12 / 16 / 24dp.
- Persian surfaces use RTL; English HUD/gameplay surfaces stay LTR where numeric readability benefits.
- Active screens use `GamifyTheme`, `GamifyColors`, `GamifySpacing`, `GamifyDimens`, `GamifyShapes`, and `gamifyTextFieldColors()`.

## Responsive rules applied in Step 2B
- Horizontal screen padding drops from 16dp to 12dp below 360dp screen width.
- Dialog bodies use available screen height instead of fixed heights, with safe maximums.
- Mission execution enters a compact layout on short/narrow displays: smaller timer, title, spacers, and result controls while preserving functionality.
- Onboarding, Settings, Shop, Mission Editor, Reward Editor, Dream Properties, Mission list/templates, World Progress and Inventory now share the same dialog/surface/input tokens.
- Dream and Shop editors keep explicit RTL layout; high-contrast input text/cursor/placeholder colors are shared app-wide.

## Regression targets
- No clipped input text (Hour, Subtask, Title, Year, Price, Reward fields).
- No fixed-height dialog should overflow on compact screens.
- RTL surfaces must preserve action placement and readable mixed Persian/Latin numbers.
- Text fields must retain readable contrast in focused/unfocused/disabled states.
