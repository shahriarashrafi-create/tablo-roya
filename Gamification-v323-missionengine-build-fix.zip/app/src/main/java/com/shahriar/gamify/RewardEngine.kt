package com.shahriar.gamify

/**
 * Pure reward redemption rules. Persistence is handled by GameStorage so the
 * coin deduction, reward state and redemption ledger can be committed together.
 */
internal enum class RewardRedemptionStatus {
    Success,
    InsufficientCoins,
    AlreadyCompleted,
    Duplicate,
    InvalidReward,
    StorageFailure
}

internal data class RewardRedemptionDecision(
    val status: RewardRedemptionStatus,
    val player: PlayerState,
    val reward: PersonalReward
)

internal object RewardEngine {

    fun normalizePositions(rewards: List<PersonalReward>): List<PersonalReward> {
        return rewards
            .sortedWith(compareBy<PersonalReward> { if (it.position > 0) it.position else Int.MAX_VALUE }.thenBy { it.id })
            .mapIndexed { index, reward -> reward.copy(position = index + 1) }
    }

    fun upsertAtPosition(rewards: List<PersonalReward>, reward: PersonalReward): List<PersonalReward> {
        val remaining = normalizePositions(rewards.filterNot { it.id == reward.id }).toMutableList()
        val targetIndex = (reward.position.coerceAtLeast(1) - 1).coerceIn(0, remaining.size)
        remaining.add(targetIndex, reward.copy(position = targetIndex + 1))
        return remaining.mapIndexed { index, item -> item.copy(position = index + 1) }
    }

    fun removeAndNormalize(rewards: List<PersonalReward>, rewardId: String): List<PersonalReward> =
        normalizePositions(rewards.filterNot { it.id == rewardId })

    fun redeem(player: PlayerState, reward: PersonalReward): RewardRedemptionDecision {
        val normalizedReward = reward.copy(
            price = reward.price.coerceAtLeast(1),
            completed = if (reward.reusable) false else reward.completed,
            redeemCount = reward.redeemCount.coerceAtLeast(0)
        )

        if (!normalizedReward.reusable && normalizedReward.completed) {
            return RewardRedemptionDecision(
                status = RewardRedemptionStatus.AlreadyCompleted,
                player = player,
                reward = normalizedReward
            )
        }

        if (player.coins < normalizedReward.price) {
            return RewardRedemptionDecision(
                status = RewardRedemptionStatus.InsufficientCoins,
                player = player,
                reward = normalizedReward
            )
        }

        val updatedPlayer = player.copy(coins = player.coins - normalizedReward.price)
        val updatedReward = normalizedReward.copy(
            completed = !normalizedReward.reusable,
            redeemCount = normalizedReward.redeemCount + 1
        )

        return RewardRedemptionDecision(
            status = RewardRedemptionStatus.Success,
            player = updatedPlayer,
            reward = updatedReward
        )
    }
}
