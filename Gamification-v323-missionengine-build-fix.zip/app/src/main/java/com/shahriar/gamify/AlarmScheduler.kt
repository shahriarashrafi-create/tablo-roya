package com.shahriar.gamify

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

internal const val TIMER_CHANNEL_ID = "mission_timer_finished"
internal const val REMINDER_CHANNEL_ID = "daily_mission_reminders"
internal const val EXTRA_TIMER_SESSION_ID = "timer_session_id"
internal const val EXTRA_REMINDER_MISSION_ID = "reminder_mission_id"
internal const val EXTRA_OPEN_MISSION_ID = "open_mission_id"
internal const val EXTRA_TIMER_RESULT_SESSION_ID = "timer_result_session_id"
internal const val ACTION_TIMER_RESULT_DONE = "com.shahriar.gamify.action.TIMER_RESULT_DONE"
internal const val ACTION_TIMER_RESULT_LATER = "com.shahriar.gamify.action.TIMER_RESULT_LATER"
internal const val ACTION_TIMER_RESULT_FAILED = "com.shahriar.gamify.action.TIMER_RESULT_FAILED"
internal const val KEY_SCHEDULED_REMINDER_IDS = "scheduled_reminder_ids"
internal const val KEY_EXTERNAL_MISSION_RESULT_REVISION = "external_mission_result_revision"
internal const val KEY_EXTERNAL_MISSION_RESULT_SESSION_ID = "external_mission_result_session_id"
internal const val KEY_EXTERNAL_MISSION_RESULT_MISSION_ID = "external_mission_result_mission_id"
internal const val KEY_EXTERNAL_MISSION_RESULT_TYPE = "external_mission_result_type"
internal const val TIMER_FINISHED_NOTIFICATION_ID = 7_142
private const val REMINDER_NOTIFICATION_BASE = 18_000

internal fun notificationsAllowed(context: Context, settings: GameSettings = loadSettings(context)): Boolean {
    if (!settings.notificationsEnabled) return false
    return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

internal fun ensureNotificationChannels(context: Context, settings: GameSettings = loadSettings(context)) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.createNotificationChannel(
        NotificationChannel(
            TIMER_CHANNEL_ID,
            "Mission timer",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifications when a mission timer finishes"
            enableVibration(settings.vibrationEnabled)
        }
    )
    manager.createNotificationChannel(
        NotificationChannel(
            REMINDER_CHANNEL_ID,
            "Mission reminders",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Daily mission reminder notifications"
            enableVibration(settings.vibrationEnabled)
        }
    )
}

/**
 * Uses an exact idle alarm when Android grants exact-alarm access, and a safe
 * idle-capable fallback otherwise. Timer state always uses the persisted wall
 * clock end timestamp, so an inexact notification cannot corrupt elapsed time.
 */
internal fun scheduleReliableAlarm(context: Context, triggerAtMillis: Long, pendingIntent: PendingIntent) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
    } else {
        try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }
}

internal fun reminderPendingIntent(context: Context, missionId: String): PendingIntent {
    val intent = Intent(context, MissionReminderReceiver::class.java).apply {
        data = Uri.parse("gamify://mission-reminder/${Uri.encode(missionId)}")
        putExtra(EXTRA_REMINDER_MISSION_ID, missionId)
    }
    return PendingIntent.getBroadcast(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

internal fun cancelMissionReminder(context: Context, missionId: String) {
    if (missionId.isBlank()) return
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(reminderPendingIntent(context, missionId))
}

internal fun nextReminderTriggerMillis(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    nowMillis: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault()
): Long? {
    if (mission.repeat != MissionRepeat.Daily) return null
    if (mission.reminderHour !in 0..23 || mission.reminderMinute !in 0..59) return null

    val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
    val reminderTime = LocalTime.of(mission.reminderHour, mission.reminderMinute)
    var date = now.toLocalDate()
    var candidate = ZonedDateTime.of(date, reminderTime, zone)

    val todayTerminal = missionCardState(mission, history, date) != MissionCardState.Active
    if (!candidate.toInstant().isAfter(now.toInstant()) || todayTerminal) {
        date = date.plusDays(1)
        candidate = ZonedDateTime.of(date, reminderTime, zone)
    }
    return candidate.toInstant().toEpochMilli()
}

internal fun scheduleMissionReminder(
    context: Context,
    mission: Mission,
    history: List<MissionHistoryEntry> = loadHistory(context),
    settings: GameSettings = loadSettings(context),
    nowMillis: Long = System.currentTimeMillis()
): Boolean {
    cancelMissionReminder(context, mission.id)
    if (!settings.notificationsEnabled || mission.id.isBlank()) return false
    val triggerAt = nextReminderTriggerMillis(mission, history, nowMillis) ?: return false
    scheduleReliableAlarm(context, triggerAt, reminderPendingIntent(context, mission.id))
    return true
}

internal fun rescheduleMissionReminders(
    context: Context,
    missions: List<Mission> = loadMissions(context),
    history: List<MissionHistoryEntry> = loadHistory(context),
    settings: GameSettings = loadSettings(context),
    nowMillis: Long = System.currentTimeMillis()
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val oldIds = prefs.getStringSet(KEY_SCHEDULED_REMINDER_IDS, emptySet()).orEmpty().toSet()
    oldIds.forEach { cancelMissionReminder(context, it) }

    if (!settings.notificationsEnabled) {
        prefs.edit().remove(KEY_SCHEDULED_REMINDER_IDS).apply()
        return
    }

    val scheduledIds = LinkedHashSet<String>()
    missions.forEach { mission ->
        if (scheduleMissionReminder(context, mission, history, settings, nowMillis)) {
            scheduledIds += mission.id
        }
    }
    prefs.edit().putStringSet(KEY_SCHEDULED_REMINDER_IDS, scheduledIds).apply()
}

internal fun synchronizeScheduledAlarms(
    context: Context,
    settings: GameSettings = loadSettings(context),
    nowMillis: Long = System.currentTimeMillis()
) {
    ensureNotificationChannels(context, settings)
    rescheduleMissionReminders(context, settings = settings, nowMillis = nowMillis)
    rescheduleTimeSheetReminders(context)

    val active = recoverActiveTimer(context, nowMillis)
    if (active == null || !active.isRunning || !settings.notificationsEnabled) {
        cancelTimerAlarm(context)
    } else {
        scheduleTimerAlarm(context, active, settings)
    }
}

internal fun timerResultPendingIntent(
    context: Context,
    sessionId: Long,
    result: MissionResult
): PendingIntent {
    val action = when (result) {
        MissionResult.Done -> ACTION_TIMER_RESULT_DONE
        MissionResult.Defer -> ACTION_TIMER_RESULT_LATER
        MissionResult.Fail -> ACTION_TIMER_RESULT_FAILED
        MissionResult.Partial -> error("Partial is not a timer notification action")
    }
    val intent = Intent(context, MissionResultReceiver::class.java).apply {
        this.action = action
        data = Uri.parse("gamify://timer-result/$sessionId/${result.name.lowercase()}")
        putExtra(EXTRA_TIMER_RESULT_SESSION_ID, sessionId)
    }
    return PendingIntent.getBroadcast(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

internal fun cancelTimerFinishedNotification(context: Context) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.cancel(TIMER_FINISHED_NOTIFICATION_ID)
}

internal data class ExternalMissionResultEvent(
    val revision: Long,
    val sessionId: Long,
    val missionId: String,
    val result: MissionResult
)

internal fun markExternalMissionResultApplied(
    context: Context,
    sessionId: Long,
    missionId: String,
    result: MissionResult
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val current = prefs.getLong(KEY_EXTERNAL_MISSION_RESULT_REVISION, 0L)
    val revision = maxOf(current + 1L, System.currentTimeMillis(), sessionId, 1L)
    prefs.edit()
        .putLong(KEY_EXTERNAL_MISSION_RESULT_REVISION, revision)
        .putLong(KEY_EXTERNAL_MISSION_RESULT_SESSION_ID, sessionId)
        .putString(KEY_EXTERNAL_MISSION_RESULT_MISSION_ID, missionId)
        .putString(KEY_EXTERNAL_MISSION_RESULT_TYPE, result.name)
        .apply()
}

internal fun externalMissionResultRevision(context: Context): Long =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getLong(KEY_EXTERNAL_MISSION_RESULT_REVISION, 0L)

internal fun externalMissionResultEvent(context: Context): ExternalMissionResultEvent? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val revision = prefs.getLong(KEY_EXTERNAL_MISSION_RESULT_REVISION, 0L)
    val sessionId = prefs.getLong(KEY_EXTERNAL_MISSION_RESULT_SESSION_ID, 0L)
    val missionId = prefs.getString(KEY_EXTERNAL_MISSION_RESULT_MISSION_ID, null).orEmpty()
    val result = prefs.getString(KEY_EXTERNAL_MISSION_RESULT_TYPE, null)
        ?.let { runCatching { MissionResult.valueOf(it) }.getOrNull() }
        ?: return null
    if (revision <= 0L || sessionId <= 0L) return null
    return ExternalMissionResultEvent(revision, sessionId, missionId, result)
}

internal fun postMissionReminderNotification(context: Context, mission: Mission) {
    val settings = loadSettings(context)
    if (!notificationsAllowed(context, settings)) return
    ensureNotificationChannels(context, settings)

    val openIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        putExtra(EXTRA_OPEN_MISSION_ID, mission.id)
    }
    val contentIntent = PendingIntent.getActivity(
        context,
        missionNotificationId(mission.id),
        openIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val detail = buildString {
        append("وقت انجام مأموریت رسیده")
        if (mission.durationMinutes > 0) append(" • ${mission.durationMinutes} min")
    }
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(context, REMINDER_CHANNEL_ID)
    } else {
        @Suppress("DEPRECATION") Notification.Builder(context)
    }
    builder
        .setSmallIcon(R.drawable.ic_timer)
        .setContentTitle(mission.title)
        .setContentText(detail)
        .setContentIntent(contentIntent)
        .setAutoCancel(true)
        .setCategory(Notification.CATEGORY_REMINDER)
        .setPriority(Notification.PRIORITY_DEFAULT)

    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.notify(missionNotificationId(mission.id), builder.build())
}

private fun missionNotificationId(missionId: String): Int =
    REMINDER_NOTIFICATION_BASE + (missionId.hashCode() and 0x1FFF)
