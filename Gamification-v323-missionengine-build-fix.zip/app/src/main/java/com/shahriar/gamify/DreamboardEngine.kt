package com.shahriar.gamify

import java.util.UUID

/**
 * Pure ordering/normalization rules for Dreamboard.
 *
 * The UI never mutates list positions directly. Every insert/update/delete goes
 * through this engine so persisted order and carousel order stay identical.
 */
internal object DreamboardEngine {
    fun newId(): String = "dream_${UUID.randomUUID()}"

    fun normalize(items: List<DreamItem>): List<DreamItem> {
        val usedIds = mutableSetOf<String>()
        return items
            .sortedBy { it.position }
            .mapIndexed { index, item ->
                val baseId = item.id.trim().ifBlank { "dream_$index" }
                var stableId = baseId
                var suffix = 1
                while (!usedIds.add(stableId)) {
                    stableId = "${baseId}_$suffix"
                    suffix++
                }
                item.copy(
                    id = stableId,
                    title = item.title.trim().take(80),
                    year = item.year.filter(Char::isDigit).take(4),
                    price = item.price.filter(Char::isDigit).take(15),
                    imageUri = item.imageUri.trim(),
                    position = index
                )
            }
    }

    fun insert(items: List<DreamItem>, item: DreamItem): List<DreamItem> {
        val normalized = normalize(items).filterNot { it.id == item.id }.toMutableList()
        val target = item.position.coerceIn(0, normalized.size)
        normalized.add(target, item.copy(position = target))
        return normalize(normalized)
    }

    fun update(items: List<DreamItem>, item: DreamItem): List<DreamItem> {
        val normalized = normalize(items)
        if (normalized.none { it.id == item.id }) return normalized
        val without = normalized.filterNot { it.id == item.id }.toMutableList()
        val target = item.position.coerceIn(0, without.size)
        without.add(target, item.copy(position = target))
        return normalize(without)
    }

    fun remove(items: List<DreamItem>, id: String): List<DreamItem> =
        normalize(items.filterNot { it.id == id })
}

/** Stage 130: one canonical projection for Dreamboard × Gamification state. */
internal data class DreamProgressSnapshot(
    val completedRuns: Int,
    val earnedXp: Int,
    val targetRuns: Int,
    val percent: Int,
    val progress: Float,
    val completed: Boolean,
    val achieved: Boolean
)

internal fun DreamItem.progressSnapshot(history: List<MissionHistoryEntry>): DreamProgressSnapshot {
    val linked = linkedMissionId.takeIf { it.isNotBlank() }
    val entries = if (linked == null) emptyList() else history.filter { it.missionId == linked }
    val completedRuns = entries.count { it.result == MissionResult.Done }
    val earnedXp = entries.sumOf { it.xpEarned }
    val targetRuns = missionCompletionTarget.coerceAtLeast(0)
    val percent = if (targetRuns > 0) completedRuns * 100 / targetRuns else 0
    val progress = if (targetRuns > 0) (completedRuns.toFloat() / targetRuns).coerceIn(0f, 1f) else 0f
    val completed = targetRuns > 0 && completedRuns >= targetRuns
    return DreamProgressSnapshot(
        completedRuns = completedRuns,
        earnedXp = earnedXp,
        targetRuns = targetRuns,
        percent = percent,
        progress = progress,
        completed = completed,
        achieved = completed && goalRewardClaimed
    )
}

internal fun dreamMilestoneCounts(): List<Int> = listOf(1, 3, 5, 10)
