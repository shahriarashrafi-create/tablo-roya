package com.shahriar.gamify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate

class MissionReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val missionId = intent?.getStringExtra(EXTRA_REMINDER_MISSION_ID).orEmpty()
        if (missionId.isBlank()) return

        val settings = loadSettings(context)
        if (!settings.notificationsEnabled) {
            cancelMissionReminder(context, missionId)
            return
        }

        performDailyResetIfNeeded(context)
        val mission = loadMissions(context).firstOrNull { it.id == missionId }
        if (mission == null || mission.repeat != MissionRepeat.Daily ||
            mission.reminderHour !in 0..23 || mission.reminderMinute !in 0..59
        ) {
            cancelMissionReminder(context, missionId)
            return
        }

        val history = loadHistory(context)
        val today = LocalDate.now()
        if (isMissionScheduledToday(mission, today) && missionCardState(mission, history, today) == MissionCardState.Active) {
            postMissionReminderNotification(context, mission)
        }

        // One-shot alarms avoid timezone/DST drift. Always calculate tomorrow
        // from the current system timezone after this occurrence fires.
        scheduleMissionReminder(context, mission, history, settings, System.currentTimeMillis() + 1_000L)
    }
}
