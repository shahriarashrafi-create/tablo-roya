package com.shahriar.gamify

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class GamifyWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, appWidgetManager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, GamifyWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences("gamify_state_v1", Context.MODE_PRIVATE)
            val level = prefs.getInt("player_level", 1)
            val rank = prefs.getInt("player_rank", 1)
            val coins = prefs.getInt("player_coins", 0)
            val combo = prefs.getInt("player_combo", 0)
            val name = prefs.getString("onboarding_name", "Player") ?: "Player"

            val views = RemoteViews(context.packageName, R.layout.widget_gamify)
            views.setTextViewText(R.id.widget_title, "$name • GAMIFICATION")
            views.setTextViewText(R.id.widget_level, "LV $level")
            views.setTextViewText(R.id.widget_rank, "RANK $rank")
            views.setTextViewText(R.id.widget_coins, "◉ $coins")
            views.setTextViewText(R.id.widget_combo, "COMBO $combo")

            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context,
                9021,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(appWidgetId, views)
        }
    }
}
