package com.shahriar.gamify

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Stage 53 — one lightweight coded backdrop for every internal game module. */
@Composable
internal fun InternalGameBackdrop(modifier: Modifier = Modifier, strength: Float = 1f) {
    val s = strength.coerceIn(0.35f, 1f)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF132132), Color(0xFF101B28), Color(0xFF09121B))
                )
            )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cell = 76.dp.toPx()
            var y = -cell
            var row = 0
            while (y < size.height + cell) {
                var x = -cell
                var col = 0
                while (x < size.width + cell) {
                    if ((row + col) % 2 == 0) {
                        drawCircle(
                            Color(0x12E5C87A).copy(alpha = 0.07f * s),
                            radius = 22.dp.toPx(),
                            center = Offset(x + cell / 2f, y + cell / 2f)
                        )
                    } else {
                        drawRoundRect(
                            Color(0x127EA6C9).copy(alpha = 0.065f * s),
                            topLeft = Offset(x + 19.dp.toPx(), y + 19.dp.toPx()),
                            size = Size(38.dp.toPx(), 38.dp.toPx()),
                            cornerRadius = CornerRadius(11.dp.toPx())
                        )
                    }
                    x += cell
                    col++
                }
                y += cell
                row++
            }
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0x1AF7C948), Color.Transparent)),
                radius = size.minDimension * 0.72f,
                center = Offset(size.width * 0.84f, size.height * 0.10f)
            )
        }
    }
}
