package com.shahriar.gamify

import java.time.LocalDate

/** Shared Jalali date utilities for the redesigned network experience. */
internal data class PersianDate(val year: Int, val month: Int, val day: Int)

internal val PERSIAN_MONTH_NAMES = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

internal fun gregorianToPersian(date: LocalDate): PersianDate {
    val gy = date.year
    val gm = date.monthValue
    val gd = date.dayOfMonth
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    var jy = if (gy > 1600) 979 else 0
    val gy2 = gy - if (gy > 1600) 1600 else 621
    val gyForLeap = if (gm > 2) gy2 + 1 else gy2
    var days = 365 * gy2 + (gyForLeap + 3) / 4 - (gyForLeap + 99) / 100 +
        (gyForLeap + 399) / 400 - 80 + gd + gdm[gm - 1]
    jy += 33 * (days / 12053)
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) {
        jm = 1 + days / 31
        jd = 1 + days % 31
    } else {
        jm = 7 + (days - 186) / 30
        jd = 1 + (days - 186) % 30
    }
    return PersianDate(jy, jm, jd)
}

internal fun toPersianDigits(value: String): String = buildString(value.length) {
    value.forEach { ch -> append(if (ch in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[ch - '0'] else ch) }
}

internal fun formatPersianDate(date: LocalDate, includeYear: Boolean = true): String {
    val p = gregorianToPersian(date)
    val base = "${toPersianDigits(p.day.toString())} ${PERSIAN_MONTH_NAMES[p.month - 1]}"
    return if (includeYear) "$base ${toPersianDigits(p.year.toString())}" else base
}
