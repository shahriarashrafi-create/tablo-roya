package com.shahriar.gamify

import android.content.Context
import java.time.LocalDate
import java.util.UUID

/**
 * Canonical mission state/order rules.
 *
 * The persisted mission-list order is the base order selected by the user.
 * Daily status never mutates that base order. Instead, this engine derives the
 * visible order for the current day: Active -> Done -> Failed, while a Later
 * action keeps a mission Active and moves it behind the other active missions
 * for that day only.
 */
internal enum class MissionDayState { Active, Later, Done, Failed }

internal fun newMissionId(): String = UUID.randomUUID().toString()

internal fun legacyMissionId(index: Int, title: String, durationMinutes: Int): String {
    val fingerprint = "$index|${title.trim()}|$durationMinutes".hashCode().toUInt().toString(16)
    return "legacy_${index}_$fingerprint"
}

internal fun normalizeMissionIdentities(missions: List<Mission>): List<Mission> {
    val used = mutableSetOf<String>()
    return missions.mapIndexed { index, mission ->
        var candidate = mission.id.trim()
        if (candidate.isBlank() || candidate in used) {
            candidate = if (mission.id.isBlank()) {
                legacyMissionId(index, mission.title, mission.durationMinutes)
            } else {
                newMissionId()
            }
        }
        used += candidate
        mission.copy(id = candidate)
    }
}
internal fun MissionHistoryEntry.matchesMission(mission: Mission): Boolean =
    if (mission.id.isNotBlank() && missionId.isNotBlank()) missionId == mission.id else missionTitle == mission.title

internal fun latestTerminalMissionEntry(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): MissionHistoryEntry? {
    val matching = history.asSequence().filter { it.matchesMission(mission) }
    val relevant = if (mission.repeat == MissionRepeat.Daily) {
        matching.filter { it.localDate() == date }
    } else {
        matching
    }
    return relevant
        .filter { it.result != MissionResult.Defer }
        .maxByOrNull { it.timestamp }
}

internal fun missionDayState(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): MissionDayState {
    val terminal = latestTerminalMissionEntry(mission, history, date)

    if (terminal != null) {
        return if (terminal.result == MissionResult.Done) MissionDayState.Done else MissionDayState.Failed
    }

    val deferredToday = history.asSequence()
        .filter { it.matchesMission(mission) && it.result == MissionResult.Defer && it.localDate() == date }
        .maxByOrNull { it.timestamp }

    return if (deferredToday != null) MissionDayState.Later else MissionDayState.Active
}


// Stage 42: context-aware mission-day helpers honor the configured day-start time.
internal fun latestTerminalMissionEntryForCurrentDay(
    context: Context, mission: Mission, history: List<MissionHistoryEntry>
): MissionHistoryEntry? {
    val day = currentMissionDay(context)
    val matching = history.asSequence().filter { it.matchesMission(mission) }
    val relevant = if (mission.repeat == MissionRepeat.Daily) matching.filter { it.missionDay(context) == day } else matching
    return relevant.filter { it.result != MissionResult.Defer }.maxByOrNull { it.timestamp }
}

internal fun missionDayStateForCurrentDay(context: Context, mission: Mission, history: List<MissionHistoryEntry>): MissionDayState {
    val terminal = latestTerminalMissionEntryForCurrentDay(context, mission, history)
    if (terminal != null) return if (terminal.result == MissionResult.Done) MissionDayState.Done else MissionDayState.Failed
    if (mission.repeat == MissionRepeat.None && history.any { it.matchesMission(mission) && it.result != MissionResult.Defer }) {
        val last = history.filter { it.matchesMission(mission) && it.result != MissionResult.Defer }.maxByOrNull { it.timestamp }
        return if (last?.result == MissionResult.Done) MissionDayState.Done else MissionDayState.Failed
    }
    val deferred = history.any { it.matchesMission(mission) && it.result == MissionResult.Defer && it.missionDay(context) == currentMissionDay(context) }
    return if (deferred) MissionDayState.Later else MissionDayState.Active
}

internal enum class MissionCardState { Active, Done, Failed }

internal fun missionCardState(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): MissionCardState = when (missionDayState(mission, history, date)) {
    MissionDayState.Active, MissionDayState.Later -> MissionCardState.Active
    MissionDayState.Done -> MissionCardState.Done
    MissionDayState.Failed -> MissionCardState.Failed
}
internal fun orderedMissionsForCurrentDay(
    context: Context,
    missions: List<Mission>,
    history: List<MissionHistoryEntry>,
    activeTimer: ActiveTimerState? = null
): List<Pair<Int, Mission>> {
    fun sameMission(a: Mission, b: Mission): Boolean =
        if (a.id.isNotBlank() && b.id.isNotBlank()) a.id == b.id else a.title == b.title

    fun latestDefer(mission: Mission): Long? = history.asSequence()
        .filter { it.matchesMission(mission) && it.result == MissionResult.Defer && it.missionDay(context) == currentMissionDay(context) }
        .maxOfOrNull { it.timestamp }

    fun terminal(mission: Mission): MissionHistoryEntry? = latestTerminalMissionEntryForCurrentDay(context, mission, history)

    return missions.mapIndexed { index, mission -> index to mission }
        .sortedWith(Comparator { a, b ->
            val aRunning = activeTimer?.mission?.let { sameMission(a.second, it) } == true
            val bRunning = activeTimer?.mission?.let { sameMission(b.second, it) } == true
            if (aRunning != bRunning) return@Comparator if (aRunning) -1 else 1

            val sa = missionDayStateForCurrentDay(context, a.second, history)
            val sb = missionDayStateForCurrentDay(context, b.second, history)
            fun group(s: MissionDayState) = when (s) {
                MissionDayState.Active -> 0
                MissionDayState.Later -> 1
                MissionDayState.Done, MissionDayState.Failed -> 2
            }
            val gd = group(sa) - group(sb)
            if (gd != 0) return@Comparator gd

            when (group(sa)) {
                1 -> {
                    val cmp = (latestDefer(a.second) ?: Long.MIN_VALUE).compareTo(latestDefer(b.second) ?: Long.MIN_VALUE)
                    if (cmp != 0) return@Comparator cmp
                }
                2 -> {
                    val cmp = (terminal(a.second)?.timestamp ?: Long.MAX_VALUE).compareTo(terminal(b.second)?.timestamp ?: Long.MAX_VALUE)
                    if (cmp != 0) return@Comparator cmp
                }
            }
            a.first.compareTo(b.first)
        })
}
