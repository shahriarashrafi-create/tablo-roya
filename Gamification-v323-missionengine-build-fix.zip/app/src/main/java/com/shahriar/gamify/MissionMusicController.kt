package com.shahriar.gamify

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * v300: three verified public-domain/CC0 Beethoven focus recordings.
 * One track is selected per mission session and loops until the mission resolves.
 * Sources: Wikimedia Commons (Moonlight Sonata, Fur Elise, Pathetique II).
 */
internal object MissionMusicController {
    private var player: MediaPlayer? = null
    private var playingSessionId: Long = 0L
    private var mutedSessionId: Long = 0L
    private var playingTrackIndex: Int = -1

    private val focusTracks = arrayOf(
        "https://upload.wikimedia.org/wikipedia/commons/d/d0/Moonlight_Sonata.ogg",
        "https://upload.wikimedia.org/wikipedia/commons/7/7b/FurElise.ogg",
        "https://upload.wikimedia.org/wikipedia/commons/6/63/Beethoven%2C_Sonata_No._8_in_C_Minor_Pathetique%2C_Op._13_-_II._Adagio_cantabile.ogg"
    )

    private fun trackIndexFor(sessionId: Long): Int {
        val mixed = sessionId xor (sessionId ushr 32) xor System.nanoTime()
        return ((mixed and Long.MAX_VALUE) % focusTracks.size).toInt()
    }

    @Synchronized
    fun ensureForTimer(context: Context, settings: GameSettings, state: ActiveTimerState?) {
        if (!settings.soundEnabled || state == null || !state.isRunning || remainingSeconds(context, state) <= 0) {
            stopPlayback(); return
        }
        if (mutedSessionId != 0L && mutedSessionId != state.sessionId) mutedSessionId = 0L
        if (mutedSessionId == state.sessionId) { stopPlayback(); return }
        if (playingSessionId == state.sessionId && player != null) return

        stopPlayback()
        val trackIndex = trackIndexFor(state.sessionId)
        val mediaPlayer = MediaPlayer()
        try {
            mediaPlayer.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            mediaPlayer.setDataSource(focusTracks[trackIndex])
            mediaPlayer.isLooping = true
            mediaPlayer.setVolume(0.42f, 0.42f)
            mediaPlayer.setOnPreparedListener { mp ->
                synchronized(this) {
                    if (player === mp && playingSessionId == state.sessionId && mutedSessionId != state.sessionId) {
                        runCatching { mp.start() }
                    }
                }
            }
            mediaPlayer.setOnErrorListener { mp, _, _ ->
                runCatching { mp.release() }
                synchronized(this) {
                    if (player === mp) { player = null; playingSessionId = 0L; playingTrackIndex = -1 }
                }
                true
            }
            player = mediaPlayer
            playingSessionId = state.sessionId
            playingTrackIndex = trackIndex
            mediaPlayer.prepareAsync()
        } catch (_: Exception) {
            runCatching { mediaPlayer.release() }
            player = null; playingSessionId = 0L; playingTrackIndex = -1
        }
    }

    @Synchronized fun isMuted(sessionId: Long): Boolean = mutedSessionId == sessionId
    @Synchronized fun setMuted(context: Context, settings: GameSettings, state: ActiveTimerState, muted: Boolean) {
        mutedSessionId = if (muted) state.sessionId else 0L
        if (muted) stopPlayback() else ensureForTimer(context, settings, state)
    }
    @Synchronized fun stop() { stopPlayback(); mutedSessionId = 0L }
    private fun stopPlayback() {
        val current = player
        player = null; playingSessionId = 0L; playingTrackIndex = -1
        if (current != null) { runCatching { if (current.isPlaying) current.stop() }; runCatching { current.release() } }
    }
}
