package com.shahriar.gamify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> restoreSchedules(context)
        }
    }

    private fun restoreSchedules(context: Context) {
        migrateState(context)
        performDailyResetIfNeeded(context)

        val beforeRecovery = loadActiveTimer(context)
        val now = System.currentTimeMillis()
        val recovered = recoverActiveTimer(context, now)
        if (beforeRecovery?.isRunning == true && recovered != null && !recovered.isRunning && recovered.remainingSeconds <= 0) {
            // Covers reboot/device-off expiry and forward wall-clock jumps. On
            // the same boot, recoverActiveTimer uses elapsedRealtime first, so
            // manually changing the clock cannot prematurely finish a timer.
            TimerFinishReceiver.finishTimer(context, recovered.sessionId, notify = true)
        }
        synchronizeScheduledAlarms(context, loadSettings(context), now)
        restoreTreeStatsReminder(context, now)
    }
}
