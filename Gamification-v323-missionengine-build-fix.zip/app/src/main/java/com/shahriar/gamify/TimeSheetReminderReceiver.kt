package com.shahriar.gamify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

private const val TIMESHEET_CHANNEL_ID = "timesheet_reminders"
private const val TIMESHEET_NOTIFICATION_BASE = 27_000

class TimeSheetReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val title = intent?.getStringExtra(EXTRA_TIMESHEET_REMINDER_TITLE).orEmpty().ifBlank { "برنامه تایم‌شیت" }
        val time = intent?.getStringExtra(EXTRA_TIMESHEET_REMINDER_TIME).orEmpty()
        postTimeSheetReminder(context, title, time)
    }
}

private fun postTimeSheetReminder(context: Context, title: String, time: String) {
    val settings = loadSettings(context)
    if (!notificationsAllowed(context, settings)) return

    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        manager.createNotificationChannel(
            NotificationChannel(
                TIMESHEET_CHANNEL_ID,
                "TimeSheet reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders five minutes before TimeSheet plans"
                enableVibration(settings.vibrationEnabled)
            }
        )
    }

    val openIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val contentIntent = PendingIntent.getActivity(
        context,
        title.hashCode(),
        openIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val detail = if (time.isBlank()) "۵ دقیقه تا شروع برنامه" else "۵ دقیقه تا شروع • $time"
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(context, TIMESHEET_CHANNEL_ID)
    } else {
        @Suppress("DEPRECATION")
        Notification.Builder(context)
    }
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setContentText(detail)
        .setAutoCancel(true)
        .setContentIntent(contentIntent)

    manager.notify(TIMESHEET_NOTIFICATION_BASE + kotlin.math.abs((title + time).hashCode() % 10000), builder.build())
}
