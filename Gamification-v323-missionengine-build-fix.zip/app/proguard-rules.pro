# Gamification release rules.
# Compose/AndroidX consumer rules are bundled with their libraries.
-keepattributes *Annotation*
