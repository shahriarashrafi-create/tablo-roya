pluginManagement {
    repositories {
        google()
        // v304: Google-hosted Maven Central mirror avoids intermittent Maven Central 403s in GitHub Actions.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // v304: prefer a second Maven Central endpoint before the canonical host.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
    }
}
rootProject.name = "Gamification"
include(":app")
