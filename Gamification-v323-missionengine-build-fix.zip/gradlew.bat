@echo off
setlocal
set VERSION=8.9
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set CACHE_ROOT=%GRADLE_USER_HOME%\gamification-wrapper
set DIST_DIR=%CACHE_ROOT%\gradle-%VERSION%
set ZIP_FILE=%CACHE_ROOT%\gradle-%VERSION%-bin.zip
set GRADLE_BIN=%DIST_DIR%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "if (!(Test-Path '%ZIP_FILE%')) { Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP_FILE%' }; if (Test-Path '%DIST_DIR%') { Remove-Item -Recurse -Force '%DIST_DIR%' }; New-Item -ItemType Directory -Force '%DIST_DIR%' | Out-Null; Expand-Archive -Force '%ZIP_FILE%' '%DIST_DIR%'"
)
call "%GRADLE_BIN%" -p "%~dp0" %*
endlocal
