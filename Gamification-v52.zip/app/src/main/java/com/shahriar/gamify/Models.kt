package com.shahriar.gamify

import androidx.compose.ui.graphics.Color

/**
 * Core application models.
 *
 * Kept separate from Compose UI so mission/progression/storage code can evolve
 * without turning MainActivity into the application data layer.
 */
data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val rankProgress: Int = 0,
    val coins: Int = 1320,
    val combo: Int = 12,
    val bestCombo: Int = 12,
    val chests: Int = 0,
    val loginStreak: Int = 0,
    val bestLoginStreak: Int = 0
)

enum class MissionRepeat { None, Daily }

data class Mission(
    val title: String,
    val durationMinutes: Int,
    val xpReward: Int,
    val coinReward: Int,
    val isRankMission: Boolean = false,
    val repeat: MissionRepeat = MissionRepeat.None,
    val reminderHour: Int = -1,
    val reminderMinute: Int = -1,
    val subtasks: List<String> = emptyList()
)

internal enum class AppScreen { Home, Mission }
enum class MissionResult { Done, Partial, Fail, Defer }

data class MissionHistoryEntry(
    val timestamp: Long,
    val missionTitle: String,
    val plannedMinutes: Int,
    val focusSeconds: Int,
    val result: MissionResult,
    val xpEarned: Int,
    val coinsEarned: Int,
    val levelRewardCoins: Int
)

data class MissionOutcome(
    val player: PlayerState,
    val xpGain: Int,
    val missionCoinGain: Int,
    val levelsGained: Int,
    val levelRewardCoins: Int,
    val comboBefore: Int,
    val comboAfter: Int,
    val rewardMultiplier: Float,
    val ranksGained: Int,
    val chestsEarned: Int
)

data class RankUpEvent(
    val fromRank: Int,
    val toRank: Int,
    val chestsEarned: Int
)

internal data class Challenge(
    val claimKey: String,
    val title: String,
    val subtitle: String,
    val progress: Int,
    val goal: Int,
    val xpReward: Int,
    val coinReward: Int,
    val weekly: Boolean
)

internal data class Achievement(
    val id: String,
    val title: String,
    val subtitle: String,
    val glyph: String,
    val progress: Int,
    val goal: Int,
    val xpReward: Int,
    val coinReward: Int
)

internal data class ShopReward(
    val id: String,
    val title: String,
    val subtitle: String,
    val price: Int
)

internal data class PersonalReward(
    val id: String,
    val title: String,
    val price: Int,
    val reusable: Boolean = false,
    val completed: Boolean = false,
    val redeemCount: Int = 0
)

internal data class DreamItem(
    val id: String,
    val title: String,
    val year: String,
    val price: String,
    val imageUri: String = "",
    val position: Int = 0
)

internal data class ProfileLoadout(
    val avatar: String = "crown",
    val title: String = "Pathfinder",
    val frame: String = "default",
    val badge: String = "none"
)

internal data class WorldRegion(
    val name: String,
    val subtitle: String,
    val minLevel: Int,
    val tint: Color
)

internal data class MissionTemplate(
    val id: String,
    val title: String,
    val subtitle: String,
    val mission: Mission
)

internal data class GameNotification(
    val id: String,
    val glyph: String,
    val title: String,
    val body: String,
    val timestamp: Long,
    val read: Boolean = false
)

internal data class OnboardingProfile(
    val name: String = "Player",
    val activeStart: String = "07:00",
    val activeEnd: String = "23:00"
)

internal data class DailyLoginEvent(
    val streak: Int,
    val coinReward: Int,
    val milestone: String?,
    val player: PlayerState
)

data class LevelUpEvent(
    val fromLevel: Int,
    val toLevel: Int,
    val rewardCoins: Int
)

internal enum class AppThemeMode { Classic, Midnight, Obsidian }

internal data class GameSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val reducedMotion: Boolean = false,
    val comboBoostEnabled: Boolean = true,
    val themeMode: AppThemeMode = AppThemeMode.Midnight
)

internal data class ActiveTimerState(
    val mission: Mission,
    val remainingSeconds: Int,
    val endAtMillis: Long,
    val isRunning: Boolean,
    val sessionId: Long,
    val checkedSubtasks: List<Boolean> = List(mission.subtasks.size) { false }
)

internal data class RewardBurst(
    val result: MissionResult,
    val xp: Int,
    val coins: Int,
    val combo: Int
)

internal data class MissionCompletionAnimation(
    val mission: Mission,
    val fromPlayer: PlayerState,
    val toPlayer: PlayerState,
    val xpGain: Int,
    val coinGain: Int,
    val levelUp: LevelUpEvent?,
    val rankUp: RankUpEvent?
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val ringColors: List<Color>
)
