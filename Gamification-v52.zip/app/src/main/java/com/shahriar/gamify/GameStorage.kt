package com.shahriar.gamify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.CalendarContract
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Persistence, migrations, timer state, and non-UI game core helpers.
 *
 * Step 1-A intentionally keeps behavior unchanged while removing SharedPreferences,
 * backup/migration, timer persistence and mission result logic from MainActivity.
 */
internal const val PREFS_NAME = "gamify_state_v1"
internal const val KEY_MISSIONS = "missions"
internal const val KEY_HISTORY = "mission_history"
internal const val KEY_PLAYER_LEVEL = "player_level"
internal const val KEY_PLAYER_XP = "player_xp"
internal const val KEY_PLAYER_NEXT_XP = "player_next_xp"
internal const val KEY_PLAYER_RANK = "player_rank"
internal const val KEY_PLAYER_RANK_PROGRESS = "player_rank_progress"
internal const val KEY_PLAYER_CHESTS = "player_chests"
internal const val KEY_PLAYER_COINS = "player_coins"
internal const val KEY_PLAYER_COMBO = "player_combo"
internal const val KEY_PLAYER_BEST_COMBO = "player_best_combo"
internal const val KEY_PLAYER_LOGIN_STREAK = "player_login_streak"
internal const val KEY_PLAYER_BEST_LOGIN_STREAK = "player_best_login_streak"
internal const val KEY_LAST_LOGIN_DATE = "last_login_date"
internal const val KEY_NOTIFICATIONS_CENTER = "notification_center"
internal const val KEY_SETTINGS_SOUND = "settings_sound"
internal const val KEY_SETTINGS_VIBRATION = "settings_vibration"
internal const val KEY_SETTINGS_NOTIFICATIONS = "settings_notifications"
internal const val KEY_SETTINGS_REDUCED_MOTION = "settings_reduced_motion"
internal const val KEY_SETTINGS_COMBO_BOOST = "settings_combo_boost"
internal const val KEY_SETTINGS_THEME = "settings_theme"
internal const val KEY_TIMER_ACTIVE = "timer_active"
internal const val KEY_TIMER_TITLE = "timer_title"
internal const val KEY_TIMER_DURATION = "timer_duration"
internal const val KEY_TIMER_XP = "timer_xp"
internal const val KEY_TIMER_COINS = "timer_coins"
internal const val KEY_TIMER_RANK = "timer_rank"
internal const val KEY_TIMER_REPEAT = "timer_repeat"
internal const val KEY_TIMER_REMINDER_HOUR = "timer_reminder_hour"
internal const val KEY_TIMER_REMINDER_MINUTE = "timer_reminder_minute"
internal const val KEY_TIMER_SUBTASKS = "timer_subtasks"
internal const val KEY_TIMER_SUBTASK_CHECKS = "timer_subtask_checks"
internal const val KEY_SUBTASK_PROGRESS = "mission_subtask_progress"
internal const val KEY_LAST_DAILY_RESET_DATE = "last_daily_reset_date"
internal const val KEY_OWNED_REWARDS = "owned_rewards"
internal const val KEY_PERSONAL_REWARDS = "personal_rewards"
internal const val KEY_DREAMBOARD_ITEMS = "dreamboard_items"
internal const val KEY_PROFILE_AVATAR = "profile_avatar"
internal const val KEY_PROFILE_TITLE = "profile_title"
internal const val KEY_PROFILE_FRAME = "profile_frame"
internal const val KEY_PROFILE_BADGE = "profile_badge"
internal const val KEY_CHALLENGE_CLAIMS = "challenge_claims"
internal const val KEY_ACHIEVEMENT_CLAIMS = "achievement_claims"
internal const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
internal const val KEY_ONBOARDING_NAME = "onboarding_name"
internal const val KEY_ONBOARDING_ACTIVE_START = "onboarding_active_start"
internal const val KEY_ONBOARDING_ACTIVE_END = "onboarding_active_end"
internal const val KEY_SCHEMA_VERSION = "schema_version"
internal const val KEY_TIMER_SESSION = "timer_session"
internal const val KEY_LAST_COMPLETED_SESSION = "last_completed_session"
internal const val CURRENT_SCHEMA_VERSION = 11
internal const val KEY_TIMER_REMAINING = "timer_remaining"
internal const val KEY_TIMER_END_AT = "timer_end_at"
internal const val KEY_TIMER_RUNNING = "timer_running"
internal const val LEVEL_UP_COIN_REWARD = 100
internal const val TIMER_REQUEST_CODE = 7142

private val RETIRED_PREF_KEYS = setOf(
    "onboarding_goal",
    "timer_deadline_hour",
    "timer_deadline_minute",
    "timer_notes"
)

private fun isBackupEligibleKey(key: String): Boolean =
    !key.startsWith("timer_") && key !in RETIRED_PREF_KEYS

internal fun defaultMission(): Mission = Mission(
    title = "۴۵ دقیقه تمرکز",
    durationMinutes = 45,
    xpReward = 50,
    coinReward = 20
)

internal fun isOnboardingComplete(context: Context): Boolean =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_ONBOARDING_COMPLETE, false)

internal fun loadOnboardingProfile(context: Context): OnboardingProfile {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return OnboardingProfile(
        name = prefs.getString(KEY_ONBOARDING_NAME, "Player") ?: "Player",
        activeStart = prefs.getString(KEY_ONBOARDING_ACTIVE_START, "07:00") ?: "07:00",
        activeEnd = prefs.getString(KEY_ONBOARDING_ACTIVE_END, "23:00") ?: "23:00"
    )
}

internal fun saveOnboardingProfile(context: Context, profile: OnboardingProfile) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_ONBOARDING_NAME, profile.name.trim().ifBlank { "Player" }.take(40))
        .putString(KEY_ONBOARDING_ACTIVE_START, profile.activeStart.take(5))
        .putString(KEY_ONBOARDING_ACTIVE_END, profile.activeEnd.take(5))
        .putBoolean(KEY_ONBOARDING_COMPLETE, true)
        .apply()
}

internal fun personalLeague(history: List<MissionHistoryEntry>): String {
    val today = LocalDate.now()
    val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val done = history.count { it.result == MissionResult.Done && !it.localDate().isBefore(weekStart) && !it.localDate().isAfter(today) }
    return when {
        done >= 20 -> "Mythic"
        done >= 14 -> "Diamond"
        done >= 9 -> "Gold"
        done >= 5 -> "Silver"
        else -> "Bronze"
    }
}

internal fun addMissionToCalendar(context: Context, mission: Mission): Boolean = runCatching {
    val start = System.currentTimeMillis() + 5 * 60 * 1000L
    val end = start + mission.durationMinutes.coerceAtLeast(1) * 60_000L
    val intent = Intent(Intent.ACTION_INSERT).apply {
        data = CalendarContract.Events.CONTENT_URI
        putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
        putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
        putExtra(CalendarContract.Events.TITLE, mission.title)
        putExtra(CalendarContract.Events.DESCRIPTION, "Gamification mission • +${mission.xpReward} XP • +${mission.coinReward} Coins")
    }
    context.startActivity(intent)
}.isSuccess

internal fun runDataHealthCheck(context: Context): String {
    val now = System.currentTimeMillis()
    val missions = loadMissions(context).map { mission ->
        mission.copy(
            title = mission.title.trim().ifBlank { "Mission" }.take(80),
            durationMinutes = mission.durationMinutes.coerceIn(1, 720),
            xpReward = mission.xpReward.coerceIn(0, 100_000),
            coinReward = mission.coinReward.coerceIn(0, 100_000)
        )
    }.ifEmpty { listOf(defaultMission()) }.take(100)
    val history = loadHistory(context)
        .filter { it.timestamp in 1..(now + 86_400_000L) }
        .map { it.copy(
            missionTitle = it.missionTitle.take(80),
            plannedMinutes = it.plannedMinutes.coerceIn(0, 1440),
            focusSeconds = it.focusSeconds.coerceIn(0, 86_400)
        ) }
        .distinctBy { "${it.timestamp}|${it.missionTitle}|${it.result}" }
        .take(500)
    val notifications = loadNotifications(context).distinctBy { it.id }.take(100)
    saveMissions(context, missions)
    saveHistory(context, history)
    saveNotifications(context, notifications)
    savePlayer(context, loadPlayer(context))
    saveSettings(context, loadSettings(context))
    savePersonalRewards(context, loadPersonalRewards(context))
    saveDreamItems(context, loadDreamItems(context))
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION).apply()
    GamifyWidgetProvider.updateAll(context)
    return "Healthy • ${missions.size} missions • ${history.size} history entries"
}

internal fun loadSettings(context: Context): GameSettings {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val theme = runCatching {
        AppThemeMode.valueOf(prefs.getString(KEY_SETTINGS_THEME, AppThemeMode.Midnight.name) ?: AppThemeMode.Midnight.name)
    }.getOrDefault(AppThemeMode.Midnight)
    return GameSettings(
        soundEnabled = prefs.getBoolean(KEY_SETTINGS_SOUND, true),
        vibrationEnabled = prefs.getBoolean(KEY_SETTINGS_VIBRATION, true),
        notificationsEnabled = prefs.getBoolean(KEY_SETTINGS_NOTIFICATIONS, true),
        reducedMotion = prefs.getBoolean(KEY_SETTINGS_REDUCED_MOTION, false),
        comboBoostEnabled = prefs.getBoolean(KEY_SETTINGS_COMBO_BOOST, true),
        themeMode = theme
    )
}

internal fun saveSettings(context: Context, settings: GameSettings) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_SETTINGS_SOUND, settings.soundEnabled)
        .putBoolean(KEY_SETTINGS_VIBRATION, settings.vibrationEnabled)
        .putBoolean(KEY_SETTINGS_NOTIFICATIONS, settings.notificationsEnabled)
        .putBoolean(KEY_SETTINGS_REDUCED_MOTION, settings.reducedMotion)
        .putBoolean(KEY_SETTINGS_COMBO_BOOST, settings.comboBoostEnabled)
        .putString(KEY_SETTINGS_THEME, settings.themeMode.name)
        .apply()
}

internal fun themeOverlay(mode: AppThemeMode): Color = when (mode) {
    AppThemeMode.Classic -> Color.Transparent
    AppThemeMode.Midnight -> Color(0x24112B4A)
    AppThemeMode.Obsidian -> Color(0x42000000)
}

internal fun comboMultiplier(combo: Int): Float = when {
    combo >= 20 -> 2.0f
    combo >= 10 -> 1.5f
    combo >= 5 -> 1.25f
    combo >= 3 -> 1.10f
    else -> 1.0f
}

internal fun rankRequirement(rank: Int): Int = if (rank >= 10) 10 else rank.coerceAtLeast(1)

internal val worldRegions = listOf(
    WorldRegion("Dawnfield", "Begin the journey", 1, Color(0x00FFFFFF)),
    WorldRegion("Ember Vale", "Build relentless momentum", 20, Color(0x161E5B78)),
    WorldRegion("Sky Citadel", "Master your systems", 40, Color(0x142F6B9A)),
    WorldRegion("Astral Reach", "Lead beyond limits", 60, Color(0x162F2A76)),
    WorldRegion("Eternal Crown", "Live at legendary level", 80, Color(0x18A46A18))
)

internal fun currentWorldRegion(level: Int): WorldRegion =
    worldRegions.lastOrNull { level >= it.minLevel } ?: worldRegions.first()

internal fun loadProfileLoadout(context: Context): ProfileLoadout {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return ProfileLoadout(
        avatar = prefs.getString(KEY_PROFILE_AVATAR, "crown") ?: "crown",
        title = prefs.getString(KEY_PROFILE_TITLE, "Pathfinder") ?: "Pathfinder",
        frame = prefs.getString(KEY_PROFILE_FRAME, "default") ?: "default",
        badge = prefs.getString(KEY_PROFILE_BADGE, "none") ?: "none"
    )
}

internal fun saveProfileLoadout(context: Context, loadout: ProfileLoadout) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_PROFILE_AVATAR, loadout.avatar)
        .putString(KEY_PROFILE_TITLE, loadout.title)
        .putString(KEY_PROFILE_FRAME, loadout.frame)
        .putString(KEY_PROFILE_BADGE, loadout.badge)
        .apply()
}

internal fun avatarGlyph(id: String): String = when (id) {
    "knight_avatar" -> "♞"
    "flame_avatar" -> "🔥"
    "star_avatar" -> "★"
    else -> "♛"
}

internal val shopRewards = listOf(
    ShopReward("focus_aura", "Focus Aura", "Golden mission glow", 250),
    ShopReward("elite_frame", "Elite Frame", "Premium profile frame", 500),
    ShopReward("midnight_crest", "Midnight Crest", "Rare progression badge", 750),
    ShopReward("knight_avatar", "Knight Avatar", "Equip a heroic profile avatar", 650),
    ShopReward("flame_avatar", "Flame Avatar", "A high-combo avatar", 900),
    ShopReward("legend_title", "Legend Title", "Equip the Legend profile title", 1000)
)

internal val defaultPersonalRewards = listOf(
    PersonalReward("coffee_break", "استراحت و قهوه", 100, reusable = true),
    PersonalReward("dessert", "دسر یا بستنی", 200, reusable = true),
    PersonalReward("free_time", "۳۰ دقیقه وقت آزاد", 250, reusable = true),
    PersonalReward("favorite_meal", "غذای مورد علاقه", 400, reusable = true),
    PersonalReward("movie_night", "شب فیلم", 500, reusable = true),
    PersonalReward("book", "خرید کتاب", 700),
    PersonalReward("small_gift", "یک هدیه کوچک برای خودم", 1000),
    PersonalReward("cafe", "کافه یا رستوران", 1500, reusable = true),
    PersonalReward("wanted_item", "خرید یک چیز مورد علاقه", 2500),
    PersonalReward("big_reward", "جایزه بزرگ", 5000)
)

internal val legacyPersonalRewardTitles = mapOf(
    "coffee_break" to "Coffee Break",
    "dessert" to "Dessert / Ice Cream",
    "free_time" to "30 Min Free Time",
    "favorite_meal" to "Favorite Meal",
    "movie_night" to "Movie Night",
    "book" to "Buy a Book",
    "small_gift" to "Small Gift for Myself",
    "cafe" to "Cafe / Restaurant",
    "wanted_item" to "Buy Something I Want",
    "big_reward" to "Big Personal Reward"
)
internal val localizedPersonalRewardTitles = defaultPersonalRewards.associate { it.id to it.title }

internal fun loadPersonalRewards(context: Context): List<PersonalReward> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_PERSONAL_REWARDS, null)
    if (raw.isNullOrBlank()) {
        savePersonalRewards(context, defaultPersonalRewards)
        return defaultPersonalRewards
    }
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val id = item.optString("id").ifBlank { "reward_${System.currentTimeMillis()}_$i" }
                val storedTitle = item.optString("title", "پاداش")
                val title = if (legacyPersonalRewardTitles[id] == storedTitle) {
                    localizedPersonalRewardTitles[id] ?: storedTitle
                } else storedTitle
                add(
                    PersonalReward(
                        id = id,
                        title = title,
                        price = item.optInt("price", 100).coerceAtLeast(0),
                        reusable = if (item.has("reusable")) item.optBoolean("reusable", false) else id in setOf("coffee_break", "dessert", "free_time", "favorite_meal", "movie_night", "cafe"),
                        completed = item.optBoolean("completed", false),
                        redeemCount = item.optInt("redeemCount", 0).coerceAtLeast(0)
                    )
                )
            }
        }
    }.getOrElse { defaultPersonalRewards }
}

internal fun savePersonalRewards(context: Context, rewards: List<PersonalReward>) {
    val array = JSONArray()
    rewards.forEach { reward ->
        array.put(
            JSONObject()
                .put("id", reward.id)
                .put("title", reward.title)
                .put("price", reward.price)
                .put("reusable", reward.reusable)
                .put("completed", reward.completed)
                .put("redeemCount", reward.redeemCount)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_PERSONAL_REWARDS, array.toString())
        .apply()
}

internal fun loadDreamItems(context: Context): List<DreamItem> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_DREAMBOARD_ITEMS, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    DreamItem(
                        id = item.optString("id").ifBlank { "dream_${System.currentTimeMillis()}_$i" },
                        title = item.optString("title", "Dream"),
                        year = item.optString("year", ""),
                        price = item.optString("price", ""),
                        imageUri = item.optString("imageUri", ""),
                        position = item.optInt("position", i)
                    )
                )
            }
        }.sortedBy { it.position }
    }.getOrElse { emptyList() }
}

internal fun saveDreamItems(context: Context, dreams: List<DreamItem>) {
    val array = JSONArray()
    dreams.sortedBy { it.position }.forEachIndexed { index, dream ->
        array.put(
            JSONObject()
                .put("id", dream.id)
                .put("title", dream.title)
                .put("year", dream.year)
                .put("price", dream.price)
                .put("imageUri", dream.imageUri)
                .put("position", index)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_DREAMBOARD_ITEMS, array.toString())
        .apply()
}

internal fun loadDreamBitmap(context: Context, uriString: String) = runCatching {
    if (uriString.isBlank()) return@runCatching null
    context.contentResolver.openInputStream(Uri.parse(uriString))?.use { stream ->
        BitmapFactory.decodeStream(stream)?.asImageBitmap()
    }
}.getOrNull()

internal fun loadDreamSourceBitmap(context: Context, uriString: String): Bitmap? = runCatching {
    if (uriString.isBlank()) return@runCatching null
    val uri = Uri.parse(uriString)
    if (uri.scheme == "file") {
        BitmapFactory.decodeFile(uri.path)
    } else {
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    }
}.getOrNull()

internal fun saveDreamCrop(
    context: Context,
    source: Bitmap,
    viewport: IntSize,
    userScale: Float,
    offset: Offset
): String? = runCatching {
    if (viewport.width <= 0 || viewport.height <= 0) return@runCatching null
    val baseScale = max(
        viewport.width.toFloat() / source.width.toFloat(),
        viewport.height.toFloat() / source.height.toFloat()
    )
    val effectiveScale = (baseScale * userScale).coerceAtLeast(0.0001f)
    val cropW = (viewport.width / effectiveScale).coerceAtMost(source.width.toFloat())
    val cropH = (viewport.height / effectiveScale).coerceAtMost(source.height.toFloat())
    val centerX = source.width / 2f - offset.x / effectiveScale
    val centerY = source.height / 2f - offset.y / effectiveScale
    val left = (centerX - cropW / 2f).coerceIn(0f, (source.width - cropW).coerceAtLeast(0f))
    val top = (centerY - cropH / 2f).coerceIn(0f, (source.height - cropH).coerceAtLeast(0f))
    val x = left.roundToInt().coerceIn(0, source.width - 1)
    val y = top.roundToInt().coerceIn(0, source.height - 1)
    val w = cropW.roundToInt().coerceIn(1, source.width - x)
    val h = cropH.roundToInt().coerceIn(1, source.height - y)
    val cropped = Bitmap.createBitmap(source, x, y, w, h)
    val output = Bitmap.createScaledBitmap(cropped, 900, 1600, true)
    val dir = File(context.filesDir, "dreamboard").apply { mkdirs() }
    val file = File(dir, "dream_${System.currentTimeMillis()}.jpg")
    FileOutputStream(file).use { out -> output.compress(Bitmap.CompressFormat.JPEG, 92, out) }
    if (output !== cropped) output.recycle()
    if (cropped !== source) cropped.recycle()
    Uri.fromFile(file).toString()
}.getOrNull()

internal fun loadStringSet(context: Context, key: String): Set<String> =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getStringSet(key, emptySet())?.toSet() ?: emptySet()

internal fun saveStringSet(context: Context, key: String, values: Set<String>) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putStringSet(key, values).apply()
}

internal val missionTemplates = listOf(
    MissionTemplate(
        "morning_routine", "روتین صبح", "Daily • Start the day intentionally",
        Mission("روتین صبح", 30, 35, 15, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "long_term_goal", "هدف بلندمدت", "Daily • Move the long game forward",
        Mission("هدف بلندمدت", 45, 60, 25, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "genealogy", "فکر روی ژینولوژی", "Daily • Build the genealogy project",
        Mission("فکر روی ژینولوژی", 45, 55, 25, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "timesheet", "Time Sheet", "Daily • Keep work records current",
        Mission("Time Sheet", 15, 20, 10, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "record_shekan_work", "گروه رکوردشکن و کاری", "Daily • Focused work block",
        Mission("گروه رکوردشکن و کاری", 60, 80, 35, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "creativity_scenario", "خلاقیت و سناریو", "Daily • Create and develop scenarios",
        Mission("خلاقیت و سناریو", 45, 60, 25, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "team_follow_up", "Team Follow-UP", "Daily • Follow up with the team",
        Mission("Team Follow-UP", 30, 40, 20, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "relation_introduction", "ارتباط‌سازی،معرفی", "Daily • Build relationships and introductions",
        Mission("ارتباط‌سازی،معرفی", 20, 30, 15, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "pre_consultation_invitation", "پیش‌مشاوره،دعوت", "Daily • Prepare and invite",
        Mission("پیش‌مشاوره،دعوت", 30, 45, 20, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "show_off", "Show-Off", "Daily • Present progress and results",
        Mission("Show-Off", 20, 30, 15, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "team_statistics", "نوشتن آمار", "Daily • Record team statistics",
        Mission("نوشتن آمار", 25, 35, 15, repeat = MissionRepeat.Daily)
    ),
    MissionTemplate(
        "night_routine", "روتین شب", "Daily • Close the day deliberately",
        Mission("روتین شب", 30, 35, 15, repeat = MissionRepeat.Daily)
    )
)

internal fun loadNotifications(context: Context): List<GameNotification> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_NOTIFICATIONS_CENTER, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    GameNotification(
                        id = item.optString("id", "n:$i"),
                        glyph = item.optString("glyph", "✦"),
                        title = item.optString("title", "Update"),
                        body = item.optString("body", ""),
                        timestamp = item.optLong("timestamp", System.currentTimeMillis()),
                        read = item.optBoolean("read", false)
                    )
                )
            }
        }
    }.getOrElse { emptyList() }
}

internal fun saveNotifications(context: Context, notifications: List<GameNotification>) {
    val array = JSONArray()
    notifications.take(100).forEach { n ->
        array.put(
            JSONObject()
                .put("id", n.id)
                .put("glyph", n.glyph)
                .put("title", n.title)
                .put("body", n.body)
                .put("timestamp", n.timestamp)
                .put("read", n.read)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_NOTIFICATIONS_CENTER, array.toString())
        .apply()
}

internal fun applyDailyLogin(context: Context, player: PlayerState): DailyLoginEvent? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val today = LocalDate.now()
    val last = prefs.getString(KEY_LAST_LOGIN_DATE, null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    if (last == today) return null
    val streak = if (last == today.minusDays(1)) player.loginStreak + 1 else 1
    val milestoneBonus = when (streak) {
        3 -> 50
        7 -> 100
        14 -> 200
        30 -> 500
        else -> 0
    }
    val reward = 10 + milestoneBonus
    val milestone = if (milestoneBonus > 0) "$streak DAY MILESTONE" else null
    val updated = player.copy(
        coins = player.coins + reward,
        loginStreak = streak,
        bestLoginStreak = maxOf(player.bestLoginStreak, streak)
    )
    prefs.edit().putString(KEY_LAST_LOGIN_DATE, today.toString()).apply()
    savePlayer(context, updated)
    return DailyLoginEvent(streak, reward, milestone, updated)
}

internal fun recurrenceTimeText(mission: Mission): String =
    if (mission.reminderHour in 0..23 && mission.reminderMinute in 0..59)
        String.format(Locale.US, "%02d:%02d", mission.reminderHour, mission.reminderMinute)
    else ""

internal fun missionRecurrenceSummary(mission: Mission): String {
    val base = if (mission.repeat == MissionRepeat.Daily) "DAILY" else ""
    val time = recurrenceTimeText(mission)
    return listOf(base, time).filter { it.isNotBlank() }.joinToString(" • ")
}

internal fun isMissionScheduledToday(mission: Mission, date: LocalDate = LocalDate.now()): Boolean =
    mission.repeat == MissionRepeat.Daily

internal fun isMissionDoneToday(mission: Mission, history: List<MissionHistoryEntry>): Boolean {
    val today = LocalDate.now()
    return history.any { it.missionTitle == mission.title && it.result == MissionResult.Done && it.localDate() == today }
}

internal enum class MissionCardState { Active, Done, Failed }

internal fun missionCardState(mission: Mission, history: List<MissionHistoryEntry>): MissionCardState {
    val today = LocalDate.now()
    val relevant = if (mission.repeat == MissionRepeat.Daily) {
        history.firstOrNull {
            it.missionTitle == mission.title &&
                it.localDate() == today &&
                it.result != MissionResult.Defer
        }
    } else {
        history.firstOrNull { it.missionTitle == mission.title && it.result != MissionResult.Defer }
    }
    return when (relevant?.result) {
        null -> MissionCardState.Active
        MissionResult.Done -> MissionCardState.Done
        else -> MissionCardState.Failed
    }
}

internal fun deferredTodayTimestamp(mission: Mission, history: List<MissionHistoryEntry>): Long? {
    val today = LocalDate.now()
    return history.firstOrNull {
        it.missionTitle == mission.title &&
            it.result == MissionResult.Defer &&
            it.localDate() == today
    }?.timestamp
}

internal fun missionSubtaskProgressKey(mission: Mission, date: LocalDate = LocalDate.now()): String =
    if (mission.repeat == MissionRepeat.Daily) "${mission.title}|$date" else "${mission.title}|once"

internal fun loadMissionSubtaskChecks(context: Context, mission: Mission): List<Boolean> {
    if (mission.subtasks.isEmpty()) return emptyList()
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}"
    return runCatching {
        val root = JSONObject(raw)
        val array = root.optJSONArray(missionSubtaskProgressKey(mission)) ?: JSONArray()
        List(mission.subtasks.size) { index -> if (index < array.length()) array.optBoolean(index, false) else false }
    }.getOrDefault(List(mission.subtasks.size) { false })
}

internal fun saveMissionSubtaskChecks(context: Context, mission: Mission, checks: List<Boolean>) {
    if (mission.subtasks.isEmpty()) return
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val root = runCatching { JSONObject(prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}") }.getOrDefault(JSONObject())
    root.put(
        missionSubtaskProgressKey(mission),
        JSONArray().apply { mission.subtasks.indices.forEach { index -> put(checks.getOrElse(index) { false }) } }
    )
    prefs.edit().putString(KEY_SUBTASK_PROGRESS, root.toString()).apply()
}

internal fun performDailyResetIfNeeded(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val today = LocalDate.now().toString()
    val last = prefs.getString(KEY_LAST_DAILY_RESET_DATE, null)
    if (last == null) {
        prefs.edit().putString(KEY_LAST_DAILY_RESET_DATE, today).apply()
        return
    }
    if (last == today) return
    loadActiveTimer(context)?.takeIf { it.mission.repeat == MissionRepeat.Daily }?.let { clearActiveTimer(context) }
    val progressRoot = runCatching { JSONObject(prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}") }.getOrDefault(JSONObject())
    val cleaned = JSONObject()
    progressRoot.keys().forEach { key ->
        if (key.endsWith("|once") || key.endsWith("|$today")) cleaned.put(key, progressRoot.optJSONArray(key) ?: JSONArray())
    }
    prefs.edit()
        .putString(KEY_SUBTASK_PROGRESS, cleaned.toString())
        .putString(KEY_LAST_DAILY_RESET_DATE, today)
        .apply()
}

internal fun buildChallenges(history: List<MissionHistoryEntry>): List<Challenge> {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val todayEntries = history.filter { it.localDate(zone) == today }
    val weekEntries = history.filter { !it.localDate(zone).isBefore(weekStart) && !it.localDate(zone).isAfter(today) }
    val todayDone = todayEntries.count { it.result == MissionResult.Done }
    val todayMinutes = todayEntries.sumOf { it.focusSeconds } / 60
    val weekDone = weekEntries.count { it.result == MissionResult.Done }
    return listOf(
        Challenge("daily:$today:done3", "3 Missions Today", "Finish three missions", todayDone, 3, 120, 60, false),
        Challenge("daily:$today:focus90", "90 Focus Minutes", "Build a focused day", todayMinutes, 90, 150, 75, false),
        Challenge("weekly:$weekStart:done10", "10 Missions This Week", "Weekly consistency challenge", weekDone, 10, 350, 180, true)
    )
}

internal fun buildAchievements(player: PlayerState, history: List<MissionHistoryEntry>): List<Achievement> {
    val done = history.count { it.result == MissionResult.Done }
    val focusMinutes = history.sumOf { it.focusSeconds } / 60
    return listOf(
        Achievement("first_mission", "First Mission", "Complete your first mission", "✦", done, 1, 80, 40),
        Achievement("mission_10", "Momentum", "Complete 10 missions", "◆", done, 10, 180, 90),
        Achievement("focus_10h", "Deep Worker", "Accumulate 10 hours of focus", "◷", focusMinutes, 600, 250, 120),
        Achievement("combo_10", "Unbroken", "Reach a Combo of 10", "🔥", player.bestCombo, 10, 220, 110),
        Achievement("rank_10", "Rising Rank", "Reach Rank 10", "♜", player.rank, 10, 300, 150),
        Achievement("level_50", "Level 50", "Reach Level 50", "★", player.level, 50, 500, 250)
    )
}

internal fun loadActiveTimer(context: Context): ActiveTimerState? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    if (!prefs.getBoolean(KEY_TIMER_ACTIVE, false)) return null
    val mission = Mission(
        title = prefs.getString(KEY_TIMER_TITLE, "Mission") ?: "Mission",
        durationMinutes = prefs.getInt(KEY_TIMER_DURATION, 45).coerceAtLeast(1),
        xpReward = prefs.getInt(KEY_TIMER_XP, 50).coerceAtLeast(0),
        coinReward = prefs.getInt(KEY_TIMER_COINS, 20).coerceAtLeast(0),
        isRankMission = prefs.getBoolean(KEY_TIMER_RANK, false),
        repeat = if ((prefs.getString(KEY_TIMER_REPEAT, MissionRepeat.None.name) ?: MissionRepeat.None.name) == MissionRepeat.None.name) MissionRepeat.None else MissionRepeat.Daily,
        reminderHour = prefs.getInt(KEY_TIMER_REMINDER_HOUR, -1).takeIf { it in 0..23 } ?: -1,
        reminderMinute = prefs.getInt(KEY_TIMER_REMINDER_MINUTE, -1).takeIf { it in 0..59 } ?: -1,
        subtasks = runCatching {
            val array = JSONArray(prefs.getString(KEY_TIMER_SUBTASKS, "[]") ?: "[]")
            buildList {
                for (i in 0 until array.length()) {
                    val value = array.optString(i, "").trim()
                    if (value.isNotEmpty()) add(value.take(120))
                }
            }
        }.getOrDefault(emptyList())
    )
    val checkedSubtasks = runCatching {
        val array = JSONArray(prefs.getString(KEY_TIMER_SUBTASK_CHECKS, "[]") ?: "[]")
        List(mission.subtasks.size) { index -> if (index < array.length()) array.optBoolean(index, false) else false }
    }.getOrDefault(List(mission.subtasks.size) { false })
    return ActiveTimerState(
        mission = mission,
        remainingSeconds = prefs.getInt(KEY_TIMER_REMAINING, mission.durationMinutes * 60).coerceAtLeast(0),
        endAtMillis = prefs.getLong(KEY_TIMER_END_AT, 0L),
        isRunning = prefs.getBoolean(KEY_TIMER_RUNNING, false),
        sessionId = prefs.getLong(KEY_TIMER_SESSION, 0L).takeIf { it > 0L }
            ?: (prefs.getLong(KEY_TIMER_END_AT, 0L) - prefs.getInt(KEY_TIMER_DURATION, 45).coerceAtLeast(1) * 60_000L).coerceAtLeast(1L),
        checkedSubtasks = checkedSubtasks
    )
}

internal fun saveActiveTimer(context: Context, state: ActiveTimerState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, true)
        .putString(KEY_TIMER_TITLE, state.mission.title)
        .putInt(KEY_TIMER_DURATION, state.mission.durationMinutes)
        .putInt(KEY_TIMER_XP, state.mission.xpReward)
        .putInt(KEY_TIMER_COINS, state.mission.coinReward)
        .putBoolean(KEY_TIMER_RANK, state.mission.isRankMission)
        .putString(KEY_TIMER_REPEAT, state.mission.repeat.name)
        .putInt(KEY_TIMER_REMINDER_HOUR, state.mission.reminderHour)
        .putInt(KEY_TIMER_REMINDER_MINUTE, state.mission.reminderMinute)
        .putString(KEY_TIMER_SUBTASKS, JSONArray().apply { state.mission.subtasks.forEach { put(it) } }.toString())
        .putString(KEY_TIMER_SUBTASK_CHECKS, JSONArray().apply { state.checkedSubtasks.forEach { put(it) } }.toString())
        .putInt(KEY_TIMER_REMAINING, state.remainingSeconds.coerceAtLeast(0))
        .putLong(KEY_TIMER_END_AT, state.endAtMillis)
        .putBoolean(KEY_TIMER_RUNNING, state.isRunning)
        .putLong(KEY_TIMER_SESSION, state.sessionId)
        .apply()
}

internal fun remainingSeconds(state: ActiveTimerState, now: Long = System.currentTimeMillis()): Int {
    if (!state.isRunning) return state.remainingSeconds.coerceAtLeast(0)
    if (state.endAtMillis <= now) return 0
    return ceil((state.endAtMillis - now) / 1000.0).toInt().coerceAtLeast(0)
}

internal fun timerPendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
    context,
    TIMER_REQUEST_CODE,
    Intent(context, TimerFinishReceiver::class.java),
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

internal fun cancelTimerAlarm(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timerPendingIntent(context))
}

internal fun scheduleTimerAlarm(context: Context, state: ActiveTimerState, settings: GameSettings) {
    cancelTimerAlarm(context)
    if (!settings.notificationsEnabled || !state.isRunning || state.endAtMillis <= System.currentTimeMillis()) return
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, state.endAtMillis, timerPendingIntent(context))
}

internal fun beginActiveTimer(context: Context, mission: Mission, settings: GameSettings): ActiveTimerState {
    val total = (mission.durationMinutes * 60).coerceAtLeast(1)
    val state = ActiveTimerState(
        mission = mission,
        remainingSeconds = total,
        endAtMillis = System.currentTimeMillis() + total * 1000L,
        isRunning = true,
        sessionId = System.currentTimeMillis(),
        checkedSubtasks = loadMissionSubtaskChecks(context, mission)
    )
    saveActiveTimer(context, state)
    scheduleTimerAlarm(context, state, settings)
    return state
}

internal fun clearActiveTimer(context: Context) {
    cancelTimerAlarm(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, false)
        .remove(KEY_TIMER_END_AT)
        .remove(KEY_TIMER_REMAINING)
        .remove(KEY_TIMER_RUNNING)
        .remove(KEY_TIMER_SESSION)
        .remove(KEY_TIMER_SUBTASKS)
        .remove(KEY_TIMER_SUBTASK_CHECKS)
        .remove("timer_deadline_hour")
        .remove("timer_deadline_minute")
        .remove("timer_notes")
        .apply()
}

internal fun playResultFeedback(context: Context, settings: GameSettings, result: MissionResult, levelUp: Boolean) {
    if (settings.soundEnabled) {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
        val toneType = when {
            levelUp -> ToneGenerator.TONE_PROP_ACK
            result == MissionResult.Done -> ToneGenerator.TONE_PROP_BEEP2
            result == MissionResult.Partial -> ToneGenerator.TONE_PROP_BEEP
            else -> ToneGenerator.TONE_PROP_NACK
        }
        tone.startTone(toneType, if (levelUp) 260 else 150)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 320L)
    }
    if (settings.vibrationEnabled) {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val pattern = if (levelUp) longArrayOf(0, 45, 55, 90) else longArrayOf(0, 45)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (levelUp) 140L else 45L)
            }
        }
    }
}

internal fun loadPlayer(context: Context): PlayerState {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val level = prefs.getInt(KEY_PLAYER_LEVEL, 37).coerceAtLeast(1)
    val threshold = prefs.getInt(KEY_PLAYER_NEXT_XP, 3000).coerceAtLeast(500)
    val combo = prefs.getInt(KEY_PLAYER_COMBO, 12).coerceAtLeast(0)
    val rank = prefs.getInt(KEY_PLAYER_RANK, 8).coerceIn(1, 100)
    return PlayerState(
        level = level,
        currentXp = prefs.getInt(KEY_PLAYER_XP, 2450).coerceIn(0, threshold - 1),
        nextLevelXp = threshold,
        rank = rank,
        rankProgress = if (rank >= 100) 0 else prefs.getInt(KEY_PLAYER_RANK_PROGRESS, 0).coerceIn(0, rankRequirement(rank) - 1),
        coins = prefs.getInt(KEY_PLAYER_COINS, 1320).coerceAtLeast(0),
        combo = combo,
        bestCombo = maxOf(combo, prefs.getInt(KEY_PLAYER_BEST_COMBO, combo).coerceAtLeast(0)),
        chests = prefs.getInt(KEY_PLAYER_CHESTS, 0).coerceAtLeast(0),
        loginStreak = prefs.getInt(KEY_PLAYER_LOGIN_STREAK, 0).coerceAtLeast(0),
        bestLoginStreak = prefs.getInt(KEY_PLAYER_BEST_LOGIN_STREAK, 0).coerceAtLeast(0)
    )
}

internal fun savePlayer(context: Context, player: PlayerState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putInt(KEY_PLAYER_LEVEL, player.level)
        .putInt(KEY_PLAYER_XP, player.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, player.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, player.rank)
        .putInt(KEY_PLAYER_RANK_PROGRESS, player.rankProgress)
        .putInt(KEY_PLAYER_CHESTS, player.chests)
        .putInt(KEY_PLAYER_COINS, player.coins)
        .putInt(KEY_PLAYER_COMBO, player.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, player.bestCombo)
        .putInt(KEY_PLAYER_LOGIN_STREAK, player.loginStreak)
        .putInt(KEY_PLAYER_BEST_LOGIN_STREAK, player.bestLoginStreak)
        .apply()
    GamifyWidgetProvider.updateAll(context)
}

internal fun loadMissions(context: Context): List<Mission> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_MISSIONS, null) ?: return listOf(defaultMission())
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    Mission(
                        title = item.optString("title", "New Mission"),
                        durationMinutes = item.optInt("durationMinutes", 45).coerceAtLeast(1),
                        xpReward = item.optInt("xpReward", 50).coerceAtLeast(0),
                        coinReward = item.optInt("coinReward", 20).coerceAtLeast(0),
                        isRankMission = item.optBoolean("isRankMission", false),
                        repeat = if (item.optString("repeat", MissionRepeat.None.name) == MissionRepeat.None.name) MissionRepeat.None else MissionRepeat.Daily,
                        reminderHour = item.optInt("reminderHour", -1).takeIf { it in 0..23 } ?: -1,
                        reminderMinute = item.optInt("reminderMinute", -1).takeIf { it in 0..59 } ?: -1,
                        subtasks = buildList {
                            val subtaskArray = item.optJSONArray("subtasks") ?: JSONArray()
                            for (j in 0 until subtaskArray.length()) {
                                val value = subtaskArray.optString(j, "").trim()
                                if (value.isNotEmpty()) add(value.take(120))
                            }
                        }
                    )
                )
            }
        }
    }.getOrElse { listOf(defaultMission()) }
}

internal fun saveMissions(context: Context, missions: List<Mission>) {
    val array = JSONArray()
    missions.forEach { mission ->
        array.put(
            JSONObject()
                .put("title", mission.title)
                .put("durationMinutes", mission.durationMinutes)
                .put("xpReward", mission.xpReward)
                .put("coinReward", mission.coinReward)
                .put("isRankMission", mission.isRankMission)
                .put("repeat", mission.repeat.name)
                .put("reminderHour", mission.reminderHour)
                .put("reminderMinute", mission.reminderMinute)
                .put("subtasks", JSONArray().apply { mission.subtasks.forEach { put(it) } })
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_MISSIONS, array.toString())
        .apply()
}

internal fun loadHistory(context: Context): List<MissionHistoryEntry> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val result = runCatching { MissionResult.valueOf(item.optString("result", "Done")) }
                    .getOrDefault(MissionResult.Done)
                add(
                    MissionHistoryEntry(
                        timestamp = item.optLong("timestamp", System.currentTimeMillis()),
                        missionTitle = item.optString("missionTitle", "Mission"),
                        plannedMinutes = item.optInt("plannedMinutes", 0),
                        focusSeconds = item.optInt("focusSeconds", 0).coerceAtLeast(0),
                        result = result,
                        xpEarned = item.optInt("xpEarned", 0).coerceAtLeast(0),
                        coinsEarned = item.optInt("coinsEarned", 0).coerceAtLeast(0),
                        levelRewardCoins = item.optInt("levelRewardCoins", 0).coerceAtLeast(0)
                    )
                )
            }
        }
    }.getOrElse { emptyList() }
}

internal fun saveHistory(context: Context, history: List<MissionHistoryEntry>) {
    val array = JSONArray()
    history.take(500).forEach { entry ->
        array.put(
            JSONObject()
                .put("timestamp", entry.timestamp)
                .put("missionTitle", entry.missionTitle)
                .put("plannedMinutes", entry.plannedMinutes)
                .put("focusSeconds", entry.focusSeconds)
                .put("result", entry.result.name)
                .put("xpEarned", entry.xpEarned)
                .put("coinsEarned", entry.coinsEarned)
                .put("levelRewardCoins", entry.levelRewardCoins)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_HISTORY, array.toString())
        .apply()
}

internal fun migrateState(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val current = prefs.getInt(KEY_SCHEMA_VERSION, 0)
    if (current >= CURRENT_SCHEMA_VERSION) return

    val legacyStarterTitles = mapOf(
        "Morning Routine" to "روتین صبح",
        "Long-Term Goal" to "هدف بلندمدت",
        "Work on the Genealogy" to "فکر روی ژینولوژی",
        "Timesheet" to "Time Sheet",
        "Record-Shekan, Work" to "گروه رکوردشکن و کاری",
        "Creativity, Scenario" to "خلاقیت و سناریو",
        "Team Follow-Up" to "Team Follow-UP",
        "Relation, Introduction" to "ارتباط‌سازی،معرفی",
        "Pre-Consultation & Invitation" to "پیش‌مشاوره،دعوت",
        "Write Team Statistics" to "نوشتن آمار",
        "Night Routine" to "روتین شب"
    )
    val safeMissions = loadMissions(context)
        .ifEmpty { listOf(defaultMission()) }
        .map { mission -> if (current < 8) mission.copy(title = legacyStarterTitles[mission.title] ?: mission.title) else mission }
    val safeHistory = loadHistory(context)
        .filter { it.timestamp > 0L }
        .map { entry -> if (current < 8) entry.copy(missionTitle = legacyStarterTitles[entry.missionTitle] ?: entry.missionTitle) else entry }
        .distinctBy { "${it.timestamp}|${it.missionTitle}|${it.result.name}" }
        .take(500)
    saveMissions(context, safeMissions)
    saveHistory(context, safeHistory)
    savePlayer(context, loadPlayer(context))
    saveSettings(context, loadSettings(context))
    savePersonalRewards(context, loadPersonalRewards(context))
    saveDreamItems(context, loadDreamItems(context))
    val editor = prefs.edit().putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION)
    if (current in 1 until CURRENT_SCHEMA_VERSION && !prefs.contains(KEY_ONBOARDING_COMPLETE)) {
        editor.putBoolean(KEY_ONBOARDING_COMPLETE, true)
    }
    RETIRED_PREF_KEYS.forEach { editor.remove(it) }
    editor.apply()
}

internal fun exportBackup(context: Context, uri: Uri): Boolean = runCatching {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val entries = JSONArray()
    val allEntries = prefs.all.entries.sortedBy { it.key }
    for (entry in allEntries) {
        val key = entry.key
        val value = entry.value
        if (!isBackupEligibleKey(key)) continue
        val item = JSONObject().put("key", key)
        when (value) {
            is String -> item.put("type", "string").put("value", value)
            is Int -> item.put("type", "int").put("value", value)
            is Long -> item.put("type", "long").put("value", value)
            is Float -> item.put("type", "float").put("value", value.toDouble())
            is Boolean -> item.put("type", "boolean").put("value", value)
            is Set<*> -> {
                val array = JSONArray()
                for (element in value) if (element is String) array.put(element)
                item.put("type", "stringSet").put("value", array)
            }
            else -> continue
        }
        entries.put(item)
    }
    val root = JSONObject()
        .put("format", "GamificationBackup")
        .put("schemaVersion", CURRENT_SCHEMA_VERSION)
        .put("exportedAt", System.currentTimeMillis())
        .put("entries", entries)
    context.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(root.toString(2)) }
}.isSuccess

internal fun importBackup(context: Context, uri: Uri): String = runCatching {
    val raw = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
    require(raw.length <= 10_000_000) { "Backup file is too large" }
    val root = JSONObject(raw)
    require(root.optString("format") == "GamificationBackup") { "Not a Gamification backup" }
    val version = root.optInt("schemaVersion", 1)
    require(version in 1..CURRENT_SCHEMA_VERSION) { "Backup version is newer than this app" }
    val entries = root.getJSONArray("entries")
    require(entries.length() <= 1000) { "Backup contains too many entries" }

    // Validate and stage everything before touching current app data.
    val staged = mutableListOf<Triple<String, String, Any>>()
    for (i in 0 until entries.length()) {
        val item = entries.getJSONObject(i)
        val key = item.getString("key")
        require(key.length in 1..120) { "Invalid backup key" }
        if (!isBackupEligibleKey(key)) continue
        val type = item.getString("type")
        val value: Any = when (type) {
            "string" -> item.optString("value", "").take(2_000_000)
            "int" -> item.optInt("value", 0)
            "long" -> item.optLong("value", 0L)
            "float" -> item.optDouble("value", 0.0).toFloat()
            "boolean" -> item.optBoolean("value", false)
            "stringSet" -> {
                val a = item.optJSONArray("value") ?: JSONArray()
                require(a.length() <= 500) { "Backup set is too large" }
                buildSet { for (j in 0 until a.length()) add(a.optString(j).take(500)) }
            }
            else -> error("Unsupported backup value type")
        }
        staged += Triple(key, type, value)
    }

    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val editor = prefs.edit().clear()
    staged.forEach { (key, type, value) ->
        when (type) {
            "string" -> editor.putString(key, value as String)
            "int" -> editor.putInt(key, value as Int)
            "long" -> editor.putLong(key, value as Long)
            "float" -> editor.putFloat(key, value as Float)
            "boolean" -> editor.putBoolean(key, value as Boolean)
            "stringSet" -> editor.putStringSet(key, (value as Set<*>).filterIsInstance<String>().toSet())
        }
    }
    editor.putBoolean(KEY_TIMER_ACTIVE, false)
        .putInt(KEY_SCHEMA_VERSION, 0)
        .apply()
    cancelTimerAlarm(context)
    migrateState(context)
    "Backup restored"
}.getOrElse { it.message ?: "Import failed" }

internal fun resetGameData(context: Context) {
    cancelTimerAlarm(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    migrateState(context)
}

internal fun applyMissionResult(
    player: PlayerState,
    mission: Mission,
    result: MissionResult,
    settings: GameSettings
): MissionOutcome {
    val comboAfter = when (result) {
        MissionResult.Done -> player.combo + 1
        MissionResult.Partial -> (player.combo - 1).coerceAtLeast(0)
        MissionResult.Fail -> 0
        MissionResult.Defer -> player.combo
    }
    val rewardMultiplier = if (settings.comboBoostEnabled && result == MissionResult.Done) {
        comboMultiplier(comboAfter)
    } else {
        1.0f
    }
    val baseXp = when (result) {
        MissionResult.Done -> mission.xpReward
        MissionResult.Partial -> mission.xpReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }
    val baseCoins = when (result) {
        MissionResult.Done -> mission.coinReward
        MissionResult.Partial -> mission.coinReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }
    val xpGain = (baseXp * rewardMultiplier).toInt()
    val missionCoinGain = (baseCoins * rewardMultiplier).toInt()

    var level = player.level
    var xp = player.currentXp + xpGain
    var threshold = player.nextLevelXp
    var levelsGained = 0
    while (xp >= threshold) {
        xp -= threshold
        level += 1
        levelsGained += 1
        threshold += 500
    }

    val levelRewardCoins = levelsGained * LEVEL_UP_COIN_REWARD

    var rank = player.rank
    var rankProgress = player.rankProgress
    var ranksGained = 0
    if (mission.isRankMission && result == MissionResult.Done && rank < 100) {
        rankProgress += 1
        while (rank < 100 && rankProgress >= rankRequirement(rank)) {
            rankProgress -= rankRequirement(rank)
            rank += 1
            ranksGained += 1
        }
        if (rank >= 100) rankProgress = 0
    }
    val chestsEarned = levelsGained + ranksGained
    val updated = player.copy(
        level = level,
        currentXp = xp,
        nextLevelXp = threshold,
        rank = rank,
        rankProgress = rankProgress,
        coins = player.coins + missionCoinGain + levelRewardCoins,
        combo = comboAfter,
        bestCombo = maxOf(player.bestCombo, comboAfter),
        chests = player.chests + chestsEarned
    )
    return MissionOutcome(
        player = updated,
        xpGain = xpGain,
        missionCoinGain = missionCoinGain,
        levelsGained = levelsGained,
        levelRewardCoins = levelRewardCoins,
        comboBefore = player.combo,
        comboAfter = comboAfter,
        rewardMultiplier = rewardMultiplier,
        ranksGained = ranksGained,
        chestsEarned = chestsEarned
    )
}

internal fun applyBonusReward(player: PlayerState, xpGain: Int, coinGain: Int): Pair<PlayerState, LevelUpEvent?> {
    var level = player.level
    var xp = player.currentXp + xpGain.coerceAtLeast(0)
    var threshold = player.nextLevelXp
    var levelsGained = 0
    while (xp >= threshold) {
        xp -= threshold
        level += 1
        levelsGained += 1
        threshold += 500
    }
    val levelCoins = levelsGained * LEVEL_UP_COIN_REWARD
    val updated = player.copy(
        level = level,
        currentXp = xp,
        nextLevelXp = threshold,
        coins = player.coins + coinGain.coerceAtLeast(0) + levelCoins,
        chests = player.chests + levelsGained
    )
    val event = if (levelsGained > 0) LevelUpEvent(player.level, level, levelCoins) else null
    return updated to event
}

internal fun MissionHistoryEntry.localDate(zoneId: ZoneId = ZoneId.systemDefault()): LocalDate =
    Instant.ofEpochMilli(timestamp).atZone(zoneId).toLocalDate()
