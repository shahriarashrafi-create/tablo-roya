# Gamification architecture

This file records the structure introduced in Step 1A.

- `MainActivity.kt` — Compose UI, navigation/orchestration, dialogs and visual components.
- `Models.kt` — application/domain state models shared by UI and persistence.
- `GameStorage.kt` — SharedPreferences persistence, migrations, backup/import, mission/timer state, Dreamboard image persistence and non-UI helpers.
- `TimerFinishReceiver.kt` — Android timer-finished broadcast receiver.
- `GamifyWidgetProvider.kt` — Android home-screen widget provider.

Step 1B is intentionally reserved for deleting legacy code, tightening migrations, and adding a reproducible Gradle build check.


## Step 1B build and migration guardrails
- Active models no longer carry retired Deadline, Notes, or Main Goal fields.
- Schema 11 removes retired preference keys but old backup files remain importable.
- Backup restoration validates input before clearing live preferences.
- `./scripts/verify-project.sh` is the canonical build verification command.
- CI runs the same verification against Android SDK 35 and Java 17.

## Design system
`DesignSystem.kt` is now the single source of truth for core visual tokens (`GamifyColors`, `GamifySpacing`, `GamifyDimens`, `GamifyShapes`) and the app Material theme. New screens should consume these tokens instead of introducing new hard-coded input colors/radii. Step 2B will migrate the remaining legacy hard-coded UI values and perform the full RTL/small-screen pass.

## v52 UI boundary
`DesignSystem.kt` is now the source of shared visual tokens plus compact-screen helpers. New UI should not introduce fixed dialog heights or local text-field palettes unless a documented exception is necessary. Persian feature surfaces should explicitly provide RTL at their boundary; mixed numeric/HUD surfaces can remain LTR.
