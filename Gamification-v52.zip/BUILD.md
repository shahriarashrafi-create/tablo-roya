# Build verification

This project is pinned to Java 17, Android SDK 35, and Gradle 8.9.

## Local
Run:

```sh
./scripts/verify-project.sh
```

The project-local `gradlew` launcher downloads the pinned Gradle distribution on first use and then runs `:app:assembleDebug`.

## CI
`.github/workflows/android-build.yml` installs Android SDK 35 and Java 17, runs the same verification script, and uploads `app-debug.apk`.

The launcher is intentionally self-contained so ZIP snapshots build without requiring a preinstalled Gradle executable.


## v52 verification note
The project structure and Kotlin delimiter balance were checked after the Step 2B UI audit. Full local Gradle compilation could not run in this environment because `services.gradle.org` DNS resolution is unavailable; the repository wrapper and CI workflow remain the authoritative build check.
