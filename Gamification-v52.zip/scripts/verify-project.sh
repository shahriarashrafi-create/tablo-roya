#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
for f in app/src/main/java/com/shahriar/gamify/MainActivity.kt app/src/main/java/com/shahriar/gamify/Models.kt app/src/main/java/com/shahriar/gamify/GameStorage.kt app/src/main/java/com/shahriar/gamify/DesignSystem.kt; do
  test -s "$f" || { echo "Missing $f" >&2; exit 1; }
done
if grep -R -n -E 'deadlineHour|deadlineMinute|mainGoal|KEY_TIMER_DEADLINE|KEY_TIMER_NOTES|KEY_ONBOARDING_GOAL' app/src/main/java/com/shahriar/gamify; then
  echo "Retired model fields are still referenced." >&2
  exit 1
fi
./gradlew :app:assembleDebug --no-daemon
