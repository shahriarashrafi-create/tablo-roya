shadbash - Page 02

Changes:
- First page redesigned to fit on one screen without scrolling.
- Responsive sizing added for short and tall phones.
- Safe spacing kept for modern phone status/navigation areas.
- Start Game now opens Page 2.
- Page 2 added: team count selection (2 to 6 teams), selection state, preview chips, and next-step button.
- Existing shadbash launcher icon remains included.
- Compatible with the current ZIP-based GitHub Actions workflow.
