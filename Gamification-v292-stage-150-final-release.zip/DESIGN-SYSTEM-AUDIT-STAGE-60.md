# Stage 60 — Design System Audit

This is the consolidation checkpoint for the visual-system phase.

## Canonical shared primitives
- Color palette: `GamifyColors`
- Typography: `GamifyType` + Material typography mapping
- Spacing/layout rhythm: `GamifySpacing`
- Icon geometry: `GamifyIcons`
- Dimensions/touch targets: `GamifyDimens`
- Shapes: `GamifyShapes`
- Buttons/states: `GamifyActionButton` + `GamifyButtonStyle`
- Form fields/states: `gamifyTextFieldColors()`
- Motion: `GamifyMotion`
- Elevation: `GamifyElevation`
- Internal coded background: `InternalGameBackdrop`
- Persistent progression HUD: `TopGameHud`

## Deliberate exceptions
Dreamboard image cards, Tree nodes/branches, Mission result feedback and TimeSheet status cells keep feature-specific geometry/color where it communicates state or identity. These are not treated as design-system drift.

## Rule for the next phases
New routine UI should use the canonical tokens/components above. A new hard-coded visual value should only be introduced for feature semantics, data visualization, or a deliberate hero treatment.
