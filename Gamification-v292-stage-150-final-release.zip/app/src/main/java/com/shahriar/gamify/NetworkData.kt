package com.shahriar.gamify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale
import java.util.UUID

/**
 * Stage 2 data foundation for the redesigned network tree.
 *
 * The UI is intentionally not switched over yet. This file establishes one durable,
 * export-friendly source of truth for tree people, daily stats, prospect actions,
 * per-person todos and coaching notes. All records use stable IDs so later UI stages
 * can safely edit, restore, filter and import data without relying on display names.
 */
internal const val KEY_NETWORK_DATA_V2 = "network_data_v2"
internal const val NETWORK_DATA_VERSION = 4

internal data class NetworkPerson(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val parentId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

internal data class DailyNetworkStats(
    val personId: String,
    /** ISO date is the stable storage key; UI will render it as Jalali. */
    val isoDate: String,
    val pv: Int = 0,
    val gpv: Int = 0,
    val count: Int = 0,
    /** True only after the user explicitly presses Save for that day. */
    val confirmed: Boolean = false,
    val savedAt: Long = 0L
)

internal enum class ProspectActionType {
    Networking,
    PreConsultation,
    Invitation,
    BusinessPresentation,
    FollowUp,
    Pp,
    ProductPresentation
}

internal data class Prospect(
    val id: String = UUID.randomUUID().toString(),
    val ownerPersonId: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

internal data class ProspectAction(
    val id: String = UUID.randomUUID().toString(),
    val prospectId: String,
    val type: ProspectActionType? = null,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

internal data class PersonTodo(
    val id: String = UUID.randomUUID().toString(),
    val personId: String,
    val title: String,
    val description: String = "",
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

internal data class CoachingNote(
    val id: String = UUID.randomUUID().toString(),
    val personId: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt
)

internal data class NetworkData(
    val version: Int = NETWORK_DATA_VERSION,
    val people: List<NetworkPerson> = emptyList(),
    val dailyStats: List<DailyNetworkStats> = emptyList(),
    val prospects: List<Prospect> = emptyList(),
    val prospectActions: List<ProspectAction> = emptyList(),
    val todos: List<PersonTodo> = emptyList(),
    val coachingNotes: List<CoachingNote> = emptyList()
) {
    fun statsFor(personId: String, date: LocalDate = LocalDate.now()): DailyNetworkStats? =
        dailyStats.lastOrNull { it.personId == personId && it.isoDate == date.toString() }

    fun isTodayConfirmed(personId: String, date: LocalDate = LocalDate.now()): Boolean =
        statsFor(personId, date)?.confirmed == true

    fun openTodoCount(personId: String): Int = todos.count { it.personId == personId && !it.done }
}

internal object NetworkDataStore {
    fun load(context: Context): NetworkData {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_NETWORK_DATA_V2, null)
        if (raw == null) {
            val migrated = migrateLegacyTree(context)
            if (migrated.people.isNotEmpty()) save(context, migrated)
            return migrated
        }
        return runCatching {
            val decoded = decode(JSONObject(raw))
            val repaired = repair(decoded)
            // Persist only when normalization actually changed something. This makes recovery
            // from old/partial data automatic without rewriting preferences on every read.
            if (repaired != decoded) save(context, repaired)
            repaired
        }.getOrElse {
            // Never destroy the raw value on a decode failure. The backup/export path can still
            // preserve it while the UI receives a safe empty model instead of crashing.
            NetworkData()
        }
    }

    fun save(context: Context, data: NetworkData) {
        val safe = repair(data)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_NETWORK_DATA_V2, encode(safe).toString())
            .apply()
    }

    /**
     * Stage 25 integrity gate. Network data can survive interrupted imports, older builds and
     * manually edited backups without letting one malformed reference crash the tree UI.
     */
    internal fun repair(data: NetworkData): NetworkData {
        val seenPeople = linkedSetOf<String>()
        val people0 = data.people.mapNotNull { p ->
            val id = p.id.trim()
            val name = p.name.trim()
            if (id.isEmpty() || name.isEmpty() || !seenPeople.add(id)) null
            else p.copy(id = id, name = name)
        }
        val validIds = people0.mapTo(linkedSetOf()) { it.id }

        // Normalize invalid/self parents first, then break parent cycles deterministically.
        val parent = people0.associate { p -> p.id to p.parentId?.takeIf { it in validIds && it != p.id } }.toMutableMap()
        for (p in people0) {
            val path = linkedSetOf<String>()
            var cursor: String? = p.id
            while (cursor != null) {
                if (!path.add(cursor)) {
                    parent[p.id] = null
                    break
                }
                cursor = parent[cursor]
            }
        }
        val people = people0.map { it.copy(parentId = parent[it.id]) }

        val statsSeen = linkedSetOf<String>()
        val stats = data.dailyStats.mapNotNull { s ->
            if (s.personId !in validIds || runCatching { LocalDate.parse(s.isoDate) }.isFailure) return@mapNotNull null
            val key = "${s.personId}|${s.isoDate}"
            if (!statsSeen.add(key)) return@mapNotNull null
            s.copy(pv = s.pv.coerceAtLeast(0), gpv = s.gpv.coerceAtLeast(0), count = s.count.coerceAtLeast(0))
        }

        val seenProspects = linkedSetOf<String>()
        val prospects = data.prospects.mapNotNull { p ->
            val id = p.id.trim(); val name = p.name.trim()
            if (id.isEmpty() || name.isEmpty() || p.ownerPersonId !in validIds || !seenProspects.add(id)) null
            else p.copy(id = id, name = name)
        }
        val prospectIds = prospects.mapTo(linkedSetOf()) { it.id }
        val seenActions = linkedSetOf<String>()
        val actions = data.prospectActions.filter { it.prospectId in prospectIds && it.id.isNotBlank() && seenActions.add(it.id) }

        val seenTodos = linkedSetOf<String>()
        val todos = data.todos.mapNotNull { t ->
            val title = t.title.trim()
            if (t.personId !in validIds || t.id.isBlank() || title.isEmpty() || !seenTodos.add(t.id)) null
            else t.copy(title = title, completedAt = if (t.done) t.completedAt else null)
        }
        val seenNotes = linkedSetOf<String>()
        val notes = data.coachingNotes.mapNotNull { n ->
            val text = n.text.trim()
            if (n.personId !in validIds || n.id.isBlank() || text.isEmpty() || !seenNotes.add(n.id)) null
            else n.copy(text = text, updatedAt = maxOf(n.updatedAt, n.createdAt))
        }
        return NetworkData(
            version = NETWORK_DATA_VERSION,
            people = people,
            dailyStats = stats,
            prospects = prospects,
            prospectActions = actions,
            todos = todos,
            coachingNotes = notes
        )
    }

    fun upsertDailyStats(
        context: Context,
        personId: String,
        pv: Int,
        gpv: Int,
        count: Int,
        date: LocalDate = LocalDate.now(),
        confirmed: Boolean = true
    ): NetworkData {
        val current = load(context)
        val key = date.toString()
        val replacement = DailyNetworkStats(
            personId = personId,
            isoDate = key,
            pv = pv.coerceAtLeast(0),
            gpv = gpv.coerceAtLeast(0),
            count = count.coerceAtLeast(0),
            confirmed = confirmed,
            savedAt = if (confirmed) System.currentTimeMillis() else 0L
        )
        val next = current.copy(
            dailyStats = current.dailyStats.filterNot { it.personId == personId && it.isoDate == key } + replacement
        )
        save(context, next)
        return next
    }

    fun addPerson(context: Context, name: String, parentId: String? = null): NetworkPerson {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Person name cannot be blank" }
        val current = load(context)
        require(parentId == null || current.people.any { it.id == parentId }) { "Parent person not found" }
        val person = NetworkPerson(name = cleanName, parentId = parentId)
        save(context, current.copy(people = current.people + person))
        return person
    }

    fun renamePerson(context: Context, personId: String, name: String): NetworkData {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Person name cannot be blank" }
        val current = load(context)
        require(current.people.any { it.id == personId }) { "Person not found" }
        return current.copy(people = current.people.map { if (it.id == personId) it.copy(name = cleanName) else it })
            .also { save(context, it) }
    }

    /** Deletes a person and their complete descendant branch, including branch-owned data. */
    fun deletePersonBranch(context: Context, personId: String): NetworkData {
        val current = load(context)
        val removedIds = buildSet {
            fun collect(id: String) {
                if (!add(id)) return
                current.people.filter { it.parentId == id }.forEach { collect(it.id) }
            }
            collect(personId)
        }
        val removedProspectIds = current.prospects.filter { it.ownerPersonId in removedIds }.mapTo(mutableSetOf()) { it.id }
        val next = current.copy(
            people = current.people.filterNot { it.id in removedIds },
            dailyStats = current.dailyStats.filterNot { it.personId in removedIds },
            prospects = current.prospects.filterNot { it.ownerPersonId in removedIds },
            prospectActions = current.prospectActions.filterNot { it.prospectId in removedProspectIds },
            todos = current.todos.filterNot { it.personId in removedIds },
            coachingNotes = current.coachingNotes.filterNot { it.personId in removedIds }
        )
        save(context, next)
        return next
    }

    fun addProspect(context: Context, ownerPersonId: String, name: String): Prospect {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Prospect name cannot be blank" }
        val current = load(context)
        require(current.people.any { it.id == ownerPersonId }) { "Owner person not found" }
        val prospect = Prospect(ownerPersonId = ownerPersonId, name = cleanName)
        save(context, current.copy(prospects = current.prospects + prospect))
        return prospect
    }

    /** Returns the existing profile for this owner/name, otherwise creates it.
     * Prospect names are compared trimmed + case-insensitively so repeated actions
     * append to one persistent profile instead of creating duplicate rows.
     */
    fun addOrGetProspect(context: Context, ownerPersonId: String, name: String): Prospect {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Prospect name cannot be blank" }
        val current = load(context)
        require(current.people.any { it.id == ownerPersonId }) { "Owner person not found" }
        current.prospects.firstOrNull {
            it.ownerPersonId == ownerPersonId && it.name.trim().equals(cleanName, ignoreCase = true)
        }?.let { return it }
        return addProspect(context, ownerPersonId, cleanName)
    }

    fun addProspectAction(
        context: Context,
        prospectId: String,
        type: ProspectActionType? = null,
        description: String = ""
    ): ProspectAction {
        val current = load(context)
        require(current.prospects.any { it.id == prospectId }) { "Prospect not found" }
        val action = ProspectAction(prospectId = prospectId, type = type, description = description.trim())
        save(context, current.copy(prospectActions = current.prospectActions + action))
        return action
    }

    fun addTodo(context: Context, personId: String, title: String, description: String = ""): PersonTodo {
        val cleanTitle = title.trim()
        require(cleanTitle.isNotEmpty()) { "Todo title cannot be blank" }
        val current = load(context)
        require(current.people.any { it.id == personId }) { "Person not found" }
        val todo = PersonTodo(personId = personId, title = cleanTitle, description = description.trim())
        save(context, current.copy(todos = current.todos + todo))
        return todo
    }

    fun updateTodo(
        context: Context,
        todoId: String,
        title: String? = null,
        description: String? = null,
        done: Boolean? = null
    ): NetworkData {
        val current = load(context)
        require(current.todos.any { it.id == todoId }) { "Todo not found" }
        val now = System.currentTimeMillis()
        val next = current.copy(todos = current.todos.map { todo ->
            if (todo.id != todoId) todo else todo.copy(
                title = title?.trim()?.takeIf { it.isNotEmpty() } ?: todo.title,
                description = description?.trim() ?: todo.description,
                done = done ?: todo.done,
                completedAt = when {
                    done == true && !todo.done -> now
                    done == false -> null
                    else -> todo.completedAt
                }
            )
        })
        save(context, next)
        return next
    }

    fun deleteTodo(context: Context, todoId: String): NetworkData {
        val current = load(context)
        return current.copy(todos = current.todos.filterNot { it.id == todoId }).also { save(context, it) }
    }

    fun addCoachingNote(context: Context, personId: String, text: String): CoachingNote {
        val cleanText = text.trim()
        require(cleanText.isNotEmpty()) { "Coaching note cannot be blank" }
        val current = load(context)
        require(current.people.any { it.id == personId }) { "Person not found" }
        val note = CoachingNote(personId = personId, text = cleanText)
        save(context, current.copy(coachingNotes = current.coachingNotes + note))
        return note
    }

    fun updateCoachingNote(context: Context, noteId: String, text: String): NetworkData {
        val cleanText = text.trim()
        require(cleanText.isNotEmpty()) { "Coaching note cannot be blank" }
        val current = load(context)
        require(current.coachingNotes.any { it.id == noteId }) { "Coaching note not found" }
        val next = current.copy(coachingNotes = current.coachingNotes.map {
            if (it.id == noteId) it.copy(text = cleanText, updatedAt = System.currentTimeMillis()) else it
        })
        save(context, next)
        return next
    }

    fun deleteCoachingNote(context: Context, noteId: String): NetworkData {
        val current = load(context)
        return current.copy(coachingNotes = current.coachingNotes.filterNot { it.id == noteId }).also { save(context, it) }
    }

    fun prospectsFor(data: NetworkData, ownerPersonId: String): List<Prospect> =
        data.prospects.filter { it.ownerPersonId == ownerPersonId }.sortedByDescending { it.createdAt }

    fun actionsFor(data: NetworkData, prospectId: String): List<ProspectAction> =
        data.prospectActions.filter { it.prospectId == prospectId }.sortedByDescending { it.createdAt }

    fun todosFor(data: NetworkData, personId: String): List<PersonTodo> =
        data.todos.filter { it.personId == personId }.sortedWith(compareBy<PersonTodo> { it.done }.thenByDescending { it.createdAt })

    fun coachingNotesFor(data: NetworkData, personId: String): List<CoachingNote> =
        data.coachingNotes.filter { it.personId == personId }.sortedByDescending { it.createdAt }

    /** Direct children only; used by the expandable/collapsible tree UI. */
    fun directChildren(data: NetworkData, parentId: String?): List<NetworkPerson> =
        data.people.filter { it.parentId == parentId }.sortedBy { it.createdAt }

    /** Lightweight name search for the tree search box. */
    fun searchPeople(data: NetworkData, query: String): List<NetworkPerson> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        return data.people.filter { it.name.contains(q, ignoreCase = true) }.sortedBy { it.name }
    }

    fun statsHistory(data: NetworkData, personId: String): List<DailyNetworkStats> =
        data.dailyStats.filter { it.personId == personId }.sortedByDescending { it.isoDate }

    fun needsDailyConfirmation(data: NetworkData, personId: String, date: LocalDate = LocalDate.now()): Boolean =
        data.statsFor(personId, date)?.confirmed != true

    /** A confirmed save is the only operation that clears the red daily-status dot. */
    fun confirmToday(
        context: Context,
        personId: String,
        pv: Int,
        gpv: Int,
        count: Int,
        date: LocalDate = LocalDate.now()
    ): NetworkData = upsertDailyStats(context, personId, pv, gpv, count, date, confirmed = true)


    /**
     * One-time compatibility bridge from the tree_state_v1 model used by v145 and earlier.
     * The legacy preference is intentionally left untouched until the redesigned Tree UI is
     * switched over, so this migration is non-destructive and rollback-safe.
     */
    private fun migrateLegacyTree(context: Context): NetworkData {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("tree_state_v1", null) ?: return NetworkData()
        return runCatching {
            val root = JSONObject(raw)
            val legacyPeople = root.optJSONArray("people") ?: JSONArray()
            val people = buildList {
                for (i in 0 until legacyPeople.length()) {
                    val o = legacyPeople.optJSONObject(i) ?: continue
                    val id = o.optString("id").ifBlank { UUID.randomUUID().toString() }
                    add(NetworkPerson(
                        id = id,
                        name = o.optString("name").trim().ifBlank { "بدون نام" },
                        parentId = if (o.isNull("parentId")) null else o.optString("parentId").takeIf { it.isNotBlank() }
                    ))
                }
            }
            val validIds = people.mapTo(mutableSetOf()) { it.id }
            val normalizedPeople = people.map { p -> p.copy(parentId = p.parentId?.takeIf { it in validIds && it != p.id }) }

            val statsByKey = linkedMapOf<String, DailyNetworkStats>()
            fun captureStats(array: JSONArray?, isoDate: String, confirmed: Boolean) {
                if (array == null || isoDate.isBlank()) return
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val personId = o.optString("id")
                    if (personId !in validIds) continue
                    statsByKey["$personId|$isoDate"] = DailyNetworkStats(
                        personId = personId, isoDate = isoDate,
                        pv = o.optInt("pv", o.optInt("sales", 0)).coerceAtLeast(0),
                        gpv = o.optInt("gpv", 0).coerceAtLeast(0),
                        count = o.optInt("active", 0).coerceAtLeast(0),
                        confirmed = confirmed, savedAt = 0L
                    )
                }
            }
            val snapshots = root.optJSONArray("snapshots")
            if (snapshots != null) for (i in 0 until snapshots.length()) {
                val snap = snapshots.optJSONObject(i) ?: continue
                captureStats(snap.optJSONArray("people"), snap.optString("key"), true)
            }
            // Current legacy values are useful even when the old build has no snapshot yet.
            captureStats(legacyPeople, LocalDate.now().toString(), false)

            val prospects = mutableListOf<Prospect>()
            val actions = mutableListOf<ProspectAction>()
            val todos = mutableListOf<PersonTodo>()
            val notes = mutableListOf<CoachingNote>()
            for (i in 0 until legacyPeople.length()) {
                val o = legacyPeople.optJSONObject(i) ?: continue
                val ownerId = o.optString("id")
                if (ownerId !in validIds) continue

                val prospectByName = linkedMapOf<String, Prospect>()
                val contacts = o.optJSONArray("contacts")
                if (contacts != null) for (j in 0 until contacts.length()) {
                    val c = contacts.optJSONObject(j) ?: continue
                    val name = c.optString("name").trim()
                    if (name.isBlank()) continue
                    val prospect = Prospect(
                        id = c.optString("id").ifBlank { UUID.randomUUID().toString() },
                        ownerPersonId = ownerId, name = name
                    )
                    prospects += prospect
                    prospectByName[name.lowercase(Locale.getDefault())] = prospect
                }

                val legacyActions = o.optJSONArray("actions") ?: o.optJSONArray("network")
                if (legacyActions != null) for (j in 0 until legacyActions.length()) {
                    val a = legacyActions.optJSONObject(j) ?: continue
                    val prospectName = a.optString("prospectName").trim().ifBlank { "بدون نام" }
                    val key = prospectName.lowercase(Locale.getDefault())
                    val prospect = prospectByName[key] ?: Prospect(ownerPersonId = ownerId, name = prospectName).also {
                        prospects += it; prospectByName[key] = it
                    }
                    actions += ProspectAction(
                        id = a.optString("id").ifBlank { UUID.randomUUID().toString() },
                        prospectId = prospect.id, type = legacyActionType(a.optString("type")),
                        description = listOf(a.optString("result"), a.optString("nextAction"))
                            .filter { it.isNotBlank() }.joinToString(" • ")
                    )
                }

                val legacyTodos = o.optJSONArray("todos")
                if (legacyTodos != null) for (j in 0 until legacyTodos.length()) {
                    val t = legacyTodos.optJSONObject(j) ?: continue
                    val title = t.optString("text").trim()
                    if (title.isNotBlank()) todos += PersonTodo(
                        id = t.optString("id").ifBlank { UUID.randomUUID().toString() },
                        personId = ownerId, title = title, done = t.optBoolean("done", false)
                    )
                }
                val noteText = o.optString("notes").trim()
                if (noteText.isNotBlank()) notes += CoachingNote(personId = ownerId, text = noteText)
            }
            NetworkData(
                people = normalizedPeople, dailyStats = statsByKey.values.toList(),
                prospects = prospects.distinctBy { it.id }, prospectActions = actions.distinctBy { it.id },
                todos = todos.distinctBy { it.id }, coachingNotes = notes
            )
        }.getOrElse { NetworkData() }
    }

    private fun legacyActionType(raw: String): ProspectActionType? {
        val value = raw.trim().lowercase(Locale.getDefault())
        return when {
            value.contains("ارتباط") || value.contains("network") -> ProspectActionType.Networking
            value.contains("پیش") || value.contains("consult") -> ProspectActionType.PreConsultation
            value.contains("دعوت") || value.contains("invite") -> ProspectActionType.Invitation
            value.contains("معرفی کار") || value.contains("business") -> ProspectActionType.BusinessPresentation
            value.contains("فالو") || value.contains("follow") -> ProspectActionType.FollowUp
            value == "pp" || value.contains("پی پی") -> ProspectActionType.Pp
            value.contains("محصول") || value.contains("product") -> ProspectActionType.ProductPresentation
            else -> null
        }
    }

    private fun encode(data: NetworkData) = JSONObject().apply {
        put("version", data.version)
        put("people", JSONArray().apply { data.people.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("name", p.name); putNullable("parentId", p.parentId); put("createdAt", p.createdAt)
        }) } })
        put("dailyStats", JSONArray().apply { data.dailyStats.forEach { s -> put(JSONObject().apply {
            put("personId", s.personId); put("isoDate", s.isoDate); put("pv", s.pv); put("gpv", s.gpv)
            put("count", s.count); put("confirmed", s.confirmed); put("savedAt", s.savedAt)
        }) } })
        put("prospects", JSONArray().apply { data.prospects.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("ownerPersonId", p.ownerPersonId); put("name", p.name); put("createdAt", p.createdAt)
        }) } })
        put("prospectActions", JSONArray().apply { data.prospectActions.forEach { a -> put(JSONObject().apply {
            put("id", a.id); put("prospectId", a.prospectId); putNullable("type", a.type?.name)
            put("description", a.description); put("createdAt", a.createdAt)
        }) } })
        put("todos", JSONArray().apply { data.todos.forEach { t -> put(JSONObject().apply {
            put("id", t.id); put("personId", t.personId); put("title", t.title); put("description", t.description)
            put("done", t.done); put("createdAt", t.createdAt); putNullable("completedAt", t.completedAt)
        }) } })
        put("coachingNotes", JSONArray().apply { data.coachingNotes.forEach { n -> put(JSONObject().apply {
            put("id", n.id); put("personId", n.personId); put("text", n.text); put("createdAt", n.createdAt); put("updatedAt", n.updatedAt)
        }) } })
    }

    private fun decode(root: JSONObject): NetworkData = NetworkData(
        version = root.optInt("version", NETWORK_DATA_VERSION),
        people = root.arrayObjects("people").map { o -> NetworkPerson(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = o.optString("name"), parentId = o.optNullableString("parentId"), createdAt = o.optLong("createdAt", 0L)
        ) },
        dailyStats = root.arrayObjects("dailyStats").map { o -> DailyNetworkStats(
            personId = o.optString("personId"), isoDate = o.optString("isoDate"), pv = o.optInt("pv"),
            gpv = o.optInt("gpv"), count = o.optInt("count"), confirmed = o.optBoolean("confirmed"), savedAt = o.optLong("savedAt")
        ) },
        prospects = root.arrayObjects("prospects").map { o -> Prospect(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() }, ownerPersonId = o.optString("ownerPersonId"),
            name = o.optString("name"), createdAt = o.optLong("createdAt", 0L)
        ) },
        prospectActions = root.arrayObjects("prospectActions").map { o -> ProspectAction(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() }, prospectId = o.optString("prospectId"),
            type = o.optNullableString("type")?.let { runCatching { ProspectActionType.valueOf(it) }.getOrNull() },
            description = o.optString("description"), createdAt = o.optLong("createdAt", 0L)
        ) },
        todos = root.arrayObjects("todos").map { o -> PersonTodo(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() }, personId = o.optString("personId"),
            title = o.optString("title"), description = o.optString("description"), done = o.optBoolean("done"),
            createdAt = o.optLong("createdAt", 0L), completedAt = o.optNullableLong("completedAt")
        ) },
        coachingNotes = root.arrayObjects("coachingNotes").map { o -> CoachingNote(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() }, personId = o.optString("personId"),
            text = o.optString("text"), createdAt = o.optLong("createdAt", 0L), updatedAt = o.optLong("updatedAt", 0L)
        ) }
    )
}

private fun JSONObject.putNullable(key: String, value: Any?) {
    if (value == null) put(key, JSONObject.NULL) else put(key, value)
}

private fun JSONObject.arrayObjects(key: String): List<JSONObject> {
    val array = optJSONArray(key) ?: return emptyList()
    return buildList { for (i in 0 until array.length()) array.optJSONObject(i)?.let(::add) }
}

private fun JSONObject.optNullableString(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

private fun JSONObject.optNullableLong(key: String): Long? =
    if (!has(key) || isNull(key)) null else optLong(key)
