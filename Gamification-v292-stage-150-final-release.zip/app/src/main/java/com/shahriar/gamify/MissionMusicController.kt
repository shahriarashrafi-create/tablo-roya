package com.shahriar.gamify

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * Stage 38: five bundled one-minute focus moods.
 * A session chooses exactly one track from its stable sessionId and keeps looping
 * that same track until the mission is resolved. A new session may choose another.
 */
internal object MissionMusicController {
    private var player: MediaPlayer? = null
    private var playingSessionId: Long = 0L
    private var mutedSessionId: Long = 0L
    private var playingTrackIndex: Int = -1

    private val focusTracks = intArrayOf(
        R.raw.mission_focus_calm,
        R.raw.mission_focus_drive,
        R.raw.mission_focus_deep,
        R.raw.mission_focus_bright,
        R.raw.mission_focus_night
    )

    private fun trackIndexFor(sessionId: Long): Int {
        val mixed = sessionId xor (sessionId ushr 32)
        return ((mixed and Long.MAX_VALUE) % focusTracks.size).toInt()
    }

    @Synchronized
    fun ensureForTimer(context: Context, settings: GameSettings, state: ActiveTimerState?) {
        if (!settings.soundEnabled || state == null || !state.isRunning || remainingSeconds(context, state) <= 0) {
            stopPlayback()
            return
        }

        if (mutedSessionId != 0L && mutedSessionId != state.sessionId) mutedSessionId = 0L
        if (mutedSessionId == state.sessionId) {
            stopPlayback()
            return
        }

        val trackIndex = trackIndexFor(state.sessionId)
        val current = player
        if (playingSessionId == state.sessionId && playingTrackIndex == trackIndex && current != null && current.isPlaying) return

        stopPlayback()
        val appContext = context.applicationContext
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val mediaPlayer = MediaPlayer.create(appContext, focusTracks[trackIndex], attributes, 0) ?: return
        mediaPlayer.isLooping = true
        mediaPlayer.setVolume(0.42f, 0.42f)
        mediaPlayer.setOnErrorListener { mp, _, _ ->
            runCatching { mp.release() }
            synchronized(this) {
                if (player === mp) {
                    player = null
                    playingSessionId = 0L
                    playingTrackIndex = -1
                }
            }
            true
        }
        mediaPlayer.start()
        player = mediaPlayer
        playingSessionId = state.sessionId
        playingTrackIndex = trackIndex
    }

    @Synchronized
    fun isMuted(sessionId: Long): Boolean = mutedSessionId == sessionId

    @Synchronized
    fun setMuted(context: Context, settings: GameSettings, state: ActiveTimerState, muted: Boolean) {
        mutedSessionId = if (muted) state.sessionId else 0L
        if (muted) stopPlayback() else ensureForTimer(context, settings, state)
    }

    /** Stage 39: stop audible playback while the app is backgrounded without
     * clearing the session mute choice. The mission timer continues independently. */
    @Synchronized
    fun pauseForBackground() {
        stopPlayback()
    }

    @Synchronized
    fun stop() {
        stopPlayback()
        mutedSessionId = 0L
    }

    private fun stopPlayback() {
        val current = player
        player = null
        playingSessionId = 0L
        playingTrackIndex = -1
        if (current != null) {
            runCatching { if (current.isPlaying) current.stop() }
            runCatching { current.release() }
        }
    }
}
