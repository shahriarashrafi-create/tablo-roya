package com.shahriar.gamify

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Shared visual tokens for Gamification.
 *
 * Stage 2A centralizes color, spacing, corner radius and input contrast so every
 * screen can use the same visual rules. Stage 2B applies these tokens across
 * every remaining screen and audits small-screen/RTL behavior.
 */
internal val Bg = Color(0xFF0C1320)
internal val Gold = Color(0xFFF7C948)
internal val GoldSoft = Color(0xFFFCE9A7)
internal val TextSoft = Color(0xFFD8DFE8)
internal val Divider = Color(0xFF2A3440)
internal val Blue = Color(0xFF5CA3FF)

internal object GamifyColors {
    val Background = Bg
    val Surface = Color(0xFF111923)
    val SurfaceRaised = Color(0xFF16202B)
    val SurfaceInput = Color(0xFF141D27)
    val SurfaceInputFocused = Color(0xFF17222E)
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = TextSoft
    val TextMuted = Color(0xFFAAB5C2)
    val Border = Color(0xFF647385)
    val BorderSoft = Color(0xFF34404D)
    val Success = Color(0xFF59C887)
    val Error = Color(0xFFFF7A7A)
    val Warning = Gold
}


/** Stage 55 — one typography scale shared by every game module. */
internal object GamifyType {
    val Hero = TextStyle(fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
    val ScreenTitle = TextStyle(fontSize = 20.sp, lineHeight = 24.sp, fontWeight = FontWeight.ExtraBold)
    val SectionTitle = TextStyle(fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold)
    val CardTitle = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold)
    val Body = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Normal)
    val BodyStrong = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.SemiBold)
    val Label = TextStyle(fontSize = 10.sp, lineHeight = 13.sp, fontWeight = FontWeight.Medium)
    val Caption = TextStyle(fontSize = 9.sp, lineHeight = 12.sp, fontWeight = FontWeight.Normal)
    val Button = TextStyle(fontSize = 12.sp, lineHeight = 15.sp, fontWeight = FontWeight.Bold)
    val Number = TextStyle(fontSize = 16.sp, lineHeight = 19.sp, fontWeight = FontWeight.ExtraBold)
    val HudPrimary = TextStyle(fontSize = 12.sp, lineHeight = 13.sp, fontWeight = FontWeight.Bold)
    val HudSecondary = TextStyle(fontSize = 8.sp, lineHeight = 10.sp, fontWeight = FontWeight.Medium)
}

private val GamifyTypography = Typography(
    displaySmall = GamifyType.Hero,
    headlineSmall = GamifyType.ScreenTitle,
    titleLarge = GamifyType.ScreenTitle,
    titleMedium = GamifyType.SectionTitle,
    titleSmall = GamifyType.CardTitle,
    bodyLarge = GamifyType.Body,
    bodyMedium = GamifyType.Body,
    bodySmall = GamifyType.Caption,
    labelLarge = GamifyType.Button,
    labelMedium = GamifyType.Label,
    labelSmall = GamifyType.Caption
)

internal object GamifySpacing {
    val Xs = 4.dp
    val Sm = 8.dp
    val Md = 12.dp
    val Lg = 16.dp
    val Xl = 24.dp

    // Stage 57 — canonical layout rhythm. These semantic values keep screen
    // edges, section gaps and card internals visually consistent.
    val ScreenTop = 10.dp
    val ScreenBottom = 54.dp
    val SectionGap = 16.dp
    val CardGap = 14.dp
    val CardHorizontal = 18.dp
    val CardVertical = 16.dp
    val InlineGap = 8.dp
    val CompactGap = 6.dp
}

/** Stage 56 — canonical icon geometry.
 * Visual glyphs stay deliberately smaller than their touch targets so icons do
 * not dominate labels/cards. Touch targets remain 38–48dp where needed.
 */
internal object GamifyIcons {
    val Tiny = 12.dp
    val Small = 16.dp
    val Standard = 20.dp
    val Navigation = 20.dp
    val Feature = 22.dp
    val Hero = 28.dp
    val Stroke = 1.45.dp
}

/** Stage 60 — final shared motion/elevation tokens for the internal design system.
 * Feature screens can still use intentional hero treatments, but routine UI
 * should use these values instead of inventing another visual rhythm.
 */
internal object GamifyMotion {
    const val FastMs = 140
    const val StandardMs = 220
    const val EmphasisMs = 360
    const val CelebrationMs = 900
}

internal object GamifyElevation {
    val Flat = 0.dp
    val Card = 2.dp
    val Floating = 6.dp
}

internal object GamifyDimens {
    val FieldMinHeight = 52.dp
    val CompactFieldHeight = 42.dp
    val ButtonHeight = 52.dp
    val DialogRadius = 24.dp
    val CardRadius = 20.dp
    val FieldRadius = 14.dp
    val ChipRadius = 11.dp
    val TouchTarget = 48.dp
    val CompactButtonHeight = 42.dp
    val ScreenHorizontalPadding = 16.dp
    val ScreenHorizontalPaddingCompact = 12.dp
}

@Composable
internal fun gamifyHorizontalPadding(): Dp =
    if (LocalConfiguration.current.screenWidthDp < 360) GamifyDimens.ScreenHorizontalPaddingCompact
    else GamifyDimens.ScreenHorizontalPadding

@Composable
internal fun gamifyDialogMaxHeight(max: Dp = 620.dp): Dp {
    val available = (LocalConfiguration.current.screenHeightDp.dp - 170.dp).coerceAtLeast(320.dp)
    return available.coerceAtMost(max)
}

@Composable
internal fun gamifyCompactScreen(): Boolean =
    LocalConfiguration.current.screenHeightDp < 720 || LocalConfiguration.current.screenWidthDp < 360



/** Stage 58 — one semantic button language for the whole app. */
internal enum class GamifyButtonStyle { Primary, Secondary, Success, Danger, Warning }

@Composable
internal fun GamifyActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: GamifyButtonStyle = GamifyButtonStyle.Primary
) {
    val container = when (style) {
        GamifyButtonStyle.Primary -> Gold
        GamifyButtonStyle.Secondary -> GamifyColors.SurfaceRaised
        GamifyButtonStyle.Success -> GamifyColors.Success
        GamifyButtonStyle.Danger -> GamifyColors.Error
        GamifyButtonStyle.Warning -> GamifyColors.Warning
    }
    val content = when (style) {
        GamifyButtonStyle.Primary, GamifyButtonStyle.Warning -> Color(0xFF211800)
        else -> Color.White
    }
    val disabledContainer = GamifyColors.BorderSoft.copy(alpha = 0.58f)
    val disabledContent = GamifyColors.TextMuted.copy(alpha = 0.72f)
    val shape = RoundedCornerShape(GamifyDimens.FieldRadius)

    if (style == GamifyButtonStyle.Secondary) {
        OutlinedButton(
            onClick = onClick, enabled = enabled, modifier = modifier, shape = shape,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = GamifyColors.TextPrimary, disabledContentColor = disabledContent
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp, if (enabled) GamifyColors.Border else GamifyColors.BorderSoft.copy(alpha = 0.5f)
            )
        ) { Text(text, style = GamifyType.Button) }
    } else {
        Button(
            onClick = onClick, enabled = enabled, modifier = modifier, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = container, contentColor = content,
                disabledContainerColor = disabledContainer, disabledContentColor = disabledContent
            )
        ) { Text(text, style = GamifyType.Button) }
    }
}

internal object GamifyShapes {
    val Dialog = RoundedCornerShape(GamifyDimens.DialogRadius)
    val Card = RoundedCornerShape(GamifyDimens.CardRadius)
    val Field = RoundedCornerShape(GamifyDimens.FieldRadius)
    val Chip = RoundedCornerShape(GamifyDimens.ChipRadius)
}

private val GamifyColorScheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF211800),
    secondary = GoldSoft,
    onSecondary = Color(0xFF211800),
    background = Bg,
    onBackground = GamifyColors.TextPrimary,
    surface = GamifyColors.Surface,
    onSurface = GamifyColors.TextPrimary,
    surfaceVariant = GamifyColors.SurfaceRaised,
    onSurfaceVariant = GamifyColors.TextSecondary,
    outline = GamifyColors.Border,
    error = GamifyColors.Error,
    onError = Color(0xFF260000)
)

@Composable
internal fun GamifyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GamifyColorScheme,
        typography = GamifyTypography,
        shapes = MaterialTheme.shapes.copy(
            small = GamifyShapes.Chip,
            medium = GamifyShapes.Field,
            large = GamifyShapes.Dialog
        ),
        content = content
    )
}

/** High-contrast field palette used app-wide. */
@Composable
internal fun gamifyTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = GamifyColors.TextPrimary,
    unfocusedTextColor = GamifyColors.TextPrimary,
    disabledTextColor = Color(0xFFB8C0CA),
    focusedContainerColor = GamifyColors.SurfaceInputFocused,
    unfocusedContainerColor = GamifyColors.SurfaceInput,
    disabledContainerColor = Color(0xB3121922),
    cursorColor = Gold,
    focusedBorderColor = Gold,
    unfocusedBorderColor = GamifyColors.Border,
    disabledBorderColor = Color(0xFF3A4653),
    errorTextColor = GamifyColors.TextPrimary,
    errorContainerColor = GamifyColors.SurfaceInput,
    errorCursorColor = GamifyColors.Error,
    errorBorderColor = GamifyColors.Error,
    errorLabelColor = GamifyColors.Error,
    focusedLabelColor = GoldSoft,
    unfocusedLabelColor = Color(0xFFE0E6ED),
    disabledLabelColor = Color(0xFF8D98A5),
    focusedPlaceholderColor = GamifyColors.TextMuted,
    unfocusedPlaceholderColor = GamifyColors.TextMuted
)

/** Compatibility name for screens that previously had their own field palette. */
@Composable
internal fun readableOutlinedFieldColors() = gamifyTextFieldColors()

/**
 * Stage 20 — shared visual language for the Network Tree and every person sub-page.
 * Keeping these tokens here prevents each page from drifting into a different palette.
 */
internal object NetworkUi {
    val BackgroundTop = Color(0xFF132132)
    val BackgroundMid = Color(0xFF172536)
    val BackgroundBottom = Color(0xFF0D1722)
    // Stage 54: network panels now use the same surface hierarchy as every internal module.
    val Panel = GamifyColors.Surface.copy(alpha = 0.95f)
    val PanelStrong = GamifyColors.SurfaceRaised.copy(alpha = 0.98f)
    val Card = GamifyColors.SurfaceRaised.copy(alpha = 0.92f)
    val CardSoft = GamifyColors.Surface.copy(alpha = 0.78f)
    val Control = GamifyColors.SurfaceInput.copy(alpha = 0.94f)
    val ControlSoft = GamifyColors.BorderSoft.copy(alpha = 0.42f)
    val Primary = Gold
    val OnPrimary = Color(0xFF17202A)
    val PrimaryText = GamifyColors.TextPrimary
    val SecondaryText = Color(0xFFB8C7D5)
    val MutedText = Color(0xFF91A4B6)
    val QuietText = Color(0xFF8195A8)
    val Placeholder = Color(0xFF8296A9)
    val SuccessText = Color(0xFF8ED6A7)
    val ErrorText = Color(0xFFFFA2A7)
    val Danger = Color(0xFF713A43)
    val DangerStrong = Color(0xFF7A2631)
    val DangerSoft = Color(0xFF5A2730)
    val DangerText = Color(0xFFFFC0C4)
    val PanelRadius = GamifyDimens.DialogRadius
    val CardRadius = GamifyDimens.CardRadius
    val CompactRadius = GamifyDimens.FieldRadius
}
