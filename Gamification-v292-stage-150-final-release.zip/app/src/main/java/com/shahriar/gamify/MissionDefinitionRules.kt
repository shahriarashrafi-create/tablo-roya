package com.shahriar.gamify

/**
 * Stage 26 mission-domain rules.
 *
 * UI work in the next stages can consume these rules without duplicating
 * duration, repeat and importance/reward logic in Compose.
 */
internal object MissionDefinitionRules {
    const val DEFAULT_DURATION_MINUTES = 10
    const val MIN_DURATION_MINUTES = 1
    const val MAX_DURATION_MINUTES = 24 * 60

    fun normalizedDuration(minutes: Int): Int =
        minutes.coerceIn(MIN_DURATION_MINUTES, MAX_DURATION_MINUTES)

    fun xpFor(importance: MissionImportance): Int = when (importance) {
        MissionImportance.Low -> 10
        MissionImportance.Medium -> 20
        MissionImportance.High -> 30
    }

    fun coinsFor(importance: MissionImportance): Int = when (importance) {
        MissionImportance.Low -> 5
        MissionImportance.Medium -> 10
        MissionImportance.High -> 15
    }

    fun withCanonicalRewards(mission: Mission): Mission = mission.copy(
        durationMinutes = normalizedDuration(mission.durationMinutes),
        xpReward = xpFor(mission.importance),
        coinReward = coinsFor(mission.importance)
    )

    fun isOneTime(repeat: MissionRepeat): Boolean = repeat == MissionRepeat.None
    fun isDaily(repeat: MissionRepeat): Boolean = repeat == MissionRepeat.Daily
}
