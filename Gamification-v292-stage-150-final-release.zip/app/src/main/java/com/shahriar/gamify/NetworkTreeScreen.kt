package com.shahriar.gamify

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.delay
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.max
import kotlin.math.min
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId

private enum class PersonSection { PROSPECTS, ADD_DIRECT, TODOS, HISTORY, COACHING }

private data class NetworkNodeLayout(val person: NetworkPerson, val center: Offset, val hasChildren: Boolean)

// Stage 131: one derived daily pulse is the bridge between real network work and
// the gamification layer. No duplicate state is stored: every number comes from
// NetworkData records and respects the configured mission-day boundary.
private data class NetworkGamificationPulse(
    val actions: Int,
    val completedTodos: Int,
    val confirmedPeople: Int,
    val activityPoints: Int
)

private data class BranchRankingEntry(
    val personId: String,
    val name: String,
    val score: Int
)

private data class NetworkGamificationSnapshot(
    val pulse: NetworkGamificationPulse,
    val personScores: Map<String, Int>,
    val branchScores: Map<String, Int>,
    val branchRanking: List<BranchRankingEntry>
)

// Stage 140: one canonical projection now powers Network Pulse, per-person scores,
// recursive branch totals and ranking. This prevents the same mission-day rules and
// activity weights from drifting across separate UI calculations.
private fun buildNetworkGamificationSnapshot(
    context: android.content.Context,
    data: NetworkData
): NetworkGamificationSnapshot {
    val day = currentMissionDay(context)
    val zone = ZoneId.systemDefault()
    val boundaryHour = loadSettings(context).dayStartHour.coerceIn(0, 23)
    fun belongsToDay(epochMillis: Long): Boolean {
        val local = Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDateTime()
        val effective = if (local.hour < boundaryHour) local.toLocalDate().minusDays(1) else local.toLocalDate()
        return effective == day
    }

    val prospectOwner = data.prospects.associate { it.id to it.ownerPersonId }
    val scores = mutableMapOf<String, Int>()
    var actions = 0
    var completedTodos = 0
    var confirmedPeople = 0

    data.prospectActions.filter { belongsToDay(it.createdAt) }.forEach { action ->
        actions += 1
        prospectOwner[action.prospectId]?.let { owner -> scores[owner] = (scores[owner] ?: 0) + 10 }
    }
    data.todos.filter { it.done && it.completedAt?.let(::belongsToDay) == true }.forEach { todo ->
        completedTodos += 1
        scores[todo.personId] = (scores[todo.personId] ?: 0) + 15
    }
    data.dailyStats.filter { it.confirmed && it.isoDate == day.toString() }.forEach { stat ->
        confirmedPeople += 1
        scores[stat.personId] = (scores[stat.personId] ?: 0) + 20
    }

    val pulse = NetworkGamificationPulse(
        actions = actions,
        completedTodos = completedTodos,
        confirmedPeople = confirmedPeople,
        activityPoints = actions * 10 + completedTodos * 15 + confirmedPeople * 20
    )

    val childrenByParent = data.people.groupBy { it.parentId }
    val branchScores = mutableMapOf<String, Int>()
    val visiting = mutableSetOf<String>()
    fun branchScore(personId: String): Int {
        branchScores[personId]?.let { return it }
        if (!visiting.add(personId)) return scores[personId] ?: 0
        val total = (scores[personId] ?: 0) + childrenByParent[personId].orEmpty().sumOf { branchScore(it.id) }
        visiting.remove(personId)
        branchScores[personId] = total
        return total
    }
    data.people.forEach { branchScore(it.id) }

    val ranking = data.people
        .filter { leader -> childrenByParent[leader.id].orEmpty().isNotEmpty() }
        .map { BranchRankingEntry(it.id, it.name, branchScores[it.id] ?: 0) }
        .sortedWith(compareByDescending<BranchRankingEntry> { it.score }.thenBy { it.name.lowercase() })
        .take(3)

    return NetworkGamificationSnapshot(pulse, scores.toMap(), branchScores.toMap(), ranking)
}

@Composable
private fun BranchRankingCard(ranking: List<BranchRankingEntry>) {
    Surface(
        color = Color(0xE6121D2A),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("BRANCH RANKING", color = Color(0xFFF7C948), fontSize = 11.sp, fontWeight = FontWeight.Black)
                Text("TODAY", color = Color(0xFF8FA6BC), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            if (ranking.isEmpty()) {
                Text("No active branches yet", color = Color(0xFF8FA6BC), fontSize = 10.sp)
            } else {
                ranking.forEachIndexed { index, entry ->
                    val medal = when (index) { 0 -> "1"; 1 -> "2"; else -> "3" }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("#$medal  ${entry.name}", color = Color.White, fontSize = 10.sp, fontWeight = if (index == 0) FontWeight.Black else FontWeight.SemiBold)
                        Text("${entry.score} PTS", color = if (index == 0) Color(0xFFF7C948) else Color(0xFFB9C8D8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private const val NETWORK_DAILY_GOAL_POINTS = 300

@Composable
private fun NetworkDailyGoalCard(
    pulse: NetworkGamificationPulse,
    claimed: Boolean,
    onClaim: () -> Unit
) {
    val goal = NETWORK_DAILY_GOAL_POINTS
    val percent = if (goal <= 0) 0 else pulse.activityPoints * 100 / goal
    val progress = (pulse.activityPoints.toFloat() / goal.toFloat()).coerceIn(0f, 1f)
    Surface(
        color = Color(0xE6121D2A),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("DAILY NETWORK GOAL", color = Color(0xFFF7C948), fontSize = 11.sp, fontWeight = FontWeight.Black)
                Text("${pulse.activityPoints} / $goal PTS • $percent%", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Color(0xFF253446), RoundedCornerShape(99.dp))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress)
                        .height(6.dp)
                        .background(if (percent >= 100) Color(0xFFF7C948) else Color(0xFF61D7A8), RoundedCornerShape(99.dp))
                )
            }
            Text(
                if (percent >= 100) "TODAY'S NETWORK GOAL COMPLETE" else "${(goal - pulse.activityPoints).coerceAtLeast(0)} PTS TO TODAY'S GOAL",
                color = if (percent >= 100) Color(0xFFF7C948) else Color(0xFF8FA6BC),
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (percent >= 100) {
                Surface(
                    onClick = { if (!claimed) onClaim() },
                    enabled = !claimed,
                    color = if (claimed) Color(0xFF253446) else Color(0xFFF7C948),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (claimed) "REWARD CLAIMED • +${NETWORK_DAILY_GOAL_REWARD_XP} XP • +${NETWORK_DAILY_GOAL_REWARD_COINS} COINS"
                        else "CLAIM • +${NETWORK_DAILY_GOAL_REWARD_XP} XP • +${NETWORK_DAILY_GOAL_REWARD_COINS} COINS",
                        color = if (claimed) Color(0xFF8FA6BC) else Color(0xFF111820),
                        fontSize = 10.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun NetworkStreakMilestonesCard(
    streak: Int,
    claimed: Set<Int>,
    onClaim: (Int) -> Unit
) {
    Surface(color = Color(0xE6121D2A), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("STREAK MILESTONES", color = Color(0xFFF7C948), fontSize = 11.sp, fontWeight = FontWeight.Black)
            NETWORK_STREAK_MILESTONES.forEach { milestone ->
                val unlocked = streak >= milestone.days
                val isClaimed = milestone.days in claimed
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "${if (unlocked) "🏅" else "🔒"} ${milestone.days} DAYS • ${milestone.title}",
                            color = if (unlocked) Color.White else Color(0xFF718399), fontSize = 9.5.sp, fontWeight = FontWeight.Bold
                        )
                        Text("+${milestone.xp} XP • +${milestone.coins} COINS", color = if (unlocked) Color(0xFF8FE3B0) else Color(0xFF66788B), fontSize = 8.5.sp)
                    }
                    if (unlocked) {
                        Surface(
                            onClick = { if (!isClaimed) onClaim(milestone.days) },
                            enabled = !isClaimed,
                            color = if (isClaimed) Color(0xFF253446) else Color(0xFFF7C948),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (isClaimed) "CLAIMED" else "CLAIM", color = if (isClaimed) Color(0xFF8FA6BC) else Color(0xFF111820), fontSize = 8.5.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkGamificationPulseCard(pulse: NetworkGamificationPulse, awardedXp: Int = 0, streak: Int = 0) {
    Surface(
        color = Color(0xE6121D2A),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("NETWORK PULSE", color = Color(0xFFF7C948), fontSize = 11.sp, fontWeight = FontWeight.Black)
                Text("${pulse.activityPoints} PTS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Actions ${pulse.actions}", color = Color(0xFFB9C8D8), fontSize = 10.sp)
                Text("Todos ${pulse.completedTodos}", color = Color(0xFFB9C8D8), fontSize = 10.sp)
                Text("Saved ${pulse.confirmedPeople}", color = Color(0xFFB9C8D8), fontSize = 10.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("NETWORK STREAK", color = Color(0xFF8FA6BC), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text("🔥 $streak DAY${if (streak == 1) "" else "S"}", color = if (streak > 0) Color(0xFFF7C948) else Color(0xFF8FA6BC), fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
            Text("XP SYNC  +$awardedXp XP this session • each record rewards once", color = Color(0xFF8FE3B0), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun visibleNetworkPeople(data: NetworkData, collapsed: Set<String>): List<NetworkPerson> {
    val result = mutableListOf<NetworkPerson>()
    fun walk(parentId: String?) {
        data.people.filter { it.parentId == parentId }.forEach { person ->
            result += person
            if (person.id !in collapsed) walk(person.id)
        }
    }
    walk(null)
    // Legacy imports can occasionally contain an orphan. Keep it searchable/visible.
    data.people.filter { candidate -> result.none { it.id == candidate.id } }.forEach { result += it }
    return result
}

private fun buildNetworkLayout(data: NetworkData, collapsed: Set<String>): List<NetworkNodeLayout> {
    val visible = visibleNetworkPeople(data, collapsed)
    if (visible.isEmpty()) return emptyList()

    val visibleIds = visible.mapTo(hashSetOf()) { it.id }
    val children = visible.groupBy { it.parentId }
    val result = mutableListOf<NetworkNodeLayout>()

    // Stage 17: tidy-tree layout. Every visible subtree reserves its own horizontal
    // span before nodes are positioned, so wide/deep organizations do not allow
    // cousins or sibling branches to collide with each other.
    val nodeClearance = 142f
    val rootClearance = 176f
    val yGap = 165f
    val spanCache = hashMapOf<String, Float>()

    fun subtreeSpan(person: NetworkPerson): Float {
        spanCache[person.id]?.let { return it }
        val kids = children[person.id].orEmpty().filter { it.id in visibleIds }
        val span = if (kids.isEmpty()) {
            nodeClearance
        } else {
            kids.sumOf { subtreeSpan(it).toDouble() }.toFloat()
                .coerceAtLeast(nodeClearance)
        }
        spanCache[person.id] = span
        return span
    }

    fun place(person: NetworkPerson, depth: Int, left: Float): Float {
        val kids = children[person.id].orEmpty().filter { it.id in visibleIds }
        val ownSpan = subtreeSpan(person)
        val centerX = if (kids.isEmpty()) {
            left + ownSpan / 2f
        } else {
            var cursor = left
            val childCenters = kids.map { child ->
                val childSpan = subtreeSpan(child)
                val childCenter = place(child, depth + 1, cursor)
                cursor += childSpan
                childCenter
            }
            (childCenters.first() + childCenters.last()) / 2f
        }

        result += NetworkNodeLayout(
            person = person,
            center = Offset(centerX, depth * yGap),
            hasChildren = data.people.any { it.parentId == person.id }
        )
        return centerX
    }

    val roots = visible.filter { it.parentId == null || data.people.none { p -> p.id == it.parentId } }
    var rootLeft = 0f
    roots.forEachIndexed { index, root ->
        if (index > 0) rootLeft += rootClearance - nodeClearance
        place(root, 0, rootLeft)
        rootLeft += subtreeSpan(root)
    }

    val minX = result.minOfOrNull { it.center.x } ?: 0f
    return result.map { node ->
        node.copy(center = Offset(node.center.x - minX + 120f, node.center.y + 130f))
    }
}


@Composable
private fun StatEditor(
    label: String, value: String, focusRequester: FocusRequester, imeAction: ImeAction,
    onNext: (() -> Unit)? = null, onDone: (() -> Unit)? = null, onValueChange: (String) -> Unit
) {
    Surface(modifier = Modifier.fillMaxWidth(), color = NetworkUi.CardSoft, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = imeAction),
                keyboardActions = KeyboardActions(onNext = { onNext?.invoke() }, onDone = { onDone?.invoke() }),
                textStyle = TextStyle(color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f).focusRequester(focusRequester)
            )
            Text(label, color = Color(0xFF9FB2C5), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PersonActionTile(label: String, badge: Int = 0, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(18.dp), color = NetworkUi.Card) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 15.dp)) {
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
            if (badge > 0) Surface(shape = CircleShape, color = Color(0xFFFF4D55), modifier = Modifier.align(Alignment.TopStart)) {
                Text(badge.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
internal fun TreeDialog(player: PlayerState, onPlayerChanged: (PlayerState) -> Unit = {}, onDismiss: () -> Unit, onHome: () -> Unit = onDismiss) {
    val context = LocalContext.current.applicationContext
    var data by remember { mutableStateOf(NetworkDataStore.load(context)) }
    var collapsed by remember { mutableStateOf(emptySet<String>()) }
    var query by remember { mutableStateOf("") }
    var highlightedId by remember { mutableStateOf<String?>(null) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var displayedPersonId by remember { mutableStateOf<String?>(null) }
    var personSection by remember { mutableStateOf<PersonSection?>(null) }
    var displayedSection by remember { mutableStateOf<PersonSection?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset(40f, 40f)) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var searchPulse by remember { mutableFloatStateOf(0f) }
    var revealCount by remember { mutableStateOf(0) }
    var revealSkipped by remember { mutableStateOf(false) }
    val layout = remember(data, collapsed) { buildNetworkLayout(data, collapsed) }
    val networkSnapshot = remember(data) { buildNetworkGamificationSnapshot(context, data) }
    val networkPulse = networkSnapshot.pulse
    val personActivityScores = networkSnapshot.personScores
    val branchActivityScores = networkSnapshot.branchScores
    val branchRanking = networkSnapshot.branchRanking
    var networkXpAwardedToday by remember { mutableStateOf(0) }
    var networkDailyGoalClaimed by remember { mutableStateOf(isNetworkDailyGoalClaimed(context)) }
    var networkDailyGoalStreak by remember { mutableStateOf(networkDailyGoalStreak(context)) }
    var networkStreakMilestoneClaims by remember { mutableStateOf(claimedNetworkStreakMilestones(context)) }

    LaunchedEffect(data) {
        val (updatedPlayer, gainedXp) = claimNetworkActivityXp(context, data)
        if (gainedXp > 0) {
            networkXpAwardedToday += gainedXp
            onPlayerChanged(updatedPlayer)
        }
    }
    val layoutById = remember(layout) { layout.associateBy { it.person.id } }

    // Stage 21: keep the last destination mounted while it animates out. This makes
    // Back feel like a true reverse transition instead of an abrupt disappearance.
    LaunchedEffect(selectedId) { if (selectedId != null) displayedPersonId = selectedId }
    LaunchedEffect(personSection) { if (personSection != null) displayedSection = personSection }

    // Stage 16: reveal the tree in a readable root-to-leaf sequence on entry.
    // Interaction remains available; any user gesture immediately reveals everything.
    LaunchedEffect(layout.size) {
        if (layout.isEmpty()) {
            revealCount = 0
            return@LaunchedEffect
        }
        revealSkipped = false
        revealCount = 0
        delay(90)
        for (i in 1..layout.size) {
            if (revealSkipped) break
            revealCount = i
            delay(if (i <= 4) 105 else 70)
        }
    }

    fun finishTreeReveal() {
        if (revealCount < layout.size) {
            revealSkipped = true
            revealCount = layout.size
        }
    }

    fun focusSearch() {
        val q = query.trim()
        if (q.isEmpty()) return
        val person = data.people.firstOrNull { it.name.contains(q, ignoreCase = true) } ?: return
        // Open all ancestors so a searched person can always be revealed.
        val ancestors = mutableSetOf<String>()
        var cursor = person
        while (cursor.parentId != null) {
            val parent = data.people.firstOrNull { it.id == cursor.parentId } ?: break
            ancestors += parent.id
            cursor = parent
        }
        collapsed = collapsed - ancestors
        highlightedId = person.id
        selectedId = null
    }

    // Stage 15: once search has expanded the ancestor chain and layout is rebuilt,
    // glide the camera to the result instead of forcing the user to hunt for it.
    LaunchedEffect(highlightedId, layout, viewportSize, zoom) {
        val id = highlightedId ?: return@LaunchedEffect
        if (viewportSize == IntSize.Zero) return@LaunchedEffect
        val node = layout.firstOrNull { it.person.id == id } ?: return@LaunchedEffect
        val target = Offset(
            viewportSize.width / 2f - node.center.x * zoom,
            viewportSize.height / 2f - node.center.y * zoom
        )
        val start = pan
        repeat(18) { step ->
            val t = (step + 1) / 18f
            val eased = 1f - (1f - t) * (1f - t)
            pan = Offset(
                start.x + (target.x - start.x) * eased,
                start.y + (target.y - start.y) * eased
            )
            delay(16)
        }
        repeat(4) { pulse ->
            searchPulse = if (pulse % 2 == 0) 1f else 0f
            delay(120)
        }
        searchPulse = 0f
    }

    // Stage 19: one authoritative navigation rule for every tree sub-page.
    // Android Back always removes exactly one layer; Home always exits the tree.
    val navigateBackOneLevel: () -> Unit = {
        when {
            personSection != null -> personSection = null
            selectedId != null -> selectedId = null
            else -> onDismiss()
        }
    }

    BackHandler(onBack = navigateBackOneLevel)
    Dialog(
        onDismissRequest = navigateBackOneLevel,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = GamifyColors.Background) {
            Box(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                InternalGameBackdrop()
                // Stage 52: the same game HUD stays visible across every major internal module.
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .zIndex(10f)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    TopGameHud(player = player, rewardCue = null)
                    NetworkGamificationPulseCard(networkPulse, networkXpAwardedToday, networkDailyGoalStreak)
                    NetworkDailyGoalCard(
                        pulse = networkPulse,
                        claimed = networkDailyGoalClaimed,
                        onClaim = {
                            claimNetworkDailyGoalReward(context, networkPulse.activityPoints, NETWORK_DAILY_GOAL_POINTS)?.let { updated ->
                                networkDailyGoalClaimed = true
                                networkDailyGoalStreak = networkDailyGoalStreak(context)
                                onPlayerChanged(updated)
                            }
                        }
                    )
                    NetworkStreakMilestonesCard(
                        streak = networkDailyGoalStreak,
                        claimed = networkStreakMilestoneClaims,
                        onClaim = { days ->
                            claimNetworkStreakMilestone(context, days)?.let { updated ->
                                networkStreakMilestoneClaims = claimedNetworkStreakMilestones(context)
                                onPlayerChanged(updated)
                            }
                        }
                    )
                    BranchRankingCard(branchRanking)
                }

                Canvas(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { viewportSize = it }
                        .pointerInput(layout, zoom, pan) {
                            detectTransformGestures { _, panChange, zoomChange, _ ->
                                finishTreeReveal()
                                zoom = (zoom * zoomChange).coerceIn(0.35f, 2.8f)
                                pan += panChange
                            }
                        }
                        .pointerInput(layout, zoom, pan) {
                            detectTapGestures { tap ->
                                finishTreeReveal()
                                val world = Offset((tap.x - pan.x) / zoom, (tap.y - pan.y) / zoom)
                                val hit = layout.minByOrNull { (it.center - world).getDistance() }
                                    ?.takeIf { (it.center - world).getDistance() <= 70f }
                                if (hit != null) {
                                    val nodeRadius = if (hit.person.id == highlightedId || hit.person.id == selectedId) 50f else 44f
                                    val branchControl = Offset(
                                        hit.center.x + nodeRadius - 2f,
                                        hit.center.y + nodeRadius - 2f
                                    )
                                    val tappedBranchControl = hit.hasChildren &&
                                        (branchControl - world).getDistance() <= 30f
                                    if (tappedBranchControl) {
                                        collapsed = if (hit.person.id in collapsed) {
                                            collapsed - hit.person.id
                                        } else {
                                            collapsed + hit.person.id
                                        }
                                        selectedId = null
                                    } else if ((hit.center - world).getDistance() <= nodeRadius + 8f) {
                                        selectedId = hit.person.id
                                        personSection = null
                                    }
                                }
                            }
                        }
                ) {
                    // Quiet geometric texture shared with the app's internal-page language.
                    val step = size.width / 8f
                    repeat(9) { i -> drawLine(Color(0x102C4863), Offset(i * step, 0f), Offset(i * step, size.height), 1f) }
                    val hStep = size.height / 11f
                    repeat(12) { i -> drawLine(Color(0x0D2C4863), Offset(0f, i * hStep), Offset(size.width, i * hStep), 1f) }

                    // Stage 18: viewport culling + zoom-aware detail. Large organizations may
                    // contain hundreds/thousands of nodes; only nodes near the visible world
                    // rectangle are painted. Layout/search still keep the complete tree.
                    val safeZoom = zoom.coerceAtLeast(0.01f)
                    val worldLeft = (-pan.x) / safeZoom
                    val worldTop = (-pan.y) / safeZoom
                    val worldRight = (size.width - pan.x) / safeZoom
                    val worldBottom = (size.height - pan.y) / safeZoom
                    val cullMargin = 240f / safeZoom
                    fun inViewport(center: Offset): Boolean =
                        center.x >= worldLeft - cullMargin && center.x <= worldRight + cullMargin &&
                        center.y >= worldTop - cullMargin && center.y <= worldBottom + cullMargin

                    withTransform({ translate(pan.x, pan.y); scale(zoom, zoom, Offset.Zero) }) {
                        val revealed = if (revealCount >= layout.size) layout else layout.take(revealCount)
                        val revealedIds = revealed.mapTo(hashSetOf()) { it.person.id }
                        val drawableNodes = revealed.filter { inViewport(it.center) }
                        drawableNodes.forEach { node ->
                            val parent = node.person.parentId?.let(layoutById::get)
                            if (parent != null && parent.person.id in revealedIds) {
                                val midY = (parent.center.y + node.center.y) / 2f
                                val path = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(parent.center.x, parent.center.y + 37f)
                                    lineTo(parent.center.x, midY)
                                    lineTo(node.center.x, midY)
                                    lineTo(node.center.x, node.center.y - 37f)
                                }
                                drawPath(path, Color(0x886A88A8), style = Stroke(width = 3f))
                            }
                        }
                        drawableNodes.forEach { node ->
                            val isHighlighted = node.person.id == highlightedId
                            val isSelected = node.person.id == selectedId
                            val radius = if (isHighlighted || isSelected) 50f else 44f
                            if (isHighlighted) {
                                val halo = 14f + (searchPulse * 10f)
                                drawCircle(Color(0x55F7C948), radius + halo, node.center)
                                drawCircle(Color(0x99F7C948), radius + 7f + (searchPulse * 4f), node.center, style = Stroke(width = 3f))
                            }
                            val isCollapsed = node.person.id in collapsed
                            drawCircle(
                                color = when {
                                    isSelected -> Color(0xFF345A78)
                                    isCollapsed -> Color(0xFF263545)
                                    else -> Color(0xFF20384E)
                                },
                                radius = radius,
                                center = node.center
                            )
                            drawCircle(
                                color = if (isHighlighted) NetworkUi.Primary else Color(0xFF7894AD),
                                radius = radius,
                                center = node.center,
                                style = Stroke(width = if (isHighlighted) 5f else 2f)
                            )
                            // At far zoom-out the tree becomes a structural overview. Skip
                            // expensive labels/branch controls until they are readable again.
                            if (zoom >= 0.48f || isHighlighted || isSelected) {
                                drawContext.canvas.nativeCanvas.drawText(
                                    node.person.name,
                                    node.center.x,
                                    node.center.y + 5f,
                                    android.graphics.Paint().apply {
                                        color = android.graphics.Color.WHITE
                                        textSize = 24f
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                                    }
                                )
                                val activityScore = personActivityScores[node.person.id] ?: 0
                                val branchScore = branchActivityScores[node.person.id] ?: activityScore
                                if (activityScore > 0 || branchScore > 0) {
                                    val scoreLabel = if (node.hasChildren && branchScore != activityScore) {
                                        "$activityScore • BR $branchScore"
                                    } else {
                                        "$activityScore PTS"
                                    }
                                    drawContext.canvas.nativeCanvas.drawText(
                                        scoreLabel,
                                        node.center.x,
                                        node.center.y + 29f,
                                        android.graphics.Paint().apply {
                                            color = android.graphics.Color.rgb(247, 201, 72)
                                            textSize = 15f
                                            textAlign = android.graphics.Paint.Align.CENTER
                                            isAntiAlias = true
                                            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                                        }
                                    )
                                }
                            }
                            if (node.hasChildren && zoom >= 0.42f) {
                                val closed = node.person.id in collapsed
                                drawCircle(NetworkUi.Primary, 18f, Offset(node.center.x + radius - 2f, node.center.y + radius - 2f))
                                drawContext.canvas.nativeCanvas.drawText(
                                    if (closed) "+" else "−",
                                    node.center.x + radius - 2f,
                                    node.center.y + radius + 5f,
                                    android.graphics.Paint().apply {
                                        color = android.graphics.Color.rgb(20, 28, 36)
                                        textSize = 25f
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                                    }
                                )
                            }
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(start = 18.dp, end = 18.dp, top = 82.dp)
                        .fillMaxWidth(),
                    color = Color(0xDD111D29),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it; if (it.isBlank()) highlightedId = null },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusSearch() }),
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Right),
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                        decorationBox = { inner ->
                            Box(Modifier.fillMaxWidth()) {
                                if (query.isBlank()) Text("جستجو در درختواره…", color = Color(0xFF8EA1B3), modifier = Modifier.align(Alignment.CenterEnd))
                                inner()
                            }
                        }
                    )
                }

                Text(
                    text = "برای باز و بسته کردن شاخه، روی + / − بزن",
                    color = NetworkUi.MutedText,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = 24.dp, top = 148.dp)
                )

                // Search is intentionally lightweight: typing narrows intent; tapping this small chip focuses the match.
                Surface(
                    onClick = { focusSearch() },
                    modifier = Modifier.align(Alignment.TopStart).padding(start = 24.dp, top = 144.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xDDF7C948)
                ) { Text("پیدا کن", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) }

                AnimatedVisibility(
                    visible = selectedId != null,
                    enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.965f) + slideInHorizontally(tween(260)) { it / 12 },
                    exit = fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 0.975f) + slideOutHorizontally(tween(220)) { it / 10 }
                ) {
                    displayedPersonId?.let { id ->
                    val person = data.people.firstOrNull { it.id == id }
                    if (person != null) {
                        val today = data.statsFor(person.id, LocalDate.now())
                        var pvText by remember(person.id, today?.savedAt) { mutableStateOf((today?.pv ?: 0).toString()) }
                        var gpvText by remember(person.id, today?.savedAt) { mutableStateOf((today?.gpv ?: 0).toString()) }
                        var countText by remember(person.id, today?.savedAt) { mutableStateOf((today?.count ?: 0).toString()) }
                        val pvFocus = remember(person.id) { FocusRequester() }
                        val gpvFocus = remember(person.id) { FocusRequester() }
                        val countFocus = remember(person.id) { FocusRequester() }
                        val keyboard = LocalSoftwareKeyboardController.current
                        fun saveDailyStats() {
                            NetworkDataStore.upsertDailyStats(context, person.id, pvText.toIntOrNull() ?: 0, gpvText.toIntOrNull() ?: 0, countText.toIntOrNull() ?: 0, confirmed = true)
                            data = NetworkDataStore.load(context)
                            keyboard?.hide()
                        }
                        val needsSave = NetworkDataStore.needsDailyConfirmation(data, person.id)
                        var showManagePerson by remember(person.id) { mutableStateOf(false) }

                        Surface(
                            modifier = Modifier.fillMaxSize().padding(top = 66.dp, bottom = 64.dp, start = 14.dp, end = 14.dp),
                            color = NetworkUi.Panel,
                            shape = RoundedCornerShape(NetworkUi.PanelRadius)
                        ) {
                            Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    if (needsSave) Surface(shape = CircleShape, color = Color(0xFFFF4D55), modifier = Modifier.width(10.dp).height(10.dp)) {}
                                    Surface(
                                        onClick = { showManagePerson = true },
                                        shape = RoundedCornerShape(12.dp),
                                        color = NetworkUi.ControlSoft
                                    ) {
                                        Text("ویرایش", color = Color(0xFFD9E5EE), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                    }
                                    Spacer(Modifier.weight(1f))
                                    Text(person.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(28.dp))
                                StatEditor("PV", pvText) { pvText = it.filter(Char::isDigit).take(9) }
                                Spacer(Modifier.height(14.dp))
                                StatEditor("GPV", gpvText) { gpvText = it.filter(Char::isDigit).take(9) }
                                Spacer(Modifier.height(14.dp))
                                StatEditor("تعداد", countText) { countText = it.filter(Char::isDigit).take(9) }
                                Spacer(Modifier.height(26.dp))
                                Surface(
                                    onClick = {
                                        data = NetworkDataStore.confirmToday(
                                            context = context,
                                            personId = person.id,
                                            pv = pvText.toIntOrNull() ?: 0,
                                            gpv = gpvText.toIntOrNull() ?: 0,
                                            count = countText.toIntOrNull() ?: 0
                                        )
                                    },
                                    shape = RoundedCornerShape(18.dp),
                                    color = NetworkUi.Primary
                                ) {
                                    Text("ذخیره اطلاعات", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 34.dp, vertical = 13.dp))
                                }
                                Spacer(Modifier.height(22.dp))
                                Text(
                                    if (needsSave) "اطلاعات امروز هنوز تأیید نشده" else "اطلاعات امروز ذخیره شده",
                                    color = if (needsSave) NetworkUi.ErrorText else NetworkUi.SuccessText,
                                    fontSize = 13.sp
                                )
                                Spacer(Modifier.height(24.dp))
                                val todoBadge = data.openTodoCount(person.id)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    PersonActionTile("لیست افراد", modifier = Modifier.weight(1f)) { personSection = PersonSection.PROSPECTS }
                                    PersonActionTile("اضافه کردن دایرکت", modifier = Modifier.weight(1f)) { personSection = PersonSection.ADD_DIRECT }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    PersonActionTile("تودو", badge = todoBadge, modifier = Modifier.weight(1f)) { personSection = PersonSection.TODOS }
                                    PersonActionTile("نگاهی به گذشته", modifier = Modifier.weight(1f)) { personSection = PersonSection.HISTORY }
                                }
                                Spacer(Modifier.height(10.dp))
                                PersonActionTile("هدایت کاری", modifier = Modifier.fillMaxWidth()) { personSection = PersonSection.COACHING }
                            }
                        }

                        if (showManagePerson) {
                            ManageNetworkPersonDialog(
                                person = person,
                                data = data,
                                onDismiss = { showManagePerson = false },
                                onRename = { newName ->
                                    data = NetworkDataStore.renamePerson(context, person.id, newName)
                                    showManagePerson = false
                                },
                                onDeleteBranch = {
                                    data = NetworkDataStore.deletePersonBranch(context, person.id)
                                    selectedId = null
                                    highlightedId = null
                                    personSection = null
                                    collapsed = collapsed - person.id
                                    showManagePerson = false
                                }
                            )
                        }
                    }
                    }
                }

                AnimatedVisibility(
                    visible = selectedId != null && personSection != null,
                    enter = fadeIn(tween(190)) + slideInHorizontally(tween(260)) { it / 5 },
                    exit = fadeOut(tween(160)) + slideOutHorizontally(tween(230)) { it / 5 }
                ) {
                    val activeSection = personSection ?: displayedSection
                    if (displayedPersonId != null && activeSection != null) {
                    val owner = data.people.firstOrNull { it.id == displayedPersonId }
                    if (owner != null) {
                        var directName by remember(owner.id, activeSection) { mutableStateOf("") }
                        Surface(
                            modifier = Modifier.fillMaxSize().padding(top = 66.dp, bottom = 64.dp, start = 14.dp, end = 14.dp),
                            color = NetworkUi.PanelStrong,
                            shape = RoundedCornerShape(NetworkUi.PanelRadius)
                        ) {
                            Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    when (activeSection) {
                                        PersonSection.PROSPECTS -> "لیست افراد"
                                        PersonSection.ADD_DIRECT -> "اضافه کردن دایرکت"
                                        PersonSection.TODOS -> "تودو"
                                        PersonSection.HISTORY -> "نگاهی به گذشته"
                                        PersonSection.COACHING -> "هدایت کاری"
                                        null -> ""
                                    },
                                    color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(owner.name, color = NetworkUi.MutedText, fontSize = 13.sp)
                                Spacer(Modifier.height(28.dp))
                                if (activeSection == PersonSection.ADD_DIRECT) {
                                    Surface(Modifier.fillMaxWidth(), color = NetworkUi.CardSoft, shape = RoundedCornerShape(18.dp)) {
                                        BasicTextField(
                                            value = directName, onValueChange = { directName = it.take(60) }, singleLine = true,
                                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                            keyboardActions = KeyboardActions(onDone = {
                                                val name = directName.trim()
                                                if (name.isNotEmpty()) {
                                                    val added = NetworkDataStore.addPerson(context, name, owner.id)
                                                    data = NetworkDataStore.load(context); selectedId = added.id; personSection = null; highlightedId = added.id
                                                }
                                            }),
                                            textStyle = TextStyle(color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Right),
                                            modifier = Modifier.padding(18.dp),
                                            decorationBox = { inner -> Box(Modifier.fillMaxWidth()) { if (directName.isBlank()) Text("نام فرد", color = NetworkUi.Placeholder, modifier = Modifier.align(Alignment.CenterEnd)); inner() } }
                                        )
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    Surface(onClick = {
                                        val name = directName.trim()
                                        if (name.isNotEmpty()) {
                                            val added = NetworkDataStore.addPerson(context, name, owner.id)
                                            data = NetworkDataStore.load(context)
                                            selectedId = added.id
                                            personSection = null
                                            highlightedId = added.id
                                        }
                                    }, shape = RoundedCornerShape(18.dp), color = NetworkUi.Primary) {
                                        Text("ثبت دایرکت", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 30.dp, vertical = 13.dp))
                                    }
                                } else if (activeSection == PersonSection.PROSPECTS) {
                                    ProspectListPage(
                                        owner = owner,
                                        data = data,
                                        onDataChanged = { data = NetworkDataStore.load(context) }
                                    )
                                } else if (activeSection == PersonSection.HISTORY) {
                                    NetworkHistoryPage(owner = owner, data = data)
                                } else if (activeSection == PersonSection.COACHING) {
                                    CoachingNotesPage(
                                        owner = owner,
                                        data = data,
                                        onDataChanged = { data = NetworkDataStore.load(context) }
                                    )
                                } else {
                                    val info = when (activeSection) {
                                        PersonSection.TODOS -> "${data.openTodoCount(owner.id)} تودوی انجام‌نشده"
                                        PersonSection.HISTORY -> "تاریخچه روزانه PV، GPV و تعداد"
                                        PersonSection.COACHING -> "${NetworkDataStore.coachingNotesFor(data, owner.id).size} یادداشت هدایت کاری"
                                        else -> ""
                                    }
                                    Text(info, color = NetworkUi.SecondaryText, fontSize = 16.sp, textAlign = TextAlign.Center)
                                    Spacer(Modifier.height(12.dp))
                                    Text("این بخش در مرحله‌های بعد با صفحه کامل عملیاتی تکمیل می‌شود.", color = NetworkUi.QuietText, fontSize = 13.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    }
                }

                // Home is the only persistent navigation affordance requested for internal pages.
                Surface(
                    onClick = onHome,
                    modifier = Modifier.align(Alignment.BottomStart).padding(18.dp),
                    shape = CircleShape,
                    color = NetworkUi.Control
                ) { Text("⌂", color = Color.White, fontSize = 25.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp)) }
            }
        }
    }
}


private enum class ProspectPageMode { ADD, LIST }

private fun actionLabel(type: ProspectActionType?): String = when (type) {
    ProspectActionType.Networking -> "ارتباط‌سازی"
    ProspectActionType.PreConsultation -> "پیش‌مشاوره"
    ProspectActionType.Invitation -> "دعوت"
    ProspectActionType.BusinessPresentation -> "معرفی کار"
    ProspectActionType.FollowUp -> "فالوآپ"
    ProspectActionType.Pp -> "PP"
    ProspectActionType.ProductPresentation -> "معرفی محصول"
    null -> "بدون اقدام"
}

@Composable
private fun ProspectListPage(
    owner: NetworkPerson,
    data: NetworkData,
    onDataChanged: () -> Unit
) {
    val context = LocalContext.current
    var mode by remember(owner.id) { mutableStateOf(ProspectPageMode.ADD) }
    var name by remember(owner.id) { mutableStateOf("") }
    var description by remember(owner.id) { mutableStateOf("") }
    var action by remember(owner.id) { mutableStateOf<ProspectActionType?>(null) }
    var selectedProspectId by remember(owner.id) { mutableStateOf<String?>(null) }
    var filter by remember(owner.id) { mutableStateOf<ProspectActionType?>(null) }
    var newestFirst by remember(owner.id) { mutableStateOf(true) }
    val nameFocus = remember(owner.id) { FocusRequester() }
    val descriptionFocus = remember(owner.id) { FocusRequester() }

    fun submit() {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val prospect = NetworkDataStore.addOrGetProspect(context, owner.id, clean)
        if (action != null || description.isNotBlank()) {
            NetworkDataStore.addProspectAction(context, prospect.id, action, description)
        }
        name = ""
        description = ""
        action = null
        onDataChanged()
        nameFocus.requestFocus()
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MiniTab("ثبت اقدام جدید", mode == ProspectPageMode.ADD, Modifier.weight(1f)) { selectedProspectId = null; mode = ProspectPageMode.ADD }
        MiniTab("لیست افراد", mode == ProspectPageMode.LIST, Modifier.weight(1f)) { selectedProspectId = null; mode = ProspectPageMode.LIST }
    }
    Spacer(Modifier.height(16.dp))

    val selected = data.prospects.firstOrNull { it.id == selectedProspectId }
    if (selected != null) {
        Text(selected.name, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val raw = NetworkDataStore.actionsFor(data, selected.id)
        val filtered = raw.filter { filter == null || it.type == filter }.let { if (newestFirst) it else it.reversed() }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MiniChip(if (newestFirst) "جدید ← قدیم" else "قدیم ← جدید", true) { newestFirst = !newestFirst }
            MiniChip(if (filter == null) "همه اقدامات" else actionLabel(filter), filter != null) {
                val all = listOf<ProspectActionType?>(null) + ProspectActionType.values().toList()
                filter = all[(all.indexOf(filter) + 1) % all.size]
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().weight(1f, fill = true).verticalScroll(rememberScrollState())) {
            if (filtered.isEmpty()) Text("هنوز اقدامی ثبت نشده", color = NetworkUi.MutedText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            filtered.forEach { item ->
                Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp), color = NetworkUi.CardSoft, shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.End) {
                        Text(actionLabel(item.type), color = NetworkUi.Primary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                        if (item.description.isNotBlank()) Text(item.description, color = Color(0xFFD4DEE7), fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                    }
                }
            }
        }
        Text("‹ بازگشت به لیست", color = NetworkUi.SecondaryText, modifier = Modifier.padding(10.dp).fillMaxWidth(), textAlign = TextAlign.Center)
        Surface(onClick = { selectedProspectId = null }, color = Color.Transparent) { Spacer(Modifier.fillMaxWidth().height(34.dp)) }
    } else if (mode == ProspectPageMode.ADD) {
        ProspectInput("نام فرد *", name, ImeAction.Next, focusRequester = nameFocus, onNext = { descriptionFocus.requestFocus() }) { name = it.take(60) }
        Spacer(Modifier.height(10.dp))
        Text("اقدام انجام‌شده (اختیاری)", color = NetworkUi.SecondaryText, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            ProspectActionType.values().toList().forEach { type -> MiniChip(actionLabel(type), action == type) { action = if (action == type) null else type } }
        }
        Spacer(Modifier.height(10.dp))
        ProspectInput("توضیحات (اختیاری)", description, ImeAction.Done, focusRequester = descriptionFocus, onDone = { submit() }) { description = it.take(240) }
        Spacer(Modifier.height(16.dp))
        Surface(onClick = { submit() }, shape = RoundedCornerShape(18.dp), color = NetworkUi.Primary) {
            Text("ثبت", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 42.dp, vertical = 12.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("اگر این نام قبلاً ثبت شده باشد، اقدام جدید به همان پروفایل اضافه می‌شود.", color = NetworkUi.QuietText, fontSize = 11.sp, textAlign = TextAlign.Center)
    } else {
        val people = NetworkDataStore.prospectsFor(data, owner.id)
        Column(Modifier.fillMaxWidth().weight(1f, fill = true).verticalScroll(rememberScrollState())) {
            if (people.isEmpty()) Text("هنوز فردی ثبت نشده", color = NetworkUi.MutedText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            people.forEach { prospect ->
                val actionCount = data.prospectActions.count { it.prospectId == prospect.id }
                Surface(onClick = { selectedProspectId = prospect.id }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), color = NetworkUi.CardSoft, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("$actionCount اقدام", color = NetworkUi.MutedText, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text(prospect.name, color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right)
                    }
                }
            }
        }
    }
}


@Composable
private fun CoachingNotesPage(
    owner: NetworkPerson,
    data: NetworkData,
    onDataChanged: () -> Unit
) {
    val context = LocalContext.current
    val notes = remember(data, owner.id) { NetworkDataStore.coachingNotesFor(data, owner.id) }
    var editorOpen by remember(owner.id) { mutableStateOf(false) }
    var editingId by remember(owner.id) { mutableStateOf<String?>(null) }
    var text by remember(owner.id) { mutableStateOf("") }

    fun openNew() {
        editingId = null
        text = ""
        editorOpen = true
    }
    fun openEdit(note: CoachingNote) {
        editingId = note.id
        text = note.text
        editorOpen = true
    }
    fun save() {
        val clean = text.trim()
        if (clean.isEmpty()) return
        if (editingId == null) NetworkDataStore.addCoachingNote(context, owner.id, clean)
        else NetworkDataStore.updateCoachingNote(context, editingId!!, clean)
        editorOpen = false
        editingId = null
        text = ""
        onDataChanged()
    }

    if (editorOpen) {
        val editing = notes.firstOrNull { it.id == editingId }
        Text(
            if (editing == null) "یادداشت جلسه جدید" else formatCoachingDate(editing.createdAt),
            color = NetworkUi.Primary, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right
        )
        Spacer(Modifier.height(12.dp))
        Surface(Modifier.fillMaxWidth().weight(1f, fill = true), color = NetworkUi.CardSoft, shape = RoundedCornerShape(18.dp)) {
            BasicTextField(
                value = text,
                onValueChange = { text = it.take(6000) },
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Right),
                modifier = Modifier.fillMaxSize().padding(16.dp),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize()) {
                        if (text.isBlank()) Text("یادداشت هدایت کاری را بنویسید…", color = NetworkUi.Placeholder, modifier = Modifier.align(Alignment.TopEnd), textAlign = TextAlign.Right)
                        inner()
                    }
                }
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (editing != null) {
                Surface(onClick = {
                    NetworkDataStore.deleteCoachingNote(context, editing.id)
                    editorOpen = false; editingId = null; text = ""; onDataChanged()
                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(15.dp), color = NetworkUi.Danger) {
                    Text("حذف", color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 12.dp))
                }
            }
            Surface(onClick = { editorOpen = false; editingId = null; text = "" }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(15.dp), color = NetworkUi.CardSoft) {
                Text("انصراف", color = Color(0xFFD4DEE7), textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 12.dp))
            }
            Surface(onClick = { save() }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(15.dp), color = NetworkUi.Primary) {
                Text("ذخیره", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 12.dp))
            }
        }
    } else {
        Surface(onClick = { openNew() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(17.dp), color = NetworkUi.Primary) {
            Text("+ یادداشت جلسه جدید", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 13.dp))
        }
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().weight(1f, fill = true).verticalScroll(rememberScrollState())) {
            if (notes.isEmpty()) {
                Text("هنوز یادداشتی ثبت نشده است.", color = NetworkUi.MutedText, modifier = Modifier.fillMaxWidth().padding(top = 24.dp), textAlign = TextAlign.Center)
            }
            notes.forEach { note ->
                Surface(onClick = { openEdit(note) }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), color = NetworkUi.CardSoft, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("‹", color = NetworkUi.MutedText, fontSize = 22.sp)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatCoachingDate(note.createdAt), color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right)
                            if (note.updatedAt != note.createdAt) Text("ویرایش شده", color = NetworkUi.QuietText, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun formatCoachingDate(timestamp: Long): String {
    val date = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate()
    return formatPersianDate(date)
}

@Composable
private fun ManageNetworkPersonDialog(
    person: NetworkPerson,
    data: NetworkData,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onDeleteBranch: () -> Unit
) {
    var name by remember(person.id) { mutableStateOf(person.name) }
    var confirmDelete by remember(person.id) { mutableStateOf(false) }
    val descendants = remember(data.people, person.id) {
        fun countChildren(id: String): Int = data.people.filter { it.parentId == id }.sumOf { 1 + countChildren(it.id) }
        countChildren(person.id)
    }
    val isRoot = person.parentId == null

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFF182939)
        ) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("مدیریت فرد", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Surface(Modifier.fillMaxWidth(), color = NetworkUi.CardSoft, shape = RoundedCornerShape(16.dp)) {
                    BasicTextField(
                        value = name,
                        onValueChange = { name = it.take(60) },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Right),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (name.trim().isNotEmpty()) onRename(name.trim()) }),
                        modifier = Modifier.padding(16.dp)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Surface(
                    onClick = { if (name.trim().isNotEmpty()) onRename(name.trim()) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = NetworkUi.Primary
                ) { Text("ذخیره نام", color = NetworkUi.OnPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(13.dp)) }

                Spacer(Modifier.height(18.dp))
                if (isRoot) {
                    Text("فرد اصلی درختواره قابل حذف نیست.", color = NetworkUi.MutedText, fontSize = 13.sp)
                } else if (!confirmDelete) {
                    Surface(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = NetworkUi.DangerSoft) {
                        Text("حذف فرد", color = NetworkUi.DangerText, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(13.dp))
                    }
                } else {
                    Text(
                        if (descendants == 0) "این فرد و اطلاعات مرتبطش حذف می‌شود." else "این فرد و $descendants نفر زیرمجموعه او، همراه اطلاعات مرتبط حذف می‌شوند.",
                        color = Color(0xFFFFB4BA), fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(onClick = { confirmDelete = false }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = Color(0xFF2A4154)) {
                            Text("انصراف", color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
                        }
                        Surface(onClick = onDeleteBranch, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = NetworkUi.DangerStrong) {
                            Text("حذف قطعی", color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkHistoryPage(owner: NetworkPerson, data: NetworkData) {
    val history = remember(data, owner.id) { NetworkDataStore.statsHistory(data, owner.id) }
    var selectedIso by remember(owner.id, history) { mutableStateOf(history.firstOrNull()?.isoDate) }
    val selectedIndex = history.indexOfFirst { it.isoDate == selectedIso }.let { if (it < 0) 0 else it }
    val selected = history.getOrNull(selectedIndex)

    if (history.isEmpty()) {
        Spacer(Modifier.height(24.dp))
        Text("هنوز اطلاعات روزانه‌ای برای این فرد ذخیره نشده است.", color = NetworkUi.MutedText, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        return
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(onClick = { if (selectedIndex < history.lastIndex) selectedIso = history[selectedIndex + 1].isoDate }, enabled = selectedIndex < history.lastIndex, shape = RoundedCornerShape(14.dp), color = NetworkUi.CardSoft) {
            Text("‹", color = Color.White, fontSize = 24.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp))
        }
        Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), color = NetworkUi.Card) {
            Text(selected?.isoDate?.let { runCatching { formatPersianDate(LocalDate.parse(it)) }.getOrElse { it } } ?: "—", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 13.dp))
        }
        Surface(onClick = { if (selectedIndex > 0) selectedIso = history[selectedIndex - 1].isoDate }, enabled = selectedIndex > 0, shape = RoundedCornerShape(14.dp), color = NetworkUi.CardSoft) {
            Text("›", color = Color.White, fontSize = 24.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp))
        }
    }
    Spacer(Modifier.height(22.dp))
    HistoryStatRow("PV", selected?.pv ?: 0)
    Spacer(Modifier.height(10.dp))
    HistoryStatRow("GPV", selected?.gpv ?: 0)
    Spacer(Modifier.height(10.dp))
    HistoryStatRow("تعداد", selected?.count ?: 0)
    Spacer(Modifier.height(18.dp))
    Text("${toPersianDigits((selectedIndex + 1).toString())} از ${toPersianDigits(history.size.toString())} روز ثبت‌شده", color = NetworkUi.QuietText, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}

@Composable
private fun HistoryStatRow(label: String, value: Int) {
    Surface(Modifier.fillMaxWidth(), color = NetworkUi.CardSoft, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(toPersianDigits(value.toString()), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(label, color = Color(0xFF9FB2C5), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MiniTab(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(14.dp), color = if (selected) NetworkUi.Primary else NetworkUi.CardSoft) {
        Text(text, color = if (selected) NetworkUi.OnPrimary else Color(0xFFD4DEE7), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 10.dp))
    }
}

@Composable
private fun MiniChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(12.dp), color = if (selected) NetworkUi.Primary else NetworkUi.CardSoft) {
        Text(text, color = if (selected) NetworkUi.OnPrimary else Color(0xFFD4DEE7), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp))
    }
}

@Composable
private fun ProspectInput(placeholder: String, value: String, imeAction: ImeAction, focusRequester: FocusRequester? = null, onNext: (() -> Unit)? = null, onDone: (() -> Unit)? = null, onChange: (String) -> Unit) {
    Surface(Modifier.fillMaxWidth(), color = NetworkUi.CardSoft, shape = RoundedCornerShape(16.dp)) {
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = imeAction),
            keyboardActions = KeyboardActions(onNext = { onNext?.invoke() }, onDone = { onDone?.invoke() }),
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Right),
            modifier = Modifier.padding(15.dp).then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
            decorationBox = { inner -> Box(Modifier.fillMaxWidth()) { if (value.isBlank()) Text(placeholder, color = NetworkUi.Placeholder, modifier = Modifier.align(Alignment.CenterEnd)); inner() } }
        )
    }
}

// Stage 142: read-only Home projection of today's canonical Network Pulse.
internal fun networkTodayPulse(context: android.content.Context): NetworkGamificationPulse =
    buildNetworkGamificationSnapshot(context, NetworkDataStore.load(context)).pulse
