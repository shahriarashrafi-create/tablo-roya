# Stage 33 / 150 — Mission Restore

Resolved Done/Failed mission cards can be restored to Active. The restore transaction removes the terminal history row and rolls back rewards that were actually granted by that result (XP, coins, rank progress and chests). Combo rollback is conservative when later progression exists, preventing a historical restore from corrupting newer combo state.
