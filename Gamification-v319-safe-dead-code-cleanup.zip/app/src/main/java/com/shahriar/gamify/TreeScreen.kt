package com.shahriar.gamify

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDate
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private const val KEY_TREE_STATE = "tree_state_v1"
private const val TREE_SNAPSHOT_LIMIT = 180

private data class TreeTodo(
    val id: String,
    val text: String,
    val done: Boolean = false
)

private data class TreeContact(
    val id: String,
    val name: String
)

private data class TreeAction(
    val id: String,
    val type: String,
    val prospectName: String,
    val date: String,
    val result: String = "",
    val nextAction: String = "",
    val nextDate: String = ""
)

private data class TreePerson(
    val id: String,
    val name: String,
    val parentId: String?,
    val pv: Int = 0,
    val gpv: Int = 0,
    val active: Int = 0,
    val targetPv: Int = 0,
    val targetGpv: Int = 0,
    val targetActive: Int = 0,
    val status: String = "",
    val nextAction: String = "",
    val notes: String = "",
    val todos: List<TreeTodo> = emptyList(),
    val contacts: List<TreeContact> = emptyList(),
    val actions: List<TreeAction> = emptyList()
)

private data class TreeSnapshot(
    val key: String,
    val label: String,
    val people: List<TreePerson>
)

private data class TreeState(
    val people: List<TreePerson>,
    val snapshots: List<TreeSnapshot> = emptyList(),
    val closedIds: Set<String> = emptySet(),
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val viewInitialized: Boolean = false,
    val monthlyNewEntryTarget: Int = 0,
    val newEntriesToToday: Int = 0
)

private enum class TreeSection(val title: String) {
    Entry("PV / GPV"),
    Today("امروز"),
    Tree("درختواره"),
    Compare("مقایسه"),
    Ranking("رنکینگ")
}

private enum class RankMode(val title: String) {
    Pv("PV"), Gpv("GPV"), Members("اعضا"), Actions("اقدامات")
}


internal data class JalaliDate(val year: Int, val month: Int, val day: Int)

internal val jalaliMonthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

internal fun gregorianToJalali(date: LocalDate): JalaliDate {
    var gy = date.year - 1600
    val gm = date.monthValue - 1
    val gd = date.dayOfMonth - 1
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
    for (i in 0 until gm) gDayNo += gDays[i]
    val originalYear = date.year
    val isGregorianLeap = originalYear % 400 == 0 || (originalYear % 4 == 0 && originalYear % 100 != 0)
    if (gm > 1 && isGregorianLeap) gDayNo++
    gDayNo += gd

    var jDayNo = gDayNo - 79
    val jNp = jDayNo / 12053
    jDayNo %= 12053
    var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
    jDayNo %= 1461
    if (jDayNo >= 366) {
        jy += (jDayNo - 1) / 365
        jDayNo = (jDayNo - 1) % 365
    }
    var jm = 0
    while (jm < 11 && jDayNo >= jDays[jm]) {
        jDayNo -= jDays[jm]
        jm++
    }
    return JalaliDate(jy, jm + 1, jDayNo + 1)
}

internal fun jalaliToGregorian(date: JalaliDate): LocalDate {
    var jy = date.year - 979
    val jm = date.month - 1
    val jd = date.day - 1
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

    var jDayNo = 365 * jy + (jy / 33) * 8 + ((jy % 33 + 3) / 4)
    for (i in 0 until jm) jDayNo += jDays[i]
    jDayNo += jd

    var gDayNo = jDayNo + 79
    var gy = 1600 + 400 * (gDayNo / 146097)
    gDayNo %= 146097
    var leap = true
    if (gDayNo >= 36525) {
        gDayNo--
        gy += 100 * (gDayNo / 36524)
        gDayNo %= 36524
        if (gDayNo >= 365) gDayNo++ else leap = false
    }
    gy += 4 * (gDayNo / 1461)
    gDayNo %= 1461
    if (gDayNo >= 366) {
        leap = false
        gDayNo--
        gy += gDayNo / 365
        gDayNo %= 365
    }

    var gm = 0
    while (gm < 12) {
        val monthDays = gDays[gm] + if (gm == 1 && leap) 1 else 0
        if (gDayNo < monthDays) break
        gDayNo -= monthDays
        gm++
    }
    return LocalDate.of(gy, gm + 1, gDayNo + 1)
}

private fun isJalaliLeap(year: Int): Boolean = runCatching {
    val g = jalaliToGregorian(JalaliDate(year, 12, 30))
    gregorianToJalali(g) == JalaliDate(year, 12, 30)
}.getOrDefault(false)

private fun jalaliMonthLength(year: Int, month: Int): Int = when {
    month <= 6 -> 31
    month <= 11 -> 30
    isJalaliLeap(year) -> 30
    else -> 29
}

private fun jalaliLabel(date: LocalDate): String {
    val j = gregorianToJalali(date)
    return String.format(Locale.US, "%04d/%02d/%02d", j.year, j.month, j.day)
}

private fun jalaliLabelFromKey(key: String): String = runCatching {
    jalaliLabel(LocalDate.parse(key))
}.getOrElse { key }

private fun persianDigits(text: String): String {
    val latin = "0123456789"
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    return buildString(text.length) {
        text.forEach { ch -> append(if (ch in latin) persian[latin.indexOf(ch)] else ch) }
    }
}

private fun initialTreeState(context: Context): TreeState {
    val profileName = runCatching { loadOnboardingProfile(context).name.trim() }.getOrDefault("")
    val rootName = profileName.takeIf { it.isNotBlank() && !it.equals("Player", ignoreCase = true) } ?: "شهریار"
    return TreeState(
        people = listOf(
            TreePerson(
                id = UUID.randomUUID().toString(),
                name = rootName,
                parentId = null
            )
        )
    )
}

private fun todoToJson(todo: TreeTodo) = JSONObject()
    .put("id", todo.id)
    .put("text", todo.text)
    .put("done", todo.done)

private fun contactToJson(contact: TreeContact) = JSONObject()
    .put("id", contact.id)
    .put("name", contact.name)

private fun actionToJson(action: TreeAction) = JSONObject()
    .put("id", action.id)
    .put("type", action.type)
    .put("prospectName", action.prospectName)
    .put("date", action.date)
    .put("result", action.result)
    .put("nextAction", action.nextAction)
    .put("nextDate", action.nextDate)

private fun personToJson(person: TreePerson): JSONObject {
    val todos = JSONArray().also { array -> person.todos.forEach { array.put(todoToJson(it)) } }
    val contacts = JSONArray().also { array -> person.contacts.forEach { array.put(contactToJson(it)) } }
    val actions = JSONArray().also { array -> person.actions.forEach { array.put(actionToJson(it)) } }
    return JSONObject()
        .put("id", person.id)
        .put("name", person.name)
        .put("parentId", person.parentId ?: JSONObject.NULL)
        .put("pv", person.pv)
        .put("gpv", person.gpv)
        .put("active", person.active)
        .put("targetPv", person.targetPv)
        .put("targetGpv", person.targetGpv)
        .put("targetActive", person.targetActive)
        .put("status", person.status)
        .put("nextAction", person.nextAction)
        .put("notes", person.notes)
        .put("todos", todos)
        .put("contacts", contacts)
        .put("actions", actions)
}

private fun peopleToJson(people: List<TreePerson>) = JSONArray().also { array ->
    people.forEach { array.put(personToJson(it)) }
}

private fun snapshotToJson(snapshot: TreeSnapshot) = JSONObject()
    .put("key", snapshot.key)
    .put("label", snapshot.label)
    .put("people", peopleToJson(snapshot.people))

private fun treeStateToJson(state: TreeState): String {
    val snapshots = JSONArray().also { array -> state.snapshots.forEach { array.put(snapshotToJson(it)) } }
    val closed = JSONArray().also { array -> state.closedIds.forEach { array.put(it) } }
    return JSONObject()
        .put("formatVersion", 1)
        .put("people", peopleToJson(state.people))
        .put("snapshots", snapshots)
        .put("closedIds", closed)
        .put("zoom", state.zoom.toDouble())
        .put("panX", state.panX.toDouble())
        .put("panY", state.panY.toDouble())
        .put("viewInitialized", state.viewInitialized)
        .put("monthlyNewEntryTarget", state.monthlyNewEntryTarget)
        .put("newEntriesToToday", state.newEntriesToToday)
        .toString()
}

private fun parseTodos(array: JSONArray?): List<TreeTodo> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val text = obj.optString("text").trim()
        if (text.isBlank()) continue
        add(TreeTodo(obj.optString("id").ifBlank { UUID.randomUUID().toString() }, text, obj.optBoolean("done", false)))
    }
}

private fun parseContacts(array: JSONArray?): List<TreeContact> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val name = obj.optString("name").trim()
        if (name.isBlank()) continue
        add(TreeContact(obj.optString("id").ifBlank { UUID.randomUUID().toString() }, name))
    }
}

private fun parseActions(array: JSONArray?): List<TreeAction> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        add(
            TreeAction(
                id = obj.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = obj.optString("type", "ارتباط‌سازی").ifBlank { "ارتباط‌سازی" },
                prospectName = obj.optString("prospectName"),
                date = obj.optString("date").ifBlank { LocalDate.now().toString() },
                result = obj.optString("result"),
                nextAction = obj.optString("nextAction", obj.optString("result")),
                nextDate = obj.optString("nextDate")
            )
        )
    }
}

private fun parsePeople(array: JSONArray?): List<TreePerson> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
        val parent = if (obj.isNull("parentId")) null else obj.optString("parentId").takeIf { it.isNotBlank() }
        add(
            TreePerson(
                id = id,
                name = obj.optString("name").trim().ifBlank { "بدون نام" },
                parentId = parent,
                pv = obj.optInt("pv", obj.optInt("sales", 0)).coerceAtLeast(0),
                gpv = obj.optInt("gpv", 0).coerceAtLeast(0),
                active = obj.optInt("active", 0).coerceAtLeast(0),
                targetPv = obj.optInt("targetPv", 0).coerceAtLeast(0),
                targetGpv = obj.optInt("targetGpv", obj.optInt("target", 0)).coerceAtLeast(0),
                targetActive = obj.optInt("targetActive", 0).coerceAtLeast(0),
                status = obj.optString("status"),
                nextAction = obj.optString("nextAction", obj.optString("next")),
                notes = obj.optString("notes"),
                todos = parseTodos(obj.optJSONArray("todos")),
                contacts = parseContacts(obj.optJSONArray("contacts")),
                actions = parseActions(obj.optJSONArray("actions") ?: obj.optJSONArray("network"))
            )
        )
    }
}

private fun normalizeTreeState(context: Context, raw: TreeState): TreeState {
    val base = raw.people.ifEmpty { initialTreeState(context).people }.distinctBy { it.id }
    val ids = base.map { it.id }.toSet()
    val rootId = base.firstOrNull { it.parentId == null || it.parentId !in ids }?.id ?: base.first().id

    val provisional = base.map { person ->
        val contacts = if (person.contacts.isEmpty()) {
            person.actions.map { it.prospectName.trim() }
                .filter { it.isNotBlank() }
                .distinctBy { it.lowercase(Locale.getDefault()) }
                .map { TreeContact(UUID.randomUUID().toString(), it) }
        } else person.contacts
        person.copy(
            parentId = if (person.id == rootId) null else person.parentId?.takeIf { it in ids && it != person.id } ?: rootId,
            contacts = contacts.distinctBy { it.name.trim().lowercase(Locale.getDefault()) },
            actions = person.actions.distinctBy { it.id }
        )
    }

    // Backups or old builds can theoretically contain a cyclic sponsor chain.
    // Break any cycle at load time so tree traversal and descendant counting can
    // never recurse forever.
    val byId = provisional.associateBy { it.id }
    val normalizedPeople = provisional.map { person ->
        if (person.id == rootId) return@map person.copy(parentId = null)
        var currentId: String? = person.id
        val seen = mutableSetOf<String>()
        var cycleFound = false
        while (currentId != null) {
            if (!seen.add(currentId)) {
                cycleFound = true
                break
            }
            currentId = byId[currentId]?.parentId
        }
        if (cycleFound) person.copy(parentId = rootId) else person
    }

    val validIds = normalizedPeople.map { it.id }.toSet()
    return raw.copy(
        people = normalizedPeople,
        snapshots = raw.snapshots.distinctBy { it.key }.sortedByDescending { it.key }.take(TREE_SNAPSHOT_LIMIT),
        closedIds = raw.closedIds.filterTo(mutableSetOf()) { it in validIds },
        zoom = raw.zoom.coerceIn(0.15f, 4.0f),
        monthlyNewEntryTarget = raw.monthlyNewEntryTarget.coerceAtLeast(0),
        newEntriesToToday = raw.newEntriesToToday.coerceAtLeast(0)
    )
}

private fun loadTreeState(context: Context): TreeState {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TREE_STATE, null)
        ?: return initialTreeState(context)
    return runCatching {
        val root = JSONObject(raw)
        val people = parsePeople(root.optJSONArray("people"))
        val snapshots = buildList {
            val array = root.optJSONArray("snapshots")
            if (array != null) for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val key = obj.optString("key")
                if (key.isBlank()) continue
                add(TreeSnapshot(key, obj.optString("label", key), parsePeople(obj.optJSONArray("people"))))
            }
        }
        val closed = buildSet {
            val array = root.optJSONArray("closedIds")
            if (array != null) for (i in 0 until array.length()) add(array.optString(i))
        }
        normalizeTreeState(
            context,
            TreeState(
                people = people,
                snapshots = snapshots,
                closedIds = closed,
                zoom = root.optDouble("zoom", 1.0).toFloat(),
                panX = root.optDouble("panX", 0.0).toFloat(),
                panY = root.optDouble("panY", 0.0).toFloat(),
                viewInitialized = root.optBoolean("viewInitialized", false),
                monthlyNewEntryTarget = root.optInt("monthlyNewEntryTarget", 0).coerceAtLeast(0),
                newEntriesToToday = root.optInt("newEntriesToToday", 0).coerceAtLeast(0)
            )
        )
    }.getOrElse { initialTreeState(context) }
}

private fun captureToday(state: TreeState): TreeState {
    val key = LocalDate.now().toString()
    val snapshot = TreeSnapshot(key = key, label = jalaliLabel(LocalDate.now()), people = state.people)
    val snapshots = (listOf(snapshot) + state.snapshots.filterNot { it.key == key })
        .sortedByDescending { it.key }
        .take(TREE_SNAPSHOT_LIMIT)
    return state.copy(snapshots = snapshots)
}

private fun persistTreeState(context: Context, state: TreeState, captureDaily: Boolean = true): TreeState {
    val normalized = normalizeTreeState(context, if (captureDaily) captureToday(state) else state)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_TREE_STATE, treeStateToJson(normalized))
        .apply()
    return normalized
}

private fun formatTreeNumber(value: Int): String = if (value == 0) "—" else String.format(Locale.US, "%,d", value)
private fun formatTreeInput(value: Int): String = if (value == 0) "" else String.format(Locale.US, "%,d", value)
private fun parseTreeNumber(text: String): Int = text.filter { it.isDigit() }.toLongOrNull()?.coerceIn(0, Int.MAX_VALUE.toLong())?.toInt() ?: 0
private fun formatTypedNumber(text: String): String = parseTreeNumber(text).let { if (it == 0 && text.none { ch -> ch.isDigit() }) "" else String.format(Locale.US, "%,d", it) }

private fun childrenOf(people: List<TreePerson>, id: String): List<TreePerson> = people.filter { it.parentId == id }
private fun rootPerson(people: List<TreePerson>): TreePerson? = people.firstOrNull { it.parentId == null } ?: people.firstOrNull()
private fun descendantCount(people: List<TreePerson>, id: String): Int {
    val children = childrenOf(people, id)
    return children.size + children.sumOf { descendantCount(people, it.id) }
}

private fun descendantIds(people: List<TreePerson>, id: String): Set<String> = buildSet {
    fun collect(parentId: String) {
        childrenOf(people, parentId).forEach { child ->
            if (add(child.id)) collect(child.id)
        }
    }
    collect(id)
}

private fun ancestorIds(people: List<TreePerson>, id: String): Set<String> = buildSet {
    var current = people.firstOrNull { it.id == id }
    val seen = mutableSetOf<String>()
    while (current?.parentId != null) {
        val parentId = current.parentId ?: break
        if (!seen.add(parentId)) break
        add(parentId)
        current = people.firstOrNull { it.id == parentId }
    }
}

private fun reorderSibling(people: List<TreePerson>, personId: String, delta: Int): List<TreePerson> {
    val person = people.firstOrNull { it.id == personId } ?: return people
    val siblings = people.filter { it.parentId == person.parentId }
    val currentIndex = siblings.indexOfFirst { it.id == personId }
    val target = siblings.getOrNull(currentIndex + delta) ?: return people
    val fromIndex = people.indexOfFirst { it.id == personId }
    val toIndex = people.indexOfFirst { it.id == target.id }
    if (fromIndex < 0 || toIndex < 0) return people
    return people.toMutableList().also { list ->
        val tmp = list[fromIndex]
        list[fromIndex] = list[toIndex]
        list[toIndex] = tmp
    }
}

@Composable
internal fun LegacyTreeDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current.applicationContext
    var state by remember { mutableStateOf(persistTreeState(context, loadTreeState(context), captureDaily = true)) }
    var section by remember { mutableStateOf(TreeSection.Entry) }
    var directParent by remember { mutableStateOf<TreePerson?>(null) }
    var editingPerson by remember { mutableStateOf<TreePerson?>(null) }
    var todoPerson by remember { mutableStateOf<TreePerson?>(null) }
    var actionsPerson by remember { mutableStateOf<TreePerson?>(null) }
    var transferPerson by remember { mutableStateOf<TreePerson?>(null) }
    var focusPersonId by remember { mutableStateOf<String?>(null) }
    var focusRequest by remember { mutableStateOf(0) }
    var entryFocusPersonId by remember { mutableStateOf<String?>(null) }
    var entryFocusRequest by remember { mutableStateOf(0) }
    var resetMonthConfirm by remember { mutableStateOf(false) }

    fun commit(updated: TreeState, captureDaily: Boolean = true) {
        state = persistTreeState(context, updated, captureDaily)
    }

    fun updatePerson(updated: TreePerson) {
        commit(state.copy(people = state.people.map { if (it.id == updated.id) updated else it }))
    }

    val hasChildDialog = directParent != null || editingPerson != null || todoPerson != null ||
        actionsPerson != null || transferPerson != null || resetMonthConfirm

    // One back closes the current tree sub-page first. A second back returns
    // from the tree module to the game home. Child dialogs keep their own back.
    BackHandler(enabled = !hasChildDialog) {
        if (section != TreeSection.Entry) section = TreeSection.Entry else onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF07101B), Color(0xFF0D1724), Color(0xFF070B12))
                        )
                    )
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(Color(0x0EF7C948), radius = size.width * 0.48f, center = Offset(size.width * 0.14f, size.height * 0.12f))
                    drawCircle(Color(0x0A2E76FF), radius = size.width * 0.54f, center = Offset(size.width * 0.92f, size.height * 0.58f))

                    val step = size.width / 8f
                    for (x in 0..8) {
                        val px = x * step
                        drawLine(Color(0x0C2F4864), Offset(px, 0f), Offset(px, size.height), strokeWidth = 0.9f)
                    }
                    val hStep = size.height / 10f
                    for (y in 0..10) {
                        val py = y * hStep
                        drawLine(Color(0x0A2C445D), Offset(0f, py), Offset(size.width, py), strokeWidth = 0.9f)
                    }

                    drawCircle(Color(0x14F7C948), radius = size.width * 0.08f, center = Offset(size.width * 0.18f, size.height * 0.82f), style = Stroke(width = 2f))
                    drawRoundRect(Color(0x10254E72), topLeft = Offset(size.width * 0.78f, size.height * 0.12f), size = Size(size.width * 0.10f, size.width * 0.10f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f), style = Stroke(width = 2f))
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(Modifier.fillMaxSize()) {
                        TreeTabs(section = section, onSelect = { section = it })
                        when (section) {
                        TreeSection.Entry -> TreeEntryScreen(
                            state = state,
                            onSavePerson = ::updatePerson,
                            onAddDirect = { directParent = it },
                            onTodos = { todoPerson = it },
                            onActions = { actionsPerson = it },
                            onEdit = { editingPerson = it },
                            focusPersonId = entryFocusPersonId,
                            focusRequest = entryFocusRequest,
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Today -> TreeTodayScreen(
                            state = state,
                            onUpdateMonthlyNewEntryTarget = { monthlyTarget ->
                                commit(
                                    state.copy(monthlyNewEntryTarget = monthlyTarget.coerceAtLeast(0)),
                                    captureDaily = false
                                )
                            },
                            onUpdateNewEntriesToToday = { actualToToday ->
                                commit(
                                    state.copy(newEntriesToToday = actualToToday.coerceAtLeast(0)),
                                    captureDaily = false
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Tree -> TreeGraphScreen(
                            state = state,
                            onPersonClick = { editingPerson = it },
                            onStateViewChange = { zoom, pan, closed, initialized ->
                                commit(
                                    state.copy(
                                        zoom = zoom,
                                        panX = pan.x,
                                        panY = pan.y,
                                        closedIds = closed,
                                        viewInitialized = initialized
                                    ),
                                    captureDaily = false
                                )
                            },
                            focusPersonId = focusPersonId,
                            focusRequest = focusRequest,
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Compare -> TreeCompareScreen(state = state, modifier = Modifier.weight(1f))
                        TreeSection.Ranking -> TreeRankingScreen(
                            state = state,
                            onPersonClick = { editingPerson = it },
                            modifier = Modifier.weight(1f)
                        )
                        }
                    }
                }
            }
        }
    }

    directParent?.let { parent ->
        AddDirectDialog(
            parent = parent,
            onDismiss = { directParent = null },
            onAdd = { name ->
                val newPerson = TreePerson(UUID.randomUUID().toString(), name.trim(), parent.id)
                commit(state.copy(people = state.people + newPerson))
                directParent = null
            }
        )
    }
    editingPerson?.let { person ->
        val currentPerson = state.people.firstOrNull { it.id == person.id } ?: person
        val siblings = state.people.filter { it.parentId == currentPerson.parentId }
        val siblingIndex = siblings.indexOfFirst { it.id == currentPerson.id }
        EditTreePersonDialog(
            person = currentPerson,
            canDelete = currentPerson.parentId != null,
            canMoveUp = currentPerson.parentId != null && siblingIndex > 0,
            canMoveDown = currentPerson.parentId != null && siblingIndex >= 0 && siblingIndex < siblings.lastIndex,
            directCount = childrenOf(state.people, currentPerson.id).size,
            organizationCount = currentPerson.active,
            onDismiss = { editingPerson = null },
            onAddDirect = {
                directParent = state.people.firstOrNull { p -> p.id == person.id }
                editingPerson = null
            },
            onTodos = {
                todoPerson = state.people.firstOrNull { p -> p.id == person.id }
                editingPerson = null
            },
            onActions = {
                actionsPerson = state.people.firstOrNull { p -> p.id == currentPerson.id }
                editingPerson = null
            },
            onLocate = {
                focusPersonId = currentPerson.id
                focusRequest += 1
                section = TreeSection.Tree
                editingPerson = null
            },
            onShowCard = {
                entryFocusPersonId = currentPerson.id
                entryFocusRequest += 1
                section = TreeSection.Entry
                editingPerson = null
            },
            onMoveUp = {
                commit(state.copy(people = reorderSibling(state.people, currentPerson.id, -1)))
                editingPerson = state.people.firstOrNull { it.id == currentPerson.id }
            },
            onMoveDown = {
                commit(state.copy(people = reorderSibling(state.people, currentPerson.id, 1)))
                editingPerson = state.people.firstOrNull { it.id == currentPerson.id }
            },
            onSave = { updated -> updatePerson(updated); editingPerson = null },
            onDelete = {
                val removeIds = mutableSetOf<String>()
                fun collect(id: String) {
                    removeIds += id
                    childrenOf(state.people, id).forEach { collect(it.id) }
                }
                collect(person.id)
                commit(
                    state.copy(
                        people = state.people.filterNot { it.id in removeIds },
                        closedIds = state.closedIds - removeIds
                    )
                )
                if (focusPersonId in removeIds) focusPersonId = null
                directParent = directParent?.takeUnless { it.id in removeIds }
                todoPerson = todoPerson?.takeUnless { it.id in removeIds }
                actionsPerson = actionsPerson?.takeUnless { it.id in removeIds }
                transferPerson = transferPerson?.takeUnless { it.id in removeIds }
                editingPerson = null
            }
        )
    }
    transferPerson?.let { person ->
        val current = state.people.firstOrNull { it.id == person.id } ?: person
        TransferSponsorDialog(
            person = current,
            people = state.people,
            onDismiss = { transferPerson = null },
            onTransfer = { sponsorId ->
                val updated = current.copy(parentId = sponsorId)
                val remaining = state.people.filterNot { it.id == current.id }
                commit(state.copy(people = remaining + updated, closedIds = state.closedIds - sponsorId))
                focusPersonId = current.id
                focusRequest += 1
                section = TreeSection.Tree
                transferPerson = null
            }
        )
    }
    todoPerson?.let { person ->
        TodoDialog(
            person = state.people.firstOrNull { it.id == person.id } ?: person,
            onDismiss = { todoPerson = null },
            onUpdate = { updatePerson(it); todoPerson = it }
        )
    }
    actionsPerson?.let { person ->
        ActionsDialog(
            person = state.people.firstOrNull { it.id == person.id } ?: person,
            allPeople = state.people,
            onDismiss = { actionsPerson = null },
            onUpdate = { updatePerson(it); actionsPerson = it }
        )
    }
    if (resetMonthConfirm) {
        AlertDialog(
            onDismissRequest = { resetMonthConfirm = false },
            containerColor = GamifyColors.Surface,
            title = { Text("شروع ماه جدید", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("PV، GPV، تعداد فعال و هدف‌ها صفر شوند؟ ساختار تیم، To Do و اقدامات باقی می‌مانند.", color = TextSoft) },
            confirmButton = {
                TextButton(onClick = {
                    // Save the final numbers of the outgoing month before the
                    // live counters are cleared. The next normal edit will start
                    // building the new month's current-day snapshot.
                    val archived = captureToday(state)
                    val resetState = archived.copy(
                        people = archived.people.map {
                            it.copy(pv = 0, gpv = 0, active = 0, targetPv = 0, targetGpv = 0, targetActive = 0)
                        }
                    )
                    commit(resetState, captureDaily = false)
                    resetMonthConfirm = false
                }) { Text("ریست ماهانه", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { resetMonthConfirm = false }) { Text("لغو", color = TextSoft) } }
        )
    }
}


@Composable
private fun TreeTabs(section: TreeSection, onSelect: (TreeSection) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TreeSection.entries.forEach { item ->
            val active = section == item
            Surface(
                modifier = Modifier.weight(1f).height(44.dp).clickable { onSelect(item) },
                color = if (active) Color(0xFFEFC74C) else Color(0xB40D1825),
                shape = RoundedCornerShape(15.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (active) Color(0xFFFFE8A0) else Color(0x55485B71)
                )
            ) {
                Box(Modifier.fillMaxSize()) {
                    Canvas(Modifier.matchParentSize()) {
                        if (active) {
                            drawRoundRect(
                                brush = Brush.verticalGradient(listOf(Color(0x40FFF0B0), Color.Transparent)),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                            )
                        } else {
                            drawRoundRect(
                                brush = Brush.verticalGradient(listOf(Color(0x121D5A8D), Color.Transparent)),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                            )
                        }
                        drawLine(
                            if (active) Color(0x66FFF2BA) else Color(0x224F647A),
                            Offset(size.width * 0.15f, size.height * 0.18f),
                            Offset(size.width * 0.85f, size.height * 0.18f),
                            strokeWidth = 1f
                        )
                    }
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            item.title,
                            color = if (active) Color(0xFF231700) else Color(0xFFDCE5EE),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
    HorizontalDivider(color = Color(0x222E3946))
}

@Composable
private fun TreeTodayScreen(
    state: TreeState,
    onUpdateMonthlyNewEntryTarget: (Int) -> Unit,
    onUpdateNewEntriesToToday: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val root = rootPerson(state.people)
    val jalaliToday = remember { gregorianToJalali(LocalDate.now()) }
    val paceDay = jalaliToday.day.coerceIn(1, 30)

    val monthlyGpvTarget = root?.targetGpv ?: 0
    val monthlyPvTarget = root?.targetPv ?: 0
    val monthlyNewEntryTarget = state.monthlyNewEntryTarget

    val gpvTargetToToday = monthlyTargetToDay(monthlyGpvTarget, paceDay)
    val pvTargetToToday = monthlyTargetToDay(monthlyPvTarget, paceDay)
    val newEntryTargetToToday = monthlyCountTargetToDay(monthlyNewEntryTarget, paceDay)

    val currentGpv = root?.gpv ?: 0
    val currentPv = root?.pv ?: 0
    val currentNewEntries = state.newEntriesToToday

    var monthlyTargetInput by remember(monthlyNewEntryTarget) {
        mutableStateOf(if (monthlyNewEntryTarget == 0) "" else formatTreeInput(monthlyNewEntryTarget))
    }
    var newEntriesInput by remember(currentNewEntries) {
        mutableStateOf(if (currentNewEntries == 0) "" else formatTreeInput(currentNewEntries))
    }

    fun saveMonthlyTarget() {
        val target = parseTreeNumber(monthlyTargetInput)
        onUpdateMonthlyNewEntryTarget(target)
        focusManager.clearFocus()
    }

    fun saveNewEntries() {
        val actual = parseTreeNumber(newEntriesInput)
        // Daily/cumulative actual is independent from the fixed monthly target.
        // Saving today's number must never rewrite or clear the month's goal.
        onUpdateNewEntriesToToday(actual)
        focusManager.clearFocus()
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TreeTodayGoalBlock(
                title = "GPV",
                monthlyTarget = monthlyGpvTarget,
                targetToToday = gpvTargetToToday,
                actualToToday = currentGpv,
                actualLabel = "GPV تا امروز"
            )
        }
        item {
            TreeTodayGoalBlock(
                title = "PV",
                monthlyTarget = monthlyPvTarget,
                targetToToday = pvTargetToToday,
                actualToToday = currentPv,
                actualLabel = "PV تا امروز"
            )
        }
        item {
            TreeTodaySectionCard("تعداد ورودی جدید") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("هدف کل ماه", color = TextSoft, fontSize = 10.sp)
                        Text("هدف ورودی جدید مستقل از تعداد سازمان", color = Color(0xFF718295), fontSize = 8.5.sp)
                    }
                    OutlinedTextField(
                        value = monthlyTargetInput,
                        onValueChange = { monthlyTargetInput = formatTypedNumber(it.filter(Char::isDigit).take(10)) },
                        modifier = Modifier.width(138.dp).height(56.dp),
                        singleLine = true,
                        placeholder = { Text("—", color = TextSoft) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { saveMonthlyTarget() }),
                        textStyle = TextStyle(
                            color = GoldSoft,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        ),
                        colors = gamifyTextFieldColors(),
                        shape = GamifyShapes.Field
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TreeTodayMetricCard(
                        title = "هدف تا امروز",
                        value = if (newEntryTargetToToday > 0) formatTreeNumber(newEntryTargetToToday) else "—",
                        modifier = Modifier.weight(1f)
                    )
                    TreeTodayEditableMetricCard(
                        title = "ورودی تا امروز",
                        value = newEntriesInput,
                        onValueChange = { newEntriesInput = formatTypedNumber(it.filter(Char::isDigit).take(10)) },
                        onDone = ::saveNewEntries,
                        modifier = Modifier.weight(1f)
                    )
                    TreeTodayMetricCard(
                        title = "درصد هدف",
                        value = todayGoalPercent(currentNewEntries, newEntryTargetToToday),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

private fun monthlyTargetToDay(monthlyTarget: Int, day: Int): Int {
    if (monthlyTarget <= 0) return 0
    return kotlin.math.round(monthlyTarget.toDouble() * day.coerceIn(1, 30).toDouble() / 30.0)
        .toLong().coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
}

private fun monthlyCountTargetToDay(monthlyTarget: Int, day: Int): Int {
    if (monthlyTarget <= 0) return 0
    return kotlin.math.ceil(monthlyTarget.toDouble() * day.coerceIn(1, 30).toDouble() / 30.0)
        .toLong().coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
}

private fun todayGoalPercent(actual: Int, targetToToday: Int): String {
    if (targetToToday <= 0) return "—"
    val pct = actual.toDouble() * 100.0 / targetToToday.toDouble()
    val shown = kotlin.math.round(pct).toInt().coerceAtMost(9999)
    return "$shown٪"
}

@Composable
private fun TreeTodayGoalBlock(
    title: String,
    monthlyTarget: Int,
    targetToToday: Int,
    actualToToday: Int,
    actualLabel: String
) {
    TreeTodaySectionCard(title) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("هدف کل ماه", color = TextSoft, fontSize = 10.sp)
            Text(
                if (monthlyTarget > 0) formatTreeNumber(monthlyTarget) else "—",
                color = GoldSoft,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
        TreeTodayComparisonRow(
            targetToToday = targetToToday,
            actualToToday = actualToToday,
            actualLabel = actualLabel
        )
    }
}

@Composable
private fun TreeTodayComparisonRow(
    targetToToday: Int,
    actualToToday: Int,
    actualLabel: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TreeTodayMetricCard(
            title = "هدف تا امروز",
            value = if (targetToToday > 0) formatTreeNumber(targetToToday) else "—",
            modifier = Modifier.weight(1f)
        )
        TreeTodayMetricCard(
            title = actualLabel,
            value = formatTreeNumber(actualToToday),
            modifier = Modifier.weight(1f)
        )
        TreeTodayMetricCard(
            title = "درصد هدف",
            value = todayGoalPercent(actualToToday, targetToToday),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun TreeTodayMetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xB5101822),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .height(88.dp)
            .border(1.dp, Color(0x334E5C6C), RoundedCornerShape(16.dp))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 11.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = TextSoft, fontSize = 8.5.sp, textAlign = TextAlign.Center, maxLines = 2)
            Text(
                value,
                color = GoldSoft,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TreeTodayEditableMetricCard(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xB5101822),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .height(88.dp)
            .border(1.dp, Color(0x445B7187), RoundedCornerShape(16.dp))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = TextSoft, fontSize = 8.5.sp, textAlign = TextAlign.Center, maxLines = 1)
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .background(Color(0xFF0B1420), RoundedCornerShape(11.dp))
                    .border(1.dp, Color(0x665D7185), RoundedCornerShape(11.dp))
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onDone() }),
                textStyle = TextStyle(
                    color = GoldSoft,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                ),
                cursorBrush = Brush.verticalGradient(listOf(Gold, Gold)),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (value.isBlank()) Text("—", color = Color(0xFF607184), fontSize = 15.sp)
                        inner()
                    }
                }
            )
        }
    }
}

@Composable
private fun TreeTodaySectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        color = Color(0xA90E1721),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x334E5C6C), RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = GoldSoft, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            content()
        }
    }
}

@Composable
private fun TreeEntryScreen(
    state: TreeState,
    onSavePerson: (TreePerson) -> Unit,
    onAddDirect: (TreePerson) -> Unit,
    onTodos: (TreePerson) -> Unit,
    onActions: (TreePerson) -> Unit,
    onEdit: (TreePerson) -> Unit,
    focusPersonId: String?,
    focusRequest: Int,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val people = state.people
    val searchResults = remember(people, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) emptyList()
        else people.filter { it.name.contains(q, ignoreCase = true) }.take(7)
    }
    val pagerState = rememberPagerState(pageCount = { people.size.coerceAtLeast(1) })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current.applicationContext

    LaunchedEffect(people.size) {
        if (people.isNotEmpty() && pagerState.currentPage > people.lastIndex) {
            pagerState.scrollToPage(people.lastIndex.coerceAtLeast(0))
        }
    }

    LaunchedEffect(focusPersonId, focusRequest, people) {
        val id = focusPersonId ?: return@LaunchedEffect
        val index = people.indexOfFirst { it.id == id }
        if (index >= 0) {
            searchQuery = ""
            pagerState.scrollToPage(index)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                color = Color(0xB00D1824),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 7.dp)
                    .height(50.dp)
                    .border(1.2.dp, Color(0x88D5B452), RoundedCornerShape(18.dp))
            ) {
                Box(Modifier.fillMaxSize()) {
                    Canvas(Modifier.matchParentSize()) {
                        drawRoundRect(
                            brush = Brush.horizontalGradient(listOf(Color(0x120F6BFF), Color.Transparent, Color(0x16F7C948))),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
                        )
                        drawLine(Color(0x1EF7C948), Offset(size.width * 0.08f, size.height * 0.22f), Offset(size.width * 0.92f, size.height * 0.22f), strokeWidth = 1.2f)
                        val left = Path().apply {
                            moveTo(size.width * 0.015f, size.height * 0.28f)
                            lineTo(size.width * 0.032f, size.height * 0.18f)
                            lineTo(size.width * 0.050f, size.height * 0.28f)
                            lineTo(size.width * 0.032f, size.height * 0.38f)
                            close()
                        }
                        val right = Path().apply {
                            moveTo(size.width * 0.985f, size.height * 0.28f)
                            lineTo(size.width * 0.968f, size.height * 0.18f)
                            lineTo(size.width * 0.950f, size.height * 0.28f)
                            lineTo(size.width * 0.968f, size.height * 0.38f)
                            close()
                        }
                        drawPath(left, Color(0x50E8C359))
                        drawPath(right, Color(0x50E8C359))
                    }
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("⌕", color = Gold, fontSize = 24.sp)
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it.take(50) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp, textAlign = TextAlign.End, fontWeight = FontWeight.SemiBold),
                            cursorBrush = Brush.verticalGradient(listOf(Gold, Gold)),
                            decorationBox = { inner ->
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                                    if (searchQuery.isBlank()) Text("جستجوی نام در PV / GPV", color = TextSoft, fontSize = 13.sp)
                                    inner()
                                }
                            }
                        )
                        if (searchQuery.isNotBlank()) {
                            Text("×", color = TextSoft, fontSize = 20.sp, modifier = Modifier.clickable { searchQuery = "" })
                        }
                    }
                }
            }

            if (searchQuery.isNotBlank()) {
                Surface(
                    color = Color(0xF20A141F),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x556C7C8E)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column {
                        if (searchResults.isEmpty()) {
                            Text(
                                "فردی پیدا نشد",
                                color = TextSoft,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            )
                        } else {
                            searchResults.forEachIndexed { resultIndex, person ->
                                val index = people.indexOfFirst { it.id == person.id }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (index >= 0) {
                                                scope.launch { pagerState.animateScrollToPage(index) }
                                                searchQuery = ""
                                            }
                                        }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        Modifier
                                            .size(30.dp)
                                            .background(Color(0x222A76B8), CircleShape)
                                            .border(1.dp, Color(0x55E8C65D), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        TreePersonGlyph(Modifier.size(16.dp))
                                    }
                                    Text(
                                        person.name,
                                        color = Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1
                                    )
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("PV ${formatTreeNumber(person.pv)}", color = TextSoft, fontSize = 9.5.sp)
                                        Text("GPV ${formatTreeNumber(person.gpv)}", color = GoldSoft, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                if (resultIndex != searchResults.lastIndex) {
                                    HorizontalDivider(color = Color(0x334A5A68), modifier = Modifier.padding(horizontal = 12.dp))
                                }
                            }
                        }
                    }
                }
            }

            if (people.isEmpty()) {
                Text("هنوز فردی ثبت نشده است.", color = TextSoft, modifier = Modifier.padding(30.dp))
                return@Column
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) { page ->
                val person = people[page]
                TreeEntryCard(
                    person = person,
                    directCount = childrenOf(state.people, person.id).size,
                    organizationCount = person.active,
                    onSave = { updated ->
                        onSavePerson(updated)
                        markTreePersonStatsRecorded(context, updated.id)
                        if (page < people.lastIndex) scope.launch { pagerState.animateScrollToPage(page + 1) }
                    },
                    onAddDirect = { onAddDirect(person) },
                    onTodos = { onTodos(person) },
                    onActions = { onActions(person) },
                    onEdit = { onEdit(person) }
                )
            }
            Row(Modifier.padding(bottom = 10.dp, top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(people.size) { index ->
                    Surface(
                        color = if (index == pagerState.currentPage) Gold else Color(0xFF56616F),
                        shape = RoundedCornerShape(20.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (index == pagerState.currentPage) Color(0xFFFFE8A0) else Color(0x225E6C7C)
                        )
                    ) {
                        Box(
                            Modifier
                                .width(if (index == pagerState.currentPage) 22.dp else 8.dp)
                                .height(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TreeEntryCard(
    person: TreePerson,
    directCount: Int,
    organizationCount: Int,
    onSave: (TreePerson) -> Unit,
    onAddDirect: () -> Unit,
    onTodos: () -> Unit,
    onActions: () -> Unit,
    onEdit: () -> Unit
) {
    var pv by remember(person.id, person.pv) { mutableStateOf(formatTreeInput(person.pv)) }
    var gpv by remember(person.id, person.gpv) { mutableStateOf(formatTreeInput(person.gpv)) }
    var active by remember(person.id, person.active) { mutableStateOf(if (person.active == 0) "" else person.active.toString()) }
    val openTodos = person.todos.count { !it.done }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Surface(
                color = Color(0xD9081320),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.fillMaxWidth().border(1.4.dp, Color(0x9DECCB62), RoundedCornerShape(26.dp))
            ) {
                Box(Modifier.fillMaxWidth()) {
                    Canvas(Modifier.matchParentSize()) {
                        // ornamental inner glow + subtle geometry
                        drawRoundRect(
                            brush = Brush.verticalGradient(listOf(Color(0x1200A9FF), Color.Transparent, Color(0x12F7C948))),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(42f, 42f)
                        )
                        val lineY = size.height * 0.30f
                        drawLine(Color(0x18F7C948), Offset(size.width * 0.08f, lineY), Offset(size.width * 0.92f, lineY), strokeWidth = 1.4f)
                        drawCircle(Color(0x10F7C948), radius = size.minDimension * 0.13f, center = Offset(size.width * 0.15f, size.height * 0.12f), style = Stroke(width = 2f))
                        drawRoundRect(Color(0x122D7DFF), topLeft = Offset(size.width * 0.74f, size.height * 0.07f), size = Size(size.width * 0.12f, size.width * 0.12f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f), style = Stroke(width = 2f))
                        val p = Path().apply {
                            moveTo(size.width * 0.03f, size.height * 0.06f)
                            lineTo(size.width * 0.08f, size.height * 0.06f)
                            lineTo(size.width * 0.11f, size.height * 0.10f)
                            lineTo(size.width * 0.08f, size.height * 0.14f)
                            lineTo(size.width * 0.03f, size.height * 0.14f)
                            close()
                        }
                        drawPath(p, Color(0x26F7C948))
                    }
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        TreeHeroHeader(person = person, onEdit = onEdit)

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            TreeMetricInputCard("PV", pv, { pv = formatTypedNumber(it) }, Modifier.weight(0.95f))
                            TreeMetricInputCard("GPV", gpv, { gpv = formatTypedNumber(it) }, Modifier.weight(1.42f))
                            TreeMetricInputCard("تعداد", active, { active = it.filter(Char::isDigit).take(5) }, Modifier.weight(0.80f))
                        }

                        TreeActionButton("لیست افراد و اقدامات", "◉", onActions)
                        TreeActionButton("اضافه کردن دایرکت", "＋", onAddDirect)
                        TreeActionButton("To Do List", "✓", onTodos, badgeCount = openTodos)
                        Button(
                            onClick = { onSave(person.copy(pv = parseTreeNumber(pv), gpv = parseTreeNumber(gpv), active = parseTreeNumber(active))) },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("ذخیره اطلاعات ${person.name}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
        item {
            Surface(
                color = Color(0x8A0D1724),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x334C5E73), RoundedCornerShape(18.dp))
            ) {
                Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    TreeMiniMetric("PV هدف", formatTreeNumber(person.targetPv))
                    TreeMiniMetric("GPV هدف", formatTreeNumber(person.targetGpv))
                    TreeMiniMetric("اقدامات", person.actions.size.toString())
                    TreeMiniMetric("دایرکت", directCount.toString())
                    TreeMiniMetric("سازمان", organizationCount.toString())
                }
            }
        }
    }
}

@Composable
private fun TreeHeroHeader(
    person: TreePerson,
    onEdit: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Row(
            modifier = Modifier.fillMaxWidth().height(72.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier.size(56.dp)
                    .background(Brush.radialGradient(listOf(Color(0xFF10233A), Color(0xFF08121D))), CircleShape)
                    .border(2.dp, Gold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                TreePersonGlyph(Modifier.size(GamifyIcons.Feature))
            }
            Text(person.name, color = Color.White, style = GamifyType.Hero)
            Text("✎", color = GoldSoft, fontSize = 18.sp, modifier = Modifier.clickable(onClick = onEdit))
            Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun TreeMetricInputCard(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.border(1.2.dp, Color(0x44E9C55D), RoundedCornerShape(18.dp)),
        color = Color(0xC70D1724),
        shape = RoundedCornerShape(18.dp)
    ) {
        Box(Modifier.fillMaxWidth()) {
            Canvas(Modifier.matchParentSize()) {
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(Color(0x180F6EFF), Color.Transparent, Color(0x12F7C948))),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
                )
                drawLine(Color(0x18F7C948), Offset(size.width * 0.12f, size.height * 0.34f), Offset(size.width * 0.88f, size.height * 0.34f), strokeWidth = 1.2f)
            }
            Column(
                Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    Box(
                        Modifier.size(28.dp)
                            .background(Color(0x2B223548), CircleShape)
                            .border(1.dp, Color(0x44E7C358), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        TreeMetricGlyph(label, Modifier.size(GamifyIcons.Small))
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .background(Color(0xFF0B1420), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0x5A607285), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    BasicTextField(
                        value = value,
                        onValueChange = onChange,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(
                            textAlign = TextAlign.Center,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp
                        ),
                        cursorBrush = Brush.verticalGradient(listOf(Gold, Gold))
                    )
                }
            }
        }
    }
}

@Composable
private fun TreeMetricGlyph(label: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val stroke = 1.6.dp.toPx()
        when (label) {
            "PV" -> {
                val p = Path().apply {
                    moveTo(s * 0.50f, s * 0.08f)
                    cubicTo(s * 0.70f, s * 0.28f, s * 0.78f, s * 0.45f, s * 0.68f, s * 0.63f)
                    cubicTo(s * 0.59f, s * 0.81f, s * 0.34f, s * 0.86f, s * 0.22f, s * 0.68f)
                    cubicTo(s * 0.10f, s * 0.49f, s * 0.25f, s * 0.31f, s * 0.36f, s * 0.20f)
                    cubicTo(s * 0.35f, s * 0.39f, s * 0.44f, s * 0.45f, s * 0.50f, s * 0.08f)
                    close()
                }
                drawPath(p, color = Gold, style = Stroke(width = stroke, cap = StrokeCap.Round))
            }
            "GPV" -> {
                val xs = listOf(0.14f, 0.41f, 0.68f)
                val tops = listOf(0.56f, 0.38f, 0.18f)
                xs.indices.forEach { i ->
                    drawRoundRect(
                        color = Gold,
                        topLeft = Offset(s * xs[i], s * tops[i]),
                        size = Size(s * 0.18f, s * (0.78f - tops[i])),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.05f, s * 0.05f)
                    )
                }
            }
            else -> {
                drawCircle(color = Gold, radius = s * 0.18f, center = Offset(s * 0.5f, s * 0.32f), style = Stroke(width = stroke))
                drawArc(
                    color = Gold,
                    startAngle = 205f,
                    sweepAngle = 130f,
                    useCenter = false,
                    topLeft = Offset(s * 0.20f, s * 0.43f),
                    size = Size(s * 0.60f, s * 0.48f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
private fun TreePersonGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val headR = size.minDimension * 0.16f
        drawCircle(Gold, radius = headR, center = Offset(size.width * 0.5f, size.height * 0.28f), style = Stroke(width = size.minDimension * 0.08f))
        val shoulders = Path().apply {
            moveTo(size.width * 0.22f, size.height * 0.78f)
            quadraticBezierTo(size.width * 0.34f, size.height * 0.52f, size.width * 0.50f, size.height * 0.52f)
            quadraticBezierTo(size.width * 0.66f, size.height * 0.52f, size.width * 0.78f, size.height * 0.78f)
        }
        drawPath(shoulders, Gold, style = Stroke(width = size.minDimension * 0.08f, cap = StrokeCap.Round))
        val lapel = Path().apply {
            moveTo(size.width * 0.44f, size.height * 0.56f)
            lineTo(size.width * 0.50f, size.height * 0.72f)
            lineTo(size.width * 0.56f, size.height * 0.56f)
        }
        drawPath(lapel, GoldSoft)
        drawLine(GoldSoft, Offset(size.width * 0.50f, size.height * 0.72f), Offset(size.width * 0.50f, size.height * 0.88f), strokeWidth = size.minDimension * 0.06f, cap = StrokeCap.Round)
    }
}


@Composable
private fun TreeActionButton(text: String, glyph: String, onClick: () -> Unit, badgeCount: Int = 0) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xA40C1622), contentColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66708AA3))
        ) {
            Box(
                modifier = Modifier.size(28.dp)
                    .background(Color(0x23203348), CircleShape)
                    .border(1.dp, Color(0x55E4BE58), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(glyph, color = Gold, fontSize = 15.sp)
            }
            Spacer(Modifier.width(10.dp))
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Text(text, modifier = Modifier.weight(1f), textAlign = TextAlign.Start, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (badgeCount > 0) {
                    Box(Modifier.padding(start = 8.dp).size(22.dp).background(Color(0xFFD33131), CircleShape), contentAlignment = Alignment.Center) {
                        Text(badgeCount.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text("‹", color = GoldSoft, fontSize = 19.sp)
        }
    }
}

@Composable
private fun TreeMiniMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextSoft, fontSize = 8.sp)
        Text(value, color = GoldSoft, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}


@Composable
private fun TreeEditMetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color(0xCC0B1520),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x334E637A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 7.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(label, color = TextSoft, fontSize = 9.5.sp, textAlign = TextAlign.Center, maxLines = 1)
            val valueFontSize = when {
                value.length >= 11 -> 13.sp
                value.length >= 9 -> 15.sp
                value.length >= 7 -> 17.sp
                else -> 19.sp
            }
            Text(
                value,
                color = GoldSoft,
                fontSize = valueFontSize,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}



@Composable
private fun TreeDialogCloseButton(onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(28.dp)
            .background(Color(0xA0162230), CircleShape)
            .border(1.dp, Color(0x404E5C6C), CircleShape)
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Text("×", color = Color(0xFFE4EAF2), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TreeCheckerPattern(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cell = size.width / 7f
        var row = 0
        var y = 0f
        while (y < size.height + cell) {
            var col = 0
            var x = 0f
            while (x < size.width + cell) {
                if ((row + col) % 2 == 0) {
                    drawRect(Color(0x0AF7C948), topLeft = Offset(x, y), size = Size(cell, cell))
                } else {
                    drawRect(Color(0x071C4B77), topLeft = Offset(x, y), size = Size(cell, cell))
                }
                x += cell
                col++
            }
            y += cell
            row++
        }
    }
}

@Composable
private fun TreeCirclePattern(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawCircle(Color(0x14F7C948), radius = size.width * 0.24f, center = Offset(size.width * 0.08f, size.height * 0.20f))
        drawCircle(Color(0x0C2D6AA0), radius = size.width * 0.32f, center = Offset(size.width * 0.92f, size.height * 0.74f))
        drawCircle(Color(0x0AF7C948), radius = size.width * 0.11f, center = Offset(size.width * 0.72f, size.height * 0.18f), style = Stroke(width = 2f))
    }
}

@Composable
private fun TreeTodoHeaderIcon() {
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0x26F7C948), Color(0x120C1622), Color.Transparent)
                ),
                CircleShape
            )
            .border(1.dp, Color(0x55F7C948), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(GamifyIcons.Navigation)) {
            val stroke = 1.9f
            drawRoundRect(
                color = GoldSoft,
                topLeft = Offset(size.width * 0.18f, size.height * 0.18f),
                size = Size(size.width * 0.64f, size.height * 0.68f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
                style = Stroke(width = stroke)
            )
            drawRoundRect(
                color = GoldSoft,
                topLeft = Offset(size.width * 0.34f, size.height * 0.08f),
                size = Size(size.width * 0.30f, size.height * 0.16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f, 5f),
                style = Stroke(width = stroke)
            )
            drawLine(GoldSoft, Offset(size.width * 0.28f, size.height * 0.42f), Offset(size.width * 0.40f, size.height * 0.54f), strokeWidth = stroke, cap = StrokeCap.Round)
            drawLine(GoldSoft, Offset(size.width * 0.40f, size.height * 0.54f), Offset(size.width * 0.66f, size.height * 0.30f), strokeWidth = stroke, cap = StrokeCap.Round)
            drawLine(GoldSoft, Offset(size.width * 0.28f, size.height * 0.70f), Offset(size.width * 0.68f, size.height * 0.70f), strokeWidth = stroke, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun TreeEditNumericField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val numericFontSize = when {
        value.length >= 11 -> 13.sp
        value.length >= 9 -> 14.5.sp
        value.length >= 7 -> 16.sp
        else -> 17.sp
    }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.height(72.dp),
        label = { Text(label, fontSize = 8.5.sp, maxLines = 1) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        textStyle = TextStyle(fontSize = numericFontSize, textAlign = TextAlign.Center),
        colors = gamifyTextFieldColors(),
        shape = GamifyShapes.Field
    )
}

private data class GraphNode(val person: TreePerson, val center: Offset, val root: Boolean)
private data class GraphEdge(val fromId: String, val toId: String, val from: Offset, val to: Offset)
private data class GraphLayout(val nodes: List<GraphNode>, val edges: List<GraphEdge>, val width: Float, val height: Float)

private fun buildGraphLayout(
    people: List<TreePerson>,
    closed: Set<String>,
    nodeWidth: Float,
    nodeHeight: Float,
    xGap: Float,
    yGap: Float
): GraphLayout {
    val roots = people.filter { it.parentId == null || people.none { p -> p.id == it.parentId } }.ifEmpty { people.take(1) }
    val widthCache = mutableMapOf<String, Float>()
    fun visibleChildren(id: String): List<TreePerson> = if (id in closed) emptyList() else childrenOf(people, id)
    fun subtreeWidth(person: TreePerson): Float {
        return widthCache.getOrPut(person.id) {
            val children = visibleChildren(person.id)
            if (children.isEmpty()) nodeWidth else max(nodeWidth, children.sumOf { subtreeWidth(it).toDouble() }.toFloat() + xGap * (children.size - 1).coerceAtLeast(0))
        }
    }
    val totalWidth = max(nodeWidth, roots.sumOf { subtreeWidth(it).toDouble() }.toFloat() + xGap * (roots.size - 1).coerceAtLeast(0))
    val nodes = mutableListOf<GraphNode>()
    val edges = mutableListOf<GraphEdge>()
    var maxY = nodeHeight
    fun place(person: TreePerson, left: Float, level: Int): Offset {
        val ownWidth = subtreeWidth(person)
        val center = Offset(left + ownWidth / 2f, nodeHeight / 2f + level * (nodeHeight + yGap))
        nodes += GraphNode(person, center, person.parentId == null)
        maxY = max(maxY, center.y + nodeHeight / 2f)
        val children = visibleChildren(person.id)
        if (children.isNotEmpty()) {
            var childLeft = left
            children.forEach { child ->
                val childWidth = subtreeWidth(child)
                val childCenter = place(child, childLeft, level + 1)
                edges += GraphEdge(person.id, child.id, Offset(center.x, center.y + nodeHeight / 2f), Offset(childCenter.x, childCenter.y - nodeHeight / 2f))
                childLeft += childWidth + xGap
            }
        }
        return center
    }
    var left = 0f
    roots.forEach { root ->
        place(root, left, 0)
        left += subtreeWidth(root) + xGap
    }
    return GraphLayout(nodes, edges, totalWidth, maxY)
}

private fun treeGoalProgress(person: TreePerson): Float? {
    val values = buildList {
        if (person.targetPv > 0) add(person.pv.toFloat() / person.targetPv.toFloat())
        if (person.targetGpv > 0) add(person.gpv.toFloat() / person.targetGpv.toFloat())
        if (person.targetActive > 0) add(person.active.toFloat() / person.targetActive.toFloat())
    }
    if (values.isEmpty()) return null
    return (values.sum() / values.size).coerceIn(0f, 1.25f)
}

@Composable
private fun TreeGraphScreen(
    state: TreeState,
    onPersonClick: (TreePerson) -> Unit,
    onStateViewChange: (Float, Offset, Set<String>, Boolean) -> Unit,
    focusPersonId: String?,
    focusRequest: Int,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val nodeWidth = with(density) { 166.dp.toPx() }
    val nodeHeight = with(density) { 108.dp.toPx() }
    val xGap = with(density) { 46.dp.toPx() }
    val yGap = with(density) { 72.dp.toPx() }
    var zoom by remember { mutableFloatStateOf(state.zoom.coerceIn(0.15f, 4.0f)) }
    var pan by remember { mutableStateOf(if (state.viewInitialized) Offset(state.panX, state.panY) else Offset.Zero) }
    var closed by remember(state.closedIds) { mutableStateOf(state.closedIds) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var searchQuery by remember { mutableStateOf("") }
    var localFocusId by remember { mutableStateOf<String?>(null) }
    var highlightedPersonId by remember { mutableStateOf<String?>(focusPersonId) }
    var didInitialCenter by remember { mutableStateOf(state.viewInitialized) }
    var pendingAnchorId by remember { mutableStateOf<String?>(null) }
    var pendingAnchorScreen by remember { mutableStateOf<Offset?>(null) }
    val childCountById = remember(state.people) {
        state.people.groupingBy { it.parentId }.eachCount()
    }
    val organizationCountById = remember(state.people) {
        state.people.associate { person -> person.id to person.active }
    }
    // Every person card uses the same name size.  The size is calculated from
    // the widest name so switching people never changes the visual rhythm.
    val compactNameTextSize = remember(state.people, nodeWidth, nodeHeight) {
        val maxSize = nodeHeight * 0.34f
        val probe = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = maxSize
        }
        val widest = state.people.maxOfOrNull { probe.measureText(it.name.ifBlank { "—" }) } ?: 1f
        (maxSize * ((nodeWidth * 0.84f) / widest).coerceAtMost(1f))
            .coerceAtLeast(nodeHeight * 0.16f)
    }
    val fullNameTextSize = remember(state.people, nodeWidth, nodeHeight) {
        val maxSize = nodeHeight * 0.205f
        val probe = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = maxSize
        }
        val widest = state.people.maxOfOrNull { probe.measureText(it.name.ifBlank { "—" }) } ?: 1f
        (maxSize * ((nodeWidth * 0.84f) / widest).coerceAtMost(1f))
            .coerceAtLeast(nodeHeight * 0.12f)
    }
    val layout = remember(state.people, closed, nodeWidth, nodeHeight, xGap, yGap) {
        buildGraphLayout(state.people, closed, nodeWidth, nodeHeight, xGap, yGap)
    }
    val highlightedPath = remember(highlightedPersonId, state.people) {
        highlightedPersonId?.let { ancestorIds(state.people, it) + it } ?: emptySet()
    }

    fun fitTreeInView() {
        if (viewportSize.width <= 0 || viewportSize.height <= 0 || layout.width <= 0f || layout.height <= 0f) return
        val horizontalSpace = (viewportSize.width - 30f).coerceAtLeast(1f)
        val topReserved = with(density) { 126.dp.toPx() }
        val bottomReserved = with(density) { 34.dp.toPx() }
        val verticalSpace = (viewportSize.height - topReserved - bottomReserved).coerceAtLeast(1f)
        val fit = min(horizontalSpace / layout.width, verticalSpace / layout.height).coerceIn(0.15f, 4.0f)
        zoom = fit
        pan = Offset(
            (viewportSize.width - layout.width * fit) / 2f,
            topReserved + (verticalSpace - layout.height * fit) / 2f
        )
    }

    LaunchedEffect(zoom, pan, closed, didInitialCenter) {
        delay(280)
        if (
            zoom != state.zoom ||
            pan.x != state.panX ||
            pan.y != state.panY ||
            closed != state.closedIds ||
            didInitialCenter != state.viewInitialized
        ) {
            onStateViewChange(zoom, pan, closed, didInitialCenter)
        }
    }

    LaunchedEffect(layout.width, layout.height, viewportSize) {
        if (!didInitialCenter && viewportSize.width > 0 && viewportSize.height > 0) {
            fitTreeInView()
            didInitialCenter = true
        }
    }

    LaunchedEffect(layout.nodes, pendingAnchorId, pendingAnchorScreen, zoom) {
        val anchorId = pendingAnchorId ?: return@LaunchedEffect
        val screenPoint = pendingAnchorScreen ?: return@LaunchedEffect
        val anchorNode = layout.nodes.firstOrNull { it.person.id == anchorId } ?: return@LaunchedEffect
        pan = screenPoint - Offset(anchorNode.center.x * zoom, anchorNode.center.y * zoom)
        pendingAnchorId = null
        pendingAnchorScreen = null
    }

    LaunchedEffect(focusPersonId, focusRequest) {
        val id = focusPersonId ?: return@LaunchedEffect
        closed = closed - ancestorIds(state.people, id)
        highlightedPersonId = id
        localFocusId = id
        searchQuery = ""
    }

    LaunchedEffect(localFocusId, layout.nodes, viewportSize, zoom) {
        val id = localFocusId ?: return@LaunchedEffect
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return@LaunchedEffect
        val node = layout.nodes.firstOrNull { it.person.id == id } ?: return@LaunchedEffect
        pan = Offset(
            viewportSize.width / 2f - node.center.x * zoom,
            viewportSize.height * 0.52f - node.center.y * zoom
        )
        highlightedPersonId = id
        localFocusId = null
    }

    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1A28), Color(0xFF102233), Color(0xFF0A1723))
                )
            )
            .onSizeChanged { viewportSize = it }
    ) {
        // Soft decorative layer: same visual language as the other modules, intentionally faint.
        Canvas(Modifier.fillMaxSize()) {
            val tile = size.width / 7f
            var row = 0
            var y = 0f
            while (y < size.height + tile) {
                var col = 0
                var x = 0f
                while (x < size.width + tile) {
                    if ((row + col) % 2 == 0) {
                        drawRect(Color(0x071E6DA8), topLeft = Offset(x, y), size = Size(tile, tile))
                    } else {
                        drawRect(Color(0x05E8C65D), topLeft = Offset(x, y), size = Size(tile, tile))
                    }
                    x += tile
                    col++
                }
                y += tile
                row++
            }
            drawCircle(Color(0x0DE8C65D), radius = size.width * 0.29f, center = Offset(size.width * 0.10f, size.height * 0.17f))
            drawCircle(Color(0x0A2B72AE), radius = size.width * 0.38f, center = Offset(size.width * 0.92f, size.height * 0.72f))
            drawCircle(Color(0x0AE8C65D), radius = size.width * 0.13f, center = Offset(size.width * 0.76f, size.height * 0.22f), style = Stroke(width = 2f))
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(layout.nodes, viewportSize) {
                    detectTransformGestures(panZoomLock = false) { centroid, panChange, zoomChange, _ ->
                        val oldZoom = zoom
                        val newZoom = (oldZoom * zoomChange).coerceIn(0.15f, 4.0f)
                        val scaleFactor = if (oldZoom == 0f) 1f else newZoom / oldZoom
                        pan = centroid - (centroid - pan) * scaleFactor + panChange
                        zoom = newZoom
                        didInitialCenter = true
                    }
                }
                .pointerInput(layout.nodes, zoom, pan, closed) {
                    detectTapGestures { tap ->
                        val logical = Offset((tap.x - pan.x) / zoom, (tap.y - pan.y) / zoom)
                        val toggleHit = layout.nodes.firstOrNull { node ->
                            val childCount = childCountById[node.person.id] ?: 0
                            val toggleCenter = Offset(node.center.x, node.center.y + nodeHeight * 0.56f)
                            childCount > 0 && hypot(
                                (toggleCenter.x - logical.x).toDouble(),
                                (toggleCenter.y - logical.y).toDouble()
                            ) <= nodeHeight * 0.15f
                        }
                        if (toggleHit != null) {
                            pendingAnchorId = toggleHit.person.id
                            pendingAnchorScreen = Offset(
                                pan.x + toggleHit.center.x * zoom,
                                pan.y + toggleHit.center.y * zoom
                            )
                            closed = if (toggleHit.person.id in closed) closed - toggleHit.person.id else closed + toggleHit.person.id
                        } else {
                            val hit = layout.nodes.firstOrNull { node ->
                                logical.x in (node.center.x - nodeWidth / 2f)..(node.center.x + nodeWidth / 2f) &&
                                    logical.y in (node.center.y - nodeHeight / 2f)..(node.center.y + nodeHeight / 2f)
                            }
                            if (hit != null) {
                                highlightedPersonId = hit.person.id
                                onPersonClick(hit.person)
                            }
                        }
                    }
                }
        ) {
            val gridStep = 56.dp.toPx()
            var gx = 0f
            while (gx <= size.width) {
                drawLine(Color(0x102E4052), Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1f)
                gx += gridStep
            }
            var gy = 0f
            while (gy <= size.height) {
                drawLine(Color(0x0D2E4052), Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                gy += gridStep
            }

            withTransform({
                translate(pan.x, pan.y)
                scale(zoom, zoom, pivot = Offset.Zero)
            }) {
                layout.edges.forEach { edge ->
                    val activeBranch = edge.fromId in highlightedPath && edge.toId in highlightedPath
                    val midY = (edge.from.y + edge.to.y) / 2f
                    val path = Path().apply {
                        moveTo(edge.from.x, edge.from.y)
                        cubicTo(edge.from.x, midY, edge.to.x, midY, edge.to.x, edge.to.y)
                    }
                    drawPath(
                        path = path,
                        color = if (activeBranch) Color(0x2EFFD96A) else Color(0x1B243342),
                        style = Stroke(width = if (activeBranch) 8f else 5.5f, cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = path,
                        color = if (activeBranch) Color(0xFFFFD86A) else Color(0x9A8296AA),
                        style = Stroke(width = if (activeBranch) 3.2f else 1.9f, cap = StrokeCap.Round)
                    )
                    val junction = Offset(edge.from.x, midY)
                    drawCircle(if (activeBranch) Gold else Color(0xFF7890A8), radius = 3.6f, center = junction)
                    drawCircle(if (activeBranch) Gold else Color(0xFF8299AE), radius = 3.3f, center = edge.to)
                }

                layout.nodes.forEach { node ->
                    val left = node.center.x - nodeWidth / 2f
                    val top = node.center.y - nodeHeight / 2f
                    val cardSize = Size(nodeWidth, nodeHeight)
                    val isFocused = node.person.id == highlightedPersonId
                    val progress = treeGoalProgress(node.person)
                    val accent = if (isFocused) Gold else Color(0xFF63A8EA)
                    val orgCount = organizationCountById[node.person.id] ?: 0
                    val childCount = childCountById[node.person.id] ?: 0
                    // One clean threshold: far zoom = identity/name only;
                    // closer zoom = the complete person snapshot. Card geometry never changes.
                    val showFullDetails = zoom >= 0.58f

                    drawRoundRect(
                        color = accent.copy(alpha = if (isFocused) 0.16f else 0.055f),
                        topLeft = Offset(left - 5f, top - 5f),
                        size = Size(nodeWidth + 10f, nodeHeight + 10f),
                        cornerRadius = CornerRadius(26f, 26f)
                    )
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF122435), Color(0xFF0C1621), Color(0xFF0A131D)),
                            start = Offset(left, top),
                            end = Offset(left + nodeWidth, top + nodeHeight)
                        ),
                        topLeft = Offset(left, top),
                        size = cardSize,
                        cornerRadius = CornerRadius(24f, 24f)
                    )
                    drawRoundRect(
                        color = accent,
                        topLeft = Offset(left, top),
                        size = cardSize,
                        cornerRadius = CornerRadius(24f, 24f),
                        style = Stroke(width = if (isFocused) 4.2f else 2.4f)
                    )
                    drawRoundRect(
                        color = Color(0x2AFFFFFF),
                        topLeft = Offset(left + 1.5f, top + 1.5f),
                        size = Size(nodeWidth - 3f, nodeHeight - 3f),
                        cornerRadius = CornerRadius(22f, 22f),
                        style = Stroke(width = 1f)
                    )
                    // A restrained top sheen gives every equal-size card a cleaner hierarchy
                    // without introducing a different root/direct visual language.
                    drawLine(
                        color = Color(0x2FFFFFFF),
                        start = Offset(left + nodeWidth * 0.15f, top + 8f),
                        end = Offset(left + nodeWidth * 0.85f, top + 8f),
                        strokeWidth = 1.2f,
                        cap = StrokeCap.Round
                    )

                    if (showFullDetails && progress != null) {
                        val trackLeft = left + 14f
                        val trackTop = top + nodeHeight - 10f
                        val trackWidth = nodeWidth - 28f
                        drawRoundRect(
                            color = Color(0xFF203244),
                            topLeft = Offset(trackLeft, trackTop),
                            size = Size(trackWidth, 5.5f),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                        drawRoundRect(
                            color = if (progress >= 1f) Color(0xFF54D887) else Gold,
                            topLeft = Offset(trackLeft, trackTop),
                            size = Size(trackWidth * progress.coerceIn(0f, 1f), 5.5f),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }

                    drawIntoCanvas { canvas ->
                        val native = canvas.nativeCanvas
                        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE
                            textAlign = Paint.Align.CENTER
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            textSize = if (showFullDetails) fullNameTextSize else compactNameTextSize
                        }
                        val pvPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(226, 233, 240)
                            textAlign = Paint.Align.CENTER
                            textSize = nodeHeight * 0.110f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        }
                        val gpvPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(247, 201, 72)
                            textAlign = Paint.Align.CENTER
                            textSize = nodeHeight * 0.124f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        }
                        val orgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(166, 198, 226)
                            textAlign = Paint.Align.CENTER
                            textSize = nodeHeight * 0.118f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                        }

                        if (!showFullDetails) {
                            // At deep zoom-out the name owns the card: one large centered line.
                            val fm = namePaint.fontMetrics
                            val baseline = node.center.y - (fm.ascent + fm.descent) / 2f
                            native.drawText(node.person.name, node.center.x, baseline, namePaint)
                        } else {
                            // Spacious rhythm: name and each metric get their own visual line.
                            val nameY = top + nodeHeight * 0.19f
                            val pvY = top + nodeHeight * 0.43f
                            val gpvY = top + nodeHeight * 0.65f
                            val orgY = top + nodeHeight * 0.86f
                            native.drawText(node.person.name, node.center.x, nameY, namePaint)
                            native.drawText("PV  ${formatTreeNumber(node.person.pv)}", node.center.x, pvY, pvPaint)
                            native.drawText("GPV  ${formatTreeNumber(node.person.gpv)}", node.center.x, gpvY, gpvPaint)
                            native.drawText("تعداد  ${formatTreeNumber(orgCount)}", node.center.x, orgY, orgPaint)
                        }
                    }

                    if (childCount > 0) {
                        val toggleCenter = Offset(node.center.x, node.center.y + nodeHeight * 0.56f)
                        val toggleRadius = nodeHeight * 0.12f
                        drawCircle(Color(0xFF0B1621), toggleRadius * 1.18f, toggleCenter)
                        drawCircle(Color(0xFF101D29), toggleRadius, toggleCenter)
                        drawCircle(if (node.person.id in closed) Gold else accent, toggleRadius, toggleCenter, style = Stroke(width = 2.2f))
                        drawIntoCanvas { canvas ->
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = if (node.person.id in closed) android.graphics.Color.rgb(247, 201, 72) else android.graphics.Color.WHITE
                                textAlign = Paint.Align.CENTER
                                textSize = nodeHeight * 0.11f
                                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            }
                            canvas.nativeCanvas.drawText(if (node.person.id in closed) "+" else "−", toggleCenter.x, toggleCenter.y + nodeHeight * 0.035f, paint)
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 6.dp)
                .background(Color(0xE90A131D), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0x55718395), RoundedCornerShape(16.dp))
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${(zoom * 100).toInt()}٪",
                color = GoldSoft,
                fontSize = 10.sp,
                modifier = Modifier.width(46.dp),
                textAlign = TextAlign.Center
            )
            TreeToolButton("◎") { fitTreeInView(); didInitialCenter = true }
            TreeToolButton("↧") { closed = emptySet(); highlightedPersonId = null }
            TreeToolButton("↥") {
                closed = state.people.filter { childrenOf(state.people, it.id).isNotEmpty() }.map { it.id }.toSet()
                highlightedPersonId = null
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 54.dp, start = 12.dp, end = 12.dp)
                .widthIn(max = 320.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(60) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("جستجوی فرد", fontSize = 11.sp) },
                leadingIcon = { Text("⌕", color = Gold, fontSize = 15.sp) },
                colors = gamifyTextFieldColors(),
                shape = GamifyShapes.Field
            )
            if (searchQuery.isNotBlank()) {
                val matches = state.people
                    .filter { it.name.contains(searchQuery.trim(), ignoreCase = true) }
                    .take(5)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xF20A121C),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x556B7888))
                ) {
                    Column {
                        if (matches.isEmpty()) {
                            Text("نتیجه‌ای پیدا نشد", color = TextSoft, fontSize = 10.sp, modifier = Modifier.padding(12.dp))
                        } else {
                            matches.forEachIndexed { index, person ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            closed = closed - ancestorIds(state.people, person.id)
                                            highlightedPersonId = person.id
                                            localFocusId = person.id
                                            searchQuery = ""
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(person.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("PV ${formatTreeNumber(person.pv)}", color = TextSoft, fontSize = 9.sp)
                                        Text("GPV ${formatTreeNumber(person.gpv)}", color = GoldSoft, fontSize = 9.sp)
                                    }
                                }
                                if (index != matches.lastIndex) HorizontalDivider(color = Color(0x334D5A68))
                            }
                        }
                    }
                }
            }
        }

        val highlightedPerson = highlightedPersonId?.let { id -> state.people.firstOrNull { it.id == id } }
        if (highlightedPerson != null) {
            val progress = treeGoalProgress(highlightedPerson)
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 9.dp),
                color = Color(0xD90A131D),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x667A8795))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(highlightedPerson.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("PV ${formatTreeNumber(highlightedPerson.pv)}", color = TextSoft, fontSize = 9.sp)
                    Text("GPV ${formatTreeNumber(highlightedPerson.gpv)}", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    if (progress != null) Text("هدف ${(progress * 100).toInt()}٪", color = if (progress >= 1f) Color(0xFF65E596) else GoldSoft, fontSize = 9.sp)
                }
            }
        } else {
            Text(
                "یک انگشت: حرکت  •  دو انگشت: زوم  •  لمس کارت: منوی فرد",
                color = Color(0xFF8E9AA8),
                fontSize = 8.5.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 9.dp)
                    .background(Color(0xA8081018), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
private fun TreeToolButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(28.dp)
            .background(Color(0x66172533), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0x446E8295), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun TreeCompareScreen(state: TreeState, modifier: Modifier = Modifier) {
    var historyMode by remember { mutableStateOf(true) }
    Column(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TreeModeChip("مقایسه افراد", !historyMode) { historyMode = false }
            TreeModeChip("مقایسه زمانی", historyMode) { historyMode = true }
        }
        if (historyMode) HistoryComparePane(state, Modifier.weight(1f)) else PeopleComparePane(state, Modifier.weight(1f))
    }
}

@Composable
private fun TreeModeChip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(42.dp).background(if (active) Color(0x22F7C948) else Color(0x44141E2A), RoundedCornerShape(13.dp)).border(1.dp, if (active) Gold else Color(0x554A5767), RoundedCornerShape(13.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (active) GoldSoft else TextSoft, fontSize = 11.sp) }
}

@Composable
private fun PeopleComparePane(state: TreeState, modifier: Modifier = Modifier) {
    val people = state.people
    val selected = remember(people) { mutableStateListOf<String>().also { list -> repeat(3) { list += people.getOrNull(it)?.id ?: people.firstOrNull()?.id.orEmpty() } } }
    val chosen = selected.map { id -> people.firstOrNull { it.id == id } }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { index ->
                TreeDropdown(
                    value = people.firstOrNull { it.id == selected[index] }?.name ?: "—",
                    options = people.map { it.id to it.name },
                    onSelect = { selected[index] = it },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        TreeCompareTable(
            headers = chosen.map { it?.name ?: "—" },
            rows = listOf(
                "PV" to chosen.map { formatTreeNumber(it?.pv ?: 0) },
                "GPV" to chosen.map { formatTreeNumber(it?.gpv ?: 0) },
                "فعال" to chosen.map { (it?.active ?: 0).toString() }
            )
        )
    }
}

@Composable
private fun HistoryComparePane(state: TreeState, modifier: Modifier = Modifier) {
    if (state.snapshots.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("هنوز تاریخچه‌ای ثبت نشده است.", color = TextSoft)
        }
        return
    }

    var personId by remember(state.people) { mutableStateOf(state.people.firstOrNull()?.id.orEmpty()) }
    val keys = remember(state.snapshots) {
        mutableStateListOf<String>().also { list ->
            repeat(3) { index ->
                list += state.snapshots.getOrNull(index)?.key ?: state.snapshots.first().key
            }
        }
    }
    var pickerIndex by remember { mutableStateOf<Int?>(null) }
    val snapshotPeople = keys.map { key ->
        state.snapshots.firstOrNull { it.key == key }?.people?.firstOrNull { it.id == personId }
    }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("مقایسه زمانی", color = GoldSoft, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        Text("یک نفر و سه تاریخ شمسی را انتخاب کن.", color = TextSoft, fontSize = 10.sp)

        TreeDropdown(
            value = state.people.firstOrNull { it.id == personId }?.name ?: "انتخاب فرد",
            options = state.people.map { it.id to it.name },
            onSelect = { personId = it },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { index ->
                val hasSnapshot = state.snapshots.any { it.key == keys[index] }
                TreeDateButton(
                    label = persianDigits(jalaliLabelFromKey(keys[index])),
                    hasSnapshot = hasSnapshot,
                    onClick = { pickerIndex = index },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        TreeCompareTable(
            headers = keys.map { key -> persianDigits(jalaliLabelFromKey(key)) },
            rows = listOf(
                "PV" to snapshotPeople.map { formatTreeNumber(it?.pv ?: 0) },
                "GPV" to snapshotPeople.map { formatTreeNumber(it?.gpv ?: 0) },
                "فعال" to snapshotPeople.map { if (it == null) "—" else it.active.toString() }
            )
        )

        val missing = keys.mapIndexedNotNull { index, key -> if (state.snapshots.none { it.key == key }) index + 1 else null }
        if (missing.isNotEmpty()) {
            Text(
                "برای تاریخ ${missing.joinToString("، ") { persianDigits(it.toString()) }} داده‌ای ثبت نشده است.",
                color = Color(0xFFE5A85B),
                fontSize = 9.5.sp
            )
        }
    }

    pickerIndex?.let { index ->
        JalaliTreeDatePickerDialog(
            initialKey = keys[index],
            availableSnapshotKeys = state.snapshots.map { it.key }.toSet(),
            onDismiss = { pickerIndex = null },
            onConfirm = { key ->
                keys[index] = key
                pickerIndex = null
            }
        )
    }
}

@Composable
private fun TreeDateButton(
    label: String,
    hasSnapshot: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .height(56.dp)
            .background(Color(0xFF101A25), RoundedCornerShape(12.dp))
            .border(1.dp, if (hasSnapshot) Color(0xFF6C5A32) else Color(0xFF68413A), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(if (hasSnapshot) "ثبت شده" else "بدون ثبت", color = if (hasSnapshot) GoldSoft else Color(0xFFD98A7F), fontSize = 7.5.sp)
    }
}

@Composable
private fun JalaliTreeDatePickerDialog(
    initialKey: String,
    availableSnapshotKeys: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val initialGregorian = runCatching { LocalDate.parse(initialKey) }.getOrDefault(LocalDate.now())
    val initial = gregorianToJalali(initialGregorian)
    val currentJalali = gregorianToJalali(LocalDate.now())
    val availableYears = availableSnapshotKeys.mapNotNull { key ->
        runCatching { gregorianToJalali(LocalDate.parse(key)).year }.getOrNull()
    }
    val minYear = minOf((availableYears.minOrNull() ?: currentJalali.year) - 1, initial.year)
    val maxYear = maxOf(currentJalali.year + 1, availableYears.maxOrNull() ?: currentJalali.year, initial.year)

    var year by remember(initialKey) { mutableStateOf(initial.year) }
    var month by remember(initialKey) { mutableStateOf(initial.month) }
    var day by remember(initialKey) { mutableStateOf(initial.day) }

    LaunchedEffect(year, month) {
        val dayLimit = jalaliMonthLength(year, month)
        if (day > dayLimit) day = dayLimit
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0C151F),
        shape = RoundedCornerShape(22.dp),
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("انتخاب تاریخ شمسی", color = GoldSoft, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    persianDigits(String.format(Locale.US, "%04d/%02d/%02d", year, month, day)),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("سال", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = persianDigits(year.toString()),
                    options = (maxYear downTo minYear).map { it.toString() to persianDigits(it.toString()) },
                    onSelect = { year = it.toIntOrNull() ?: year },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("ماه", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = jalaliMonthNames[month - 1],
                    options = jalaliMonthNames.mapIndexed { index, name -> (index + 1).toString() to name },
                    onSelect = { month = it.toIntOrNull()?.coerceIn(1, 12) ?: month },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("روز", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = persianDigits(day.toString()),
                    options = (1..jalaliMonthLength(year, month)).map { it.toString() to persianDigits(it.toString()) },
                    onSelect = { day = it.toIntOrNull()?.coerceIn(1, jalaliMonthLength(year, month)) ?: day },
                    modifier = Modifier.fillMaxWidth()
                )

                val selectedKey = runCatching { jalaliToGregorian(JalaliDate(year, month, day)).toString() }.getOrNull()
                val hasData = selectedKey != null && selectedKey in availableSnapshotKeys
                Surface(
                    color = if (hasData) Color(0x2210B981) else Color(0x22D97757),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (hasData) "برای این تاریخ اطلاعات ثبت شده است." else "برای این تاریخ هنوز اطلاعاتی ثبت نشده است.",
                        color = if (hasData) Color(0xFF8EE0B8) else Color(0xFFE7A18C),
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(9.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val key = jalaliToGregorian(JalaliDate(year, month, day)).toString()
                    onConfirm(key)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Gold)
            ) { Text("انتخاب", color = Color(0xFF16100A), fontWeight = FontWeight.ExtraBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف", color = TextSoft) } }
    )
}

@Composable
private fun TreeCompareTable(headers: List<String>, rows: List<Pair<String, List<String>>>) {
    Surface(color = Color(0xCC0D1722), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x444D5A69), RoundedCornerShape(18.dp))) {
        Column {
            Row(Modifier.fillMaxWidth().background(Color(0x331F2A36)).padding(vertical = 10.dp)) {
                Text("", Modifier.width(72.dp))
                headers.forEach { Text(it.take(12), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
            rows.forEachIndexed { index, row ->
                if (index > 0) HorizontalDivider(color = Color(0x223D4A57))
                Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row.first, color = TextSoft, fontSize = 10.sp, modifier = Modifier.width(72.dp).padding(start = 8.dp))
                    row.second.forEach { Text(it, color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun TreeDropdown(
    value: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        Box(
            Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF101A25), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF43505E), RoundedCornerShape(12.dp)).clickable { expanded = true }.padding(horizontal = 9.dp),
            contentAlignment = Alignment.Center
        ) { Text(value, color = Color.White, fontSize = 10.sp, maxLines = 1) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (key, label) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(key); expanded = false })
            }
        }
    }
}

@Composable
private fun TreeRankingScreen(state: TreeState, onPersonClick: (TreePerson) -> Unit, modifier: Modifier = Modifier) {
    var mode by remember { mutableStateOf(RankMode.Pv) }
    val candidates = state.people.filter { it.parentId != null }
    fun value(person: TreePerson): Int = when (mode) {
        RankMode.Pv -> person.pv
        RankMode.Gpv -> person.gpv
        RankMode.Members -> person.active
        RankMode.Actions -> person.actions.size
    }
    val sorted = candidates.sortedByDescending(::value)
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RankMode.entries.forEach { item -> TreeModeChip(item.title, mode == item) { mode = item } }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(sorted, key = { it.id }) { person ->
                val rank = sorted.indexOf(person) + 1
                Surface(
                    color = Color(0xC9101924),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onPersonClick(person) }.border(1.dp, if (rank <= 3) Color(0x55F7C948) else Color(0x334B5968), RoundedCornerShape(16.dp))
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(if (rank == 1) Color(0x22F7C948) else Color(0x221C2733), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                            Text(rank.toString(), color = if (rank <= 3) Gold else TextSoft, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(person.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(formatTreeNumber(value(person)), color = GoldSoft, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddDirectDialog(parent: TreePerson, onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xF20B1620),
            shape = RoundedCornerShape(28.dp),
            title = {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(Modifier.fillMaxWidth()) {
                        TreeDialogCloseButton(onDismiss, Modifier.align(Alignment.CenterStart))
                        Text(
                            "اضافه کردن دایرکت",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.align(Alignment.CenterEnd).padding(start = 48.dp)
                        )
                    }
                }
            },
            text = {
                Box(Modifier.fillMaxWidth()) {
                    TreeCirclePattern(Modifier.matchParentSize())
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "زیرمجموعه ${parent.name}",
                            color = TextSoft,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(60) },
                            label = { Text("نام فرد", fontSize = 10.sp) },
                            singleLine = true,
                            textStyle = TextStyle(textAlign = TextAlign.Right, fontSize = 18.sp),
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = name.trim().isNotBlank(), onClick = { onAdd(name) }) {
                    Text("ثبت", color = Gold, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {}
        )
    }
}

@Composable
private fun TransferSponsorDialog(
    person: TreePerson,
    people: List<TreePerson>,
    onDismiss: () -> Unit,
    onTransfer: (String) -> Unit
) {
    var query by remember(person.id) { mutableStateOf("") }
    val blockedIds = descendantIds(people, person.id) + person.id
    val candidates = people
        .filter { it.id !in blockedIds }
        .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        title = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(Modifier.fillMaxWidth()) {
                    TreeDialogCloseButton(onDismiss, Modifier.align(Alignment.CenterStart))
                    Text("تغییر حامی", color = Color.White, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Right, modifier = Modifier.align(Alignment.CenterEnd).padding(start = 48.dp))
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("حامی جدید ${person.name} را انتخاب کن.", color = TextSoft, fontSize = 11.sp)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it.take(60) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("جستجوی حامی") },
                    colors = gamifyTextFieldColors(),
                    shape = GamifyShapes.Field
                )
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 330.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(candidates, key = { it.id }) { candidate ->
                        val selected = person.parentId == candidate.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (selected) Color(0x22F7C948) else Color(0x33121C27), RoundedCornerShape(12.dp))
                                .border(1.dp, if (selected) Gold else Color(0x334F5C6B), RoundedCornerShape(12.dp))
                                .clickable(enabled = !selected) { onTransfer(candidate.id) }
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(candidate.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("${childrenOf(people, candidate.id).size} دایرکت • ${formatTreeNumber(candidate.active)} نفر سازمان", color = TextSoft, fontSize = 9.sp)
                            }
                            if (selected) Text("حامی فعلی", color = GoldSoft, fontSize = 9.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {}
        )
    }
}

@Composable
private fun EditTreePersonDialog(
    person: TreePerson,
    canDelete: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    directCount: Int,
    organizationCount: Int,
    onDismiss: () -> Unit,
    onAddDirect: () -> Unit,
    onTodos: () -> Unit,
    onActions: () -> Unit,
    onLocate: () -> Unit,
    onShowCard: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onSave: (TreePerson) -> Unit,
    onDelete: () -> Unit
) {
    var name by remember(person.id) { mutableStateOf(person.name) }
    var targetPv by remember(person.id) { mutableStateOf(formatTreeInput(person.targetPv)) }
    var targetGpv by remember(person.id) { mutableStateOf(formatTreeInput(person.targetGpv)) }
    var targetActive by remember(person.id) { mutableStateOf(if (person.targetActive == 0) "" else person.targetActive.toString()) }
    var confirmDelete by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xF20A131E),
            shape = RoundedCornerShape(28.dp),
            title = {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(Modifier.fillMaxWidth()) {
                        TreeDialogCloseButton(onDismiss, Modifier.align(Alignment.TopStart))
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(start = 50.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Text(
                                person.name,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 24.sp,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Box(
                                modifier = Modifier
                                    .width(74.dp)
                                    .height(3.dp)
                                    .background(Gold, RoundedCornerShape(999.dp))
                            )
                        }
                    }
                }
            },
            text = {
                Box(Modifier.fillMaxWidth()) {
                    TreeCheckerPattern(Modifier.matchParentSize())
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TreeEditMetricCard(
                                    label = "تعداد سازمان",
                                    value = organizationCount.toString(),
                                    modifier = Modifier.weight(1f).height(82.dp)
                                )
                                TreeEditMetricCard(
                                    label = "PV",
                                    value = formatTreeNumber(person.pv),
                                    modifier = Modifier.weight(1f).height(82.dp)
                                )
                                TreeEditMetricCard(
                                    label = "GPV",
                                    value = formatTreeNumber(person.gpv),
                                    modifier = Modifier.weight(1.32f).height(82.dp)
                                )
                            }
                        }
                        item {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                Text(
                                    "نام فرد",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it.take(60) },
                                    modifier = Modifier.fillMaxWidth().height(70.dp),
                                    singleLine = true,
                                    placeholder = { Text("مثلاً شهریار", fontSize = 11.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
                                    textStyle = TextStyle(color = GamifyColors.TextPrimary, textAlign = TextAlign.Right, fontSize = 18.sp),
                                    colors = gamifyTextFieldColors(),
                                    shape = GamifyShapes.Field
                                )
                            }
                        }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TreeEditNumericField("هدف PV", targetPv, { targetPv = formatTypedNumber(it) }, Modifier.weight(1f))
                                TreeEditNumericField("هدف GPV", targetGpv, { targetGpv = formatTypedNumber(it) }, Modifier.weight(1.32f))
                                TreeEditNumericField("هدف تعداد", targetActive, { targetActive = it.filter(Char::isDigit).take(5) }, Modifier.weight(1f))
                            }
                        }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(onClick = onLocate, modifier = Modifier.weight(1f)) {
                                    Text("نمایش در درختواره", fontSize = 10.sp, maxLines = 1)
                                }
                                OutlinedButton(onClick = onShowCard, modifier = Modifier.weight(1f)) {
                                    Text("نمایش کارت", fontSize = 10.sp, maxLines = 1)
                                }
                            }
                        }
                        if (canDelete) item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(enabled = canMoveUp, onClick = onMoveUp, modifier = Modifier.weight(1f)) {
                                    Text("← جایگاه", fontSize = 10.sp)
                                }
                                OutlinedButton(enabled = canMoveDown, onClick = onMoveDown, modifier = Modifier.weight(1f)) {
                                    Text("جایگاه →", fontSize = 10.sp)
                                }
                            }
                        }
                        if (canDelete) item {
                            TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("حذف این فرد و تمام زیرشاخه‌اش", color = GamifyColors.Error, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.trim().isNotBlank(),
                    onClick = {
                        onSave(
                            person.copy(
                                name = name.trim(),
                                targetPv = parseTreeNumber(targetPv),
                                targetGpv = parseTreeNumber(targetGpv),
                                targetActive = parseTreeNumber(targetActive)
                            )
                        )
                    }
                ) {
                    Text("ذخیره", color = Gold, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {}
        )
    }
    if (confirmDelete) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                containerColor = GamifyColors.Surface,
                title = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Box(Modifier.fillMaxWidth()) {
                            TreeDialogCloseButton({ confirmDelete = false }, Modifier.align(Alignment.CenterStart))
                            Text("حذف شاخه؟", color = Color.White, textAlign = TextAlign.Right, modifier = Modifier.align(Alignment.CenterEnd).padding(start = 48.dp))
                        }
                    }
                },
                text = {
                    Text(
                        if (organizationCount > 0)
                            "${person.name} به همراه $organizationCount نفر زیرمجموعه حذف می‌شوند. To Do و اقدامات این شاخه هم حذف می‌شوند؛ تاریخچه روزهای قبل حفظ می‌شود."
                        else
                            "${person.name} حذف می‌شود. To Do و اقدامات این فرد هم حذف می‌شوند؛ تاریخچه روزهای قبل حفظ می‌شود.",
                        color = TextSoft,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = { confirmDelete = false; onDelete() }) {
                        Text("حذف", color = GamifyColors.Error)
                    }
                },
                dismissButton = {}
            )
        }
    }
}

@Composable
private fun TodoDialog(person: TreePerson, onDismiss: () -> Unit, onUpdate: (TreePerson) -> Unit) {
    var text by remember(person.id) { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    fun addTodo() {
        val clean = text.trim()
        if (clean.isNotBlank()) {
            onUpdate(person.copy(todos = person.todos + TreeTodo(UUID.randomUUID().toString(), clean)))
            text = ""
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xF20C1722),
            shape = RoundedCornerShape(28.dp),
            title = {
                Box(Modifier.fillMaxWidth()) {
                    TreeDialogCloseButton(onDismiss, Modifier.align(Alignment.TopEnd))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 36.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "To Do List • ${person.name}",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 21.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.weight(1f)
                        )
                        TreeTodoHeaderIcon()
                    }
                }
            },
            text = {
                Box(Modifier.fillMaxWidth()) {
                    TreeCirclePattern(Modifier.matchParentSize())
                    TreeCheckerPattern(Modifier.matchParentSize())
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 500.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    addTodo()
                                    focusRequester.requestFocus()
                                },
                                modifier = Modifier.size(64.dp),
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold)
                            ) {
                                Text("+", color = Color(0xFF17202A), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedTextField(
                                value = text,
                                onValueChange = { text = it.take(160) },
                                modifier = Modifier.weight(1f).focusRequester(focusRequester),
                                placeholder = {
                                    Text(
                                        "یک مورد بنویس...",
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        addTodo()
                                        focusRequester.requestFocus()
                                    }
                                ),
                                textStyle = TextStyle(textAlign = TextAlign.Right),
                                colors = gamifyTextFieldColors(),
                                shape = GamifyShapes.Field
                            )
                        }
                        val orderedTodos = person.todos.sortedBy { it.done }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(orderedTodos, key = { it.id }) { todo ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xAA111E2A), RoundedCornerShape(12.dp))
                                        .border(1.dp, Color(0x334E637A), RoundedCornerShape(12.dp))
                                        .padding(5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Checkbox(
                                        checked = todo.done,
                                        onCheckedChange = { checked ->
                                            onUpdate(person.copy(todos = person.todos.map { if (it.id == todo.id) it.copy(done = checked) else it }))
                                        }
                                    )
                                    Text(
                                        todo.text,
                                        color = if (todo.done) Color(0xFF8995A3) else Color.White,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = {
                                        onUpdate(person.copy(todos = person.todos.filterNot { it.id == todo.id }))
                                    }) {
                                        Text("×", color = GamifyColors.Error)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
}

@Composable
private fun ActionsDialog(
    person: TreePerson,
    allPeople: List<TreePerson>,
    onDismiss: () -> Unit,
    onUpdate: (TreePerson) -> Unit
) {
    val actionTypes = listOf("ارتباط‌سازی", "پیش‌مشاوره", "دعوت", "معرفی کار", "فالوآپ", "ثبت سفارش", "پیگیری")
    var mode by remember(person.id) { mutableStateOf(0) }
    var doneAction by remember(person.id) { mutableStateOf(actionTypes.first()) }
    var doneExpanded by remember { mutableStateOf(false) }
    var prospect by remember(person.id) { mutableStateOf("") }
    var editingActionId by remember(person.id) { mutableStateOf<String?>(null) }
    var contactName by remember(person.id) { mutableStateOf("") }
    var editingContactId by remember(person.id) { mutableStateOf<String?>(null) }
    var editingContactName by remember(person.id) { mutableStateOf("") }

    fun resetActionForm() {
        doneAction = actionTypes.first()
        prospect = ""
        editingActionId = null
    }

    fun latestActionFor(name: String): TreeAction? = person.actions
        .filter { it.prospectName.equals(name, ignoreCase = true) }
        .maxWithOrNull(compareBy<TreeAction> { it.date }.thenBy { it.id })

    fun addContact() {
        val clean = contactName.trim()
        if (clean.isNotBlank() && person.contacts.none { it.name.equals(clean, ignoreCase = true) }) {
            onUpdate(person.copy(contacts = person.contacts + TreeContact(UUID.randomUUID().toString(), clean)))
        }
        contactName = ""
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xFF0E1924),
            shape = RoundedCornerShape(24.dp),
            title = {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(Modifier.fillMaxWidth()) {
                        TreeDialogCloseButton(onDismiss, Modifier.align(Alignment.CenterStart))
                        Text(
                            person.name,
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.End,
                            modifier = Modifier.align(Alignment.CenterEnd).padding(start = 48.dp)
                        )
                    }
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 590.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            Modifier.weight(1f).height(40.dp)
                                .background(if (mode == 1) Color(0x22F7C948) else Color(0x66131D28), RoundedCornerShape(12.dp))
                                .border(1.dp, if (mode == 1) Gold else Color(0x554E5C6C), RoundedCornerShape(12.dp))
                                .clickable { mode = 1 },
                            contentAlignment = Alignment.Center
                        ) { Text("لیست افراد", color = if (mode == 1) GoldSoft else TextSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        Box(
                            Modifier.weight(1f).height(40.dp)
                                .background(if (mode == 0) Color(0x22F7C948) else Color(0x66131D28), RoundedCornerShape(12.dp))
                                .border(1.dp, if (mode == 0) Gold else Color(0x554E5C6C), RoundedCornerShape(12.dp))
                                .clickable { mode = 0 },
                            contentAlignment = Alignment.Center
                        ) { Text("اقدامات", color = if (mode == 0) GoldSoft else TextSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }

                    if (mode == 0) {
                        Surface(
                            color = Color(0x8F111E2A),
                            shape = RoundedCornerShape(17.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x44576A7E), RoundedCornerShape(17.dp))
                        ) {
                            Box(Modifier.fillMaxWidth()) {
                                Canvas(Modifier.matchParentSize()) {
                                    val cell = size.width / 4f
                                    for (i in 0..4) {
                                        for (j in 0..4) {
                                            if ((i + j) % 2 == 0) drawRect(Color(0x081B6FB8), topLeft = Offset(i * cell, j * cell * 0.6f), size = Size(cell, cell * 0.6f))
                                        }
                                    }
                                }
                                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    OutlinedTextField(
                                        value = prospect,
                                        onValueChange = { prospect = it.take(60) },
                                        modifier = Modifier.fillMaxWidth().height(52.dp),
                                        placeholder = { Text("نام فرد", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End) },
                                        textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White, fontSize = 13.sp),
                                        singleLine = true,
                                        colors = gamifyTextFieldColors(),
                                        shape = GamifyShapes.Field
                                    )
                                    Box(Modifier.fillMaxWidth()) {
                                        Box(
                                            Modifier.fillMaxWidth().height(50.dp)
                                                .background(GamifyColors.SurfaceInput, RoundedCornerShape(12.dp))
                                                .border(1.dp, GamifyColors.Border, RoundedCornerShape(12.dp))
                                                .clickable { doneExpanded = true }
                                                .padding(horizontal = 9.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("انجام‌شده", color = TextSoft, fontSize = 9.sp)
                                                Text(doneAction, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                            }
                                        }
                                        DropdownMenu(expanded = doneExpanded, onDismissRequest = { doneExpanded = false }) {
                                            actionTypes.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { doneAction = item; doneExpanded = false }) }
                                        }
                                    }
                                    Button(
                                        enabled = prospect.trim().isNotBlank(),
                                        onClick = {
                                            val cleanName = prospect.trim()
                                            val editedId = editingActionId
                                            val oldAction = editedId?.let { id -> person.actions.firstOrNull { it.id == id } }
                                            val previousNext = latestActionFor(cleanName)?.nextAction ?: ""
                                            val updatedAction = TreeAction(
                                                id = editedId ?: UUID.randomUUID().toString(),
                                                type = doneAction,
                                                prospectName = cleanName,
                                                date = oldAction?.date ?: LocalDate.now().toString(),
                                                result = "",
                                                nextAction = previousNext,
                                                nextDate = ""
                                            )
                                            val updatedActions = if (editedId == null) person.actions + updatedAction else person.actions.map { if (it.id == editedId) updatedAction else it }
                                            var updatedContacts = person.contacts
                                            if (updatedContacts.none { it.name.equals(cleanName, ignoreCase = true) }) updatedContacts = updatedContacts + TreeContact(UUID.randomUUID().toString(), cleanName)
                                            onUpdate(person.copy(contacts = updatedContacts, actions = updatedActions))
                                            resetActionForm()
                                        },
                                        modifier = Modifier.fillMaxWidth().height(44.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                        shape = RoundedCornerShape(13.dp)
                                    ) { Text(if (editingActionId == null) "ثبت اقدام" else "ذخیره تغییرات", fontWeight = FontWeight.ExtraBold) }
                                }
                            }
                        }
                        if (person.actions.isNotEmpty()) {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                items(person.actions.reversed(), key = { it.id }) { action ->
                                    Surface(
                                        color = Color(0x9A111D29),
                                        shape = RoundedCornerShape(13.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x3D526478), RoundedCornerShape(13.dp))
                                    ) {
                                        Box(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 9.dp)) {
                                            Text(
                                                "${action.prospectName}  •  ${jalaliLabelFromKey(action.date)}  •  ${action.type}",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                textAlign = TextAlign.End,
                                                modifier = Modifier.align(Alignment.CenterEnd).padding(start = 72.dp)
                                            )
                                            Row(Modifier.align(Alignment.CenterStart), horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                                                TextButton(onClick = { editingActionId = action.id; doneAction = action.type.takeIf { it in actionTypes } ?: actionTypes.first(); prospect = action.prospectName }, modifier = Modifier.width(34.dp)) { Text("✎", color = GoldSoft, fontSize = 12.sp) }
                                                TextButton(onClick = { onUpdate(person.copy(actions = person.actions.filterNot { it.id == action.id })); if (editingActionId == action.id) resetActionForm() }, modifier = Modifier.width(34.dp)) { Text("×", color = GamifyColors.Error, fontSize = 15.sp) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Surface(
                            color = Color(0x8F111E2A),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp).border(1.dp, Color(0x44576A7E), RoundedCornerShape(14.dp))
                        ) {
                            Row(Modifier.fillMaxSize().padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("＋", color = Gold, fontSize = 18.sp, modifier = Modifier.clickable { addContact() }.padding(4.dp))
                                BasicTextField(
                                    value = contactName,
                                    onValueChange = { contactName = it.take(60) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                    keyboardActions = KeyboardActions(onNext = { addContact() }),
                                    textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White, fontSize = 12.sp),
                                    cursorBrush = Brush.verticalGradient(listOf(Gold, Gold)),
                                    decorationBox = { inner -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) { if (contactName.isBlank()) Text("نام فرد", color = TextSoft, fontSize = 11.sp); inner() } }
                                )
                            }
                        }
                        Box(Modifier.fillMaxWidth()) {
                            Canvas(Modifier.matchParentSize()) {
                                val cell = size.width / 4f
                                for (i in 0..5) {
                                    for (j in 0..5) {
                                        if ((i + j) % 2 == 0) drawRect(Color(0x081B6FB8), topLeft = Offset(i * cell, j * cell * 0.52f), size = Size(cell, cell * 0.52f))
                                    }
                                }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                items(person.contacts, key = { it.id }) { contact ->
                                    val latest = latestActionFor(contact.name)
                                    Surface(
                                        color = Color(0x96111D29),
                                        shape = RoundedCornerShape(13.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x3D526478), RoundedCornerShape(13.dp))
                                    ) {
                                        if (editingContactId == contact.id) {
                                            Row(Modifier.fillMaxWidth().height(46.dp).padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                                TextButton(onClick = { editingContactId = null; editingContactName = "" }, modifier = Modifier.width(34.dp)) { Text("×", color = TextSoft) }
                                                TextButton(onClick = {
                                                    val clean = editingContactName.trim()
                                                    if (clean.isNotBlank()) {
                                                        val oldName = contact.name
                                                        val renamedContacts = person.contacts.map { if (it.id == contact.id) it.copy(name = clean) else it }
                                                        val renamedActions = person.actions.map { if (it.prospectName.equals(oldName, ignoreCase = true)) it.copy(prospectName = clean) else it }
                                                        onUpdate(person.copy(contacts = renamedContacts, actions = renamedActions))
                                                    }
                                                    editingContactId = null
                                                    editingContactName = ""
                                                }, modifier = Modifier.width(34.dp)) { Text("✓", color = Gold) }
                                                BasicTextField(value = editingContactName, onValueChange = { editingContactName = it.take(60) }, modifier = Modifier.weight(1f), singleLine = true, textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White, fontSize = 12.sp), cursorBrush = Brush.verticalGradient(listOf(Gold, Gold)))
                                            }
                                        } else {
                                            Box(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 10.dp)) {
                                                Text(
                                                    "${contact.name}  •  ${latest?.nextAction?.ifBlank { "اقدام بعدی ندارد" } ?: "اقدام بعدی ندارد"}",
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.align(Alignment.CenterEnd).padding(start = 72.dp)
                                                )
                                                Row(Modifier.align(Alignment.CenterStart)) {
                                                    TextButton(onClick = { editingContactId = contact.id; editingContactName = contact.name }, modifier = Modifier.width(34.dp)) { Text("✎", color = GoldSoft, fontSize = 11.sp) }
                                                    TextButton(onClick = { onUpdate(person.copy(contacts = person.contacts.filterNot { it.id == contact.id })) }, modifier = Modifier.width(34.dp)) { Text("×", color = GamifyColors.Error, fontSize = 14.sp) }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}
