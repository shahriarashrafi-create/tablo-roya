package com.shahriar.gamify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

/*
 * TimeSheet rewrite - version 8 / visual polish pass.
 *
 * Final pass keeps the synchronized sticky-header pan/zoom engine, merged multi-hour
 * blocks, and board-level touch arbitration. Gesture callbacks/events are read through
 * updated state so editing or changing weeks never leaves the touch engine with stale
 * hit-test data. One-finger pan, two-finger pinch/pan, and sticky headers stay isolated.
 */

private const val KEY_TIMESHEET_STATE = "timesheet_state_v1"
private const val TS_MIN_HOUR = 7
private const val TS_MAX_HOUR = 24
private const val TS_MAX_WEEK_OFFSET = 10
private const val TS_REMINDER_PREF_KEY = "timesheet_reminder_keys"
internal const val EXTRA_TIMESHEET_REMINDER_TITLE = "timesheet_reminder_title"
internal const val EXTRA_TIMESHEET_REMINDER_TIME = "timesheet_reminder_time"

private val TS_DAYS = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
private val TS_HOURS_DESC = (TS_MIN_HOUR until TS_MAX_HOUR).toList().reversed()

// Stage 54: TimeSheet shares the global game surface hierarchy.
private val TsBg = GamifyColors.Background
private val TsPanel = GamifyColors.Surface
private val TsPanel2 = GamifyColors.SurfaceRaised
private val TsGrid = Color(0xFF1E3D59)
private val TsText = Color(0xFFF2F6FB)
private val TsMuted = Color(0xFF99A8BB)
private val TsGold = Color(0xFFF0CC68)
private val TsBlue = Color(0xFF3B8BDF)
private val TsGreen = Color(0xFF38D9A9)
private val TsRed = Color(0xFFFF6E84)

private data class TimeSheetEvent(
    val id: Long,
    val day: Int,
    val startHour: Int,
    val endHour: Int,
    val title: String,
    val status: String = "planned",
    val recurring: Boolean = false,
    val reminder: Boolean = false,
    val templateId: Long = 0L,
    val linkedMissionId: String = ""
)

private data class TimeSheetState(
    val weekOffset: Int = 0,
    val zoom: Float = 1f,
    val weeks: Map<String, List<TimeSheetEvent>> = emptyMap(),
    val templates: List<TimeSheetEvent> = emptyList(),
    val nextId: Long = 1L
)


// Stage 120: canonical TimeSheet × Mission projection. All block/day/week UI now
// derives planned time, committed focus and coverage through these helpers.
private data class TsPlanActual(
    val plannedMinutes: Int,
    val actualFocusSeconds: Int
) {
    val actualMinutes: Int get() = actualFocusSeconds.coerceAtLeast(0) / 60
    val coveragePercent: Int get() = if (plannedMinutes > 0) {
        ((actualFocusSeconds.coerceAtLeast(0) * 100L) / (plannedMinutes * 60L)).toInt().coerceIn(0, 999)
    } else 0
    val progressFraction: Float get() = coveragePercent.coerceAtMost(100) / 100f
}

private fun tsPlanActual(plannedMinutes: Int, actualFocusSeconds: Int): TsPlanActual =
    TsPlanActual(plannedMinutes.coerceAtLeast(0), actualFocusSeconds.coerceAtLeast(0))

private fun tsDayPlanActual(
    day: Int,
    date: LocalDate,
    events: List<TimeSheetEvent>,
    history: List<MissionHistoryEntry>,
    context: Context
): TsPlanActual = tsPlanActual(
    plannedMinutes = events.filter { it.day == day }.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) * 60 },
    actualFocusSeconds = history.filter { it.missionDay(context) == date }.sumOf { it.focusSeconds.coerceAtLeast(0) }
)

private fun tsCompactMinutes(minutes: Int): String = when {
    minutes >= 60 && minutes % 60 == 0 -> "${minutes / 60}h"
    minutes >= 60 -> "${minutes / 60}h ${minutes % 60}m"
    else -> "${minutes}m"
}

private data class TsJalaliDate(val year: Int, val month: Int, val day: Int)

private val tsJalaliMonthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

private fun tsGregorianToJalali(date: LocalDate): TsJalaliDate {
    var gy = date.year - 1600
    val gm = date.monthValue - 1
    val gd = date.dayOfMonth - 1
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
    for (i in 0 until gm) gDayNo += gDays[i]
    val originalYear = date.year
    val leap = originalYear % 400 == 0 || (originalYear % 4 == 0 && originalYear % 100 != 0)
    if (gm > 1 && leap) gDayNo++
    gDayNo += gd

    var jDayNo = gDayNo - 79
    val jNp = jDayNo / 12053
    jDayNo %= 12053
    var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
    jDayNo %= 1461
    if (jDayNo >= 366) {
        jy += (jDayNo - 1) / 365
        jDayNo = (jDayNo - 1) % 365
    }
    var jm = 0
    while (jm < 11 && jDayNo >= jDays[jm]) {
        jDayNo -= jDays[jm]
        jm++
    }
    return TsJalaliDate(jy, jm + 1, jDayNo + 1)
}

private fun tsPersianDigits(text: String): String {
    val latin = "0123456789"
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    return buildString(text.length) {
        text.forEach { ch -> append(if (ch in latin) persian[latin.indexOf(ch)] else ch) }
    }
}

private fun tsDateShort(date: LocalDate): String {
    val j = tsGregorianToJalali(date)
    return tsPersianDigits(String.format(Locale.US, "%02d/%02d", j.month, j.day))
}

private fun tsWeekLabel(start: LocalDate): String {
    val end = start.plusDays(6)
    val a = tsGregorianToJalali(start)
    val b = tsGregorianToJalali(end)
    return if (a.year == b.year && a.month == b.month) {
        "${tsPersianDigits(a.day.toString())} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[a.month - 1]} ${tsPersianDigits(a.year.toString())}"
    } else {
        "${tsPersianDigits(a.day.toString())} ${tsJalaliMonthNames[a.month - 1]} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[b.month - 1]}"
    }
}

private fun tsBaseSaturday(today: LocalDate = LocalDate.now()): LocalDate {
    val daysBack = (today.dayOfWeek.value - 6 + 7) % 7
    return today.minusDays(daysBack.toLong())
}

private fun tsWeekStart(offset: Int): LocalDate = tsBaseSaturday().plusWeeks(offset.toLong())
private fun tsWeekKey(start: LocalDate): String = start.toString()

private fun timeSheetEventToJson(event: TimeSheetEvent) = JSONObject()
    .put("id", event.id)
    .put("day", event.day)
    .put("startHour", event.startHour)
    .put("endHour", event.endHour)
    .put("title", event.title)
    .put("status", event.status)
    .put("recurring", event.recurring)
    .put("reminder", event.reminder)
    .put("templateId", event.templateId)
    .put("linkedMissionId", event.linkedMissionId)

private fun timeSheetStateToJson(state: TimeSheetState): String {
    val weeksObject = JSONObject()
    state.weeks.forEach { (key, events) ->
        weeksObject.put(key, JSONArray().also { array -> events.forEach { array.put(timeSheetEventToJson(it)) } })
    }
    val templates = JSONArray().also { array -> state.templates.forEach { array.put(timeSheetEventToJson(it)) } }
    return JSONObject()
        .put("formatVersion", 2)
        .put("weekOffset", state.weekOffset)
        .put("zoom", state.zoom.toDouble())
        .put("weeks", weeksObject)
        .put("templates", templates)
        .put("nextId", state.nextId)
        .toString()
}

private fun parseTimeSheetEvent(obj: JSONObject): TimeSheetEvent? {
    val title = obj.optString("title").trim()
    if (title.isBlank()) return null
    val start = obj.optInt("startHour", TS_MIN_HOUR).coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)
    val end = obj.optInt("endHour", start + 1).coerceIn(start + 1, TS_MAX_HOUR)
    return TimeSheetEvent(
        id = obj.optLong("id", 0L).takeIf { it > 0L } ?: System.currentTimeMillis(),
        day = obj.optInt("day", 0).coerceIn(0, 6),
        startHour = start,
        endHour = end,
        title = title,
        status = obj.optString("status", "planned").takeIf { it in setOf("planned", "done", "missed") } ?: "planned",
        recurring = obj.optBoolean("recurring", false),
        reminder = obj.optBoolean("reminder", false),
        templateId = obj.optLong("templateId", 0L),
        linkedMissionId = obj.optString("linkedMissionId", "")
    )
}

private fun parseTimeSheetArray(array: JSONArray?): List<TimeSheetEvent> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val event = array.optJSONObject(i)?.let(::parseTimeSheetEvent) ?: continue
        add(event)
    }
}

private fun loadTimeSheetState(context: Context): TimeSheetState = runCatching {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TIMESHEET_STATE, null)
        ?: return@runCatching TimeSheetState()
    val root = JSONObject(raw)
    val weeksObj = root.optJSONObject("weeks")
    val weeks = linkedMapOf<String, List<TimeSheetEvent>>()
    if (weeksObj != null) {
        val keys = weeksObj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            weeks[key] = parseTimeSheetArray(weeksObj.optJSONArray(key))
        }
    }
    TimeSheetState(
        weekOffset = root.optInt("weekOffset", 0).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET),
        zoom = root.optDouble("zoom", 1.0).toFloat(),
        weeks = weeks,
        templates = parseTimeSheetArray(root.optJSONArray("templates")),
        nextId = root.optLong("nextId", 1L).coerceAtLeast(1L)
    )
}.getOrDefault(TimeSheetState())

private fun saveTimeSheetState(context: Context, state: TimeSheetState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_TIMESHEET_STATE, timeSheetStateToJson(state))
        .apply()
}

private fun tsDisplayedEvents(state: TimeSheetState, weekStart: LocalDate): List<TimeSheetEvent> {
    val weekEvents = state.weeks[tsWeekKey(weekStart)].orEmpty()
    val overriddenTemplateIds = weekEvents.mapNotNull { it.templateId.takeIf { id -> id > 0L } }.toSet()
    val fixed = state.templates
        .filterNot { it.id in overriddenTemplateIds }
        .map { template ->
            template.copy(
                id = -template.id,
                recurring = true,
                templateId = template.id,
                status = "planned"
            )
        }
    return (fixed + weekEvents)
        .sortedWith(compareBy<TimeSheetEvent> { it.day }.thenBy { it.startHour }.thenBy { it.endHour })
}

private fun tsOverlaps(aDay: Int, aStart: Int, aEnd: Int, event: TimeSheetEvent): Boolean =
    aDay == event.day && aStart < event.endHour && aEnd > event.startHour

private fun tsHasConflict(
    state: TimeSheetState,
    weekStart: LocalDate,
    day: Int,
    startHour: Int,
    endHour: Int,
    recurring: Boolean,
    editing: TimeSheetEvent?
): Boolean {
    val editingTemplateId = editing?.templateId?.takeIf { it > 0L }
        ?: editing?.takeIf { it.recurring && it.id != 0L }?.id?.let { kotlin.math.abs(it) }
    val editingExplicitId = editing?.takeIf { !it.recurring && it.id > 0L }?.id

    fun sameLogical(event: TimeSheetEvent): Boolean {
        if (editingTemplateId != null) {
            val eventTemplateId = event.templateId.takeIf { it > 0L }
                ?: event.takeIf { it.recurring }?.id?.let { kotlin.math.abs(it) }
            return eventTemplateId == editingTemplateId
        }
        if (editingExplicitId != null) return event.id == editingExplicitId
        return false
    }

    if (recurring) {
        if (state.templates.any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }) return true
        return state.weeks.values.flatten().any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }
    }
    return tsDisplayedEvents(state, weekStart).any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }
}

@Composable
internal fun TimeSheetDialog(
    player: PlayerState,
    onDismiss: () -> Unit,
    onHome: () -> Unit = onDismiss,
    onLaunchMission: (Mission) -> Unit = {}
) {
    val context = LocalContext.current.applicationContext
    var state by remember { mutableStateOf(loadTimeSheetState(context)) }
    val missionHistory = remember { loadHistory(context) }
    val missions = remember { loadMissions(context) }
    var editorSeed by remember { mutableStateOf<TimeSheetEvent?>(null) }

    fun commit(next: TimeSheetState) {
        state = next
        saveTimeSheetState(context, next)
        rescheduleTimeSheetReminders(context, next)
    }

    val weekStart = tsWeekStart(state.weekOffset)
    val events = tsDisplayedEvents(state, weekStart)

    LaunchedEffect(Unit) { rescheduleTimeSheetReminders(context, state) }
    BackHandler(onBack = onDismiss)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = TsBg) {
            InternalGameBackdrop()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(Modifier.fillMaxWidth()) { TopGameHud(player = player, rewardCue = null) }
                TimeSheetV1Header()
                TimeSheetV1WeekBar(
                    weekStart = weekStart,
                    weekOffset = state.weekOffset,
                    onPrevious = {
                        val next = (state.weekOffset - 1).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET)
                        if (next != state.weekOffset) commit(state.copy(weekOffset = next))
                    },
                    onCurrent = { if (state.weekOffset != 0) commit(state.copy(weekOffset = 0)) },
                    onNext = {
                        val next = (state.weekOffset + 1).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET)
                        if (next != state.weekOffset) commit(state.copy(weekOffset = next))
                    }
                )
                TimeSheetV1CompactSummary(events)
                TimeSheetV1Board(
                    weekStart = weekStart,
                    events = events,
                    history = missionHistory,
                    zoom = state.zoom,
                    onZoomSettled = { settledZoom ->
                        if (kotlin.math.abs(state.zoom - settledZoom) > 0.001f) {
                            commit(state.copy(zoom = settledZoom))
                        }
                    },
                    modifier = Modifier.weight(1f),
                    onCellClick = { day, hour, event ->
                        val eventDate = weekStart.plusDays(day.toLong())
                        val linkedMission = event?.linkedMissionId
                            ?.takeIf { it.isNotBlank() }
                            ?.let { id -> missions.firstOrNull { it.id == id } }
                        val linkedTerminal = linkedMission?.let { mission ->
                            missionHistory.any { entry ->
                                entry.missionId == mission.id &&
                                    entry.missionDay(context) == eventDate &&
                                    (entry.result == MissionResult.Done || entry.result == MissionResult.Fail)
                            }
                        } == true

                        // Stage 114: an unfinished linked block is now a real mission entry point.
                        // Tapping it starts the linked mission, or continues it when it is already running.
                        if (linkedMission != null && !linkedTerminal) {
                            onLaunchMission(linkedMission)
                        } else {
                            editorSeed = event ?: TimeSheetEvent(
                                id = 0L,
                                day = day,
                                startHour = hour,
                                endHour = (hour + 1).coerceAtMost(TS_MAX_HOUR),
                                title = ""
                            )
                        }
                    }
                )
                InternalHomeButton(
                    onClick = onHome,
                    modifier = Modifier.align(Alignment.Start)
                )
            }
        }
    }

    editorSeed?.let { seed ->
        TimeSheetV1Editor(
            seed = seed,
            state = state,
            weekStart = weekStart,
            missions = missions,
            onDismiss = { editorSeed = null },
            onDelete = {
                val templateId = seed.templateId.takeIf { it > 0L }
                    ?: seed.takeIf { it.recurring && it.id != 0L }?.id?.let { kotlin.math.abs(it) }
                val next = if (templateId != null) {
                    val cleanedWeeks = state.weeks.mapValues { (_, list) -> list.filterNot { it.templateId == templateId } }
                    state.copy(
                        templates = state.templates.filterNot { it.id == templateId },
                        weeks = cleanedWeeks
                    )
                } else {
                    val key = tsWeekKey(weekStart)
                    state.copy(weeks = state.weeks + (key to state.weeks[key].orEmpty().filterNot { it.id == seed.id }))
                }
                commit(next)
                editorSeed = null
            },
            onSave = { title, day, startHour, endHour, recurring, reminder, status, linkedMissionId ->
                val key = tsWeekKey(weekStart)
                val editing = seed.takeIf { it.id != 0L }
                val oldTemplateId = editing?.templateId?.takeIf { it > 0L }
                    ?: editing?.takeIf { it.recurring }?.id?.let { kotlin.math.abs(it) }

                if (recurring) {
                    val templateId = oldTemplateId ?: state.nextId
                    val template = TimeSheetEvent(
                        id = templateId,
                        day = day,
                        startHour = startHour,
                        endHour = endHour,
                        title = title,
                        status = "planned",
                        recurring = true,
                        reminder = reminder,
                        linkedMissionId = linkedMissionId
                    )
                    val templates = if (oldTemplateId != null) {
                        state.templates.map { if (it.id == oldTemplateId) template else it }
                    } else state.templates + template
                    var weekList = state.weeks[key].orEmpty().filterNot { stored ->
                        (editing != null && !editing.recurring && stored.id == editing.id) ||
                            (oldTemplateId != null && stored.templateId == oldTemplateId)
                    }
                    var nextId = if (oldTemplateId == null) state.nextId + 1 else state.nextId
                    if (status != "planned") {
                        weekList = weekList + template.copy(
                            id = nextId,
                            status = status,
                            templateId = templateId
                        )
                        nextId++
                    }
                    commit(
                        state.copy(
                            templates = templates,
                            weeks = state.weeks + (key to weekList),
                            nextId = nextId
                        )
                    )
                } else {
                    val id = editing?.takeIf { !it.recurring && it.id > 0L }?.id ?: state.nextId
                    val event = TimeSheetEvent(
                        id = id,
                        day = day,
                        startHour = startHour,
                        endHour = endHour,
                        title = title,
                        status = status,
                        recurring = false,
                        reminder = reminder,
                        linkedMissionId = linkedMissionId
                    )
                    var weekList = state.weeks[key].orEmpty().filterNot { stored ->
                        (editing != null && !editing.recurring && stored.id == editing.id) ||
                            (oldTemplateId != null && stored.templateId == oldTemplateId)
                    }
                    weekList = weekList + event
                    val cleanedTemplates = if (oldTemplateId != null) state.templates.filterNot { it.id == oldTemplateId } else state.templates
                    commit(
                        state.copy(
                            templates = cleanedTemplates,
                            weeks = state.weeks + (key to weekList),
                            nextId = if (editing == null || editing.recurring) state.nextId + 1 else state.nextId
                        )
                    )
                }
                editorSeed = null
            }
        )
    }
}

@Composable
private fun TimeSheetV1Header() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth().height(34.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Time", color = TsGold, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("Sheet", color = TsText, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun TimeSheetV1WeekBar(
    weekStart: LocalDate,
    weekOffset: Int,
    onPrevious: () -> Unit,
    onCurrent: () -> Unit,
    onNext: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = TsPanel.copy(alpha = 0.95f),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, TsBlue.copy(alpha = 0.55f))
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0x221D6BA8), Color.Transparent, Color(0x161D6BA8))
                        )
                    )
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = onPrevious, enabled = weekOffset > -TS_MAX_WEEK_OFFSET) {
                    Text("‹ هفته قبل", color = if (weekOffset > -TS_MAX_WEEK_OFFSET) TsText else TsMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                TextButton(onClick = onCurrent, modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (weekOffset == 0) "این هفته" else "بازگشت به این هفته", color = TsGold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                        Text(tsWeekLabel(weekStart), color = TsMuted, fontSize = 9.sp)
                    }
                }
                TextButton(onClick = onNext, enabled = weekOffset < TS_MAX_WEEK_OFFSET) {
                    Text("هفته بعد ›", color = if (weekOffset < TS_MAX_WEEK_OFFSET) TsText else TsMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}


@Composable
private fun TimeSheetV1CompactSummary(events: List<TimeSheetEvent>) {
    val plannedMinutes = events.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) * 60 }
    val doneMinutes = events.filter { it.status == "done" }.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) * 60 }
    val coverage = if (plannedMinutes > 0) ((doneMinutes * 100f) / plannedMinutes).toInt().coerceIn(0, 100) else 0
    Surface(
        modifier = Modifier.fillMaxWidth().height(38.dp),
        color = TsPanel.copy(alpha = 0.88f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, TsGold.copy(alpha = 0.28f))
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text("برنامه ${tsCompactMinutes(plannedMinutes)}", color = TsText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("  •  ", color = TsMuted, fontSize = 10.sp)
                Text("انجام ${tsCompactMinutes(doneMinutes)}", color = TsGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("  •  ", color = TsMuted, fontSize = 10.sp)
                Text("$coverage%", color = if (coverage >= 100) TsGreen else TsGold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}




@Composable
private fun TimeSheetV1Stat(
    label: String,
    value: String,
    symbol: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(80.dp),
        color = TsPanel.copy(alpha = 0.97f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.62f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(accent.copy(alpha = 0.19f), Color.Transparent),
                        radius = 310f,
                        center = Offset(46f, 42f)
                    )
                )
                .padding(horizontal = 8.dp, vertical = 7.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Surface(
                        color = accent.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.32f))
                    ) {
                        Box(Modifier.size(27.dp), contentAlignment = Alignment.Center) {
                            Text(symbol, color = accent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                    Text(value, color = accent, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(3.dp))
                Text(label, color = TsText.copy(alpha = 0.9f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun TimeSheetV1Board(
    weekStart: LocalDate,
    events: List<TimeSheetEvent>,
    history: List<MissionHistoryEntry>,
    zoom: Float,
    onZoomSettled: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onCellClick: (day: Int, hour: Int, event: TimeSheetEvent?) -> Unit
) {
    val density = LocalDensity.current

    // The grid and the two sticky headers deliberately use different geometry:
    // the body cells zoom, while the day column / hour header remain readable and fixed.
    val baseHourCellWidth = 82.dp
    val fixedDayColumnWidth = 92.dp
    val fixedHeaderHeight = 52.dp
    val baseDayRowHeight = 72.dp

    val baseHourCellWidthPx = with(density) { baseHourCellWidth.toPx() }
    val fixedDayColumnWidthPx = with(density) { fixedDayColumnWidth.toPx() }
    val fixedHeaderHeightPx = with(density) { fixedHeaderHeight.toPx() }
    val baseDayRowHeightPx = with(density) { baseDayRowHeight.toPx() }
    val baseBodyWidthPx = baseHourCellWidthPx * TS_HOURS_DESC.size
    val baseBodyHeightPx = baseDayRowHeightPx * 7f

    var boardZoom by remember { mutableStateOf(zoom.coerceIn(0.50f, 1.50f)) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var initialPositioned by remember { mutableStateOf(false) }
    val currentEvents by rememberUpdatedState(events)
    val currentOnCellClick by rememberUpdatedState(onCellClick)

    fun bodyViewportWidth(): Float =
        (viewportSize.width.toFloat() - fixedDayColumnWidthPx).coerceAtLeast(0f)

    fun bodyViewportHeight(): Float =
        (viewportSize.height.toFloat() - fixedHeaderHeightPx).coerceAtLeast(0f)

    fun scaledBodyWidth(scale: Float): Float = baseBodyWidthPx * scale
    fun scaledBodyHeight(scale: Float): Float = baseBodyHeightPx * scale

    fun clampPan(raw: Offset, scale: Float): Offset {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return raw

        val viewportW = bodyViewportWidth()
        val viewportH = bodyViewportHeight()
        val contentW = scaledBodyWidth(scale)
        val contentH = scaledBodyHeight(scale)

        // Horizontal content is RTL-facing: when it is smaller than the viewport it
        // stays attached to the fixed day column, never floating away from it.
        val x = if (contentW <= viewportW) {
            viewportW - contentW
        } else {
            raw.x.coerceIn(viewportW - contentW, 0f)
        }

        // Vertical content starts below the fixed hour header. If it fits, keep it at top.
        val y = if (contentH <= viewportH) {
            0f
        } else {
            raw.y.coerceIn(viewportH - contentH, 0f)
        }
        return Offset(x, y)
    }

    fun applyTransform(centroid: Offset, panChange: Offset, zoomChange: Float) {
        val oldZoom = boardZoom
        val newZoom = (oldZoom * zoomChange).coerceIn(0.50f, 1.50f)
        val viewportW = bodyViewportWidth()
        val bodyBottom = fixedHeaderHeightPx + bodyViewportHeight()

        val oldRightAlignedX = (viewportW - scaledBodyWidth(oldZoom)).coerceAtMost(0f)
        val wasRightAnchored = kotlin.math.abs(pan.x - oldRightAlignedX) <= 2.5f

        // Vertical zoom keeps the point beneath the fingers stable. Horizontally, when
        // the board is sitting at its canonical RTL start position, keep the right edge
        // locked to the sticky day column so 7-8 never drifts away during pinch zoom.
        val focusY = centroid.y.coerceIn(fixedHeaderHeightPx, bodyBottom)
        val contentBaseY = (focusY - fixedHeaderHeightPx - pan.y) / oldZoom
        val transformedY = (focusY - fixedHeaderHeightPx) - contentBaseY * newZoom + panChange.y

        val transformedX = if (kotlin.math.abs(zoomChange - 1f) > 0.002f && wasRightAnchored) {
            (viewportW - scaledBodyWidth(newZoom)).coerceAtMost(0f) + panChange.x
        } else {
            pan.x + panChange.x
        }

        boardZoom = newZoom
        pan = clampPan(Offset(transformedX, transformedY), newZoom)
    }

    fun openAt(screenPosition: Offset) {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return
        val bodyRight = bodyViewportWidth()
        if (
            screenPosition.x !in 0f..bodyRight ||
            screenPosition.y < fixedHeaderHeightPx ||
            screenPosition.y >= viewportSize.height.toFloat()
        ) return

        val contentX = (screenPosition.x - pan.x) / boardZoom
        val contentY = (screenPosition.y - fixedHeaderHeightPx - pan.y) / boardZoom
        if (contentX < 0f || contentY < 0f || contentX >= baseBodyWidthPx || contentY >= baseBodyHeightPx) return

        val hourIndex = (contentX / baseHourCellWidthPx).toInt()
        val day = (contentY / baseDayRowHeightPx).toInt()
        if (day !in 0..6 || hourIndex !in TS_HOURS_DESC.indices) return

        val hour = TS_HOURS_DESC[hourIndex]
        val event = currentEvents.firstOrNull { it.day == day && hour >= it.startHour && hour < it.endHour }
        currentOnCellClick(day, hour, event)
    }

    LaunchedEffect(viewportSize, weekStart) {
        if (viewportSize.width > 0 && viewportSize.height > 0) {
            // Always enter a week with the early-day hours touching the fixed day column.
            // This is the canonical RTL start position of the TimeSheet.
            val rightAlignedX = bodyViewportWidth() - scaledBodyWidth(boardZoom)
            pan = clampPan(Offset(rightAlignedX, 0f), boardZoom)
            initialPositioned = true
        }
    }

    LaunchedEffect(boardZoom) {
        if (!initialPositioned) return@LaunchedEffect
        delay(280L)
        onZoomSettled(boardZoom)
    }

    val scaledHourCellWidth = baseHourCellWidth * boardZoom
    val scaledDayRowHeight = baseDayRowHeight * boardZoom
    val scaledBodyWidth = scaledHourCellWidth * TS_HOURS_DESC.size
    val scaledBodyHeight = scaledDayRowHeight * 7

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xD1091624),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, TsBlue.copy(alpha = 0.45f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF0A1A2A), Color(0xFF081522), Color(0xFF07111B))
                    )
                )
                .onSizeChanged { newSize ->
                    viewportSize = newSize
                    if (initialPositioned) pan = clampPan(pan, boardZoom)
                }
                .pointerInput(weekStart, viewportSize) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val tapPosition = down.position
                        var totalSingleDrag = Offset.Zero
                        var previousSinglePosition: Offset? = down.position
                        var transforming = false
                        var usedMultiplePointers = false

                        while (true) {
                            val pointerEvent = awaitPointerEvent()
                            val pressed = pointerEvent.changes.filter { it.pressed }
                            if (pressed.isEmpty()) {
                                if (!transforming && !usedMultiplePointers) openAt(tapPosition)
                                break
                            }

                            if (pressed.size >= 2) {
                                usedMultiplePointers = true
                                transforming = true
                                previousSinglePosition = null
                                val centroid = pointerEvent.calculateCentroid(useCurrent = true)
                                val panChange = pointerEvent.calculatePan()
                                val zoomChange = pointerEvent.calculateZoom()
                                applyTransform(centroid, panChange, zoomChange)
                                pointerEvent.changes.forEach { if (it.pressed) it.consume() }
                            } else {
                                val current = pressed.first().position
                                val previous = previousSinglePosition
                                previousSinglePosition = current
                                val delta = if (previous == null) Offset.Zero else current - previous
                                if (!transforming) {
                                    totalSingleDrag += delta
                                    if (totalSingleDrag.getDistance() > viewConfiguration.touchSlop) {
                                        transforming = true
                                        applyTransform(current, totalSingleDrag, 1f)
                                        totalSingleDrag = Offset.Zero
                                        pressed.first().consume()
                                    }
                                } else {
                                    applyTransform(current, delta, 1f)
                                    pressed.first().consume()
                                }
                            }
                        }
                    }
                }
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                val bodyWidthPx = bodyViewportWidth()
                val bodyHeightPx = bodyViewportHeight()
                val cellWidthPx = baseHourCellWidthPx * boardZoom
                val rowHeightPx = baseDayRowHeightPx * boardZoom

                // Body viewport. Children are positioned directly in viewport coordinates
                // instead of placing one oversized Row/Column. This avoids Compose's
                // requiredSize overflow-centering behavior that previously separated the
                // grid from the sticky day column at 50% zoom.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = fixedHeaderHeight, end = fixedDayColumnWidth)
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    for (day in 0..6) {
                        val date = weekStart.plusDays(day.toLong())
                        val isToday = date == LocalDate.now()
                        val yPx = pan.y + day * rowHeightPx

                        TS_HOURS_DESC.forEachIndexed { hourIndex, _ ->
                            val xPx = pan.x + hourIndex * cellWidthPx
                            // Skip cells that are fully outside the body viewport.
                            if (xPx + cellWidthPx >= 0f && xPx <= bodyWidthPx && yPx + rowHeightPx >= 0f && yPx <= bodyHeightPx) {
                                Surface(
                                    modifier = Modifier
                                        .offset {
                                            androidx.compose.ui.unit.IntOffset(
                                                xPx.roundToInt(),
                                                yPx.roundToInt()
                                            )
                                        }
                                        .width(scaledHourCellWidth)
                                        .height(scaledDayRowHeight),
                                    color = if (isToday) Color(0x1F2E8BD8) else Color(0x180B1724),
                                    border = BorderStroke(0.55.dp, TsGrid.copy(alpha = 0.82f))
                                ) {
                                    Spacer(Modifier.fillMaxSize())
                                }
                            }
                        }

                        events.filter { it.day == day }.forEach { event ->
                            val firstDisplayedHour = (event.endHour - 1).coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)
                            val leftIndex = TS_HOURS_DESC.indexOf(firstDisplayedHour)
                            val span = (event.endHour - event.startHour).coerceAtLeast(1)
                            if (leftIndex >= 0) {
                                val eventXPx = pan.x + leftIndex * cellWidthPx
                                val eventWidthPx = span * cellWidthPx
                                if (eventXPx + eventWidthPx >= 0f && eventXPx <= bodyWidthPx && yPx + rowHeightPx >= 0f && yPx <= bodyHeightPx) {
                                    val eventDate = weekStart.plusDays(event.day.toLong())
                                    val linkedResults = if (event.linkedMissionId.isNotBlank()) {
                                        history.filter { it.missionId == event.linkedMissionId && it.missionDay(LocalContext.current.applicationContext) == eventDate }
                                    } else emptyList()
                                    val latestTerminalResult = linkedResults
                                        .filter { it.result == MissionResult.Done || it.result == MissionResult.Fail }
                                        .maxByOrNull { it.timestamp }
                                    val linkedState = when (latestTerminalResult?.result) {
                                        MissionResult.Done -> "done"
                                        MissionResult.Fail -> "missed"
                                        else -> "planned"
                                    }
                                    // Stage 115: the block reflects the latest terminal run for this linked
                                    // mission on this work-day. Its real focus duration comes from the same
                                    // committed history entry, so the status and focus can never disagree.
                                    val plannedMinutes = span * 60
                                    val blockPlanActual = latestTerminalResult?.let {
                                        tsPlanActual(plannedMinutes, it.focusSeconds)
                                    }
                                    val planVsActualPercent = blockPlanActual?.coveragePercent
                                    val planVsActualText = blockPlanActual?.let { metric ->
                                        "◷ ${metric.actualMinutes} / ${metric.plannedMinutes} min • ${metric.coveragePercent}%"
                                    }
                                    val visualStatus = if (event.linkedMissionId.isNotBlank()) linkedState else event.status
                                    val accent = when (visualStatus) {
                                        "done" -> TsGreen
                                        "missed" -> TsRed
                                        else -> TsBlue
                                    }
                                    val accent2 = when (visualStatus) {
                                        "done" -> Color(0xFF1CA87D)
                                        "missed" -> Color(0xFFC94868)
                                        else -> Color(0xFF6457D8)
                                    }
                                    Surface(
                                        modifier = Modifier
                                            .offset {
                                                androidx.compose.ui.unit.IntOffset(
                                                    eventXPx.roundToInt(),
                                                    yPx.roundToInt()
                                                )
                                            }
                                            .width(scaledHourCellWidth * span)
                                            .height(scaledDayRowHeight)
                                            .padding(2.dp),
                                        color = Color(0xFF0B1724),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, accent.copy(alpha = 0.92f))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.horizontalGradient(
                                                        listOf(accent.copy(alpha = 0.48f), accent2.copy(alpha = 0.26f))
                                                    )
                                                )
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(
                                                    event.title,
                                                    color = TsText,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (event.linkedMissionId.isNotBlank()) {
                                                    Text(
                                                        when (visualStatus) {
                                                            "done" -> "✓ انجام شده"
                                                            "missed" -> "✕ ناموفق"
                                                            else -> "• هنوز انجام نشده"
                                                        },
                                                        color = accent,
                                                        fontSize = 7.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1
                                                    )
                                                    if (planVsActualText != null && planVsActualPercent != null) {
                                                        Text(
                                                            planVsActualText,
                                                            color = TsText.copy(alpha = 0.86f),
                                                            fontSize = 6.5.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            maxLines = 1
                                                        )
                                                        // Stage 117: a glanceable visual layer for Plan vs Actual.
                                                        // The bar caps at 100% because its job is spatial progress;
                                                        // the text above still preserves over-delivery such as 125%.
                                                        LinearProgressIndicator(
                                                            progress = { (planVsActualPercent.coerceAtMost(100) / 100f) },
                                                            modifier = Modifier
                                                                .fillMaxWidth(0.82f)
                                                                .padding(top = 2.dp)
                                                                .height(3.dp),
                                                            color = accent,
                                                            trackColor = Color.White.copy(alpha = 0.16f)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sticky hour header. It uses the exact same horizontal translation and
                // exact same scaled column width as the body, but never moves vertically.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(fixedHeaderHeight)
                        .padding(end = fixedDayColumnWidth)
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    TS_HOURS_DESC.forEachIndexed { hourIndex, hour ->
                        val xPx = pan.x + hourIndex * cellWidthPx
                        if (xPx + cellWidthPx >= 0f && xPx <= bodyWidthPx) {
                            Surface(
                                modifier = Modifier
                                    .offset { androidx.compose.ui.unit.IntOffset(xPx.roundToInt(), 0) }
                                    .width(scaledHourCellWidth)
                                    .height(fixedHeaderHeight),
                                color = TsPanel2.copy(alpha = 0.96f),
                                border = BorderStroke(0.7.dp, TsGrid)
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(listOf(Color(0x271E74B3), Color.Transparent))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "${hour}-${hour + 1}",
                                        color = TsText.copy(alpha = 0.92f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // Sticky day column. Its screen X is fixed, while its row heights and Y
                // translation exactly match the body at every zoom level.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = fixedHeaderHeight)
                        .width(fixedDayColumnWidth)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    for (day in 0..6) {
                        val yPx = pan.y + day * rowHeightPx
                        if (yPx + rowHeightPx >= 0f && yPx <= bodyHeightPx) {
                            Box(
                                modifier = Modifier.offset {
                                    androidx.compose.ui.unit.IntOffset(0, yPx.roundToInt())
                                }
                            ) {
                                TimeSheetV5DayHeader(
                                    day = day,
                                    date = weekStart.plusDays(day.toLong()),
                                    width = fixedDayColumnWidth,
                                    height = scaledDayRowHeight,
                                    events = events,
                                    history = history
                                )
                            }
                        }
                    }
                }

                // Fixed corner cell: never pans. The dimensions remain readable while the
                // day row heights / hour column widths scale in sync with the grid.
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .width(fixedDayColumnWidth)
                        .height(fixedHeaderHeight),
                    color = Color(0xFF102943),
                    border = BorderStroke(0.8.dp, TsBlue.copy(alpha = 0.48f))
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("روز", color = TsText.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}


@Composable
private fun TimeSheetV5DayHeader(
    day: Int,
    date: LocalDate,
    width: androidx.compose.ui.unit.Dp,
    height: androidx.compose.ui.unit.Dp,
    events: List<TimeSheetEvent>,
    history: List<MissionHistoryEntry>
) {
    val context = LocalContext.current.applicationContext
    val today = LocalDate.now()
    val isToday = date == today
    // Stage 118: each sticky day header now carries its own Plan vs Actual roll-up.
    // Planned time comes from every TimeSheet block on that row; actual focus comes
    // from committed mission history on the same configured mission-day boundary.
    val dailyPlanActual = remember(day, date, events, history) {
        tsDayPlanActual(day, date, events, history, context)
    }
    val plannedMinutes = dailyPlanActual.plannedMinutes
    val actualFocusMinutes = dailyPlanActual.actualMinutes
    val dailyCoverage = dailyPlanActual.coveragePercent
    Surface(
        modifier = Modifier.width(width).height(height),
        color = if (isToday) Color(0xFF123A59) else TsPanel2,
        border = BorderStroke(0.8.dp, if (isToday) Color(0xFF36A7F0) else TsGrid)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    if (isToday) {
                        Brush.horizontalGradient(listOf(Color(0x4A1E92D0), Color(0x121E92D0)))
                    } else {
                        Brush.horizontalGradient(listOf(Color(0x171E6A9C), Color.Transparent))
                    }
                )
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Text(
                            TS_DAYS[day],
                            color = TsText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (isToday) {
                            Spacer(Modifier.width(5.dp))
                            Box(
                                Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF4BC4FF), RoundedCornerShape(50))
                            )
                        }
                    }
                    if (height >= 36.dp) {
                        Spacer(Modifier.height(2.dp))
                        Text(tsDateShort(date), color = if (isToday) Color(0xFFB8DDFA) else TsMuted, fontSize = 7.5.sp, maxLines = 1)
                    }
                    if (height >= 54.dp && plannedMinutes > 0) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "◷ ${tsCompactMinutes(actualFocusMinutes)} / ${tsCompactMinutes(plannedMinutes)} • ${dailyCoverage}%",
                            color = when {
                                dailyCoverage >= 100 -> TsGreen
                                dailyCoverage > 0 -> TsGold
                                else -> TsMuted
                            },
                            fontSize = 6.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        LinearProgressIndicator(
                            progress = { dailyPlanActual.progressFraction },
                            modifier = Modifier.fillMaxWidth(0.72f).padding(top = 1.dp).height(2.dp),
                            color = if (dailyCoverage >= 100) TsGreen else TsGold,
                            trackColor = Color.White.copy(alpha = 0.12f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeSheetV1Editor(
    seed: TimeSheetEvent,
    state: TimeSheetState,
    weekStart: LocalDate,
    missions: List<Mission>,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onSave: (String, Int, Int, Int, Boolean, Boolean, String, String) -> Unit
) {
    var title by remember(seed.id) { mutableStateOf(seed.title) }
    var day by remember(seed.id) { mutableStateOf(seed.day.coerceIn(0, 6)) }
    var start by remember(seed.id) { mutableStateOf(seed.startHour.coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)) }
    var end by remember(seed.id) { mutableStateOf(seed.endHour.coerceIn(start + 1, TS_MAX_HOUR)) }
    var recurring by remember(seed.id) { mutableStateOf(if (seed.id == 0L) true else seed.recurring) }
    var reminder by remember(seed.id) { mutableStateOf(seed.reminder) }
    var status by remember(seed.id) { mutableStateOf(seed.status) }
    var linkedMissionId by remember(seed.id) { mutableStateOf(seed.linkedMissionId) }

    val cleanTitle = title.trim()
    val conflict = cleanTitle.isNotBlank() && tsHasConflict(
        state = state,
        weekStart = weekStart,
        day = day,
        startHour = start,
        endHour = end,
        recurring = recurring,
        editing = seed.takeIf { it.id != 0L }
    )
    val canSave = cleanTitle.isNotBlank() && end > start && !conflict

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0B1723),
        shape = RoundedCornerShape(22.dp),
        title = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Text(
                    if (seed.id == 0L) "برنامه جدید" else "ویرایش برنامه",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right,
                    color = TsText,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        },
        text = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                        singleLine = true,
                        label = { Text("عنوان برنامه") },
                        colors = gamifyTextFieldColors(),
                        shape = GamifyShapes.Field
                    )

                    TimeSheetV1Stepper(
                        label = "روز",
                        value = "${TS_DAYS[day]} • ${tsDateShort(weekStart.plusDays(day.toLong()))}",
                        onMinus = { day = (day - 1).coerceAtLeast(0) },
                        onPlus = { day = (day + 1).coerceAtMost(6) }
                    )
                    TimeSheetV1Stepper(
                        label = "شروع",
                        value = "${tsPersianDigits(start.toString())}:۰۰",
                        onMinus = {
                            start = (start - 1).coerceAtLeast(TS_MIN_HOUR)
                            if (end <= start) end = (start + 1).coerceAtMost(TS_MAX_HOUR)
                        },
                        onPlus = {
                            start = (start + 1).coerceAtMost(TS_MAX_HOUR - 1)
                            if (end <= start) end = (start + 1).coerceAtMost(TS_MAX_HOUR)
                        }
                    )
                    TimeSheetV1Stepper(
                        label = "پایان",
                        value = "${tsPersianDigits(end.toString())}:۰۰",
                        onMinus = { end = (end - 1).coerceAtLeast(start + 1) },
                        onPlus = { end = (end + 1).coerceAtMost(TS_MAX_HOUR) }
                    )

                    Text("ماموریت مرتبط", color = TsMuted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        val choices = listOf("" to "بدون Mission") + missions.map { it.id to it.title }
                        choices.forEach { (id, label) ->
                            val selected = linkedMissionId == id
                            Surface(
                                modifier = Modifier.fillMaxWidth().heightIn(min = 34.dp).clickable { linkedMissionId = id },
                                color = if (selected) TsBlue.copy(alpha = 0.22f) else TsPanel,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (selected) TsBlue else TsGrid)
                            ) {
                                Text(label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = if (selected) Color(0xFFB8DDFA) else TsMuted, fontSize = 9.sp, textAlign = TextAlign.Right)
                            }
                        }
                    }

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = recurring, onCheckedChange = { recurring = it })
                        Text("برنامه ثابت هفتگی", color = TsText, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = reminder, onCheckedChange = { reminder = it })
                        Text("یادآوری ۵ دقیقه قبل", color = TsText, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
                    }

                    if (seed.id != 0L) {
                        Text("وضعیت", color = TsMuted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("planned" to "برنامه", "done" to "انجام شد", "missed" to "انجام نشد").forEach { (value, label) ->
                                val selected = status == value
                                val accent = when (value) {
                                    "done" -> TsGreen
                                    "missed" -> TsRed
                                    else -> TsGold
                                }
                                Surface(
                                    modifier = Modifier.weight(1f).height(38.dp).clickable { status = value },
                                    color = if (selected) accent.copy(alpha = 0.22f) else TsPanel,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (selected) accent else TsGrid)
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(label, color = if (selected) accent else TsMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    if (conflict) {
                        Text("این بازه با یک برنامه دیگر تداخل دارد.", color = TsRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(cleanTitle, day, start, end, recurring, reminder, status, linkedMissionId) },
                enabled = canSave,
                colors = ButtonDefaults.buttonColors(containerColor = TsGold, contentColor = Color(0xFF211800))
            ) {
                Text("ذخیره", fontWeight = FontWeight.ExtraBold)
            }
        },
        dismissButton = {
            Row {
                if (seed.id != 0L) {
                    TextButton(onClick = onDelete) { Text("حذف", color = TsRed) }
                }
                TextButton(onClick = onDismiss) { Text("انصراف", color = TsMuted) }
            }
        }
    )
}

@Composable
private fun TimeSheetV1Stepper(
    label: String,
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = TsPanel,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, TsGrid)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onMinus) { Text("−", color = TsText, fontSize = 20.sp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label, color = TsMuted, fontSize = 8.sp)
                    Text(value, color = TsText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onPlus) { Text("+", color = TsText, fontSize = 18.sp) }
            }
        }
    }
}

private fun timeSheetReminderPendingIntent(
    context: Context,
    occurrenceKey: String,
    title: String,
    timeLabel: String
): PendingIntent {
    val intent = Intent(context, TimeSheetReminderReceiver::class.java).apply {
        data = Uri.parse("gamify://timesheet-reminder/${Uri.encode(occurrenceKey)}")
        putExtra(EXTRA_TIMESHEET_REMINDER_TITLE, title)
        putExtra(EXTRA_TIMESHEET_REMINDER_TIME, timeLabel)
    }
    return PendingIntent.getBroadcast(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun cancelTimeSheetReminder(context: Context, occurrenceKey: String) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timeSheetReminderPendingIntent(context, occurrenceKey, "", ""))
}

internal fun rescheduleTimeSheetReminders(context: Context) {
    rescheduleTimeSheetReminders(context, loadTimeSheetState(context))
}

private fun rescheduleTimeSheetReminders(
    context: Context,
    state: TimeSheetState,
    nowMillis: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault()
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val oldKeys = prefs.getStringSet(TS_REMINDER_PREF_KEY, emptySet()).orEmpty().toSet()
    oldKeys.forEach { cancelTimeSheetReminder(context, it) }

    val settings = loadSettings(context)
    if (!settings.notificationsEnabled) {
        prefs.edit().remove(TS_REMINDER_PREF_KEY).apply()
        return
    }

    val scheduled = linkedSetOf<String>()
    fun schedule(event: TimeSheetEvent, date: LocalDate, logicalId: Long) {
        if (!event.reminder || event.status != "planned") return
        val start = ZonedDateTime.of(date, LocalTime.of(event.startHour, 0), zone)
        val triggerAt = start.minusMinutes(5).toInstant().toEpochMilli()
        if (triggerAt <= nowMillis) return
        val key = "$logicalId@$date"
        val timeLabel = "${TS_DAYS[event.day]} ${tsDateShort(date)} • ${tsPersianDigits(event.startHour.toString())}:۰۰"
        scheduleReliableAlarm(context, triggerAt, timeSheetReminderPendingIntent(context, key, event.title, timeLabel))
        scheduled += key
    }

    state.weeks.forEach { (weekKey, entries) ->
        val weekStart = runCatching { LocalDate.parse(weekKey) }.getOrNull() ?: return@forEach
        entries.filter { !it.recurring && it.templateId == 0L }.forEach { event ->
            schedule(event, weekStart.plusDays(event.day.toLong()), event.id)
        }
    }

    val base = tsBaseSaturday()
    for (weekOffset in 0..TS_MAX_WEEK_OFFSET) {
        val weekStart = base.plusWeeks(weekOffset.toLong())
        val key = tsWeekKey(weekStart)
        val overrides = state.weeks[key].orEmpty()
        state.templates.forEach { template ->
            if (!template.reminder) return@forEach
            val override = overrides.firstOrNull { it.templateId == template.id }
            val occurrence = if (override != null) template.copy(status = override.status) else template
            schedule(occurrence, weekStart.plusDays(template.day.toLong()), template.id)
        }
    }

    prefs.edit().putStringSet(TS_REMINDER_PREF_KEY, scheduled).apply()
}

// Stage 64: compact daily summary for the World Map. The map only needs to know
// whether today's schedule still needs attention; detailed editing remains here.
internal fun timeSheetWorldState(context: Context): WorldNodeState {
    val state = loadTimeSheetState(context)
    val weekStart = tsBaseSaturday()
    val today = LocalDate.now()
    val dayIndex = java.time.temporal.ChronoUnit.DAYS.between(weekStart, today).toInt().coerceIn(0, 6)
    val todayEvents = tsDisplayedEvents(state, weekStart).filter { it.day == dayIndex }
    return when {
        todayEvents.isEmpty() -> WorldNodeState.Normal
        todayEvents.all { it.status == "done" } -> WorldNodeState.Completed
        else -> WorldNodeState.Pending
    }
}

// Stage 142: lightweight Home projection so the World dashboard reads the same
// persisted TimeSheet data without duplicating its storage format.
internal data class TimeSheetTodaySummary(
    val plannedMinutes: Int,
    val actualFocusSeconds: Int
) {
    val coveragePercent: Int get() = if (plannedMinutes > 0) {
        ((actualFocusSeconds.coerceAtLeast(0) * 100L) / (plannedMinutes * 60L)).toInt().coerceIn(0, 999)
    } else 0
}
