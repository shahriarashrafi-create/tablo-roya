shadbash - Sound FX + Sound Toggle

Changes:
- Added built-in game sound effects for:
  - game start
  - correct answer
  - wrong answer
  - next team
  - round transition
  - 10-second timeout
  - final winner
- Sound effects are generated locally inside the app and do not require external audio files.
- Added «افکت صدا» ON/OFF switch in Settings.
- Sound preference is persisted.
- Sound preference is included in Export / Import metadata backup.
- The song audio itself is not muted by this switch; it controls game sound effects only.
- In song editing, Play and Stop are now a single full-width two-button row directly beside each other.
- No reset-to-start button exists in the test controls.
