plugins {
    id("com.android.application")
}

android {
    namespace = "com.shahriar.nextbeat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shahriar.shadbash"
        minSdk = 24
        targetSdk = 35
        versionCode = 23
        versionName = "2.2.0-shadbash-sound-fx-settings"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
