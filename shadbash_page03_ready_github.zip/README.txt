shadbash - Page 03 ready

Changes in this ZIP:
- Unified section title sizes for: تعداد تیم‌ها / نام تیم‌ها / تعداد راندها
- Changed heading to «تعداد تیم‌ها»
- Removed the note under team-name section
- Team-name field widths now adapt based on selected team count
- Default fallback names are team placeholders: تیم اول / تیم دوم / ...
- If a field is left blank, the game uses the default team title automatically
- Added custom round modal with selection from 1 to 20
- Replaced button text with «شروع بازی»
- Added next page: ready/start screen with summary and start round button
- Compatible with the existing ZIP-based workflow
