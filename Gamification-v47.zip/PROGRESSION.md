# Gamification v47 Progress

- Rebuilt Dreamboard as a full-screen 9:16 horizontal snap carousel.
- Removed Dreamboard title, top add button, close button and photo three-dot controls.
- Center dream is emphasized; adjacent dreams are slightly smaller/dimmer.
- Dream info remains only on the bottom of the image: price left, year center, title right.
- Long-pressing a dream opens its properties directly.
- Added a final 9:16 Add Dream card at the end of the carousel.
- Dream properties are reduced to image, title, year, price and display position.
- Added a 9:16 crop flow after gallery selection, with one-finger pan and pinch zoom.
- Display position remains selectable as a simple position picker.
- Version bumped to 0.47.
