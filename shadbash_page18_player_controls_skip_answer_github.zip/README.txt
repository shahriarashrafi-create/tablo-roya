shadbash - Player Controls / Skip Answer Playback

Changes:
- In song edit testing, Play is now directly beside Stop.
- Removed the old jump-to-start button from the test controls.
- Seek bar and ±5 second controls remain for moving within the selected test range.
- Back confirmation after game start is now minimal:
  - «خروج از این دور؟»
  - «ادامه مسابقه»
  - «خروج از این دور»
- Removed the extra reset/score warning texts.
- Added a forward button during continuation playback.
- Forward immediately stops the continuation audio and opens the saved answer with Correct / Wrong.
- Existing compact song list, inline testing, backup/import, readiness checks, scoring and reset-on-back behavior remain.
