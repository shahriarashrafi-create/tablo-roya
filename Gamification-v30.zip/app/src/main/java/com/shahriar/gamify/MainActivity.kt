package com.shahriar.gamify

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import java.util.Locale
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0C1320)
private val Gold = Color(0xFFF7C948)
private val GoldSoft = Color(0xFFFCE9A7)
private val TextSoft = Color(0xFFD8DFE8)
private val Divider = Color(0xFF2A3440)
private val Blue = Color(0xFF5CA3FF)

private val motivationalQuotes = listOf(
    "Small steps build great futures.",
    "Discipline creates freedom.",
    "Keep moving forward.",
    "Win the next moment.",
    "Progress over perfection.",
    "Build the life you want.",
    "Focus. Execute. Grow.",
    "Your future starts today.",
    "One mission at a time.",
    "Consistency beats intensity.",
    "Become stronger every day.",
    "Do the hard thing first.",
    "Make today count.",
    "Your habits shape your destiny.",
    "Keep the promise to yourself.",
    "Action creates confidence.",
    "Great things take repetition.",
    "Earn your next level.",
    "Stay focused on the mission.",
    "Become who you said you would.",
    "Momentum changes everything.",
    "Show up and do the work.",
    "Every effort adds up.",
    "Your discipline is your power.",
    "Start before you feel ready.",
    "Keep building your future.",
    "One focused hour can change a day.",
    "Progress is always earned.",
    "Make your future proud.",
    "Train your mind to finish.",
    "Growth begins with action.",
    "Your next level needs you.",
    "Build momentum, not excuses.",
    "Today is another chance to grow.",
    "Focus turns goals into reality.",
    "Keep going when it gets hard.",
    "Success is built in small moments.",
    "Make discipline your advantage.",
    "Your actions define your path.",
    "Push beyond your comfort zone.",
    "Finish what you started.",
    "Create a life worth leveling up.",
    "Stay consistent. Stay dangerous.",
    "The mission is simple: improve.",
    "Build yourself every single day.",
    "Your future rewards consistency.",
    "Focus now. Celebrate later.",
    "Every mission makes you stronger.",
    "Become better than yesterday.",
    "Keep climbing. Your peak is ahead."
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val coins: Int = 1320,
    val combo: Int = 12,
    val bestCombo: Int = 12
)

data class Mission(
    val title: String,
    val durationMinutes: Int,
    val xpReward: Int,
    val coinReward: Int
)

private enum class AppScreen { Home, Mission }
enum class MissionResult { Done, Partial, Fail, Defer }

data class MissionHistoryEntry(
    val timestamp: Long,
    val missionTitle: String,
    val plannedMinutes: Int,
    val focusSeconds: Int,
    val result: MissionResult,
    val xpEarned: Int,
    val coinsEarned: Int,
    val levelRewardCoins: Int
)

data class MissionOutcome(
    val player: PlayerState,
    val xpGain: Int,
    val missionCoinGain: Int,
    val levelsGained: Int,
    val levelRewardCoins: Int,
    val comboBefore: Int,
    val comboAfter: Int,
    val rewardMultiplier: Float
)

data class LevelUpEvent(
    val fromLevel: Int,
    val toLevel: Int,
    val rewardCoins: Int
)

private enum class AppThemeMode { Classic, Midnight, Obsidian }

private data class GameSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val reducedMotion: Boolean = false,
    val comboBoostEnabled: Boolean = true,
    val themeMode: AppThemeMode = AppThemeMode.Midnight
)

private data class ActiveTimerState(
    val mission: Mission,
    val remainingSeconds: Int,
    val endAtMillis: Long,
    val isRunning: Boolean
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val ringColors: List<Color>
)

private enum class WorldButtonType { Quest, Map, Inbox, Shop }
private enum class BottomNavType { Home, Stats, Settings }

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", Color(0xFF6D3C1D), Color(0xFFF2C56F)),
    RankTier(6, 10, "Explorer", Color(0xFF7D1E1A), Color(0xFFF5CC62)),
    RankTier(11, 15, "Seeker", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value)

private const val PREFS_NAME = "gamify_state_v1"
private const val KEY_MISSIONS = "missions"
private const val KEY_HISTORY = "mission_history"
private const val KEY_PLAYER_LEVEL = "player_level"
private const val KEY_PLAYER_XP = "player_xp"
private const val KEY_PLAYER_NEXT_XP = "player_next_xp"
private const val KEY_PLAYER_RANK = "player_rank"
private const val KEY_PLAYER_COINS = "player_coins"
private const val KEY_PLAYER_COMBO = "player_combo"
private const val KEY_PLAYER_BEST_COMBO = "player_best_combo"
private const val KEY_SETTINGS_SOUND = "settings_sound"
private const val KEY_SETTINGS_VIBRATION = "settings_vibration"
private const val KEY_SETTINGS_NOTIFICATIONS = "settings_notifications"
private const val KEY_SETTINGS_REDUCED_MOTION = "settings_reduced_motion"
private const val KEY_SETTINGS_COMBO_BOOST = "settings_combo_boost"
private const val KEY_SETTINGS_THEME = "settings_theme"
private const val KEY_TIMER_ACTIVE = "timer_active"
private const val KEY_TIMER_TITLE = "timer_title"
private const val KEY_TIMER_DURATION = "timer_duration"
private const val KEY_TIMER_XP = "timer_xp"
private const val KEY_TIMER_COINS = "timer_coins"
private const val KEY_TIMER_REMAINING = "timer_remaining"
private const val KEY_TIMER_END_AT = "timer_end_at"
private const val KEY_TIMER_RUNNING = "timer_running"
private const val LEVEL_UP_COIN_REWARD = 100
private const val TIMER_REQUEST_CODE = 7142

private fun defaultMission(): Mission = Mission(
    title = "۴۵ دقیقه تمرکز",
    durationMinutes = 45,
    xpReward = 50,
    coinReward = 20
)

private fun loadSettings(context: Context): GameSettings {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val theme = runCatching {
        AppThemeMode.valueOf(prefs.getString(KEY_SETTINGS_THEME, AppThemeMode.Midnight.name) ?: AppThemeMode.Midnight.name)
    }.getOrDefault(AppThemeMode.Midnight)
    return GameSettings(
        soundEnabled = prefs.getBoolean(KEY_SETTINGS_SOUND, true),
        vibrationEnabled = prefs.getBoolean(KEY_SETTINGS_VIBRATION, true),
        notificationsEnabled = prefs.getBoolean(KEY_SETTINGS_NOTIFICATIONS, true),
        reducedMotion = prefs.getBoolean(KEY_SETTINGS_REDUCED_MOTION, false),
        comboBoostEnabled = prefs.getBoolean(KEY_SETTINGS_COMBO_BOOST, true),
        themeMode = theme
    )
}

private fun saveSettings(context: Context, settings: GameSettings) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_SETTINGS_SOUND, settings.soundEnabled)
        .putBoolean(KEY_SETTINGS_VIBRATION, settings.vibrationEnabled)
        .putBoolean(KEY_SETTINGS_NOTIFICATIONS, settings.notificationsEnabled)
        .putBoolean(KEY_SETTINGS_REDUCED_MOTION, settings.reducedMotion)
        .putBoolean(KEY_SETTINGS_COMBO_BOOST, settings.comboBoostEnabled)
        .putString(KEY_SETTINGS_THEME, settings.themeMode.name)
        .apply()
}

private fun themeOverlay(mode: AppThemeMode): Color = when (mode) {
    AppThemeMode.Classic -> Color.Transparent
    AppThemeMode.Midnight -> Color(0x24112B4A)
    AppThemeMode.Obsidian -> Color(0x42000000)
}

private fun comboMultiplier(combo: Int): Float = when {
    combo >= 20 -> 2.0f
    combo >= 10 -> 1.5f
    combo >= 5 -> 1.25f
    combo >= 3 -> 1.10f
    else -> 1.0f
}

private fun loadActiveTimer(context: Context): ActiveTimerState? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    if (!prefs.getBoolean(KEY_TIMER_ACTIVE, false)) return null
    val mission = Mission(
        title = prefs.getString(KEY_TIMER_TITLE, "Mission") ?: "Mission",
        durationMinutes = prefs.getInt(KEY_TIMER_DURATION, 45).coerceAtLeast(1),
        xpReward = prefs.getInt(KEY_TIMER_XP, 50).coerceAtLeast(0),
        coinReward = prefs.getInt(KEY_TIMER_COINS, 20).coerceAtLeast(0)
    )
    return ActiveTimerState(
        mission = mission,
        remainingSeconds = prefs.getInt(KEY_TIMER_REMAINING, mission.durationMinutes * 60).coerceAtLeast(0),
        endAtMillis = prefs.getLong(KEY_TIMER_END_AT, 0L),
        isRunning = prefs.getBoolean(KEY_TIMER_RUNNING, false)
    )
}

private fun saveActiveTimer(context: Context, state: ActiveTimerState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, true)
        .putString(KEY_TIMER_TITLE, state.mission.title)
        .putInt(KEY_TIMER_DURATION, state.mission.durationMinutes)
        .putInt(KEY_TIMER_XP, state.mission.xpReward)
        .putInt(KEY_TIMER_COINS, state.mission.coinReward)
        .putInt(KEY_TIMER_REMAINING, state.remainingSeconds.coerceAtLeast(0))
        .putLong(KEY_TIMER_END_AT, state.endAtMillis)
        .putBoolean(KEY_TIMER_RUNNING, state.isRunning)
        .apply()
}

private fun remainingSeconds(state: ActiveTimerState, now: Long = System.currentTimeMillis()): Int {
    if (!state.isRunning) return state.remainingSeconds.coerceAtLeast(0)
    if (state.endAtMillis <= now) return 0
    return ceil((state.endAtMillis - now) / 1000.0).toInt().coerceAtLeast(0)
}

private fun timerPendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
    context,
    TIMER_REQUEST_CODE,
    Intent(context, TimerFinishReceiver::class.java),
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

private fun cancelTimerAlarm(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timerPendingIntent(context))
}

private fun scheduleTimerAlarm(context: Context, state: ActiveTimerState, settings: GameSettings) {
    cancelTimerAlarm(context)
    if (!settings.notificationsEnabled || !state.isRunning || state.endAtMillis <= System.currentTimeMillis()) return
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, state.endAtMillis, timerPendingIntent(context))
}

private fun beginActiveTimer(context: Context, mission: Mission, settings: GameSettings): ActiveTimerState {
    val total = (mission.durationMinutes * 60).coerceAtLeast(1)
    val state = ActiveTimerState(
        mission = mission,
        remainingSeconds = total,
        endAtMillis = System.currentTimeMillis() + total * 1000L,
        isRunning = true
    )
    saveActiveTimer(context, state)
    scheduleTimerAlarm(context, state, settings)
    return state
}

private fun clearActiveTimer(context: Context) {
    cancelTimerAlarm(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, false)
        .remove(KEY_TIMER_END_AT)
        .remove(KEY_TIMER_REMAINING)
        .remove(KEY_TIMER_RUNNING)
        .apply()
}

private fun playResultFeedback(context: Context, settings: GameSettings, result: MissionResult, levelUp: Boolean) {
    if (settings.soundEnabled) {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
        val toneType = when {
            levelUp -> ToneGenerator.TONE_PROP_ACK
            result == MissionResult.Done -> ToneGenerator.TONE_PROP_BEEP2
            result == MissionResult.Partial -> ToneGenerator.TONE_PROP_BEEP
            else -> ToneGenerator.TONE_PROP_NACK
        }
        tone.startTone(toneType, if (levelUp) 260 else 150)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 320L)
    }
    if (settings.vibrationEnabled) {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val pattern = if (levelUp) longArrayOf(0, 45, 55, 90) else longArrayOf(0, 45)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (levelUp) 140L else 45L)
            }
        }
    }
}

private fun loadPlayer(context: Context): PlayerState {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val combo = prefs.getInt(KEY_PLAYER_COMBO, 12)
    return PlayerState(
        level = prefs.getInt(KEY_PLAYER_LEVEL, 37),
        currentXp = prefs.getInt(KEY_PLAYER_XP, 2450),
        nextLevelXp = prefs.getInt(KEY_PLAYER_NEXT_XP, 3000),
        rank = prefs.getInt(KEY_PLAYER_RANK, 8),
        coins = prefs.getInt(KEY_PLAYER_COINS, 1320),
        combo = combo,
        bestCombo = prefs.getInt(KEY_PLAYER_BEST_COMBO, combo)
    )
}

private fun savePlayer(context: Context, player: PlayerState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putInt(KEY_PLAYER_LEVEL, player.level)
        .putInt(KEY_PLAYER_XP, player.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, player.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, player.rank)
        .putInt(KEY_PLAYER_COINS, player.coins)
        .putInt(KEY_PLAYER_COMBO, player.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, player.bestCombo)
        .apply()
}

private fun loadMissions(context: Context): List<Mission> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_MISSIONS, null) ?: return listOf(defaultMission())
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    Mission(
                        title = item.optString("title", "New Mission"),
                        durationMinutes = item.optInt("durationMinutes", 45).coerceAtLeast(1),
                        xpReward = item.optInt("xpReward", 50).coerceAtLeast(0),
                        coinReward = item.optInt("coinReward", 20).coerceAtLeast(0)
                    )
                )
            }
        }
    }.getOrElse { listOf(defaultMission()) }
}

private fun saveMissions(context: Context, missions: List<Mission>) {
    val array = JSONArray()
    missions.forEach { mission ->
        array.put(
            JSONObject()
                .put("title", mission.title)
                .put("durationMinutes", mission.durationMinutes)
                .put("xpReward", mission.xpReward)
                .put("coinReward", mission.coinReward)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_MISSIONS, array.toString())
        .apply()
}

private fun loadHistory(context: Context): List<MissionHistoryEntry> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val result = runCatching { MissionResult.valueOf(item.optString("result", "Done")) }
                    .getOrDefault(MissionResult.Done)
                add(
                    MissionHistoryEntry(
                        timestamp = item.optLong("timestamp", System.currentTimeMillis()),
                        missionTitle = item.optString("missionTitle", "Mission"),
                        plannedMinutes = item.optInt("plannedMinutes", 0),
                        focusSeconds = item.optInt("focusSeconds", 0).coerceAtLeast(0),
                        result = result,
                        xpEarned = item.optInt("xpEarned", 0).coerceAtLeast(0),
                        coinsEarned = item.optInt("coinsEarned", 0).coerceAtLeast(0),
                        levelRewardCoins = item.optInt("levelRewardCoins", 0).coerceAtLeast(0)
                    )
                )
            }
        }
    }.getOrElse { emptyList() }
}

private fun saveHistory(context: Context, history: List<MissionHistoryEntry>) {
    val array = JSONArray()
    history.take(500).forEach { entry ->
        array.put(
            JSONObject()
                .put("timestamp", entry.timestamp)
                .put("missionTitle", entry.missionTitle)
                .put("plannedMinutes", entry.plannedMinutes)
                .put("focusSeconds", entry.focusSeconds)
                .put("result", entry.result.name)
                .put("xpEarned", entry.xpEarned)
                .put("coinsEarned", entry.coinsEarned)
                .put("levelRewardCoins", entry.levelRewardCoins)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_HISTORY, array.toString())
        .apply()
}

private fun applyMissionResult(
    player: PlayerState,
    mission: Mission,
    result: MissionResult,
    settings: GameSettings
): MissionOutcome {
    val comboAfter = when (result) {
        MissionResult.Done -> player.combo + 1
        MissionResult.Partial -> (player.combo - 1).coerceAtLeast(0)
        MissionResult.Fail, MissionResult.Defer -> 0
    }
    val rewardMultiplier = if (settings.comboBoostEnabled && result == MissionResult.Done) {
        comboMultiplier(comboAfter)
    } else {
        1.0f
    }
    val baseXp = when (result) {
        MissionResult.Done -> mission.xpReward
        MissionResult.Partial -> mission.xpReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }
    val baseCoins = when (result) {
        MissionResult.Done -> mission.coinReward
        MissionResult.Partial -> mission.coinReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }
    val xpGain = (baseXp * rewardMultiplier).toInt()
    val missionCoinGain = (baseCoins * rewardMultiplier).toInt()

    var level = player.level
    var xp = player.currentXp + xpGain
    var threshold = player.nextLevelXp
    var levelsGained = 0
    while (xp >= threshold) {
        xp -= threshold
        level += 1
        levelsGained += 1
        threshold += 500
    }

    val levelRewardCoins = levelsGained * LEVEL_UP_COIN_REWARD
    val updated = player.copy(
        level = level,
        currentXp = xp,
        nextLevelXp = threshold,
        coins = player.coins + missionCoinGain + levelRewardCoins,
        combo = comboAfter,
        bestCombo = maxOf(player.bestCombo, comboAfter)
    )
    return MissionOutcome(
        player = updated,
        xpGain = xpGain,
        missionCoinGain = missionCoinGain,
        levelsGained = levelsGained,
        levelRewardCoins = levelRewardCoins,
        comboBefore = player.combo,
        comboAfter = comboAfter,
        rewardMultiplier = rewardMultiplier
    )
}

private fun MissionHistoryEntry.localDate(zoneId: ZoneId = ZoneId.systemDefault()): LocalDate =
    Instant.ofEpochMilli(timestamp).atZone(zoneId).toLocalDate()

@Composable
fun App() {
    val context = LocalContext.current.applicationContext
    val restoredTimer = remember { loadActiveTimer(context) }
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf(if (restoredTimer != null) AppScreen.Mission else AppScreen.Home) }
    var player by remember { mutableStateOf(loadPlayer(context)) }
    var settings by remember { mutableStateOf(loadSettings(context)) }
    var quoteIndex by remember { mutableIntStateOf(motivationalQuotes.indices.random()) }
    var activeMission by remember { mutableStateOf(restoredTimer?.mission) }
    var levelUpEvent by remember { mutableStateOf<LevelUpEvent?>(null) }
    val quote = motivationalQuotes[quoteIndex]
    val missions = remember {
        mutableStateListOf<Mission>().also { it.addAll(loadMissions(context)) }
    }
    val history = remember {
        mutableStateListOf<MissionHistoryEntry>().also { it.addAll(loadHistory(context)) }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted && settings.notificationsEnabled) {
            settings = settings.copy(notificationsEnabled = false)
            saveSettings(context, settings)
            cancelTimerAlarm(context)
        } else if (granted) {
            loadActiveTimer(context)?.let { scheduleTimerAlarm(context, it, settings) }
        }
    }

    LaunchedEffect(Unit) {
        val restored = loadActiveTimer(context)
        val canNotify = !settings.notificationsEnabled ||
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (restored != null && restored.isRunning && canNotify) {
            scheduleTimerAlarm(context, restored, settings)
        }
    }

    fun completeMission(mission: Mission, result: MissionResult, focusSeconds: Int) {
        clearActiveTimer(context)
        val beforeLevel = player.level
        val outcome = applyMissionResult(player, mission, result, settings)
        player = outcome.player
        savePlayer(context, player)

        val entry = MissionHistoryEntry(
            timestamp = System.currentTimeMillis(),
            missionTitle = mission.title,
            plannedMinutes = mission.durationMinutes,
            focusSeconds = focusSeconds.coerceAtLeast(0),
            result = result,
            xpEarned = outcome.xpGain,
            coinsEarned = outcome.missionCoinGain + outcome.levelRewardCoins,
            levelRewardCoins = outcome.levelRewardCoins
        )
        history.add(0, entry)
        while (history.size > 500) history.removeAt(history.lastIndex)
        saveHistory(context, history)

        playResultFeedback(
            context = context,
            settings = settings,
            result = result,
            levelUp = outcome.levelsGained > 0
        )

        if (outcome.levelsGained > 0) {
            levelUpEvent = LevelUpEvent(
                fromLevel = beforeLevel,
                toLevel = outcome.player.level,
                rewardCoins = outcome.levelRewardCoins
            )
        }

        activeMission = null
        screen = AppScreen.Home
    }

    MaterialTheme {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    if (screen == AppScreen.Home) {
                        GameBottomNavigation(
                            selected = tab,
                            onSelect = { i ->
                                tab = i
                                if (i == 0) {
                                    var next = motivationalQuotes.indices.random()
                                    if (motivationalQuotes.size > 1) {
                                        while (next == quoteIndex) next = motivationalQuotes.indices.random()
                                    }
                                    quoteIndex = next
                                }
                            }
                        )
                    }
                }
            ) { pad ->
                when (screen) {
                    AppScreen.Mission -> {
                        val mission = activeMission ?: loadActiveTimer(context)?.mission ?: missions.firstOrNull() ?: defaultMission()
                        MissionExecutionScreen(
                            mission = mission,
                            player = player,
                            settings = settings,
                            onAbandon = { focusSeconds ->
                                completeMission(mission, MissionResult.Defer, focusSeconds)
                            },
                            onResult = { result, focusSeconds ->
                                completeMission(mission, result, focusSeconds)
                            },
                            modifier = Modifier.padding(top = pad.calculateTopPadding())
                        )
                    }
                    AppScreen.Home -> {
                        when (tab) {
                            0 -> {
                                GameHome(
                                    player = player,
                                    quote = quote,
                                    missions = missions,
                                    settings = settings,
                                    onStartMission = { mission ->
                                        val needsNotificationPermission = settings.notificationsEnabled &&
                                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                        if (needsNotificationPermission) {
                                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                        beginActiveTimer(context, mission, settings)
                                        activeMission = mission
                                        screen = AppScreen.Mission
                                    },
                                    onAddMission = { position, mission ->
                                        val index = position.coerceIn(0, missions.size)
                                        missions.add(index, mission)
                                        saveMissions(context, missions)
                                    },
                                    onUpdateMission = { index, newPosition, mission ->
                                        if (index in missions.indices) {
                                            missions[index] = mission
                                            val moved = missions.removeAt(index)
                                            val target = newPosition.coerceIn(0, missions.size)
                                            missions.add(target, moved)
                                            saveMissions(context, missions)
                                        }
                                    },
                                    onDeleteMission = { index ->
                                        if (index in missions.indices) {
                                            missions.removeAt(index)
                                            saveMissions(context, missions)
                                        }
                                    },
                                    modifier = Modifier.padding(top = pad.calculateTopPadding())
                                )
                            }
                            1 -> {
                                StatsScreen(
                                    player = player,
                                    history = history,
                                    settings = settings,
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                            else -> {
                                SettingsScreen(
                                    settings = settings,
                                    onSettingsChange = { updated ->
                                        settings = updated
                                        saveSettings(context, updated)
                                        if (!updated.notificationsEnabled) {
                                            cancelTimerAlarm(context)
                                        } else {
                                            val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                            if (needsPermission) {
                                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            } else {
                                                loadActiveTimer(context)?.let { scheduleTimerAlarm(context, it, updated) }
                                            }
                                        }
                                    },
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                        }
                    }
                }
            }

            levelUpEvent?.let { event ->
                LevelUpOverlay(
                    event = event,
                    reducedMotion = settings.reducedMotion,
                    onDismiss = { levelUpEvent = null }
                )
            }
        }
    }
}

@Composable
private fun MissionExecutionScreen(
    mission: Mission,
    player: PlayerState,
    settings: GameSettings,
    onAbandon: (Int) -> Unit,
    onResult: (MissionResult, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current.applicationContext
    var timerState by remember(mission) {
        mutableStateOf(
            loadActiveTimer(context)?.takeIf { it.mission == mission }
                ?: beginActiveTimer(context, mission, settings)
        )
    }
    var remaining by remember(mission) { mutableIntStateOf(remainingSeconds(timerState)) }
    var choosingResult by remember(mission) { mutableStateOf(remaining <= 0) }
    var showAbandonDialog by remember { mutableStateOf(false) }

    fun persistTimer(state: ActiveTimerState) {
        timerState = state
        remaining = remainingSeconds(state)
        saveActiveTimer(context, state)
        if (state.isRunning) scheduleTimerAlarm(context, state, settings) else cancelTimerAlarm(context)
    }

    BackHandler { showAbandonDialog = true }

    LaunchedEffect(timerState.isRunning, timerState.endAtMillis, choosingResult) {
        if (choosingResult || !timerState.isRunning) {
            remaining = remainingSeconds(timerState)
            return@LaunchedEffect
        }
        while (timerState.isRunning && !choosingResult) {
            val nowRemaining = remainingSeconds(timerState)
            remaining = nowRemaining
            if (nowRemaining <= 0) {
                val ended = timerState.copy(remainingSeconds = 0, endAtMillis = 0L, isRunning = false)
                timerState = ended
                saveActiveTimer(context, ended)
                cancelTimerAlarm(context)
                choosingResult = true
                break
            }
            delay(250L)
        }
    }

    val totalSeconds = (mission.durationMinutes * 60).coerceAtLeast(1)
    val focusedSeconds = (totalSeconds - remaining).coerceIn(0, totalSeconds)
    val minutes = remaining / 60
    val seconds = remaining % 60
    val timerText = String.format(Locale.US, "%02d:%02d", minutes, seconds)
    val progress = remaining.toFloat() / totalSeconds.toFloat()
    val nextCombo = player.combo + 1
    val boost = if (settings.comboBoostEnabled) comboMultiplier(nextCombo) else 1.0f
    val previewXp = (mission.xpReward * boost).toInt()
    val previewCoins = (mission.coinReward * boost).toInt()

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xD80A1018), Color(0xE80A1018), Color(0xF40A1018))))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "‹ Back",
                    color = GoldSoft,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { showAbandonDialog = true }.padding(8.dp)
                )
                Text("MISSION", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.width(52.dp))
            }

            Spacer(Modifier.height(28.dp))
            Text(
                mission.title,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(9.dp))
            Text(
                if (boost > 1f) "+$previewXp XP   •   +$previewCoins Coins   •   Combo x${String.format(Locale.US, "%.2g", boost)}"
                else "+${mission.xpReward} XP   •   +${mission.coinReward} Coins",
                color = GoldSoft,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(30.dp))
            Box(modifier = Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 10.dp.toPx()
                    drawCircle(color = Color(0x55000000), radius = size.minDimension * 0.45f)
                    drawCircle(
                        color = Color(0xFF28313D),
                        radius = size.minDimension * 0.45f,
                        style = Stroke(width = stroke)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(GoldSoft, Gold, Color(0xFFE7A91C), GoldSoft)),
                        startAngle = -90f,
                        sweepAngle = 360f * progress,
                        useCenter = false,
                        topLeft = Offset(size.width * 0.05f, size.height * 0.05f),
                        size = Size(size.width * 0.90f, size.height * 0.90f),
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(timerText, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        when {
                            choosingResult -> "COMPLETE"
                            timerState.isRunning -> "FOCUS"
                            else -> "PAUSED"
                        },
                        color = GoldSoft,
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                    if (!choosingResult) {
                        Spacer(Modifier.height(5.dp))
                        Text("${formatFocusTime(focusedSeconds)} focused", color = TextSoft, fontSize = 9.sp)
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            if (!choosingResult) {
                Button(
                    onClick = {
                        if (timerState.isRunning) {
                            val nowRemaining = remainingSeconds(timerState)
                            persistTimer(
                                timerState.copy(
                                    remainingSeconds = nowRemaining,
                                    endAtMillis = 0L,
                                    isRunning = false
                                )
                            )
                        } else {
                            val safeRemaining = remaining.coerceAtLeast(1)
                            persistTimer(
                                timerState.copy(
                                    remainingSeconds = safeRemaining,
                                    endAtMillis = System.currentTimeMillis() + safeRemaining * 1000L,
                                    isRunning = true
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text(if (timerState.isRunning) "Pause" else "Resume", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .clickable {
                            val nowRemaining = remainingSeconds(timerState)
                            persistTimer(
                                timerState.copy(
                                    remainingSeconds = nowRemaining,
                                    endAtMillis = 0L,
                                    isRunning = false
                                )
                            )
                            choosingResult = true
                        },
                    color = Color(0xB0151B24),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x55F1D487))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("Finish Mission", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            } else {
                Text("How did it go?", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ResultButton("Done", Gold, Modifier.weight(1f)) { onResult(MissionResult.Done, focusedSeconds) }
                    ResultButton("Partial", Color(0xFF5CA3FF), Modifier.weight(1f)) { onResult(MissionResult.Partial, focusedSeconds) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ResultButton("Fail", Color(0xFFB35A5A), Modifier.weight(1f)) { onResult(MissionResult.Fail, focusedSeconds) }
                    ResultButton("Defer", Color(0xFF596574), Modifier.weight(1f)) { onResult(MissionResult.Defer, focusedSeconds) }
                }
            }
        }
    }

    if (showAbandonDialog) {
        AlertDialog(
            onDismissRequest = { showAbandonDialog = false },
            containerColor = Color(0xFF111923),
            title = { Text("Leave mission?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Leaving marks this mission as deferred and resets your current Combo. The timer will stop.",
                    color = TextSoft,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { onAbandon(focusedSeconds) }) {
                    Text("Leave", color = Color(0xFFE67B7B), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAbandonDialog = false }) {
                    Text("Keep focusing", color = GoldSoft)
                }
            }
        )
    }
}

@Composable
private fun ResultButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

private fun formatFocusTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val secs = safe % 60
    return when {
        hours > 0 -> String.format(Locale.US, "%dh %02dm", hours, minutes)
        minutes > 0 -> String.format(Locale.US, "%dm %02ds", minutes, secs)
        else -> String.format(Locale.US, "%ds", secs)
    }
}

private fun historyResultColor(result: MissionResult): Color = when (result) {
    MissionResult.Done -> Gold
    MissionResult.Partial -> Blue
    MissionResult.Fail -> Color(0xFFE67B7B)
    MissionResult.Defer -> Color(0xFFAAB3C0)
}

@Composable
private fun StatsScreen(
    player: PlayerState,
    history: List<MissionHistoryEntry>,
    settings: GameSettings,
    modifier: Modifier = Modifier
) {
    val zoneId = ZoneId.systemDefault()
    val today = LocalDate.now(zoneId)
    val todayEntries = history.filter { it.localDate(zoneId) == today }
    val todayXp = todayEntries.sumOf { it.xpEarned }
    val todayFocus = todayEntries.sumOf { it.focusSeconds }
    val todayDone = todayEntries.count { it.result == MissionResult.Done }
    val recordedXp = history.sumOf { it.xpEarned }
    val recordedCoins = history.sumOf { it.coinsEarned }
    val totalFocus = history.sumOf { it.focusSeconds }
    val totalDone = history.count { it.result == MissionResult.Done }
    val lastSevenDays = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val focusByDay = lastSevenDays.map { day ->
        history.asSequence()
            .filter { it.localDate(zoneId) == day }
            .sumOf { it.focusSeconds } / 60
    }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xE40A1119), Color(0xF00A1119), Color(0xFA080D14))
                    )
                )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text(
                        "STATS",
                        color = Gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.2.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Your progress, built from completed missions.",
                        color = TextSoft,
                        fontSize = 12.sp
                    )
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("TODAY XP", "+${formatNumber(todayXp)}", "XP", Modifier.weight(1f))
                    StatMetricCard("FOCUS", formatFocusTime(todayFocus), "today", Modifier.weight(1f))
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("DONE", todayDone.toString(), "today", Modifier.weight(1f))
                    StatMetricCard("BEST COMBO", player.bestCombo.toString(), "record", Modifier.weight(1f))
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("7 DAY FOCUS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Minutes focused each day", color = TextSoft, fontSize = 10.sp)
                            }
                            Text("${focusByDay.sum()} min", color = GoldSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(14.dp))
                        SevenDayFocusChart(days = lastSevenDays, minutes = focusByDay)
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, Color(0x302D3948))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ALL TIME", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        StatLine("Recorded XP", formatNumber(recordedXp))
                        StatLine("Recorded Coins", formatNumber(recordedCoins))
                        StatLine("Focus Time", formatFocusTime(totalFocus))
                        StatLine("Missions Done", totalDone.toString())
                        StatLine("Current Level", player.level.toString())
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("MISSION HISTORY", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("${history.size} records", color = TextSoft, fontSize = 10.sp)
                }
            }

            if (history.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xA90D141E)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("No mission history yet", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("Finish a mission and your activity will appear here.", color = TextSoft, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(history, key = { "${it.timestamp}-${it.missionTitle}" }) { entry ->
                    MissionHistoryRow(entry)
                }
            }
        }
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    suffix: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(92.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 13.dp, vertical = 11.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Column {
                Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(suffix, color = GoldSoft, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextSoft, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SevenDayFocusChart(days: List<LocalDate>, minutes: List<Int>) {
    val maxMinutes = (minutes.maxOrNull() ?: 0).coerceAtLeast(1)
    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(112.dp)) {
            val count = minutes.size.coerceAtLeast(1)
            val gap = 8.dp.toPx()
            val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(2.dp.toPx())
            val baseline = size.height - 4.dp.toPx()
            drawLine(
                color = Color(0x444B5664),
                start = Offset(0f, baseline),
                end = Offset(size.width, baseline),
                strokeWidth = 1.dp.toPx()
            )
            minutes.forEachIndexed { index, value ->
                val fraction = value.toFloat() / maxMinutes.toFloat()
                val barHeight = if (value == 0) 4.dp.toPx() else (size.height * 0.86f * fraction).coerceAtLeast(8.dp.toPx())
                val left = index * (barWidth + gap)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(GoldSoft, Gold, Color(0xFFC58D20))),
                    topLeft = Offset(left, baseline - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            days.forEach { day ->
                Text(
                    text = day.dayOfWeek.name.take(1),
                    color = if (day == LocalDate.now()) GoldSoft else TextSoft,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MissionHistoryRow(entry: MissionHistoryEntry) {
    val dateText = remember(entry.timestamp) {
        val formatter = DateTimeFormatter.ofPattern("MMM d • HH:mm", Locale.US)
        Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.systemDefault()).format(formatter)
    }
    val resultColor = historyResultColor(entry.result)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xBF0D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color(0x292D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(entry.missionTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(dateText, color = TextSoft, fontSize = 9.sp)
                }
                Spacer(Modifier.width(10.dp))
                Surface(
                    color = resultColor.copy(alpha = 0.16f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, resultColor.copy(alpha = 0.45f))
                ) {
                    Text(
                        entry.result.name.uppercase(Locale.US),
                        color = resultColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⏱ ${formatFocusTime(entry.focusSeconds)}", color = TextSoft, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("+${entry.xpEarned} XP", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("+${entry.coinsEarned} Coins", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (entry.levelRewardCoins > 0) {
                Text(
                    "Includes +${entry.levelRewardCoins} level-up bonus coins",
                    color = Gold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: GameSettings,
    onSettingsChange: (GameSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xE90A1119), Color(0xF50A1119), Color(0xFC080D14))))
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text("SETTINGS", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Tune focus, feedback and gameplay to your style.", color = TextSoft, fontSize = 12.sp)
                }
            }

            item {
                SettingsGroup(title = "FEEDBACK") {
                    SettingsToggleRow(
                        title = "Sound effects",
                        subtitle = "Mission complete and level-up sounds",
                        checked = settings.soundEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(soundEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Vibration",
                        subtitle = "Short haptics for results and rewards",
                        checked = settings.vibrationEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(vibrationEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Timer notifications",
                        subtitle = "Notify when a running mission reaches zero",
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "GAMEPLAY") {
                    SettingsToggleRow(
                        title = "Combo reward boost",
                        subtitle = "Longer combos increase XP and Coin rewards",
                        checked = settings.comboBoostEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(comboBoostEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Reduced motion",
                        subtitle = "Disable pulse and carousel depth animations",
                        checked = settings.reducedMotion,
                        onCheckedChange = { onSettingsChange(settings.copy(reducedMotion = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "THEME") {
                    Text(
                        "World tint",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.values().forEach { mode ->
                            ThemeChoice(
                                mode = mode,
                                selected = settings.themeMode == mode,
                                onClick = { onSettingsChange(settings.copy(themeMode = mode)) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xB90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x2FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("COMBO RULES", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Done  →  +1 Combo", color = Color.White, fontSize = 11.sp)
                        Text("Partial  →  −1 Combo", color = TextSoft, fontSize = 11.sp)
                        Text("Fail / Defer  →  Combo resets", color = TextSoft, fontSize = 11.sp)
                        Text("Boosts: x1.10 at 3 • x1.25 at 5 • x1.50 at 10 • x2 at 20", color = GoldSoft, fontSize = 9.5.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsGroup(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xD10D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(title, color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = TextSoft, fontSize = 9.5.sp, lineHeight = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .height(1.dp)
            .background(Color(0x302D3948))
    )
}

@Composable
private fun ThemeChoice(
    mode: AppThemeMode,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val label = when (mode) {
        AppThemeMode.Classic -> "Classic"
        AppThemeMode.Midnight -> "Midnight"
        AppThemeMode.Obsidian -> "Obsidian"
    }
    val swatch = when (mode) {
        AppThemeMode.Classic -> Color(0xFFB98A36)
        AppThemeMode.Midnight -> Color(0xFF274D78)
        AppThemeMode.Obsidian -> Color(0xFF181B20)
    }
    Surface(
        modifier = modifier.height(62.dp).clickable(onClick = onClick),
        color = if (selected) Color(0x2EF7C948) else Color(0x60131B25),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (selected) Gold else Color(0x353A4654))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(19.dp).clip(androidx.compose.foundation.shape.CircleShape).background(swatch))
            Spacer(Modifier.height(5.dp))
            Text(label, color = if (selected) GoldSoft else TextSoft, fontSize = 8.5.sp, maxLines = 1)
        }
    }
}

@Composable
private fun LevelUpOverlay(event: LevelUpEvent, reducedMotion: Boolean, onDismiss: () -> Unit) {
    BackHandler(onBack = onDismiss)
    val pulse = if (reducedMotion) {
        1f
    } else {
        val pulseTransition = rememberInfiniteTransition(label = "level-up-pulse")
        val animatedPulse by pulseTransition.animateFloat(
            initialValue = 0.97f,
            targetValue = 1.035f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 650),
                repeatMode = RepeatMode.Reverse
            ),
            label = "level-up-scale"
        )
        animatedPulse
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xDC05090F)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.43f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0x6AF7C948), Color(0x20F7C948), Color.Transparent),
                    center = center,
                    radius = size.minDimension * 0.62f
                ),
                radius = size.minDimension * 0.62f,
                center = center
            )
        }

        Card(
            modifier = Modifier
                .padding(horizontal = 30.dp)
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                },
            colors = CardDefaults.cardColors(containerColor = Color(0xF20B121A)),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, Color(0xA8E8C96D))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("LEVEL UP", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(Brush.radialGradient(listOf(Color(0xFFFFE89B), Gold, Color(0xFF8C5B0F)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(event.toLevel.toString(), color = Color(0xFF241A04), fontSize = 38.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "Level ${event.fromLevel} → ${event.toLevel}",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    "+${event.rewardCoins} bonus coins",
                    color = GoldSoft,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun GameBottomNavigation(selected: Int, onSelect: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x520B1119),
                        Color(0xB20A1018),
                        Color(0xE2080D14)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0x55E5C87A), Color.Transparent)
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(size.width, 1.dp.toPx())
                )
            }
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(BottomNavType.Home, "خانه", 0),
                Triple(BottomNavType.Stats, "آمار", 1),
                Triple(BottomNavType.Settings, "تنظیمات", 2)
            )
            items.forEach { (type, title, index) ->
                BottomNavItem(
                    type = type,
                    title = title,
                    selected = selected == index,
                    onClick = { onSelect(index) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    type: BottomNavType,
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconColor = if (selected) Gold else Color(0xFFB3BBC7)
    val textColor = if (selected) GoldSoft else Color(0xFFA6AFBC)

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(width = 46.dp, height = 30.dp)
                .drawBehind {
                    if (selected) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color(0x38F6C84C), Color(0x12F6C84C), Color.Transparent),
                                center = center,
                                radius = size.width * 0.52f
                            ),
                            radius = size.width * 0.52f,
                            center = center
                        )
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, Gold.copy(alpha = 0.85f), Color.Transparent)
                            ),
                            topLeft = Offset(size.width * 0.16f, 0f),
                            size = Size(size.width * 0.68f, 1.5.dp.toPx()),
                            cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            BottomNavIcon(type = type, color = iconColor)
        }
        Spacer(Modifier.height(1.dp))
        Text(
            text = title,
            color = textColor,
            fontSize = 9.5.sp,
            lineHeight = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun BottomNavIcon(type: BottomNavType, color: Color) {
    Canvas(modifier = Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.5.dp.toPx()
        when (type) {
            BottomNavType.Home -> {
                // Compact gamepad icon.
                val body = Path().apply {
                    moveTo(w * 0.22f, h * 0.42f)
                    cubicTo(w * 0.28f, h * 0.24f, w * 0.42f, h * 0.23f, w * 0.50f, h * 0.31f)
                    cubicTo(w * 0.58f, h * 0.23f, w * 0.72f, h * 0.24f, w * 0.78f, h * 0.42f)
                    lineTo(w * 0.88f, h * 0.70f)
                    cubicTo(w * 0.91f, h * 0.80f, w * 0.82f, h * 0.88f, w * 0.73f, h * 0.81f)
                    lineTo(w * 0.60f, h * 0.70f)
                    lineTo(w * 0.40f, h * 0.70f)
                    lineTo(w * 0.27f, h * 0.81f)
                    cubicTo(w * 0.18f, h * 0.88f, w * 0.09f, h * 0.80f, w * 0.12f, h * 0.70f)
                    close()
                }
                drawPath(body, color = color, style = Stroke(width = stroke))
                drawLine(color, Offset(w * 0.31f, h * 0.48f), Offset(w * 0.31f, h * 0.64f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(w * 0.23f, h * 0.56f), Offset(w * 0.39f, h * 0.56f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.67f, h * 0.51f))
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.75f, h * 0.60f))
            }
            BottomNavType.Stats -> {
                drawRoundRect(color = color, topLeft = Offset(w * 0.16f, h * 0.56f), size = Size(w * 0.14f, h * 0.28f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.43f, h * 0.38f), size = Size(w * 0.14f, h * 0.46f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.70f, h * 0.20f), size = Size(w * 0.14f, h * 0.64f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
            }
            BottomNavType.Settings -> {
                drawCircle(color = color, radius = w * 0.23f, center = center, style = Stroke(width = stroke))
                drawCircle(color = color, radius = w * 0.07f, center = center)
                val cx = center.x
                val cy = center.y
                val r1 = w * 0.30f
                val r2 = w * 0.42f
                listOf(0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f).forEach { a ->
                    val rad = Math.toRadians(a.toDouble())
                    val p1 = Offset(cx + cos(rad).toFloat() * r1, cy + sin(rad).toFloat() * r1)
                    val p2 = Offset(cx + cos(rad).toFloat() * r2, cy + sin(rad).toFloat() * r2)
                    drawLine(color, p1, p2, strokeWidth = stroke, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun GameHome(
    player: PlayerState,
    quote: String,
    missions: List<Mission>,
    settings: GameSettings,
    onStartMission: (Mission) -> Unit,
    onAddMission: (Int, Mission) -> Unit,
    onUpdateMission: (Int, Int, Mission) -> Unit,
    onDeleteMission: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = "World Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x6A081118),
                        Color(0x140A1118),
                        Color(0x120B1118),
                        Color(0x46091018),
                        Color(0xD8091018)
                    ),
                    startY = 0f,
                    endY = size.height
                )
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0x4C050B12),
                        Color(0x14050B12),
                        Color(0x00050B12),
                        Color(0x14050B12),
                        Color(0x4C050B12)
                    )
                )
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x18FFFFFF), Color(0x08FFFFFF), Color.Transparent)
                ),
                topLeft = Offset(0f, 0f),
                size = Size(size.width, size.height * 0.14f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            TopGameHud(player)
            Spacer(Modifier.height(8.dp))
            WorldStage(
                quote = quote,
                missions = missions,
                settings = settings,
                onStartMission = onStartMission,
                onAddMission = onAddMission,
                onUpdateMission = onUpdateMission,
                onDeleteMission = onDeleteMission,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun WorldStage(
    quote: String,
    missions: List<Mission>,
    settings: GameSettings,
    onStartMission: (Mission) -> Unit,
    onAddMission: (Int, Mission) -> Unit,
    onUpdateMission: (Int, Int, Mission) -> Unit,
    onDeleteMission: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddMission by remember { mutableStateOf(false) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var pendingScrollPage by remember { mutableStateOf<Int?>(null) }
    val pagerState = rememberPagerState(pageCount = { missions.size + 1 })

    LaunchedEffect(missions.size, pendingScrollPage) {
        val maxPage = missions.size
        if (pagerState.currentPage > maxPage) pagerState.scrollToPage(maxPage)
        pendingScrollPage?.let { target ->
            pagerState.animateScrollToPage(target.coerceIn(0, maxPage))
            pendingScrollPage = null
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(type = WorldButtonType.Quest, label = "Quests", badge = "1")
            SideWorldButton(type = WorldButtonType.Map, label = "Map")
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(type = WorldButtonType.Inbox, label = "Inbox")
            SideWorldButton(type = WorldButtonType.Shop, label = "Shop")
        }

        HeadlineBlock(
            quote = quote,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp, start = 76.dp, end = 76.dp)
        )

        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 100.dp)
                .fillMaxWidth()
                .height(150.dp)
        ) { page ->
            val pageOffset = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                .coerceIn(0f, 1f)
            val scale = if (settings.reducedMotion) 1f else 1f - (pageOffset * 0.035f)
            val pageAlpha = if (settings.reducedMotion) 1f else 1f - (pageOffset * 0.16f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        alpha = pageAlpha
                    }
            ) {
                if (page < missions.size) {
                    MissionCard(
                        mission = missions[page],
                        onStart = { onStartMission(missions[page]) },
                        onManage = { editingIndex = page },
                        reducedMotion = settings.reducedMotion,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                } else {
                    AddMissionCard(
                        onClick = { showAddMission = true },
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 74.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(missions.size + 1) { index ->
                PageDot(active = pagerState.currentPage == index)
            }
        }
    }

    if (showAddMission) {
        AddMissionDialog(
            missionCount = missions.size,
            onDismiss = { showAddMission = false },
            onCreate = { position, mission ->
                onAddMission(position, mission)
                pendingScrollPage = position
                showAddMission = false
            }
        )
    }

    editingIndex?.let { index ->
        if (index in missions.indices) {
            EditMissionDialog(
                mission = missions[index],
                currentIndex = index,
                missionCount = missions.size,
                onDismiss = { editingIndex = null },
                onSave = { newPosition, mission ->
                    onUpdateMission(index, newPosition, mission)
                    pendingScrollPage = newPosition
                    editingIndex = null
                },
                onDelete = {
                    onDeleteMission(index)
                    editingIndex = null
                }
            )
        } else {
            editingIndex = null
        }
    }
}

@Composable
private fun AddMissionCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(150.dp)
            .clickable(onClick = onClick)
            .border(1.dp, Color(0x66D8B55E), androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xC90B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0x22F7C948))
                    .border(1.dp, Color(0x99F7C948), androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
            Spacer(Modifier.height(8.dp))
            Text("Add New Mission", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text("Create a card and choose its position", color = TextSoft, fontSize = 9.sp)
        }
    }
}

@Composable
private fun AddMissionDialog(
    missionCount: Int,
    onDismiss: () -> Unit,
    onCreate: (Int, Mission) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("45") }
    var xp by remember { mutableStateOf("50") }
    var coins by remember { mutableStateOf("20") }
    var position by remember { mutableIntStateOf(missionCount + 1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111923),
        title = {
            Text("Create Mission Card", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Mission title") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = duration,
                        onValueChange = { duration = it.filter(Char::isDigit).take(3) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Minutes") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = xp,
                        onValueChange = { xp = it.filter(Char::isDigit).take(4) },
                        modifier = Modifier.weight(1f),
                        label = { Text("XP") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = coins,
                        onValueChange = { coins = it.filter(Char::isDigit).take(4) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Coins") },
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text("Card position", color = GoldSoft, fontSize = 11.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(38.dp).clickable { position = (position - 1).coerceAtLeast(1) },
                        color = Color(0xFF1A2430),
                        shape = androidx.compose.foundation.shape.CircleShape,
                        border = BorderStroke(1.dp, Color(0x55F1D487))
                    ) { Box(contentAlignment = Alignment.Center) { Text("−", color = Color.White, fontSize = 20.sp) } }
                    Text(
                        "  $position / ${missionCount + 1}  ",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        modifier = Modifier.size(38.dp).clickable { position = (position + 1).coerceAtMost(missionCount + 1) },
                        color = Color(0xFF1A2430),
                        shape = androidx.compose.foundation.shape.CircleShape,
                        border = BorderStroke(1.dp, Color(0x55F1D487))
                    ) { Box(contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 20.sp) } }
                }
                Text(
                    "The new card will be inserted at this position.",
                    color = TextSoft,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val safeTitle = title.trim().ifEmpty { "New Mission" }
                    onCreate(
                        position - 1,
                        Mission(
                            title = safeTitle,
                            durationMinutes = duration.toIntOrNull()?.coerceAtLeast(1) ?: 45,
                            xpReward = xp.toIntOrNull()?.coerceAtLeast(0) ?: 50,
                            coinReward = coins.toIntOrNull()?.coerceAtLeast(0) ?: 20
                        )
                    )
                }
            ) { Text("Create", color = Gold, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSoft) }
        }
    )
}

@Composable
private fun EditMissionDialog(
    mission: Mission,
    currentIndex: Int,
    missionCount: Int,
    onDismiss: () -> Unit,
    onSave: (Int, Mission) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(mission) { mutableStateOf(mission.title) }
    var duration by remember(mission) { mutableStateOf(mission.durationMinutes.toString()) }
    var xp by remember(mission) { mutableStateOf(mission.xpReward.toString()) }
    var coins by remember(mission) { mutableStateOf(mission.coinReward.toString()) }
    var position by remember(mission, currentIndex) { mutableIntStateOf(currentIndex + 1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111923),
        title = {
            Text("Edit Mission", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Mission title") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = duration,
                        onValueChange = { duration = it.filter(Char::isDigit).take(3) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Minutes") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = xp,
                        onValueChange = { xp = it.filter(Char::isDigit).take(4) },
                        modifier = Modifier.weight(1f),
                        label = { Text("XP") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = coins,
                        onValueChange = { coins = it.filter(Char::isDigit).take(4) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Coins") },
                        singleLine = true
                    )
                }

                Spacer(Modifier.height(2.dp))
                Text("Card position", color = GoldSoft, fontSize = 11.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(38.dp).clickable { position = (position - 1).coerceAtLeast(1) },
                        color = Color(0xFF1A2430),
                        shape = androidx.compose.foundation.shape.CircleShape,
                        border = BorderStroke(1.dp, Color(0x55F1D487))
                    ) { Box(contentAlignment = Alignment.Center) { Text("←", color = Color.White, fontSize = 18.sp) } }
                    Text(
                        "  $position / $missionCount  ",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        modifier = Modifier.size(38.dp).clickable { position = (position + 1).coerceAtMost(missionCount.coerceAtLeast(1)) },
                        color = Color(0xFF1A2430),
                        shape = androidx.compose.foundation.shape.CircleShape,
                        border = BorderStroke(1.dp, Color(0x55F1D487))
                    ) { Box(contentAlignment = Alignment.Center) { Text("→", color = Color.White, fontSize = 18.sp) } }
                }
                Text(
                    "Move this card anywhere in the Home carousel.",
                    color = TextSoft,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val safeTitle = title.trim().ifEmpty { "New Mission" }
                    onSave(
                        position - 1,
                        Mission(
                            title = safeTitle,
                            durationMinutes = duration.toIntOrNull()?.coerceAtLeast(1) ?: mission.durationMinutes,
                            xpReward = xp.toIntOrNull()?.coerceAtLeast(0) ?: mission.xpReward,
                            coinReward = coins.toIntOrNull()?.coerceAtLeast(0) ?: mission.coinReward
                        )
                    )
                }
            ) { Text("Save", color = Gold, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDelete) {
                    Text("Delete", color = Color(0xFFFF7A7A), fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSoft)
                }
            }
        }
    )
}

@Composable
private fun HeadlineBlock(quote: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = quote.uppercase(Locale.US),
            color = Color(0xFFF8EFD8),
            textAlign = TextAlign.Center,
            fontSize = 9.6.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 12.sp,
            letterSpacing = 1.1.sp,
            style = androidx.compose.ui.text.TextStyle(
                shadow = Shadow(
                    color = Color(0xFF10151D),
                    offset = Offset(0f, 1.6f),
                    blurRadius = 6f
                )
            ),
            modifier = Modifier.drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(listOf(Color.Transparent, Color(0x12000000), Color.Transparent)),
                    topLeft = Offset(-10.dp.toPx(), -2.dp.toPx()),
                    size = Size(size.width + 20.dp.toPx(), size.height + 4.dp.toPx())
                )
            }
        )
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0x00E9C969), Color(0xA5E8C96D), Color(0xCCEFD98A))
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .padding(horizontal = 7.dp)
                    .size(11.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val diamond = Path().apply {
                        moveTo(size.width * 0.5f, 0f)
                        lineTo(size.width, size.height * 0.5f)
                        lineTo(size.width * 0.5f, size.height)
                        lineTo(0f, size.height * 0.5f)
                        close()
                    }
                    drawPath(diamond, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0B0), Color(0xFFE3BE53))))
                    drawPath(diamond, color = Color(0xFFF9E9B3), style = Stroke(width = 1.dp.toPx()))
                    drawCircle(brush = Brush.radialGradient(listOf(Color(0x70FFF2BF), Color.Transparent)), radius = size.minDimension * 0.55f)
                }
            }
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xCCEFD98A), Color(0xA5E8C96D), Color(0x00E9C969))
                        )
                    )
            )
        }
    }
}

@Composable
private fun PageDot(active: Boolean) {
    Box(
        modifier = Modifier
            .size(if (active) 10.dp else 8.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(if (active) Gold else Color(0xFF5A606D))
    )
}

@Composable
private fun SideWorldButton(type: WorldButtonType, label: String, badge: String? = null) {
    Box {
        Column(
            modifier = Modifier
                .width(44.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .background(Color(0x94090E14))
                .border(0.8.dp, Color(0x34E5C87A), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .padding(vertical = 5.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            WorldButtonIcon(type)
            Text(label, color = Color.White, fontSize = 8.sp, textAlign = TextAlign.Center, lineHeight = 8.sp)
        }
        if (badge != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 1.dp, y = (-2).dp)
                    .size(13.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0xFFEE4B4B)),
                contentAlignment = Alignment.Center
            ) {
                Text(badge, color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun WorldButtonIcon(type: WorldButtonType) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.3.dp.toPx()
        when (type) {
            WorldButtonType.Quest -> {
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.20f, h * 0.18f),
                    size = Size(w * 0.56f, h * 0.56f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawLine(Color(0xFF805A1A), Offset(w * 0.30f, h * 0.34f), Offset(w * 0.64f, h * 0.34f), strokeWidth = stroke)
                drawLine(Color(0xFF805A1A), Offset(w * 0.30f, h * 0.48f), Offset(w * 0.60f, h * 0.48f), strokeWidth = stroke)
                drawLine(Color(0xFF805A1A), Offset(w * 0.28f, h * 0.62f), Offset(w * 0.56f, h * 0.62f), strokeWidth = stroke)
                drawCircle(Color(0xFFD29B42), radius = w * 0.10f, center = Offset(w * 0.24f, h * 0.26f))
                drawCircle(Color(0xFFD29B42), radius = w * 0.10f, center = Offset(w * 0.76f, h * 0.68f))
            }
            WorldButtonType.Map -> {
                val path = Path().apply {
                    moveTo(w * 0.18f, h * 0.68f)
                    lineTo(w * 0.18f, h * 0.26f)
                    lineTo(w * 0.40f, h * 0.18f)
                    lineTo(w * 0.56f, h * 0.30f)
                    lineTo(w * 0.78f, h * 0.22f)
                    lineTo(w * 0.78f, h * 0.64f)
                    lineTo(w * 0.56f, h * 0.72f)
                    lineTo(w * 0.40f, h * 0.60f)
                    close()
                }
                drawPath(path, color = Color(0xFFE8C06A))
                drawLine(Color(0xFF815A17), Offset(w * 0.40f, h * 0.19f), Offset(w * 0.40f, h * 0.60f), strokeWidth = stroke)
                drawLine(Color(0xFF815A17), Offset(w * 0.56f, h * 0.30f), Offset(w * 0.56f, h * 0.71f), strokeWidth = stroke)
                drawCircle(Color(0xFFB53A31), radius = w * 0.09f, center = Offset(w * 0.54f, h * 0.42f))
            }
            WorldButtonType.Inbox -> {
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.16f, h * 0.28f),
                    size = Size(w * 0.68f, h * 0.40f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawLine(Color(0xFF7B5414), Offset(w * 0.18f, h * 0.30f), Offset(w * 0.50f, h * 0.52f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.82f, h * 0.30f), Offset(w * 0.50f, h * 0.52f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.18f, h * 0.67f), Offset(w * 0.40f, h * 0.48f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.82f, h * 0.67f), Offset(w * 0.60f, h * 0.48f), strokeWidth = stroke)
            }
            WorldButtonType.Shop -> {
                drawRoundRect(
                    color = Color(0xFFB86A2F),
                    topLeft = Offset(w * 0.18f, h * 0.34f),
                    size = Size(w * 0.64f, h * 0.34f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.14f, h * 0.22f),
                    size = Size(w * 0.72f, h * 0.20f),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
                drawLine(Color(0xFF7B3E11), Offset(w * 0.50f, h * 0.22f), Offset(w * 0.50f, h * 0.68f), strokeWidth = stroke)
                drawRoundRect(
                    color = Color(0xFFF7D883),
                    topLeft = Offset(w * 0.44f, h * 0.42f),
                    size = Size(w * 0.12f, h * 0.12f),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun MissionCard(
    mission: Mission,
    onStart: () -> Unit,
    onManage: () -> Unit,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    val startScale = if (reducedMotion) {
        1f
    } else {
        val transition = rememberInfiniteTransition(label = "start-button-pulse")
        val pulse by transition.animateFloat(
            initialValue = 0.996f,
            targetValue = 1.012f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 900),
                repeatMode = RepeatMode.Reverse
            ),
            label = "start-button-scale"
        )
        pulse
    }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x66D8B55E), androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xD80B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xDE0D1420), Color(0xD30A1017))))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    mission.title,
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 30.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Reward("★  +${mission.xpReward} XP", Gold, fontSize = 10.5.sp)
                    Spacer(Modifier.width(14.dp))
                    Reward("◉  +${mission.coinReward} سکه", Color.White, fontSize = 10.5.sp)
                    Spacer(Modifier.width(14.dp))
                    Reward("⏱  ${mission.durationMinutes} min", TextSoft, fontSize = 10.5.sp)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .drawBehind {
                            drawRoundRect(
                                color = Gold.copy(alpha = if (reducedMotion) 0.10f else 0.18f),
                                cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                            )
                        }
                        .padding(1.5.dp)
                ) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = startScale; scaleY = startScale },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                    ) {
                        Text("▶   Start Mission", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 8.dp, end = 10.dp)
                    .size(34.dp)
                    .clickable(onClick = onManage),
                color = Color(0x401A2430),
                shape = androidx.compose.foundation.shape.CircleShape,
                border = BorderStroke(1.dp, Color(0x44F1D487))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("⋮", color = GoldSoft, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun TopGameHud(player: PlayerState) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(21.dp))
                .background(Brush.verticalGradient(listOf(Color(0xBC101722), Color(0xA7080D14))))
                .drawBehind {
                    val stroke = 1.2.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xAAEED68A), Color(0xAAAF7A1E), Color(0xAAF1D57D), Color(0xAA996716))
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(Color(0x12FFF4C8), Color.Transparent, Color(0x0AFFF4C8))),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 3.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1.68f), verticalAlignment = Alignment.CenterVertically) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        XpBar(progress)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP",
                            color = Color(0xFFE8EBEF),
                            fontSize = 8.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.16f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text("Rank ${player.rank}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 11.sp)
                        Text(rankTier.title, color = rankTier.secondary, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.00f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(formatNumber(player.coins), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Today", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(0.82f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    FlameBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(player.combo.toString(), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Combo", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(41.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f
            drawCircle(brush = Brush.sweepGradient(tier.ringColors), radius = radius, style = Stroke(width = stroke))
            drawCircle(color = Color(0xFF10141B), radius = size.minDimension * 0.36f)
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )
            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                drawCircle(
                    color = GoldSoft,
                    radius = dotR,
                    center = Offset(cx + cos(rad).toFloat() * ringR, cy + sin(rad).toFloat() * ringR)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
            .background(Color(0xFF242B34))
            .border(1.dp, Color(0x805E4A20), androidx.compose.foundation.shape.RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

private fun DrawScope.starPath(center: Offset, outerRadius: Float, innerRadius: Float, points: Int = 5): Path {
    val path = Path()
    val angle = Math.PI / points
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val theta = i * angle - Math.PI / 2
        val x = center.x + cos(theta).toFloat() * r
        val y = center.y + sin(theta).toFloat() * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                lineTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.80f, h * 0.66f)
                quadraticBezierTo(w * 0.66f, h * 0.87f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.87f, w * 0.20f, h * 0.66f)
                lineTo(w * 0.14f, h * 0.18f)
                close()
            }
            drawPath(shield, brush = Brush.verticalGradient(listOf(tier.secondary.copy(alpha = 0.18f), tier.primary)))
            drawPath(shield, color = tier.secondary, style = Stroke(width = 1.6f))
            val inner = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.77f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.61f)
                quadraticBezierTo(w * 0.61f, h * 0.77f, w * 0.50f, h * 0.83f)
                quadraticBezierTo(w * 0.39f, h * 0.77f, w * 0.28f, h * 0.61f)
                lineTo(w * 0.23f, h * 0.24f)
                close()
            }
            drawPath(inner, color = Color(0x14FFFFFF))
            val star = starPath(Offset(w * 0.50f, h * 0.44f), outerRadius = w * 0.17f, innerRadius = w * 0.07f)
            drawPath(star, color = GoldSoft)
        }
    }
}

@Composable
private fun CoinBadge() {
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFF0B5), Color(0xFFF5C84F), Color(0xFFC88715))),
                radius = size.minDimension / 2f,
                center = center
            )
            drawCircle(color = Color(0x30FFFFFF), radius = size.minDimension * 0.34f, center = Offset(center.x, center.y - 1.dp.toPx()))
            drawCircle(color = Color(0xB9784B0A), radius = size.minDimension / 2f - 0.6.dp.toPx(), center = center, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(color = Color(0xFFFCE9A7), radius = size.minDimension / 2f - 1.4.dp.toPx(), center = center, style = Stroke(width = 0.8.dp.toPx()))
            val star = starPath(center, outerRadius = size.minDimension * 0.18f, innerRadius = size.minDimension * 0.08f)
            drawPath(star, color = Color(0xFF7A4E00))
        }
    }
}

@Composable
private fun FlameBadge() {
    Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))))
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(inner, brush = Brush.verticalGradient(listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))))
        }
    }
}

@Composable
private fun HudDivider() {
    Box(Modifier.width(1.dp).height(31.dp).background(Divider))
}

@Composable
private fun Reward(text: String, color: Color, fontSize: TextUnit = 12.5.sp) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = fontSize)
}
