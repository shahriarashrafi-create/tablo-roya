package com.shahriar.gamify

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDate
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private const val KEY_TREE_STATE = "tree_state_v1"
private const val TREE_SNAPSHOT_LIMIT = 180

private data class TreeTodo(
    val id: String,
    val text: String,
    val done: Boolean = false
)

private data class TreeContact(
    val id: String,
    val name: String
)

private data class TreeAction(
    val id: String,
    val type: String,
    val prospectName: String,
    val date: String,
    val result: String = "",
    val nextAction: String = "",
    val nextDate: String = ""
)

private data class TreePerson(
    val id: String,
    val name: String,
    val parentId: String?,
    val pv: Int = 0,
    val gpv: Int = 0,
    val active: Int = 0,
    val targetPv: Int = 0,
    val targetGpv: Int = 0,
    val targetActive: Int = 0,
    val status: String = "",
    val nextAction: String = "",
    val notes: String = "",
    val todos: List<TreeTodo> = emptyList(),
    val contacts: List<TreeContact> = emptyList(),
    val actions: List<TreeAction> = emptyList()
)

private data class TreeSnapshot(
    val key: String,
    val label: String,
    val people: List<TreePerson>
)

private data class TreeState(
    val people: List<TreePerson>,
    val snapshots: List<TreeSnapshot> = emptyList(),
    val closedIds: Set<String> = emptySet(),
    val zoom: Float = 1f
)

private enum class TreeSection(val title: String) {
    Entry("PV / GPV"),
    Today("امروز"),
    Tree("درختواره"),
    Compare("مقایسه"),
    Ranking("رنکینگ")
}

private enum class RankMode(val title: String) {
    Pv("PV"), Gpv("GPV"), Members("اعضا"), Actions("اقدامات")
}


private data class JalaliDate(val year: Int, val month: Int, val day: Int)

private val jalaliMonthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

private fun gregorianToJalali(date: LocalDate): JalaliDate {
    var gy = date.year - 1600
    val gm = date.monthValue - 1
    val gd = date.dayOfMonth - 1
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
    for (i in 0 until gm) gDayNo += gDays[i]
    val originalYear = date.year
    val isGregorianLeap = originalYear % 400 == 0 || (originalYear % 4 == 0 && originalYear % 100 != 0)
    if (gm > 1 && isGregorianLeap) gDayNo++
    gDayNo += gd

    var jDayNo = gDayNo - 79
    val jNp = jDayNo / 12053
    jDayNo %= 12053
    var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
    jDayNo %= 1461
    if (jDayNo >= 366) {
        jy += (jDayNo - 1) / 365
        jDayNo = (jDayNo - 1) % 365
    }
    var jm = 0
    while (jm < 11 && jDayNo >= jDays[jm]) {
        jDayNo -= jDays[jm]
        jm++
    }
    return JalaliDate(jy, jm + 1, jDayNo + 1)
}

private fun jalaliToGregorian(date: JalaliDate): LocalDate {
    var jy = date.year - 979
    val jm = date.month - 1
    val jd = date.day - 1
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

    var jDayNo = 365 * jy + (jy / 33) * 8 + ((jy % 33 + 3) / 4)
    for (i in 0 until jm) jDayNo += jDays[i]
    jDayNo += jd

    var gDayNo = jDayNo + 79
    var gy = 1600 + 400 * (gDayNo / 146097)
    gDayNo %= 146097
    var leap = true
    if (gDayNo >= 36525) {
        gDayNo--
        gy += 100 * (gDayNo / 36524)
        gDayNo %= 36524
        if (gDayNo >= 365) gDayNo++ else leap = false
    }
    gy += 4 * (gDayNo / 1461)
    gDayNo %= 1461
    if (gDayNo >= 366) {
        leap = false
        gDayNo--
        gy += gDayNo / 365
        gDayNo %= 365
    }

    var gm = 0
    while (gm < 12) {
        val monthDays = gDays[gm] + if (gm == 1 && leap) 1 else 0
        if (gDayNo < monthDays) break
        gDayNo -= monthDays
        gm++
    }
    return LocalDate.of(gy, gm + 1, gDayNo + 1)
}

private fun isJalaliLeap(year: Int): Boolean = runCatching {
    val g = jalaliToGregorian(JalaliDate(year, 12, 30))
    gregorianToJalali(g) == JalaliDate(year, 12, 30)
}.getOrDefault(false)

private fun jalaliMonthLength(year: Int, month: Int): Int = when {
    month <= 6 -> 31
    month <= 11 -> 30
    isJalaliLeap(year) -> 30
    else -> 29
}

private fun jalaliLabel(date: LocalDate): String {
    val j = gregorianToJalali(date)
    return String.format(Locale.US, "%04d/%02d/%02d", j.year, j.month, j.day)
}

private fun jalaliLabelFromKey(key: String): String = runCatching {
    jalaliLabel(LocalDate.parse(key))
}.getOrElse { key }

private fun persianDigits(text: String): String {
    val latin = "0123456789"
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    return buildString(text.length) {
        text.forEach { ch -> append(if (ch in latin) persian[latin.indexOf(ch)] else ch) }
    }
}

private fun initialTreeState(context: Context): TreeState {
    val profileName = runCatching { loadOnboardingProfile(context).name.trim() }.getOrDefault("")
    val rootName = profileName.takeIf { it.isNotBlank() && !it.equals("Player", ignoreCase = true) } ?: "شهریار"
    return TreeState(
        people = listOf(
            TreePerson(
                id = UUID.randomUUID().toString(),
                name = rootName,
                parentId = null
            )
        )
    )
}

private fun todoToJson(todo: TreeTodo) = JSONObject()
    .put("id", todo.id)
    .put("text", todo.text)
    .put("done", todo.done)

private fun contactToJson(contact: TreeContact) = JSONObject()
    .put("id", contact.id)
    .put("name", contact.name)

private fun actionToJson(action: TreeAction) = JSONObject()
    .put("id", action.id)
    .put("type", action.type)
    .put("prospectName", action.prospectName)
    .put("date", action.date)
    .put("result", action.result)
    .put("nextAction", action.nextAction)
    .put("nextDate", action.nextDate)

private fun personToJson(person: TreePerson): JSONObject {
    val todos = JSONArray().also { array -> person.todos.forEach { array.put(todoToJson(it)) } }
    val contacts = JSONArray().also { array -> person.contacts.forEach { array.put(contactToJson(it)) } }
    val actions = JSONArray().also { array -> person.actions.forEach { array.put(actionToJson(it)) } }
    return JSONObject()
        .put("id", person.id)
        .put("name", person.name)
        .put("parentId", person.parentId ?: JSONObject.NULL)
        .put("pv", person.pv)
        .put("gpv", person.gpv)
        .put("active", person.active)
        .put("targetPv", person.targetPv)
        .put("targetGpv", person.targetGpv)
        .put("targetActive", person.targetActive)
        .put("status", person.status)
        .put("nextAction", person.nextAction)
        .put("notes", person.notes)
        .put("todos", todos)
        .put("contacts", contacts)
        .put("actions", actions)
}

private fun peopleToJson(people: List<TreePerson>) = JSONArray().also { array ->
    people.forEach { array.put(personToJson(it)) }
}

private fun snapshotToJson(snapshot: TreeSnapshot) = JSONObject()
    .put("key", snapshot.key)
    .put("label", snapshot.label)
    .put("people", peopleToJson(snapshot.people))

private fun treeStateToJson(state: TreeState): String {
    val snapshots = JSONArray().also { array -> state.snapshots.forEach { array.put(snapshotToJson(it)) } }
    val closed = JSONArray().also { array -> state.closedIds.forEach { array.put(it) } }
    return JSONObject()
        .put("formatVersion", 1)
        .put("people", peopleToJson(state.people))
        .put("snapshots", snapshots)
        .put("closedIds", closed)
        .put("zoom", state.zoom.toDouble())
        .toString()
}

private fun parseTodos(array: JSONArray?): List<TreeTodo> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val text = obj.optString("text").trim()
        if (text.isBlank()) continue
        add(TreeTodo(obj.optString("id").ifBlank { UUID.randomUUID().toString() }, text, obj.optBoolean("done", false)))
    }
}

private fun parseContacts(array: JSONArray?): List<TreeContact> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val name = obj.optString("name").trim()
        if (name.isBlank()) continue
        add(TreeContact(obj.optString("id").ifBlank { UUID.randomUUID().toString() }, name))
    }
}

private fun parseActions(array: JSONArray?): List<TreeAction> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        add(
            TreeAction(
                id = obj.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = obj.optString("type", "ارتباط‌سازی").ifBlank { "ارتباط‌سازی" },
                prospectName = obj.optString("prospectName"),
                date = obj.optString("date").ifBlank { LocalDate.now().toString() },
                result = obj.optString("result"),
                nextAction = obj.optString("nextAction", obj.optString("result")),
                nextDate = obj.optString("nextDate")
            )
        )
    }
}

private fun parsePeople(array: JSONArray?): List<TreePerson> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val obj = array.optJSONObject(i) ?: continue
        val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
        val parent = if (obj.isNull("parentId")) null else obj.optString("parentId").takeIf { it.isNotBlank() }
        add(
            TreePerson(
                id = id,
                name = obj.optString("name").trim().ifBlank { "بدون نام" },
                parentId = parent,
                pv = obj.optInt("pv", obj.optInt("sales", 0)).coerceAtLeast(0),
                gpv = obj.optInt("gpv", 0).coerceAtLeast(0),
                active = obj.optInt("active", 0).coerceAtLeast(0),
                targetPv = obj.optInt("targetPv", 0).coerceAtLeast(0),
                targetGpv = obj.optInt("targetGpv", obj.optInt("target", 0)).coerceAtLeast(0),
                targetActive = obj.optInt("targetActive", 0).coerceAtLeast(0),
                status = obj.optString("status"),
                nextAction = obj.optString("nextAction", obj.optString("next")),
                notes = obj.optString("notes"),
                todos = parseTodos(obj.optJSONArray("todos")),
                contacts = parseContacts(obj.optJSONArray("contacts")),
                actions = parseActions(obj.optJSONArray("actions") ?: obj.optJSONArray("network"))
            )
        )
    }
}

private fun normalizeTreeState(context: Context, raw: TreeState): TreeState {
    val base = raw.people.ifEmpty { initialTreeState(context).people }.distinctBy { it.id }
    val ids = base.map { it.id }.toSet()
    val rootId = base.firstOrNull { it.parentId == null || it.parentId !in ids }?.id ?: base.first().id

    val provisional = base.map { person ->
        val contacts = if (person.contacts.isEmpty()) {
            person.actions.map { it.prospectName.trim() }
                .filter { it.isNotBlank() }
                .distinctBy { it.lowercase(Locale.getDefault()) }
                .map { TreeContact(UUID.randomUUID().toString(), it) }
        } else person.contacts
        person.copy(
            parentId = if (person.id == rootId) null else person.parentId?.takeIf { it in ids && it != person.id } ?: rootId,
            contacts = contacts.distinctBy { it.name.trim().lowercase(Locale.getDefault()) },
            actions = person.actions.distinctBy { it.id }
        )
    }

    // Backups or old builds can theoretically contain a cyclic sponsor chain.
    // Break any cycle at load time so tree traversal and descendant counting can
    // never recurse forever.
    val byId = provisional.associateBy { it.id }
    val normalizedPeople = provisional.map { person ->
        if (person.id == rootId) return@map person.copy(parentId = null)
        var currentId: String? = person.id
        val seen = mutableSetOf<String>()
        var cycleFound = false
        while (currentId != null) {
            if (!seen.add(currentId)) {
                cycleFound = true
                break
            }
            currentId = byId[currentId]?.parentId
        }
        if (cycleFound) person.copy(parentId = rootId) else person
    }

    val validIds = normalizedPeople.map { it.id }.toSet()
    return raw.copy(
        people = normalizedPeople,
        snapshots = raw.snapshots.distinctBy { it.key }.sortedByDescending { it.key }.take(TREE_SNAPSHOT_LIMIT),
        closedIds = raw.closedIds.filterTo(mutableSetOf()) { it in validIds },
        zoom = raw.zoom.coerceIn(0.2f, 1.8f)
    )
}

private fun loadTreeState(context: Context): TreeState {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TREE_STATE, null)
        ?: return initialTreeState(context)
    return runCatching {
        val root = JSONObject(raw)
        val people = parsePeople(root.optJSONArray("people"))
        val snapshots = buildList {
            val array = root.optJSONArray("snapshots")
            if (array != null) for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val key = obj.optString("key")
                if (key.isBlank()) continue
                add(TreeSnapshot(key, obj.optString("label", key), parsePeople(obj.optJSONArray("people"))))
            }
        }
        val closed = buildSet {
            val array = root.optJSONArray("closedIds")
            if (array != null) for (i in 0 until array.length()) add(array.optString(i))
        }
        normalizeTreeState(context, TreeState(people, snapshots, closed, root.optDouble("zoom", 1.0).toFloat()))
    }.getOrElse { initialTreeState(context) }
}

private fun captureToday(state: TreeState): TreeState {
    val key = LocalDate.now().toString()
    val snapshot = TreeSnapshot(key = key, label = jalaliLabel(LocalDate.now()), people = state.people)
    val snapshots = (listOf(snapshot) + state.snapshots.filterNot { it.key == key })
        .sortedByDescending { it.key }
        .take(TREE_SNAPSHOT_LIMIT)
    return state.copy(snapshots = snapshots)
}

private fun persistTreeState(context: Context, state: TreeState, captureDaily: Boolean = true): TreeState {
    val normalized = normalizeTreeState(context, if (captureDaily) captureToday(state) else state)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_TREE_STATE, treeStateToJson(normalized))
        .apply()
    return normalized
}

private fun formatTreeNumber(value: Int): String = if (value == 0) "—" else String.format(Locale.US, "%,d", value)
private fun formatTreeInput(value: Int): String = if (value == 0) "" else String.format(Locale.US, "%,d", value)
private fun parseTreeNumber(text: String): Int = text.filter { it.isDigit() }.toLongOrNull()?.coerceIn(0, Int.MAX_VALUE.toLong())?.toInt() ?: 0
private fun formatTypedNumber(text: String): String = parseTreeNumber(text).let { if (it == 0 && text.none { ch -> ch.isDigit() }) "" else String.format(Locale.US, "%,d", it) }

private fun childrenOf(people: List<TreePerson>, id: String): List<TreePerson> = people.filter { it.parentId == id }
private fun rootPerson(people: List<TreePerson>): TreePerson? = people.firstOrNull { it.parentId == null } ?: people.firstOrNull()
private fun descendantCount(people: List<TreePerson>, id: String): Int {
    val children = childrenOf(people, id)
    return children.size + children.sumOf { descendantCount(people, it.id) }
}

private fun descendantIds(people: List<TreePerson>, id: String): Set<String> = buildSet {
    fun collect(parentId: String) {
        childrenOf(people, parentId).forEach { child ->
            if (add(child.id)) collect(child.id)
        }
    }
    collect(id)
}

private fun ancestorIds(people: List<TreePerson>, id: String): Set<String> = buildSet {
    var current = people.firstOrNull { it.id == id }
    val seen = mutableSetOf<String>()
    while (current?.parentId != null) {
        val parentId = current.parentId ?: break
        if (!seen.add(parentId)) break
        add(parentId)
        current = people.firstOrNull { it.id == parentId }
    }
}

private fun reorderSibling(people: List<TreePerson>, personId: String, delta: Int): List<TreePerson> {
    val person = people.firstOrNull { it.id == personId } ?: return people
    val siblings = people.filter { it.parentId == person.parentId }
    val currentIndex = siblings.indexOfFirst { it.id == personId }
    val target = siblings.getOrNull(currentIndex + delta) ?: return people
    val fromIndex = people.indexOfFirst { it.id == personId }
    val toIndex = people.indexOfFirst { it.id == target.id }
    if (fromIndex < 0 || toIndex < 0) return people
    return people.toMutableList().also { list ->
        val tmp = list[fromIndex]
        list[fromIndex] = list[toIndex]
        list[toIndex] = tmp
    }
}

@Composable
internal fun TreeDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current.applicationContext
    var state by remember { mutableStateOf(persistTreeState(context, loadTreeState(context), captureDaily = true)) }
    var section by remember { mutableStateOf(TreeSection.Entry) }
    var directParent by remember { mutableStateOf<TreePerson?>(null) }
    var editingPerson by remember { mutableStateOf<TreePerson?>(null) }
    var todoPerson by remember { mutableStateOf<TreePerson?>(null) }
    var actionsPerson by remember { mutableStateOf<TreePerson?>(null) }
    var transferPerson by remember { mutableStateOf<TreePerson?>(null) }
    var focusPersonId by remember { mutableStateOf<String?>(null) }
    var focusRequest by remember { mutableStateOf(0) }
    var resetMonthConfirm by remember { mutableStateOf(false) }

    fun commit(updated: TreeState, captureDaily: Boolean = true) {
        state = persistTreeState(context, updated, captureDaily)
    }

    fun updatePerson(updated: TreePerson) {
        commit(state.copy(people = state.people.map { if (it.id == updated.id) updated else it }))
    }

    val hasChildDialog = directParent != null || editingPerson != null || todoPerson != null ||
        actionsPerson != null || transferPerson != null || resetMonthConfirm

    // One back closes the current tree sub-page first. A second back returns
    // from the tree module to the game home. Child dialogs keep their own back.
    BackHandler(enabled = !hasChildDialog) {
        if (section != TreeSection.Entry) section = TreeSection.Entry else onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF07101B), Color(0xFF0D1724), Color(0xFF070B12))
                        )
                    )
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(Color(0x12F7C948), radius = size.width * 0.60f, center = Offset(size.width * 0.12f, size.height * 0.16f))
                    drawCircle(Color(0x0D5CA3FF), radius = size.width * 0.75f, center = Offset(size.width * 0.94f, size.height * 0.56f))
                }
                Column(Modifier.fillMaxSize()) {
                    TreeHeader(
                        state = state,
                        onBack = {
                            if (section != TreeSection.Entry) section = TreeSection.Entry else onDismiss()
                        },
                        onMonthlyReset = { resetMonthConfirm = true }
                    )
                    TreeTabs(section = section, onSelect = { section = it })
                    when (section) {
                        TreeSection.Entry -> TreeEntryScreen(
                            state = state,
                            onSavePerson = ::updatePerson,
                            onAddDirect = { directParent = it },
                            onTodos = { todoPerson = it },
                            onActions = { actionsPerson = it },
                            onEdit = { editingPerson = it },
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Today -> TreeTodayScreen(
                            state = state,
                            onPersonClick = { editingPerson = it },
                            onActions = { actionsPerson = it },
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Tree -> TreeGraphScreen(
                            state = state,
                            onPersonClick = { editingPerson = it },
                            onStateViewChange = { zoom, closed -> commit(state.copy(zoom = zoom, closedIds = closed), captureDaily = false) },
                            focusPersonId = focusPersonId,
                            focusRequest = focusRequest,
                            modifier = Modifier.weight(1f)
                        )
                        TreeSection.Compare -> TreeCompareScreen(state = state, modifier = Modifier.weight(1f))
                        TreeSection.Ranking -> TreeRankingScreen(
                            state = state,
                            onPersonClick = { editingPerson = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    directParent?.let { parent ->
        AddDirectDialog(
            parent = parent,
            onDismiss = { directParent = null },
            onAdd = { name ->
                val newPerson = TreePerson(UUID.randomUUID().toString(), name.trim(), parent.id)
                commit(state.copy(people = state.people + newPerson))
                directParent = null
            }
        )
    }
    editingPerson?.let { person ->
        val currentPerson = state.people.firstOrNull { it.id == person.id } ?: person
        val siblings = state.people.filter { it.parentId == currentPerson.parentId }
        val siblingIndex = siblings.indexOfFirst { it.id == currentPerson.id }
        EditTreePersonDialog(
            person = currentPerson,
            canDelete = currentPerson.parentId != null,
            canMoveUp = currentPerson.parentId != null && siblingIndex > 0,
            canMoveDown = currentPerson.parentId != null && siblingIndex >= 0 && siblingIndex < siblings.lastIndex,
            directCount = childrenOf(state.people, currentPerson.id).size,
            organizationCount = descendantCount(state.people, currentPerson.id),
            onDismiss = { editingPerson = null },
            onAddDirect = {
                directParent = state.people.firstOrNull { p -> p.id == person.id }
                editingPerson = null
            },
            onTodos = {
                todoPerson = state.people.firstOrNull { p -> p.id == person.id }
                editingPerson = null
            },
            onActions = {
                actionsPerson = state.people.firstOrNull { p -> p.id == currentPerson.id }
                editingPerson = null
            },
            onLocate = {
                focusPersonId = currentPerson.id
                focusRequest += 1
                section = TreeSection.Tree
                editingPerson = null
            },
            onTransfer = {
                transferPerson = currentPerson
                editingPerson = null
            },
            onMoveUp = {
                commit(state.copy(people = reorderSibling(state.people, currentPerson.id, -1)))
                editingPerson = state.people.firstOrNull { it.id == currentPerson.id }
            },
            onMoveDown = {
                commit(state.copy(people = reorderSibling(state.people, currentPerson.id, 1)))
                editingPerson = state.people.firstOrNull { it.id == currentPerson.id }
            },
            onSave = { updated -> updatePerson(updated); editingPerson = null },
            onDelete = {
                val removeIds = mutableSetOf<String>()
                fun collect(id: String) {
                    removeIds += id
                    childrenOf(state.people, id).forEach { collect(it.id) }
                }
                collect(person.id)
                commit(
                    state.copy(
                        people = state.people.filterNot { it.id in removeIds },
                        closedIds = state.closedIds - removeIds
                    )
                )
                if (focusPersonId in removeIds) focusPersonId = null
                directParent = directParent?.takeUnless { it.id in removeIds }
                todoPerson = todoPerson?.takeUnless { it.id in removeIds }
                actionsPerson = actionsPerson?.takeUnless { it.id in removeIds }
                transferPerson = transferPerson?.takeUnless { it.id in removeIds }
                editingPerson = null
            }
        )
    }
    transferPerson?.let { person ->
        val current = state.people.firstOrNull { it.id == person.id } ?: person
        TransferSponsorDialog(
            person = current,
            people = state.people,
            onDismiss = { transferPerson = null },
            onTransfer = { sponsorId ->
                val updated = current.copy(parentId = sponsorId)
                val remaining = state.people.filterNot { it.id == current.id }
                commit(state.copy(people = remaining + updated, closedIds = state.closedIds - sponsorId))
                focusPersonId = current.id
                focusRequest += 1
                section = TreeSection.Tree
                transferPerson = null
            }
        )
    }
    todoPerson?.let { person ->
        TodoDialog(
            person = state.people.firstOrNull { it.id == person.id } ?: person,
            onDismiss = { todoPerson = null },
            onUpdate = { updatePerson(it); todoPerson = it }
        )
    }
    actionsPerson?.let { person ->
        ActionsDialog(
            person = state.people.firstOrNull { it.id == person.id } ?: person,
            allPeople = state.people,
            onDismiss = { actionsPerson = null },
            onUpdate = { updatePerson(it); actionsPerson = it }
        )
    }
    if (resetMonthConfirm) {
        AlertDialog(
            onDismissRequest = { resetMonthConfirm = false },
            containerColor = GamifyColors.Surface,
            title = { Text("شروع ماه جدید", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("PV، GPV، تعداد فعال و هدف‌ها صفر شوند؟ ساختار تیم، To Do و اقدامات باقی می‌مانند.", color = TextSoft) },
            confirmButton = {
                TextButton(onClick = {
                    // Save the final numbers of the outgoing month before the
                    // live counters are cleared. The next normal edit will start
                    // building the new month's current-day snapshot.
                    val archived = captureToday(state)
                    val resetState = archived.copy(
                        people = archived.people.map {
                            it.copy(pv = 0, gpv = 0, active = 0, targetPv = 0, targetGpv = 0, targetActive = 0)
                        }
                    )
                    commit(resetState, captureDaily = false)
                    resetMonthConfirm = false
                }) { Text("ریست ماهانه", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { resetMonthConfirm = false }) { Text("لغو", color = TextSoft) } }
        )
    }
}

@Composable
private fun TreeHeader(state: TreeState, onBack: () -> Unit, onMonthlyReset: () -> Unit) {
    val total = rootPerson(state.people)?.gpv ?: 0
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier.size(44.dp).border(1.dp, Color(0x88F7C948), CircleShape).clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { Text("‹", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Light) }
        Column(Modifier.weight(1f)) {
            Text("درختواره", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("${state.people.size} نفر در سازمان", color = TextSoft, fontSize = 10.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("GPV کل", color = TextSoft, fontSize = 9.sp)
            Text(formatTreeNumber(total), color = Gold, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        TextButton(onClick = onMonthlyReset) { Text("ماه جدید", color = GoldSoft, fontSize = 10.sp) }
    }
}

@Composable
private fun TreeTabs(section: TreeSection, onSelect: (TreeSection) -> Unit) {
    val scroll = rememberScrollState()
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(scroll).padding(horizontal = 10.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TreeSection.entries.forEach { item ->
            val active = section == item
            val glyph = when (item) {
                TreeSection.Entry -> "▮▮▮"
                TreeSection.Today -> "◷"
                TreeSection.Tree -> "⎇"
                TreeSection.Compare -> "≍"
                TreeSection.Ranking -> "★"
            }
            Box(
                modifier = Modifier
                    .height(48.dp)
                    .widthIn(min = 108.dp)
                    .background(
                        if (active) Brush.horizontalGradient(listOf(Color(0xFFFFD75A), Color(0xFFF0B82D)))
                        else Brush.horizontalGradient(listOf(Color(0xFF101B29), Color(0xFF0C1520))),
                        RoundedCornerShape(16.dp)
                    )
                    .border(1.dp, if (active) Color(0xFFFFE38A) else Color(0x554E6074), RoundedCornerShape(16.dp))
                    .clickable { onSelect(item) }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(
                            item.title,
                            color = if (active) Color(0xFF241A00) else Color(0xFFD9E0E8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(glyph, color = if (active) Color(0xFF241A00) else Color(0xFFD9E0E8), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    HorizontalDivider(color = Color(0x332E3946))
}

@Composable
private fun TreeTodayScreen(
    state: TreeState,
    onPersonClick: (TreePerson) -> Unit,
    onActions: (TreePerson) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayKey = LocalDate.now().toString()
    val root = rootPerson(state.people)
    val previousSnapshot = state.snapshots
        .filter { it.key < todayKey }
        .maxByOrNull { it.key }
    val previousRoot = previousSnapshot?.people?.let(::rootPerson)
    val gpvDelta = (root?.gpv ?: 0) - (previousRoot?.gpv ?: 0)
    val pvDelta = (root?.pv ?: 0) - (previousRoot?.pv ?: 0)
    val todayActions = state.people.flatMap { owner ->
        owner.actions.filter { it.date == todayKey }.map { owner to it }
    }
    val openTodos = state.people.sumOf { person -> person.todos.count { !it.done } }
    val goalPeople = state.people.filter { person ->
        val progress = treeGoalProgress(person)
        progress != null && progress >= 1f
    }
    val actionTypes = listOf("ارتباط‌سازی", "پیش‌مشاوره", "دعوت", "معرفی کار", "فالوآپ", "ثبت سفارش", "پیگیری")
    val actionCounts = actionTypes.associateWith { type -> todayActions.count { it.second.type == type } }
    val maxActionCount = actionCounts.values.maxOrNull()?.coerceAtLeast(1) ?: 1
    val actionLeaders = todayActions.groupingBy { it.first.id }.eachCount()
        .entries.sortedByDescending { it.value }.take(5)
        .mapNotNull { entry -> state.people.firstOrNull { it.id == entry.key }?.let { it to entry.value } }
    val progressLeaders = state.people.mapNotNull { person ->
        treeGoalProgress(person)?.let { person to it }
    }.sortedByDescending { it.second }.take(5)

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("گزارش امروز", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(jalaliLabel(LocalDate.now()), color = TextSoft, fontSize = 10.sp)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TreeTodayMetricCard("GPV امروز", formatTreeDeltaValue(gpvDelta, previousSnapshot != null), treeTodayTotalCaption(root?.gpv ?: 0, previousSnapshot != null), Modifier.weight(1f))
                TreeTodayMetricCard("PV امروز", formatTreeDeltaValue(pvDelta, previousSnapshot != null), treeTodayTotalCaption(root?.pv ?: 0, previousSnapshot != null), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TreeTodayMetricCard("اقدام امروز", todayActions.size.toString(), "${state.people.size} نفر سازمان", Modifier.weight(1f))
                TreeTodayMetricCard("To Do باز", openTodos.toString(), "${goalPeople.size} نفر به هدف رسیده", Modifier.weight(1f))
            }
        }
        item {
            TreeTodaySectionCard("اقدامات امروز") {
                if (todayActions.isEmpty()) {
                    Text("هنوز اقدامی برای امروز ثبت نشده است.", color = TextSoft, fontSize = 10.sp)
                } else {
                    actionTypes.forEach { type ->
                        val count = actionCounts[type] ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(type, color = Color.White, fontSize = 10.sp, modifier = Modifier.width(82.dp))
                            Box(
                                Modifier.weight(1f).height(8.dp).background(Color(0x552E3946), RoundedCornerShape(20.dp))
                            ) {
                                if (count > 0) {
                                    Box(
                                        Modifier.fillMaxWidth(count.toFloat() / maxActionCount.toFloat())
                                            .height(8.dp)
                                            .background(Brush.horizontalGradient(listOf(Gold, GoldSoft)), RoundedCornerShape(20.dp))
                                    )
                                }
                            }
                            Text(count.toString(), color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp), textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }
        if (actionLeaders.isNotEmpty()) {
            item {
                TreeTodaySectionCard("بیشترین اقدام امروز") {
                    actionLeaders.forEachIndexed { index, (person, count) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onActions(person) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${index + 1}", color = Gold, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(28.dp))
                            Text(person.name, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
                            Text("$count اقدام", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (progressLeaders.isNotEmpty()) {
            item {
                TreeTodaySectionCard("پیشرفت هدف‌ها") {
                    progressLeaders.forEach { (person, progress) ->
                        val pct = (progress * 100f).toInt().coerceAtMost(999)
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onPersonClick(person) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(person.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0x552E3946), RoundedCornerShape(20.dp))) {
                                    Box(
                                        Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).height(6.dp)
                                            .background(if (progress >= 1f) Color(0xFF61D48A) else Gold, RoundedCornerShape(20.dp))
                                    )
                                }
                            }
                            Text("$pct٪", color = if (progress >= 1f) Color(0xFF7CE6A4) else GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

private fun formatTreeDeltaValue(value: Int, hasPrevious: Boolean): String {
    if (!hasPrevious) return formatTreeNumber(value.coerceAtLeast(0))
    return when {
        value > 0 -> "+${formatTreeNumber(value)}"
        value < 0 -> "-${formatTreeNumber(-value)}"
        else -> "0"
    }
}

private fun treeTodayTotalCaption(total: Int, hasPrevious: Boolean): String =
    if (hasPrevious) "کل فعلی: ${formatTreeNumber(total)}" else "اولین ثبت"

private fun treeDeltaCaption(value: Int, hasPrevious: Boolean): String {
    if (!hasPrevious) return "اولین ثبت"
    return when {
        value > 0 -> "+${formatTreeNumber(value)} نسبت به ثبت قبل"
        value < 0 -> "-${formatTreeNumber(-value)} نسبت به ثبت قبل"
        else -> "بدون تغییر نسبت به ثبت قبل"
    }
}

@Composable
private fun TreeTodayMetricCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xB5101822),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.border(1.dp, Color(0x334E5C6C), RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = TextSoft, fontSize = 9.sp)
            Text(value, color = GoldSoft, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Text(caption, color = Color(0xFF8E9CAB), fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun TreeTodaySectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        color = Color(0xA90E1721),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x334E5C6C), RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = GoldSoft, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            content()
        }
    }
}

@Composable
private fun TreeEntryScreen(
    state: TreeState,
    onSavePerson: (TreePerson) -> Unit,
    onAddDirect: (TreePerson) -> Unit,
    onTodos: (TreePerson) -> Unit,
    onActions: (TreePerson) -> Unit,
    onEdit: (TreePerson) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val displayPeople = remember(state.people, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) state.people else state.people.filter { it.name.contains(q, ignoreCase = true) }
    }
    val pagerState = rememberPagerState(pageCount = { displayPeople.size.coerceAtLeast(1) })
    val scope = rememberCoroutineScope()

    LaunchedEffect(searchQuery, displayPeople.size) {
        if (displayPeople.isNotEmpty() && pagerState.currentPage > displayPeople.lastIndex) pagerState.scrollToPage(0)
        if (searchQuery.isNotBlank() && displayPeople.isNotEmpty()) pagerState.scrollToPage(0)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(50) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                placeholder = { Text("جستجوی نام در PV / GPV", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()) },
                leadingIcon = {
                    if (searchQuery.isNotBlank()) Text("×", color = TextSoft, fontSize = 22.sp, modifier = Modifier.clickable { searchQuery = "" }.padding(6.dp))
                },
                trailingIcon = { Text("⌕", color = Gold, fontSize = 20.sp) },
                singleLine = true,
                textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White),
                colors = gamifyTextFieldColors(),
                shape = RoundedCornerShape(16.dp)
            )

            if (state.people.isEmpty()) {
                Text("هنوز فردی ثبت نشده است.", color = TextSoft, modifier = Modifier.padding(30.dp))
                return@Column
            }
            if (displayPeople.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("فردی با این نام پیدا نشد.", color = TextSoft)
                }
                return@Column
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) { page ->
                val person = displayPeople[page]
                TreeEntryCard(
                    person = person,
                    directCount = childrenOf(state.people, person.id).size,
                    organizationCount = descendantCount(state.people, person.id),
                    onSave = { updated ->
                        onSavePerson(updated)
                        if (page < displayPeople.lastIndex) scope.launch { pagerState.animateScrollToPage(page + 1) }
                    },
                    onAddDirect = { onAddDirect(person) },
                    onTodos = { onTodos(person) },
                    onActions = { onActions(person) },
                    onEdit = { onEdit(person) }
                )
            }
            Row(Modifier.padding(bottom = 10.dp, top = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(displayPeople.size) { index ->
                    Box(
                        Modifier
                            .width(if (index == pagerState.currentPage) 22.dp else 7.dp)
                            .height(7.dp)
                            .background(if (index == pagerState.currentPage) Gold else Color(0xFF56616F), RoundedCornerShape(20.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun TreeEntryCard(
    person: TreePerson,
    directCount: Int,
    organizationCount: Int,
    onSave: (TreePerson) -> Unit,
    onAddDirect: () -> Unit,
    onTodos: () -> Unit,
    onActions: () -> Unit,
    onEdit: () -> Unit
) {
    var pv by remember(person.id, person.pv) { mutableStateOf(formatTreeInput(person.pv)) }
    var gpv by remember(person.id, person.gpv) { mutableStateOf(formatTreeInput(person.gpv)) }
    var active by remember(person.id, person.active) { mutableStateOf(if (person.active == 0) "" else person.active.toString()) }
    val openTodos = person.todos.count { !it.done }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Surface(
                    color = Color(0xE60A1420),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().border(1.3.dp, Color(0xA6EBC95F), RoundedCornerShape(28.dp))
                ) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("⋯", color = GoldSoft, fontSize = 26.sp, modifier = Modifier.clickable(onClick = onEdit).padding(top = 2.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(person.name, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                Box(
                                    modifier = Modifier.size(82.dp)
                                        .background(Color(0xFF091522), CircleShape)
                                        .border(2.dp, Color(0xFFE7C45A), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("♛", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                            TreeMetricInputCard("PV", "♛", pv, { pv = formatTypedNumber(it) }, Modifier.weight(1f))
                            TreeMetricInputCard("GPV", "▮▮▮", gpv, { gpv = formatTypedNumber(it) }, Modifier.weight(1.35f))
                            TreeMetricInputCard("تعداد", "◉", active, { active = it.filter(Char::isDigit).take(5) }, Modifier.weight(0.8f))
                        }

                        TreeActionButton("لیست افراد و اقدامات", "◉", onActions)
                        TreeActionButton("اضافه کردن دایرکت", "＋", onAddDirect)
                        TreeActionButton(if (openTodos > 0) "To Do List  •  $openTodos" else "To Do List", "✓", onTodos)
                        Button(
                            onClick = { onSave(person.copy(pv = parseTreeNumber(pv), gpv = parseTreeNumber(gpv), active = parseTreeNumber(active))) },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                            shape = RoundedCornerShape(16.dp)
                        ) { Text("ذخیره اطلاعات ${person.name}", fontWeight = FontWeight.ExtraBold) }
                    }
                }
            }
            item {
                Surface(color = Color(0x99101924), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                        TreeMiniMetric("PV هدف", formatTreeNumber(person.targetPv))
                        TreeMiniMetric("GPV هدف", formatTreeNumber(person.targetGpv))
                        TreeMiniMetric("اقدامات", person.actions.size.toString())
                        TreeMiniMetric("دایرکت", directCount.toString())
                        TreeMiniMetric("سازمان", organizationCount.toString())
                    }
                }
            }
        }
    }
}

@Composable
private fun TreeMetricInputCard(
    label: String,
    glyph: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.border(1.dp, Color(0x44566A7F), RoundedCornerShape(17.dp)),
        color = Color(0xAA101B28),
        shape = RoundedCornerShape(17.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.size(28.dp).background(Color(0x332D3947), CircleShape), contentAlignment = Alignment.Center) {
                    Text(glyph, color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            OutlinedTextField(
                value = value,
                onValueChange = onChange,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = TextStyle(textAlign = TextAlign.Center, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp),
                colors = gamifyTextFieldColors(),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
private fun TreeNumericField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = gamifyTextFieldColors(),
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun TreeActionButton(text: String, glyph: String, onClick: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
        ) {
            Text(text, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
            Spacer(Modifier.width(8.dp))
            Text(glyph, color = Gold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun TreeMiniMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextSoft, fontSize = 8.sp)
        Text(value, color = GoldSoft, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

private data class GraphNode(val person: TreePerson, val center: Offset, val root: Boolean)
private data class GraphEdge(val fromId: String, val toId: String, val from: Offset, val to: Offset)
private data class GraphLayout(val nodes: List<GraphNode>, val edges: List<GraphEdge>, val width: Float, val height: Float)

private fun buildGraphLayout(
    people: List<TreePerson>,
    closed: Set<String>,
    nodeDiameter: Float,
    xGap: Float,
    yGap: Float
): GraphLayout {
    val roots = people.filter { it.parentId == null || people.none { p -> p.id == it.parentId } }.ifEmpty { people.take(1) }
    val widthCache = mutableMapOf<String, Float>()
    fun visibleChildren(id: String): List<TreePerson> = if (id in closed) emptyList() else childrenOf(people, id)
    fun subtreeWidth(person: TreePerson): Float {
        return widthCache.getOrPut(person.id) {
            val children = visibleChildren(person.id)
            if (children.isEmpty()) nodeDiameter else max(nodeDiameter, children.sumOf { subtreeWidth(it).toDouble() }.toFloat() + xGap * (children.size - 1).coerceAtLeast(0))
        }
    }
    val totalWidth = max(nodeDiameter, roots.sumOf { subtreeWidth(it).toDouble() }.toFloat() + xGap * (roots.size - 1).coerceAtLeast(0))
    val nodes = mutableListOf<GraphNode>()
    val edges = mutableListOf<GraphEdge>()
    var maxY = nodeDiameter
    fun place(person: TreePerson, left: Float, level: Int): Offset {
        val ownWidth = subtreeWidth(person)
        val center = Offset(left + ownWidth / 2f, nodeDiameter / 2f + level * (nodeDiameter + yGap))
        nodes += GraphNode(person, center, person.parentId == null)
        maxY = max(maxY, center.y + nodeDiameter / 2f)
        val children = visibleChildren(person.id)
        if (children.isNotEmpty()) {
            var childLeft = left
            children.forEach { child ->
                val childWidth = subtreeWidth(child)
                val childCenter = place(child, childLeft, level + 1)
                edges += GraphEdge(person.id, child.id, Offset(center.x, center.y + nodeDiameter / 2f), Offset(childCenter.x, childCenter.y - nodeDiameter / 2f))
                childLeft += childWidth + xGap
            }
        }
        return center
    }
    var left = 0f
    roots.forEach { root ->
        place(root, left, 0)
        left += subtreeWidth(root) + xGap
    }
    return GraphLayout(nodes, edges, totalWidth, maxY)
}

private fun treeGoalProgress(person: TreePerson): Float? {
    val values = buildList {
        if (person.targetPv > 0) add(person.pv.toFloat() / person.targetPv.toFloat())
        if (person.targetGpv > 0) add(person.gpv.toFloat() / person.targetGpv.toFloat())
        if (person.targetActive > 0) add(person.active.toFloat() / person.targetActive.toFloat())
    }
    if (values.isEmpty()) return null
    return (values.sum() / values.size).coerceIn(0f, 1.25f)
}

@Composable
private fun TreeGraphScreen(
    state: TreeState,
    onPersonClick: (TreePerson) -> Unit,
    onStateViewChange: (Float, Set<String>) -> Unit,
    focusPersonId: String?,
    focusRequest: Int,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val nodeDiameter = with(density) { 138.dp.toPx() }
    val xGap = with(density) { 34.dp.toPx() }
    val yGap = with(density) { 54.dp.toPx() }
    var zoom by remember(state.zoom) { mutableFloatStateOf(state.zoom) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var closed by remember(state.closedIds) { mutableStateOf(state.closedIds) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var searchQuery by remember { mutableStateOf("") }
    var localFocusId by remember { mutableStateOf<String?>(null) }
    var highlightedPersonId by remember { mutableStateOf<String?>(focusPersonId) }
    var didInitialCenter by remember { mutableStateOf(false) }
    val layout = remember(state.people, closed, nodeDiameter, xGap, yGap) {
        buildGraphLayout(state.people, closed, nodeDiameter, xGap, yGap)
    }
    val highlightedPath = remember(highlightedPersonId, state.people) {
        highlightedPersonId?.let { ancestorIds(state.people, it) + it } ?: emptySet()
    }

    fun fitTreeInView() {
        if (viewportSize.width <= 0 || viewportSize.height <= 0 || layout.width <= 0f || layout.height <= 0f) return
        val horizontalSpace = (viewportSize.width - 30f).coerceAtLeast(1f)
        val topReserved = with(density) { 126.dp.toPx() }
        val bottomReserved = with(density) { 34.dp.toPx() }
        val verticalSpace = (viewportSize.height - topReserved - bottomReserved).coerceAtLeast(1f)
        val fit = min(horizontalSpace / layout.width, verticalSpace / layout.height).coerceIn(0.22f, 1.12f)
        zoom = fit
        pan = Offset(
            (viewportSize.width - layout.width * fit) / 2f,
            topReserved + (verticalSpace - layout.height * fit) / 2f
        )
    }

    LaunchedEffect(zoom, closed) {
        delay(260)
        if (zoom != state.zoom || closed != state.closedIds) onStateViewChange(zoom, closed)
    }

    LaunchedEffect(layout.width, layout.height, viewportSize) {
        if (!didInitialCenter && viewportSize.width > 0 && viewportSize.height > 0) {
            fitTreeInView()
            didInitialCenter = true
        }
    }

    LaunchedEffect(focusPersonId, focusRequest) {
        val id = focusPersonId ?: return@LaunchedEffect
        closed = closed - ancestorIds(state.people, id)
        highlightedPersonId = id
        localFocusId = id
        searchQuery = ""
    }

    LaunchedEffect(localFocusId, layout.nodes, viewportSize, zoom) {
        val id = localFocusId ?: return@LaunchedEffect
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return@LaunchedEffect
        val node = layout.nodes.firstOrNull { it.person.id == id } ?: return@LaunchedEffect
        pan = Offset(
            viewportSize.width / 2f - node.center.x * zoom,
            viewportSize.height * 0.52f - node.center.y * zoom
        )
        highlightedPersonId = id
        localFocusId = null
    }

    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF07111C), Color(0xFF091521), Color(0xFF060C13))
                )
            )
            .onSizeChanged { viewportSize = it }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(layout.nodes, viewportSize) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        var transformed = false
                        var accumulatedPan = Offset.Zero
                        var accumulatedZoom = 1f
                        var lastPressed = true
                        while (lastPressed) {
                            val event = awaitPointerEvent()
                            val zoomChange = event.calculateZoom()
                            val panChange = event.calculatePan()
                            accumulatedPan += panChange
                            accumulatedZoom *= zoomChange
                            val pressedCount = event.changes.count { it.pressed }
                            val shouldTransform = transformed || pressedCount > 1 ||
                                abs(accumulatedZoom - 1f) > 0.015f ||
                                hypot(accumulatedPan.x.toDouble(), accumulatedPan.y.toDouble()) > viewConfiguration.touchSlop

                            if (shouldTransform) {
                                val centroid = event.calculateCentroid(useCurrent = true)
                                if (!transformed) {
                                    transformed = true
                                    val oldZoom = zoom
                                    val newZoom = (oldZoom * accumulatedZoom).coerceIn(0.2f, 1.8f)
                                    val factor = if (oldZoom == 0f) 1f else newZoom / oldZoom
                                    pan = centroid - (centroid - pan) * factor + accumulatedPan
                                    zoom = newZoom
                                } else {
                                    val oldZoom = zoom
                                    val newZoom = (oldZoom * zoomChange).coerceIn(0.2f, 1.8f)
                                    val factor = if (oldZoom == 0f) 1f else newZoom / oldZoom
                                    pan = centroid - (centroid - pan) * factor + panChange
                                    zoom = newZoom
                                }
                            }
                            lastPressed = event.changes.any { it.pressed }
                        }

                        if (!transformed) {
                            val tap = down.position
                            val logical = Offset((tap.x - pan.x) / zoom, (tap.y - pan.y) / zoom)
                            val toggleHit = layout.nodes.firstOrNull { node ->
                                childrenOf(state.people, node.person.id).isNotEmpty() &&
                                    hypot(
                                        (node.center.x - logical.x).toDouble(),
                                        (node.center.y + nodeDiameter * 0.44f - logical.y).toDouble()
                                    ) <= nodeDiameter * 0.13f
                            }
                            if (toggleHit != null) {
                                closed = if (toggleHit.person.id in closed) closed - toggleHit.person.id else closed + toggleHit.person.id
                            } else {
                                val hit = layout.nodes.minByOrNull {
                                    hypot((it.center.x - logical.x).toDouble(), (it.center.y - logical.y).toDouble())
                                }
                                if (hit != null && hypot(
                                        (hit.center.x - logical.x).toDouble(),
                                        (hit.center.y - logical.y).toDouble()
                                    ) <= nodeDiameter * 0.52f
                                ) {
                                    highlightedPersonId = hit.person.id
                                    localFocusId = hit.person.id
                                    onPersonClick(hit.person)
                                }
                            }
                        }
                    }
                }
        ) {
            val gridStep = 56.dp.toPx()
            var gx = 0f
            while (gx <= size.width) {
                drawLine(Color(0x102E4052), Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1f)
                gx += gridStep
            }
            var gy = 0f
            while (gy <= size.height) {
                drawLine(Color(0x0D2E4052), Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                gy += gridStep
            }

            withTransform({
                translate(pan.x, pan.y)
                scale(zoom, zoom, pivot = Offset.Zero)
            }) {
                layout.edges.forEach { edge ->
                    val activeBranch = edge.fromId in highlightedPath && edge.toId in highlightedPath
                    val midY = (edge.from.y + edge.to.y) / 2f
                    val path = Path().apply {
                        moveTo(edge.from.x, edge.from.y)
                        cubicTo(edge.from.x, midY, edge.to.x, midY, edge.to.x, edge.to.y)
                    }
                    drawPath(
                        path = path,
                        color = if (activeBranch) Color(0x35FFD96A) else Color(0x241D2B39),
                        style = Stroke(width = if (activeBranch) 10f else 7f, cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = path,
                        color = if (activeBranch) Color(0xFFFFD86A) else Color(0x7B7C91A6),
                        style = Stroke(width = if (activeBranch) 3.8f else 2.2f, cap = StrokeCap.Round)
                    )
                }

                layout.nodes.forEach { node ->
                    val radius = nodeDiameter / 2f
                    val isFocused = node.person.id == highlightedPersonId
                    val progress = treeGoalProgress(node.person)
                    val progressAccent = when {
                        progress == null -> if (node.root) Gold else Color(0xFF66B8F4)
                        progress >= 1f -> Color(0xFF5AE08B)
                        progress >= 0.70f -> Gold
                        else -> Color(0xFF66B8F4)
                    }
                    val accent = if (isFocused) Color(0xFFFFE082) else progressAccent

                    drawCircle(
                        color = accent.copy(alpha = if (isFocused) 0.18f else 0.08f),
                        radius = radius * if (isFocused) 1.13f else 1.07f,
                        center = node.center
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = if (node.root) {
                                listOf(Color(0xFF5A4215), Color(0xFF17140C), Color(0xFF090B0E))
                            } else {
                                listOf(Color(0xFF17334B), Color(0xFF0A1723), Color(0xFF070C12))
                            },
                            center = Offset(node.center.x - radius * 0.20f, node.center.y - radius * 0.25f),
                            radius = radius * 1.2f
                        ),
                        radius = radius,
                        center = node.center
                    )
                    drawCircle(
                        color = Color(0xFF273442),
                        radius = radius * 0.90f,
                        center = node.center,
                        style = Stroke(width = 1.2f)
                    )
                    drawCircle(
                        color = accent,
                        radius = radius,
                        center = node.center,
                        style = Stroke(width = if (isFocused) 6f else 3.2f)
                    )

                    if (progress != null) {
                        val arcRadius = radius + 7f
                        drawArc(
                            color = accent.copy(alpha = 0.25f),
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = Offset(node.center.x - arcRadius, node.center.y - arcRadius),
                            size = Size(arcRadius * 2f, arcRadius * 2f),
                            style = Stroke(width = 5f, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = accent,
                            startAngle = -90f,
                            sweepAngle = 360f * progress.coerceIn(0f, 1f),
                            useCenter = false,
                            topLeft = Offset(node.center.x - arcRadius, node.center.y - arcRadius),
                            size = Size(arcRadius * 2f, arcRadius * 2f),
                            style = Stroke(width = 5f, cap = StrokeCap.Round)
                        )
                    }

                    drawIntoCanvas { canvas ->
                        val native = canvas.nativeCanvas
                        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE
                            textAlign = Paint.Align.CENTER
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            textSize = if (node.root) 20f else 17f
                        }
                        val metricPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(218, 225, 234)
                            textAlign = Paint.Align.CENTER
                            textSize = 12.5f
                        }
                        val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(247, 201, 72)
                            textAlign = Paint.Align.CENTER
                            textSize = 13f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        }
                        val name = node.person.name.take(18)
                        native.drawText(name, node.center.x, node.center.y - 24f, namePaint)
                        native.drawText("PV ${formatTreeNumber(node.person.pv)}", node.center.x, node.center.y + 1f, metricPaint)
                        native.drawText("GPV ${formatTreeNumber(node.person.gpv)}", node.center.x, node.center.y + 23f, goldPaint)
                        native.drawText("${node.person.active} فعال", node.center.x, node.center.y + 45f, metricPaint)
                    }

                    if (childrenOf(state.people, node.person.id).isNotEmpty()) {
                        val toggleCenter = Offset(node.center.x, node.center.y + nodeDiameter * 0.44f)
                        val toggleRadius = nodeDiameter * 0.105f
                        drawCircle(Color(0xFF07121E), toggleRadius * 1.14f, toggleCenter)
                        drawCircle(Color(0xFF101D29), toggleRadius, toggleCenter)
                        drawCircle(if (node.person.id in closed) Gold else accent, toggleRadius, toggleCenter, style = Stroke(width = 2.5f))
                        drawIntoCanvas { canvas ->
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = if (node.person.id in closed) android.graphics.Color.rgb(247, 201, 72) else android.graphics.Color.WHITE
                                textAlign = Paint.Align.CENTER
                                textSize = nodeDiameter * 0.10f
                                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            }
                            canvas.nativeCanvas.drawText(if (node.person.id in closed) "+" else "−", toggleCenter.x, toggleCenter.y + nodeDiameter * 0.035f, paint)
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 8.dp)
                .background(Color(0xE90A131D), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0x55718395), RoundedCornerShape(16.dp))
                .padding(horizontal = 5.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TreeToolButton("−") { zoom = (zoom - 0.1f).coerceAtLeast(0.2f) }
            Text("${(zoom * 100).toInt()}٪", color = GoldSoft, fontSize = 10.sp, modifier = Modifier.width(40.dp), textAlign = TextAlign.Center)
            TreeToolButton("+") { zoom = (zoom + 0.1f).coerceAtMost(1.8f) }
            TreeToolButton("◎") { fitTreeInView() }
            TreeToolButton("↧") { closed = emptySet(); highlightedPersonId = null }
            TreeToolButton("↥") {
                closed = state.people.filter { childrenOf(state.people, it.id).isNotEmpty() }.map { it.id }.toSet()
                highlightedPersonId = null
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 62.dp, start = 12.dp, end = 12.dp)
                .widthIn(max = 360.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(60) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("جستجوی فرد") },
                leadingIcon = { Text("⌕", color = Gold, fontSize = 18.sp) },
                colors = gamifyTextFieldColors(),
                shape = RoundedCornerShape(14.dp)
            )
            if (searchQuery.isNotBlank()) {
                val matches = state.people
                    .filter { it.name.contains(searchQuery.trim(), ignoreCase = true) }
                    .take(5)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xF20A121C),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x556B7888))
                ) {
                    Column {
                        if (matches.isEmpty()) {
                            Text("نتیجه‌ای پیدا نشد", color = TextSoft, fontSize = 10.sp, modifier = Modifier.padding(12.dp))
                        } else {
                            matches.forEachIndexed { index, person ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            closed = closed - ancestorIds(state.people, person.id)
                                            highlightedPersonId = person.id
                                            localFocusId = person.id
                                            searchQuery = ""
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(person.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("PV ${formatTreeNumber(person.pv)}", color = TextSoft, fontSize = 9.sp)
                                        Text("GPV ${formatTreeNumber(person.gpv)}", color = GoldSoft, fontSize = 9.sp)
                                    }
                                }
                                if (index != matches.lastIndex) HorizontalDivider(color = Color(0x334D5A68))
                            }
                        }
                    }
                }
            }
        }

        val highlightedPerson = highlightedPersonId?.let { id -> state.people.firstOrNull { it.id == id } }
        if (highlightedPerson != null) {
            val progress = treeGoalProgress(highlightedPerson)
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 9.dp),
                color = Color(0xD90A131D),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x667A8795))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(highlightedPerson.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("PV ${formatTreeNumber(highlightedPerson.pv)}", color = TextSoft, fontSize = 9.sp)
                    Text("GPV ${formatTreeNumber(highlightedPerson.gpv)}", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    if (progress != null) Text("هدف ${(progress * 100).toInt()}٪", color = if (progress >= 1f) Color(0xFF65E596) else GoldSoft, fontSize = 9.sp)
                }
            }
        } else {
            Text(
                "یک انگشت: حرکت  •  دو انگشت: زوم",
                color = Color(0xFF8E9AA8),
                fontSize = 8.5.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 9.dp)
                    .background(Color(0xA8081018), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
private fun TreeToolButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(32.dp)
            .background(Color(0x66172533), RoundedCornerShape(9.dp))
            .border(1.dp, Color(0x446E8295), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun TreeCompareScreen(state: TreeState, modifier: Modifier = Modifier) {
    var historyMode by remember { mutableStateOf(true) }
    Column(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TreeModeChip("مقایسه افراد", !historyMode) { historyMode = false }
            TreeModeChip("مقایسه زمانی", historyMode) { historyMode = true }
        }
        if (historyMode) HistoryComparePane(state, Modifier.weight(1f)) else PeopleComparePane(state, Modifier.weight(1f))
    }
}

@Composable
private fun TreeModeChip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(42.dp).background(if (active) Color(0x22F7C948) else Color(0x44141E2A), RoundedCornerShape(13.dp)).border(1.dp, if (active) Gold else Color(0x554A5767), RoundedCornerShape(13.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (active) GoldSoft else TextSoft, fontSize = 11.sp) }
}

@Composable
private fun PeopleComparePane(state: TreeState, modifier: Modifier = Modifier) {
    val people = state.people
    val selected = remember(people) { mutableStateListOf<String>().also { list -> repeat(3) { list += people.getOrNull(it)?.id ?: people.firstOrNull()?.id.orEmpty() } } }
    val chosen = selected.map { id -> people.firstOrNull { it.id == id } }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { index ->
                TreeDropdown(
                    value = people.firstOrNull { it.id == selected[index] }?.name ?: "—",
                    options = people.map { it.id to it.name },
                    onSelect = { selected[index] = it },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        TreeCompareTable(
            headers = chosen.map { it?.name ?: "—" },
            rows = listOf(
                "PV" to chosen.map { formatTreeNumber(it?.pv ?: 0) },
                "GPV" to chosen.map { formatTreeNumber(it?.gpv ?: 0) },
                "فعال" to chosen.map { (it?.active ?: 0).toString() }
            )
        )
    }
}

@Composable
private fun HistoryComparePane(state: TreeState, modifier: Modifier = Modifier) {
    if (state.snapshots.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("هنوز تاریخچه‌ای ثبت نشده است.", color = TextSoft)
        }
        return
    }

    var personId by remember(state.people) { mutableStateOf(state.people.firstOrNull()?.id.orEmpty()) }
    val keys = remember(state.snapshots) {
        mutableStateListOf<String>().also { list ->
            repeat(3) { index ->
                list += state.snapshots.getOrNull(index)?.key ?: state.snapshots.first().key
            }
        }
    }
    var pickerIndex by remember { mutableStateOf<Int?>(null) }
    val snapshotPeople = keys.map { key ->
        state.snapshots.firstOrNull { it.key == key }?.people?.firstOrNull { it.id == personId }
    }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("مقایسه زمانی", color = GoldSoft, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        Text("یک نفر و سه تاریخ شمسی را انتخاب کن.", color = TextSoft, fontSize = 10.sp)

        TreeDropdown(
            value = state.people.firstOrNull { it.id == personId }?.name ?: "انتخاب فرد",
            options = state.people.map { it.id to it.name },
            onSelect = { personId = it },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { index ->
                val hasSnapshot = state.snapshots.any { it.key == keys[index] }
                TreeDateButton(
                    label = persianDigits(jalaliLabelFromKey(keys[index])),
                    hasSnapshot = hasSnapshot,
                    onClick = { pickerIndex = index },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        TreeCompareTable(
            headers = keys.map { key -> persianDigits(jalaliLabelFromKey(key)) },
            rows = listOf(
                "PV" to snapshotPeople.map { formatTreeNumber(it?.pv ?: 0) },
                "GPV" to snapshotPeople.map { formatTreeNumber(it?.gpv ?: 0) },
                "فعال" to snapshotPeople.map { if (it == null) "—" else it.active.toString() }
            )
        )

        val missing = keys.mapIndexedNotNull { index, key -> if (state.snapshots.none { it.key == key }) index + 1 else null }
        if (missing.isNotEmpty()) {
            Text(
                "برای تاریخ ${missing.joinToString("، ") { persianDigits(it.toString()) }} داده‌ای ثبت نشده است.",
                color = Color(0xFFE5A85B),
                fontSize = 9.5.sp
            )
        }
    }

    pickerIndex?.let { index ->
        JalaliTreeDatePickerDialog(
            initialKey = keys[index],
            availableSnapshotKeys = state.snapshots.map { it.key }.toSet(),
            onDismiss = { pickerIndex = null },
            onConfirm = { key ->
                keys[index] = key
                pickerIndex = null
            }
        )
    }
}

@Composable
private fun TreeDateButton(
    label: String,
    hasSnapshot: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .height(56.dp)
            .background(Color(0xFF101A25), RoundedCornerShape(12.dp))
            .border(1.dp, if (hasSnapshot) Color(0xFF6C5A32) else Color(0xFF68413A), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(if (hasSnapshot) "ثبت شده" else "بدون ثبت", color = if (hasSnapshot) GoldSoft else Color(0xFFD98A7F), fontSize = 7.5.sp)
    }
}

@Composable
private fun JalaliTreeDatePickerDialog(
    initialKey: String,
    availableSnapshotKeys: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val initialGregorian = runCatching { LocalDate.parse(initialKey) }.getOrDefault(LocalDate.now())
    val initial = gregorianToJalali(initialGregorian)
    val currentJalali = gregorianToJalali(LocalDate.now())
    val availableYears = availableSnapshotKeys.mapNotNull { key ->
        runCatching { gregorianToJalali(LocalDate.parse(key)).year }.getOrNull()
    }
    val minYear = minOf((availableYears.minOrNull() ?: currentJalali.year) - 1, initial.year)
    val maxYear = maxOf(currentJalali.year + 1, availableYears.maxOrNull() ?: currentJalali.year, initial.year)

    var year by remember(initialKey) { mutableStateOf(initial.year) }
    var month by remember(initialKey) { mutableStateOf(initial.month) }
    var day by remember(initialKey) { mutableStateOf(initial.day) }

    LaunchedEffect(year, month) {
        val dayLimit = jalaliMonthLength(year, month)
        if (day > dayLimit) day = dayLimit
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0C151F),
        shape = RoundedCornerShape(22.dp),
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("انتخاب تاریخ شمسی", color = GoldSoft, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    persianDigits(String.format(Locale.US, "%04d/%02d/%02d", year, month, day)),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("سال", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = persianDigits(year.toString()),
                    options = (maxYear downTo minYear).map { it.toString() to persianDigits(it.toString()) },
                    onSelect = { year = it.toIntOrNull() ?: year },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("ماه", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = jalaliMonthNames[month - 1],
                    options = jalaliMonthNames.mapIndexed { index, name -> (index + 1).toString() to name },
                    onSelect = { month = it.toIntOrNull()?.coerceIn(1, 12) ?: month },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("روز", color = TextSoft, fontSize = 9.sp)
                TreeDropdown(
                    value = persianDigits(day.toString()),
                    options = (1..jalaliMonthLength(year, month)).map { it.toString() to persianDigits(it.toString()) },
                    onSelect = { day = it.toIntOrNull()?.coerceIn(1, jalaliMonthLength(year, month)) ?: day },
                    modifier = Modifier.fillMaxWidth()
                )

                val selectedKey = runCatching { jalaliToGregorian(JalaliDate(year, month, day)).toString() }.getOrNull()
                val hasData = selectedKey != null && selectedKey in availableSnapshotKeys
                Surface(
                    color = if (hasData) Color(0x2210B981) else Color(0x22D97757),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (hasData) "برای این تاریخ اطلاعات ثبت شده است." else "برای این تاریخ هنوز اطلاعاتی ثبت نشده است.",
                        color = if (hasData) Color(0xFF8EE0B8) else Color(0xFFE7A18C),
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(9.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val key = jalaliToGregorian(JalaliDate(year, month, day)).toString()
                    onConfirm(key)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Gold)
            ) { Text("انتخاب", color = Color(0xFF16100A), fontWeight = FontWeight.ExtraBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف", color = TextSoft) } }
    )
}

@Composable
private fun TreeCompareTable(headers: List<String>, rows: List<Pair<String, List<String>>>) {
    Surface(color = Color(0xCC0D1722), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x444D5A69), RoundedCornerShape(18.dp))) {
        Column {
            Row(Modifier.fillMaxWidth().background(Color(0x331F2A36)).padding(vertical = 10.dp)) {
                Text("", Modifier.width(72.dp))
                headers.forEach { Text(it.take(12), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
            rows.forEachIndexed { index, row ->
                if (index > 0) HorizontalDivider(color = Color(0x223D4A57))
                Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row.first, color = TextSoft, fontSize = 10.sp, modifier = Modifier.width(72.dp).padding(start = 8.dp))
                    row.second.forEach { Text(it, color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun TreeDropdown(
    value: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        Box(
            Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF101A25), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF43505E), RoundedCornerShape(12.dp)).clickable { expanded = true }.padding(horizontal = 9.dp),
            contentAlignment = Alignment.Center
        ) { Text(value, color = Color.White, fontSize = 10.sp, maxLines = 1) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (key, label) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(key); expanded = false })
            }
        }
    }
}

@Composable
private fun TreeRankingScreen(state: TreeState, onPersonClick: (TreePerson) -> Unit, modifier: Modifier = Modifier) {
    var mode by remember { mutableStateOf(RankMode.Pv) }
    val candidates = state.people.filter { it.parentId != null }
    fun value(person: TreePerson): Int = when (mode) {
        RankMode.Pv -> person.pv
        RankMode.Gpv -> person.gpv
        RankMode.Members -> descendantCount(state.people, person.id)
        RankMode.Actions -> person.actions.size
    }
    val sorted = candidates.sortedByDescending(::value)
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RankMode.entries.forEach { item -> TreeModeChip(item.title, mode == item) { mode = item } }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(sorted, key = { it.id }) { person ->
                val rank = sorted.indexOf(person) + 1
                Surface(
                    color = Color(0xC9101924),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onPersonClick(person) }.border(1.dp, if (rank <= 3) Color(0x55F7C948) else Color(0x334B5968), RoundedCornerShape(16.dp))
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(if (rank == 1) Color(0x22F7C948) else Color(0x221C2733), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                            Text(rank.toString(), color = if (rank <= 3) Gold else TextSoft, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(person.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(formatTreeNumber(value(person)), color = GoldSoft, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddDirectDialog(parent: TreePerson, onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        title = { Text("اضافه کردن دایرکت", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("زیرمجموعه ${parent.name}", color = TextSoft, fontSize = 11.sp)
                OutlinedTextField(value = name, onValueChange = { name = it.take(60) }, label = { Text("نام فرد") }, singleLine = true, colors = gamifyTextFieldColors(), modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = name.trim().isNotBlank(), onClick = { onAdd(name) }) { Text("ثبت", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("لغو", color = TextSoft) } }
    )
}

@Composable
private fun TransferSponsorDialog(
    person: TreePerson,
    people: List<TreePerson>,
    onDismiss: () -> Unit,
    onTransfer: (String) -> Unit
) {
    var query by remember(person.id) { mutableStateOf("") }
    val blockedIds = descendantIds(people, person.id) + person.id
    val candidates = people
        .filter { it.id !in blockedIds }
        .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        title = { Text("تغییر حامی", color = Color.White, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("حامی جدید ${person.name} را انتخاب کن.", color = TextSoft, fontSize = 11.sp)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it.take(60) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("جستجوی حامی") },
                    colors = gamifyTextFieldColors()
                )
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 330.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(candidates, key = { it.id }) { candidate ->
                        val selected = person.parentId == candidate.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (selected) Color(0x22F7C948) else Color(0x33121C27), RoundedCornerShape(12.dp))
                                .border(1.dp, if (selected) Gold else Color(0x334F5C6B), RoundedCornerShape(12.dp))
                                .clickable(enabled = !selected) { onTransfer(candidate.id) }
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(candidate.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("${childrenOf(people, candidate.id).size} دایرکت • ${descendantCount(people, candidate.id)} نفر سازمان", color = TextSoft, fontSize = 9.sp)
                            }
                            if (selected) Text("حامی فعلی", color = GoldSoft, fontSize = 9.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن", color = TextSoft) } }
    )
}

@Composable
private fun EditTreePersonDialog(
    person: TreePerson,
    canDelete: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    directCount: Int,
    organizationCount: Int,
    onDismiss: () -> Unit,
    onAddDirect: () -> Unit,
    onTodos: () -> Unit,
    onActions: () -> Unit,
    onLocate: () -> Unit,
    onTransfer: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onSave: (TreePerson) -> Unit,
    onDelete: () -> Unit
) {
    var name by remember(person.id) { mutableStateOf(person.name) }
    var targetPv by remember(person.id) { mutableStateOf(formatTreeInput(person.targetPv)) }
    var targetGpv by remember(person.id) { mutableStateOf(formatTreeInput(person.targetGpv)) }
    var targetActive by remember(person.id) { mutableStateOf(if (person.targetActive == 0) "" else person.targetActive.toString()) }
    var status by remember(person.id) { mutableStateOf(person.status) }
    var nextAction by remember(person.id) { mutableStateOf(person.nextAction) }
    var notes by remember(person.id) { mutableStateOf(person.notes) }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        title = { Text(person.name, color = Color.White, fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TreeMiniMetric("دایرکت", directCount.toString())
                        Spacer(Modifier.weight(1f))
                        TreeMiniMetric("کل سازمان", organizationCount.toString())
                        Spacer(Modifier.weight(1f))
                        TreeMiniMetric("PV", formatTreeNumber(person.pv))
                        Spacer(Modifier.weight(1f))
                        TreeMiniMetric("GPV", formatTreeNumber(person.gpv))
                    }
                }
                item { OutlinedTextField(name, { name = it.take(60) }, label = { Text("نام فرد") }, singleLine = true, colors = gamifyTextFieldColors(), modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TreeNumericField("هدف PV", targetPv, { targetPv = formatTypedNumber(it) }, Modifier.weight(1f))
                        TreeNumericField("هدف GPV", targetGpv, { targetGpv = formatTypedNumber(it) }, Modifier.weight(1f))
                        TreeNumericField("هدف تعداد", targetActive, { targetActive = it.filter(Char::isDigit).take(5) }, Modifier.weight(1f))
                    }
                }
                item { OutlinedTextField(status, { status = it.take(80) }, label = { Text("وضعیت همکاری") }, singleLine = true, colors = gamifyTextFieldColors(), modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(nextAction, { nextAction = it.take(120) }, label = { Text("اقدام بعدی") }, singleLine = true, colors = gamifyTextFieldColors(), modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("یادداشت‌ها") }, minLines = 3, colors = gamifyTextFieldColors(), modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = onAddDirect, modifier = Modifier.weight(1f)) { Text("+ دایرکت") }
                        OutlinedButton(onClick = onTodos, modifier = Modifier.weight(1f)) { Text("To Do") }
                        OutlinedButton(onClick = onActions, modifier = Modifier.weight(1f)) { Text("اقدامات") }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = onLocate, modifier = Modifier.weight(1f)) { Text("نمایش در درخت", fontSize = 10.sp) }
                        if (canDelete) OutlinedButton(onClick = onTransfer, modifier = Modifier.weight(1f)) { Text("تغییر حامی", fontSize = 10.sp) }
                    }
                }
                if (canDelete) item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(enabled = canMoveUp, onClick = onMoveUp, modifier = Modifier.weight(1f)) { Text("← جایگاه", fontSize = 10.sp) }
                        OutlinedButton(enabled = canMoveDown, onClick = onMoveDown, modifier = Modifier.weight(1f)) { Text("جایگاه →", fontSize = 10.sp) }
                    }
                }
                if (canDelete) item {
                    TextButton(onClick = { confirmDelete = true }) { Text("حذف این فرد و تمام زیرشاخه‌اش", color = GamifyColors.Error, fontSize = 11.sp) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.trim().isNotBlank(), onClick = {
                onSave(person.copy(name = name.trim(), targetPv = parseTreeNumber(targetPv), targetGpv = parseTreeNumber(targetGpv), targetActive = parseTreeNumber(targetActive), status = status.trim(), nextAction = nextAction.trim(), notes = notes.trim()))
            }) { Text("ذخیره", color = Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن", color = TextSoft) } }
    )
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = GamifyColors.Surface,
            title = { Text("حذف شاخه؟", color = Color.White) },
            text = {
                Text(
                    if (organizationCount > 0)
                        "${person.name} به همراه $organizationCount نفر زیرمجموعه حذف می‌شوند. To Do و اقدامات این شاخه هم حذف می‌شوند؛ تاریخچه روزهای قبل حفظ می‌شود."
                    else
                        "${person.name} حذف می‌شود. To Do و اقدامات این فرد هم حذف می‌شوند؛ تاریخچه روزهای قبل حفظ می‌شود.",
                    color = TextSoft
                )
            },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("حذف", color = GamifyColors.Error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("لغو", color = TextSoft) } }
        )
    }
}

@Composable
private fun TodoDialog(person: TreePerson, onDismiss: () -> Unit, onUpdate: (TreePerson) -> Unit) {
    var text by remember(person.id) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        title = { Text("To Do List • ${person.name}", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 500.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(text, { text = it.take(160) }, modifier = Modifier.weight(1f), placeholder = { Text("یک مورد بنویس...") }, singleLine = true, colors = gamifyTextFieldColors())
                    Button(onClick = {
                        if (text.trim().isNotBlank()) {
                            onUpdate(person.copy(todos = person.todos + TreeTodo(UUID.randomUUID().toString(), text.trim())))
                            text = ""
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("+") }
                }
                val orderedTodos = person.todos.sortedBy { it.done }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(orderedTodos, key = { it.id }) { todo ->
                        Row(Modifier.fillMaxWidth().background(Color(0x5517222D), RoundedCornerShape(11.dp)).padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = todo.done, onCheckedChange = { checked -> onUpdate(person.copy(todos = person.todos.map { if (it.id == todo.id) it.copy(done = checked) else it })) })
                            Text(todo.text, color = if (todo.done) Color(0xFF8995A3) else Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { onUpdate(person.copy(todos = person.todos.filterNot { it.id == todo.id })) }) { Text("×", color = GamifyColors.Error) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن", color = Gold) } }
    )
}

@Composable
private fun ActionsDialog(
    person: TreePerson,
    allPeople: List<TreePerson>,
    onDismiss: () -> Unit,
    onUpdate: (TreePerson) -> Unit
) {
    val actionTypes = listOf("ارتباط‌سازی", "پیش‌مشاوره", "دعوت", "معرفی کار", "فالوآپ", "ثبت سفارش", "پیگیری")
    var mode by remember(person.id) { mutableStateOf(0) }
    var doneAction by remember(person.id) { mutableStateOf(actionTypes.first()) }
    var nextAction by remember(person.id) { mutableStateOf(actionTypes.first()) }
    var doneExpanded by remember { mutableStateOf(false) }
    var nextExpanded by remember { mutableStateOf(false) }
    var prospect by remember(person.id) { mutableStateOf("") }
    var nextDate by remember(person.id) { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
    var editingActionId by remember(person.id) { mutableStateOf<String?>(null) }
    var contactName by remember(person.id) { mutableStateOf("") }
    var editingContactId by remember(person.id) { mutableStateOf<String?>(null) }
    var editingContactName by remember(person.id) { mutableStateOf("") }

    fun resetActionForm() {
        doneAction = actionTypes.first()
        nextAction = actionTypes.first()
        prospect = ""
        nextDate = LocalDate.now().plusDays(1).toString()
        editingActionId = null
    }

    fun latestActionFor(name: String): TreeAction? = person.actions
        .filter { it.prospectName.equals(name, ignoreCase = true) }
        .maxWithOrNull(compareBy<TreeAction> { it.date }.thenBy { it.id })

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xFF0E1924),
            shape = RoundedCornerShape(28.dp),
            title = {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("افراد و اقدامات", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text(person.name, color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 590.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            Modifier.weight(1f).height(44.dp)
                                .background(if (mode == 0) Color(0x22F7C948) else Color(0x66131D28), RoundedCornerShape(14.dp))
                                .border(1.dp, if (mode == 0) Gold else Color(0x554E5C6C), RoundedCornerShape(14.dp))
                                .clickable { mode = 0 },
                            contentAlignment = Alignment.Center
                        ) { Text("اقدامات", color = if (mode == 0) GoldSoft else TextSoft, fontWeight = FontWeight.Bold) }
                        Box(
                            Modifier.weight(1f).height(44.dp)
                                .background(if (mode == 1) Color(0x22F7C948) else Color(0x66131D28), RoundedCornerShape(14.dp))
                                .border(1.dp, if (mode == 1) Gold else Color(0x554E5C6C), RoundedCornerShape(14.dp))
                                .clickable { mode = 1 },
                            contentAlignment = Alignment.Center
                        ) { Text("لیست افراد", color = if (mode == 1) GoldSoft else TextSoft, fontWeight = FontWeight.Bold) }
                    }

                    if (mode == 0) {
                        Surface(
                            color = Color(0x8F111E2A),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x44576A7E), RoundedCornerShape(20.dp))
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp), horizontalAlignment = Alignment.End) {
                                Text(if (editingActionId == null) "ثبت اقدام جدید" else "ویرایش اقدام", color = GoldSoft, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                OutlinedTextField(
                                    value = prospect,
                                    onValueChange = { prospect = it.take(60) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("نام فرد") },
                                    textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White),
                                    singleLine = true,
                                    colors = gamifyTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(Modifier.weight(1f)) {
                                        Box(
                                            Modifier.fillMaxWidth().height(56.dp)
                                                .background(GamifyColors.SurfaceInput, RoundedCornerShape(14.dp))
                                                .border(1.dp, GamifyColors.Border, RoundedCornerShape(14.dp))
                                                .clickable { nextExpanded = true }
                                                .padding(horizontal = 10.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("اقدام بعدی", color = TextSoft, fontSize = 8.sp)
                                                Text(nextAction, color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        DropdownMenu(expanded = nextExpanded, onDismissRequest = { nextExpanded = false }) {
                                            actionTypes.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { nextAction = item; nextExpanded = false }) }
                                        }
                                    }
                                    Box(Modifier.weight(1f)) {
                                        Box(
                                            Modifier.fillMaxWidth().height(56.dp)
                                                .background(GamifyColors.SurfaceInput, RoundedCornerShape(14.dp))
                                                .border(1.dp, GamifyColors.Border, RoundedCornerShape(14.dp))
                                                .clickable { doneExpanded = true }
                                                .padding(horizontal = 10.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("اقدام انجام‌شده", color = TextSoft, fontSize = 8.sp)
                                                Text(doneAction, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        DropdownMenu(expanded = doneExpanded, onDismissRequest = { doneExpanded = false }) {
                                            actionTypes.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { doneAction = item; doneExpanded = false }) }
                                        }
                                    }
                                }
                                OutlinedTextField(
                                    value = nextDate,
                                    onValueChange = { nextDate = it.take(10) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("تاریخ اقدام بعدی") },
                                    supportingText = { Text("YYYY-MM-DD", fontSize = 8.sp) },
                                    textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White),
                                    singleLine = true,
                                    colors = gamifyTextFieldColors(),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                Button(
                                    enabled = prospect.trim().isNotBlank(),
                                    onClick = {
                                        val cleanName = prospect.trim()
                                        val editedId = editingActionId
                                        val oldAction = editedId?.let { id -> person.actions.firstOrNull { it.id == id } }
                                        val performedDate = oldAction?.date ?: LocalDate.now().toString()
                                        val updatedAction = TreeAction(
                                            id = editedId ?: UUID.randomUUID().toString(),
                                            type = doneAction,
                                            prospectName = cleanName,
                                            date = performedDate,
                                            result = "",
                                            nextAction = nextAction,
                                            nextDate = nextDate.trim()
                                        )
                                        val updatedActions = if (editedId == null) person.actions + updatedAction
                                        else person.actions.map { if (it.id == editedId) updatedAction else it }

                                        var updatedContacts = person.contacts
                                        if (oldAction != null && !oldAction.prospectName.equals(cleanName, ignoreCase = true)) {
                                            val oldName = oldAction.prospectName.trim()
                                            val stillUsed = person.actions.any { it.id != oldAction.id && it.prospectName.equals(oldName, ignoreCase = true) }
                                            if (oldName.isNotBlank() && !stillUsed) {
                                                updatedContacts = updatedContacts.map { if (it.name.equals(oldName, ignoreCase = true)) it.copy(name = cleanName) else it }
                                            }
                                        }
                                        if (updatedContacts.none { it.name.equals(cleanName, ignoreCase = true) }) {
                                            updatedContacts = updatedContacts + TreeContact(UUID.randomUUID().toString(), cleanName)
                                        }
                                        onUpdate(person.copy(contacts = updatedContacts, actions = updatedActions))
                                        resetActionForm()
                                    },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                    shape = RoundedCornerShape(15.dp)
                                ) { Text(if (editingActionId == null) "ثبت اقدام" else "ذخیره تغییرات", fontWeight = FontWeight.ExtraBold) }
                            }
                        }

                        HorizontalDivider(color = Color(0x334B5866))
                        if (person.actions.isEmpty()) {
                            Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) { Text("هنوز اقدامی ثبت نشده است.", color = TextSoft) }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(person.actions.reversed(), key = { it.id }) { action ->
                                    Surface(
                                        color = Color(0x9A111D29),
                                        shape = RoundedCornerShape(17.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x3D526478), RoundedCornerShape(17.dp))
                                    ) {
                                        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.End) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(jalaliLabelFromKey(action.date), color = TextSoft, fontSize = 8.sp)
                                                Text(action.prospectName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                Text(action.type, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.width(5.dp))
                                                Text(":اقدام انجام‌شده", color = TextSoft, fontSize = 9.sp)
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(action.nextDate.takeIf { it.isNotBlank() }?.let(::jalaliLabelFromKey) ?: "—", color = GoldSoft, fontSize = 9.sp)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(action.nextAction.ifBlank { "—" }, color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text(":اقدام بعدی", color = TextSoft, fontSize = 9.sp)
                                                }
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                                                TextButton(onClick = {
                                                    editingActionId = action.id
                                                    doneAction = action.type.takeIf { it in actionTypes } ?: actionTypes.first()
                                                    nextAction = action.nextAction.takeIf { it in actionTypes } ?: actionTypes.first()
                                                    prospect = action.prospectName
                                                    nextDate = action.nextDate.ifBlank { LocalDate.now().plusDays(1).toString() }
                                                }) { Text("ویرایش", color = GoldSoft, fontSize = 9.sp) }
                                                TextButton(onClick = {
                                                    onUpdate(person.copy(actions = person.actions.filterNot { it.id == action.id }))
                                                    if (editingActionId == action.id) resetActionForm()
                                                }) { Text("حذف", color = GamifyColors.Error, fontSize = 9.sp) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                enabled = contactName.trim().isNotBlank(),
                                onClick = {
                                    val clean = contactName.trim()
                                    if (person.contacts.none { it.name.equals(clean, ignoreCase = true) }) {
                                        onUpdate(person.copy(contacts = person.contacts + TreeContact(UUID.randomUUID().toString(), clean)))
                                    }
                                    contactName = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Gold),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text("+") }
                            OutlinedTextField(
                                contactName,
                                { contactName = it.take(60) },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("نام فرد جدید") },
                                textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White),
                                singleLine = true,
                                colors = gamifyTextFieldColors(),
                                shape = RoundedCornerShape(14.dp)
                            )
                        }
                        Text("${person.contacts.size} نفر", color = TextSoft, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(person.contacts, key = { it.id }) { contact ->
                                val latest = latestActionFor(contact.name)
                                Surface(
                                    color = Color(0x96111D29),
                                    shape = RoundedCornerShape(17.dp),
                                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x3D526478), RoundedCornerShape(17.dp))
                                ) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp), horizontalAlignment = Alignment.End) {
                                        if (editingContactId == contact.id) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                TextButton(onClick = { editingContactId = null; editingContactName = "" }) { Text("×", color = TextSoft) }
                                                TextButton(onClick = {
                                                    val clean = editingContactName.trim()
                                                    if (clean.isNotBlank()) {
                                                        val oldName = contact.name
                                                        val renamedContacts = person.contacts.map { if (it.id == contact.id) it.copy(name = clean) else it }
                                                        val renamedActions = person.actions.map { if (it.prospectName.equals(oldName, ignoreCase = true)) it.copy(prospectName = clean) else it }
                                                        onUpdate(person.copy(contacts = renamedContacts, actions = renamedActions))
                                                    }
                                                    editingContactId = null
                                                    editingContactName = ""
                                                }) { Text("✓", color = Gold) }
                                                OutlinedTextField(
                                                    editingContactName,
                                                    { editingContactName = it.take(60) },
                                                    singleLine = true,
                                                    textStyle = TextStyle(textAlign = TextAlign.End, color = Color.White),
                                                    colors = gamifyTextFieldColors(),
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        } else {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Row {
                                                    TextButton(onClick = { onUpdate(person.copy(contacts = person.contacts.filterNot { it.id == contact.id })) }) { Text("×", color = GamifyColors.Error) }
                                                    TextButton(onClick = { editingContactId = contact.id; editingContactName = contact.name }) { Text("ویرایش", color = GoldSoft, fontSize = 8.sp) }
                                                }
                                                Text(contact.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                Text(latest?.type ?: "—", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.width(5.dp))
                                                Text(":اقدام انجام‌شده", color = TextSoft, fontSize = 9.sp)
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(latest?.nextDate?.takeIf { it.isNotBlank() }?.let(::jalaliLabelFromKey) ?: "—", color = GoldSoft, fontSize = 9.sp)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(latest?.nextAction?.ifBlank { "مشخص نشده" } ?: "مشخص نشده", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text(":اقدام بعدی", color = TextSoft, fontSize = 9.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("بستن", color = Gold) } }
        )
    }
}

