shadbash - Page 01

- Launcher/app name: shadbash
- Updated first page with the new header design for «شادباش»
- Safe-area padding added for modern phones so content does not sit under status/navigation areas
- Custom launcher icon included from the designed app icon
- Android WebView project compatible with your ZIP-based GitHub Actions workflow
