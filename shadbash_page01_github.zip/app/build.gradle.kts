plugins {
    id("com.android.application")
}

android {
    namespace = "com.shahriar.nextbeat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shahriar.shadbash"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.0-shadbash-page01"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
