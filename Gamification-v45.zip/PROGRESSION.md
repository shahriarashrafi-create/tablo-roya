# Gamification v45 Progress

- Slowed mission completion flight and HUD reward count-up animations.
- Replaced numbered side notification badges with tiny red dots.
- Replaced Quests with Dreamboard and added a dedicated Dreamboard placeholder view for the next design pass.
- Replaced Inbox with Missions and added a complete mission list with active/done/missed states; active missions jump back to their matching Home card.
- Reworked Shop into a personal reward store that spends Coins.
- Added 10 editable default personal rewards from 100 to 5000 Coins.
- Added add, edit, delete, and redeem actions for personal rewards with persistent storage.
- Version bumped to 0.45.
