shadbash - Page 04 round

Changes in this ZIP:
- Removed the text «شروع بازی» and «آماده ورود به راند اول» from the ready page header.
- Added the game icon at the top of the ready page.
- Removed «ویرایش تیم‌ها» and «بازگشت به خانه».
- Implemented in-app back flow: each phone back moves one step backward inside the app.
- On the home screen, pressing back twice exits the app.
- Added the next page: first-round start screen with current team, round summary, mini scoreboard, and random-card entry button.
- Compatible with the existing ZIP-based workflow.
