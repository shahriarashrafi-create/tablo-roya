package com.shahriar.gamify

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * Owns the calm focus soundtrack for the active timer session.
 * The bundled track is two minutes long and loops until the mission ends,
 * sound is disabled, or the user mutes this specific active mission.
 */
internal object MissionMusicController {
    private var player: MediaPlayer? = null
    private var playingSessionId: Long = 0L
    private var mutedSessionId: Long = 0L

    @Synchronized
    fun ensureForTimer(context: Context, settings: GameSettings, state: ActiveTimerState?) {
        if (!settings.soundEnabled || state == null || !state.isRunning || remainingSeconds(context, state) <= 0) {
            stopPlayback()
            return
        }

        // Mute applies only to the currently active card. A newly started card
        // gets its focus soundtrack automatically.
        if (mutedSessionId != 0L && mutedSessionId != state.sessionId) {
            mutedSessionId = 0L
        }
        if (mutedSessionId == state.sessionId) {
            stopPlayback()
            return
        }

        val current = player
        if (playingSessionId == state.sessionId && current != null && current.isPlaying) return

        stopPlayback()
        val appContext = context.applicationContext
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val mediaPlayer = MediaPlayer.create(appContext, R.raw.mission_focus_loop, attributes, 0) ?: return
        mediaPlayer.isLooping = true
        mediaPlayer.setVolume(0.42f, 0.42f)
        mediaPlayer.setOnErrorListener { mp, _, _ ->
            runCatching { mp.release() }
            synchronized(this) {
                if (player === mp) {
                    player = null
                    playingSessionId = 0L
                }
            }
            true
        }
        mediaPlayer.start()
        player = mediaPlayer
        playingSessionId = state.sessionId
    }

    @Synchronized
    fun isMuted(sessionId: Long): Boolean = mutedSessionId == sessionId

    @Synchronized
    fun setMuted(context: Context, settings: GameSettings, state: ActiveTimerState, muted: Boolean) {
        mutedSessionId = if (muted) state.sessionId else 0L
        if (muted) {
            stopPlayback()
        } else {
            ensureForTimer(context, settings, state)
        }
    }

    @Synchronized
    fun stop() {
        stopPlayback()
        mutedSessionId = 0L
    }

    private fun stopPlayback() {
        val current = player
        player = null
        playingSessionId = 0L
        if (current != null) {
            runCatching { if (current.isPlaying) current.stop() }
            runCatching { current.release() }
        }
    }
}
