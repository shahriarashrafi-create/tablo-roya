package com.shahriar.gamify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.CalendarContract
import android.provider.Settings
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Persistence, migrations, timer state, and non-UI game core helpers.
 *
 * Step 1-A intentionally keeps behavior unchanged while removing SharedPreferences,
 * backup/migration, timer persistence and mission result logic from MainActivity.
 */
internal const val PREFS_NAME = "gamify_state_v1"
internal const val KEY_MISSIONS = "missions"
internal const val KEY_HISTORY = "mission_history"
internal const val KEY_PLAYER_LEVEL = "player_level"
internal const val KEY_PLAYER_XP = "player_xp"
internal const val KEY_PLAYER_NEXT_XP = "player_next_xp"
internal const val KEY_PLAYER_RANK = "player_rank"
internal const val KEY_PLAYER_RANK_PROGRESS = "player_rank_progress"
internal const val KEY_PLAYER_CHESTS = "player_chests"
internal const val KEY_PLAYER_COINS = "player_coins"
internal const val KEY_PLAYER_COMBO = "player_combo"
internal const val KEY_PLAYER_BEST_COMBO = "player_best_combo"
internal const val KEY_COMBO_EXPIRES_AT = "combo_expires_at"
internal const val COMBO_WINDOW_MS = 30L * 60L * 1000L
internal const val KEY_PLAYER_LOGIN_STREAK = "player_login_streak"
internal const val KEY_PLAYER_BEST_LOGIN_STREAK = "player_best_login_streak"
internal const val KEY_LAST_LOGIN_DATE = "last_login_date"
private const val KEY_FRESH_START_V113 = "fresh_start_v113_applied"
internal const val KEY_NOTIFICATIONS_CENTER = "notification_center"
internal const val KEY_SETTINGS_SOUND = "settings_sound"
internal const val KEY_SETTINGS_VIBRATION = "settings_vibration"
internal const val KEY_SETTINGS_NOTIFICATIONS = "settings_notifications"
internal const val KEY_SETTINGS_REDUCED_MOTION = "settings_reduced_motion"
internal const val KEY_SETTINGS_COMBO_BOOST = "settings_combo_boost"
internal const val KEY_SETTINGS_THEME = "settings_theme"
internal const val KEY_TIMER_ACTIVE = "timer_active"
internal const val KEY_TIMER_TITLE = "timer_title"
internal const val KEY_TIMER_MISSION_ID = "timer_mission_id"
internal const val KEY_TIMER_DURATION = "timer_duration"
internal const val KEY_TIMER_XP = "timer_xp"
internal const val KEY_TIMER_COINS = "timer_coins"
internal const val KEY_TIMER_RANK = "timer_rank"
internal const val KEY_TIMER_REPEAT = "timer_repeat"
internal const val KEY_TIMER_REMINDER_HOUR = "timer_reminder_hour"
internal const val KEY_TIMER_REMINDER_MINUTE = "timer_reminder_minute"
internal const val KEY_TIMER_SUBTASKS = "timer_subtasks"
internal const val KEY_TIMER_SUBTASK_CHECKS = "timer_subtask_checks"
internal const val KEY_SUBTASK_PROGRESS = "mission_subtask_progress"
internal const val KEY_LAST_DAILY_RESET_DATE = "last_daily_reset_date"
internal const val KEY_OWNED_REWARDS = "owned_rewards"
internal const val KEY_PERSONAL_REWARDS = "personal_rewards"
internal const val KEY_REWARD_REDEMPTIONS = "reward_redemptions"
internal const val KEY_LAST_REWARD_REDEEM_ID = "last_reward_redeem_id"
internal const val KEY_LAST_REWARD_REDEEM_AT = "last_reward_redeem_at"
internal const val KEY_DREAMBOARD_ITEMS = "dreamboard_items"
internal const val KEY_PROFILE_AVATAR = "profile_avatar"
internal const val KEY_PROFILE_TITLE = "profile_title"
internal const val KEY_PROFILE_FRAME = "profile_frame"
internal const val KEY_PROFILE_BADGE = "profile_badge"
internal const val KEY_CHALLENGE_CLAIMS = "challenge_claims"
internal const val KEY_ACHIEVEMENT_CLAIMS = "achievement_claims"
internal const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
internal const val KEY_ONBOARDING_NAME = "onboarding_name"
internal const val KEY_ONBOARDING_ACTIVE_START = "onboarding_active_start"
internal const val KEY_ONBOARDING_ACTIVE_END = "onboarding_active_end"
internal const val KEY_SCHEMA_VERSION = "schema_version"
internal const val KEY_TIMER_SESSION = "timer_session"
internal const val KEY_LAST_COMPLETED_SESSION = "last_completed_session"
internal const val KEY_COMPLETED_MISSION_SESSIONS = "completed_mission_sessions"
internal const val CURRENT_SCHEMA_VERSION = 19
internal const val KEY_TIMER_REMAINING = "timer_remaining"
internal const val KEY_TIMER_END_AT = "timer_end_at"
internal const val KEY_TIMER_RUNNING = "timer_running"
internal const val KEY_TIMER_END_ELAPSED = "timer_end_elapsed"
internal const val KEY_TIMER_BOOT_COUNT = "timer_boot_count"
internal const val TIMER_REQUEST_CODE = 7142

private val RETIRED_PREF_KEYS = setOf(
    "onboarding_goal",
    "timer_deadline_hour",
    "timer_deadline_minute",
    "timer_notes",
    KEY_LAST_COMPLETED_SESSION
)

private val EPHEMERAL_PREF_KEYS = setOf(
    KEY_LAST_REWARD_REDEEM_ID,
    KEY_LAST_REWARD_REDEEM_AT,
    KEY_COMBO_EXPIRES_AT,
    KEY_SCHEDULED_REMINDER_IDS,
    KEY_EXTERNAL_MISSION_RESULT_REVISION
)

private fun isBackupEligibleKey(key: String): Boolean =
    !key.startsWith("timer_") && key !in RETIRED_PREF_KEYS && key !in EPHEMERAL_PREF_KEYS

internal fun defaultMission(): Mission = Mission(
    title = "۴۵ دقیقه تمرکز",
    durationMinutes = 45,
    xpReward = 50,
    coinReward = 20
)

internal fun isOnboardingComplete(context: Context): Boolean =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_ONBOARDING_COMPLETE, false)

internal fun loadOnboardingProfile(context: Context): OnboardingProfile {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return OnboardingProfile(
        name = prefs.getString(KEY_ONBOARDING_NAME, "Player") ?: "Player",
        activeStart = prefs.getString(KEY_ONBOARDING_ACTIVE_START, "07:00") ?: "07:00",
        activeEnd = prefs.getString(KEY_ONBOARDING_ACTIVE_END, "23:00") ?: "23:00"
    )
}

internal fun saveOnboardingProfile(context: Context, profile: OnboardingProfile) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_ONBOARDING_NAME, profile.name.trim().ifBlank { "Player" }.take(40))
        .putString(KEY_ONBOARDING_ACTIVE_START, profile.activeStart.take(5))
        .putString(KEY_ONBOARDING_ACTIVE_END, profile.activeEnd.take(5))
        .putBoolean(KEY_ONBOARDING_COMPLETE, true)
        .apply()
}

internal fun personalLeague(history: List<MissionHistoryEntry>): String {
    val today = LocalDate.now()
    val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val done = history.count { it.result == MissionResult.Done && !it.localDate().isBefore(weekStart) && !it.localDate().isAfter(today) }
    return when {
        done >= 20 -> "Mythic"
        done >= 14 -> "Diamond"
        done >= 9 -> "Gold"
        done >= 5 -> "Silver"
        else -> "Bronze"
    }
}

internal fun addMissionToCalendar(context: Context, mission: Mission): Boolean = runCatching {
    val start = System.currentTimeMillis() + 5 * 60 * 1000L
    val end = start + mission.durationMinutes.coerceAtLeast(1) * 60_000L
    val intent = Intent(Intent.ACTION_INSERT).apply {
        data = CalendarContract.Events.CONTENT_URI
        putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
        putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
        putExtra(CalendarContract.Events.TITLE, mission.title)
        putExtra(CalendarContract.Events.DESCRIPTION, "Gamification mission • +${mission.xpReward} XP • +${mission.coinReward} Coins")
    }
    context.startActivity(intent)
}.isSuccess

internal fun runDataHealthCheck(context: Context): String {
    val now = System.currentTimeMillis()
    val missions = normalizeMissionIdentities(loadMissions(context).map { mission ->
        mission.copy(
            title = mission.title.trim().ifBlank { "Mission" }.take(80),
            durationMinutes = mission.durationMinutes.coerceIn(1, 720),
            xpReward = mission.xpReward.coerceIn(0, 100_000),
            coinReward = mission.coinReward.coerceIn(0, 100_000)
        )
    }.ifEmpty { listOf(defaultMission()) }.take(100))
    val missionIdByTitle = missions.groupBy { it.title }.mapValues { it.value.first().id }
    val history = loadHistory(context)
        .filter { it.timestamp in 1..(now + 86_400_000L) }
        .map { entry ->
            entry.copy(
                missionTitle = entry.missionTitle.take(80),
                plannedMinutes = entry.plannedMinutes.coerceIn(0, 1440),
                focusSeconds = entry.focusSeconds.coerceIn(0, 86_400),
                missionId = entry.missionId.ifBlank { missionIdByTitle[entry.missionTitle].orEmpty() }
            )
        }
        .distinctBy { if (it.sessionId > 0L) "session:${it.sessionId}" else "${it.timestamp}|${it.missionId}|${it.missionTitle}|${it.result}" }
        .take(500)
    val notifications = loadNotifications(context).distinctBy { it.id }.take(100)
    saveMissions(context, missions)
    saveHistory(context, history)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putStringSet(
            KEY_COMPLETED_MISSION_SESSIONS,
            history.asSequence().map { it.sessionId }.filter { it > 0L }.take(200).map { it.toString() }.toSet()
        )
        .apply()
    saveNotifications(context, notifications)
    savePlayer(context, loadPlayer(context))
    saveSettings(context, loadSettings(context))
    savePersonalRewards(context, loadPersonalRewards(context))
    val safeDreams = loadDreamItems(context)
    saveDreamItems(context, safeDreams)
    pruneOwnedDreamImages(context, safeDreams)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION).apply()
    GamifyWidgetProvider.updateAll(context)
    return "Healthy • ${missions.size} missions • ${history.size} history entries"
}

internal fun loadSettings(context: Context): GameSettings {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val theme = runCatching {
        AppThemeMode.valueOf(prefs.getString(KEY_SETTINGS_THEME, AppThemeMode.Midnight.name) ?: AppThemeMode.Midnight.name)
    }.getOrDefault(AppThemeMode.Midnight)
    return GameSettings(
        soundEnabled = prefs.getBoolean(KEY_SETTINGS_SOUND, true),
        vibrationEnabled = prefs.getBoolean(KEY_SETTINGS_VIBRATION, true),
        notificationsEnabled = prefs.getBoolean(KEY_SETTINGS_NOTIFICATIONS, true),
        treeStatsReminderEnabled = prefs.getBoolean(KEY_TREE_STATS_REMINDER_ENABLED, true),
        treeStatsReminderHour = prefs.getInt(KEY_TREE_STATS_REMINDER_HOUR, 22).coerceIn(0, 23),
        treeStatsReminderMinute = prefs.getInt(KEY_TREE_STATS_REMINDER_MINUTE, 0).coerceIn(0, 59),
        reducedMotion = prefs.getBoolean(KEY_SETTINGS_REDUCED_MOTION, false),
        comboBoostEnabled = prefs.getBoolean(KEY_SETTINGS_COMBO_BOOST, true),
        themeMode = theme
    )
}

internal fun saveSettings(context: Context, settings: GameSettings) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_SETTINGS_SOUND, settings.soundEnabled)
        .putBoolean(KEY_SETTINGS_VIBRATION, settings.vibrationEnabled)
        .putBoolean(KEY_SETTINGS_NOTIFICATIONS, settings.notificationsEnabled)
        .putBoolean(KEY_TREE_STATS_REMINDER_ENABLED, settings.treeStatsReminderEnabled)
        .putInt(KEY_TREE_STATS_REMINDER_HOUR, settings.treeStatsReminderHour.coerceIn(0, 23))
        .putInt(KEY_TREE_STATS_REMINDER_MINUTE, settings.treeStatsReminderMinute.coerceIn(0, 59))
        .putBoolean(KEY_SETTINGS_REDUCED_MOTION, settings.reducedMotion)
        .putBoolean(KEY_SETTINGS_COMBO_BOOST, settings.comboBoostEnabled)
        .putString(KEY_SETTINGS_THEME, settings.themeMode.name)
        .apply()
}

internal fun themeOverlay(mode: AppThemeMode): Color = when (mode) {
    AppThemeMode.Classic -> Color.Transparent
    AppThemeMode.Midnight -> Color(0x24112B4A)
    AppThemeMode.Obsidian -> Color(0x42000000)
}

internal val worldRegions = listOf(
    WorldRegion("Dawnfield", "Begin the journey", 1, Color(0x00FFFFFF)),
    WorldRegion("Ember Vale", "Build relentless momentum", 20, Color(0x161E5B78)),
    WorldRegion("Sky Citadel", "Master your systems", 40, Color(0x142F6B9A)),
    WorldRegion("Astral Reach", "Lead beyond limits", 60, Color(0x162F2A76)),
    WorldRegion("Eternal Crown", "Live at legendary level", 80, Color(0x18A46A18))
)

internal fun currentWorldRegion(level: Int): WorldRegion =
    worldRegions.lastOrNull { level >= it.minLevel } ?: worldRegions.first()

internal fun loadProfileLoadout(context: Context): ProfileLoadout {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return ProfileLoadout(
        avatar = prefs.getString(KEY_PROFILE_AVATAR, "crown") ?: "crown",
        title = prefs.getString(KEY_PROFILE_TITLE, "Pathfinder") ?: "Pathfinder",
        frame = prefs.getString(KEY_PROFILE_FRAME, "default") ?: "default",
        badge = prefs.getString(KEY_PROFILE_BADGE, "none") ?: "none"
    )
}

internal fun saveProfileLoadout(context: Context, loadout: ProfileLoadout) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_PROFILE_AVATAR, loadout.avatar)
        .putString(KEY_PROFILE_TITLE, loadout.title)
        .putString(KEY_PROFILE_FRAME, loadout.frame)
        .putString(KEY_PROFILE_BADGE, loadout.badge)
        .apply()
}

internal fun avatarGlyph(id: String): String = when (id) {
    "knight_avatar" -> "♞"
    "flame_avatar" -> "🔥"
    "star_avatar" -> "★"
    else -> "♛"
}

internal val shopRewards = listOf(
    ShopReward("focus_aura", "Focus Aura", "Golden mission glow", 250),
    ShopReward("elite_frame", "Elite Frame", "Premium profile frame", 500),
    ShopReward("midnight_crest", "Midnight Crest", "Rare progression badge", 750),
    ShopReward("knight_avatar", "Knight Avatar", "Equip a heroic profile avatar", 650),
    ShopReward("flame_avatar", "Flame Avatar", "A high-combo avatar", 900),
    ShopReward("legend_title", "Legend Title", "Equip the Legend profile title", 1000)
)

internal val defaultPersonalRewards = listOf(
    PersonalReward("coffee_break", "استراحت و قهوه", 100, reusable = true, position = 1),
    PersonalReward("dessert", "دسر یا بستنی", 200, reusable = true, position = 2),
    PersonalReward("free_time", "۳۰ دقیقه وقت آزاد", 250, reusable = true, position = 3),
    PersonalReward("favorite_meal", "غذای مورد علاقه", 400, reusable = true, position = 4),
    PersonalReward("movie_night", "شب فیلم", 500, reusable = true, position = 5),
    PersonalReward("book", "خرید کتاب", 700, position = 6),
    PersonalReward("small_gift", "یک هدیه کوچک برای خودم", 1000, position = 7),
    PersonalReward("cafe", "کافه یا رستوران", 1500, reusable = true, position = 8),
    PersonalReward("wanted_item", "خرید یک چیز مورد علاقه", 2500, position = 9),
    PersonalReward("big_reward", "جایزه بزرگ", 5000, position = 10)
)

internal val legacyPersonalRewardTitles = mapOf(
    "coffee_break" to "Coffee Break",
    "dessert" to "Dessert / Ice Cream",
    "free_time" to "30 Min Free Time",
    "favorite_meal" to "Favorite Meal",
    "movie_night" to "Movie Night",
    "book" to "Buy a Book",
    "small_gift" to "Small Gift for Myself",
    "cafe" to "Cafe / Restaurant",
    "wanted_item" to "Buy Something I Want",
    "big_reward" to "Big Personal Reward"
)
internal val localizedPersonalRewardTitles = defaultPersonalRewards.associate { it.id to it.title }

internal fun loadPersonalRewards(context: Context): List<PersonalReward> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_PERSONAL_REWARDS, null)
    if (raw.isNullOrBlank()) {
        savePersonalRewards(context, defaultPersonalRewards)
        return defaultPersonalRewards
    }
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val id = item.optString("id").ifBlank { "reward_${System.currentTimeMillis()}_$i" }
                val storedTitle = item.optString("title", "پاداش")
                val title = if (legacyPersonalRewardTitles[id] == storedTitle) {
                    localizedPersonalRewardTitles[id] ?: storedTitle
                } else storedTitle
                val reusable = if (item.has("reusable")) {
                    item.optBoolean("reusable", false)
                } else {
                    id in setOf("coffee_break", "dessert", "free_time", "favorite_meal", "movie_night", "cafe")
                }
                add(
                    PersonalReward(
                        id = id,
                        title = title,
                        price = item.optInt("price", 100).coerceAtLeast(1),
                        reusable = reusable,
                        completed = if (reusable) false else item.optBoolean("completed", false),
                        redeemCount = item.optInt("redeemCount", 0).coerceAtLeast(0),
                        position = item.optInt("position", i + 1).coerceAtLeast(1)
                    )
                )
            }
        }.let(RewardEngine::normalizePositions)
    }.getOrElse { defaultPersonalRewards }
}

private fun encodePersonalRewards(rewards: List<PersonalReward>): String {
    val array = JSONArray()
    RewardEngine.normalizePositions(rewards).forEach { reward ->
        val normalized = reward.copy(
            price = reward.price.coerceAtLeast(1),
            completed = if (reward.reusable) false else reward.completed,
            redeemCount = reward.redeemCount.coerceAtLeast(0),
            position = reward.position.coerceAtLeast(1)
        )
        array.put(
            JSONObject()
                .put("id", normalized.id)
                .put("title", normalized.title)
                .put("price", normalized.price)
                .put("reusable", normalized.reusable)
                .put("completed", normalized.completed)
                .put("redeemCount", normalized.redeemCount)
                .put("position", normalized.position)
        )
    }
    return array.toString()
}

internal fun savePersonalRewards(context: Context, rewards: List<PersonalReward>) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_PERSONAL_REWARDS, encodePersonalRewards(rewards))
        .apply()
}

private fun encodeRewardRedemptions(entries: List<RewardRedemptionEntry>): String {
    val array = JSONArray()
    entries.take(500).forEach { entry ->
        array.put(
            JSONObject()
                .put("transactionId", entry.transactionId)
                .put("timestamp", entry.timestamp)
                .put("rewardId", entry.rewardId)
                .put("rewardTitle", entry.rewardTitle)
                .put("price", entry.price)
                .put("reusable", entry.reusable)
                .put("balanceBefore", entry.balanceBefore)
                .put("balanceAfter", entry.balanceAfter)
        )
    }
    return array.toString()
}

internal fun loadRewardRedemptions(context: Context): List<RewardRedemptionEntry> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_REWARD_REDEMPTIONS, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val price = item.optInt("price", 0).coerceAtLeast(0)
                val before = item.optInt("balanceBefore", 0).coerceAtLeast(0)
                val after = item.optInt("balanceAfter", (before - price).coerceAtLeast(0)).coerceAtLeast(0)
                add(
                    RewardRedemptionEntry(
                        transactionId = item.optString("transactionId").ifBlank { "legacy_reward_${item.optLong("timestamp", 0L)}_$i" },
                        timestamp = item.optLong("timestamp", 0L).coerceAtLeast(0L),
                        rewardId = item.optString("rewardId", ""),
                        rewardTitle = item.optString("rewardTitle", "پاداش"),
                        price = price,
                        reusable = item.optBoolean("reusable", false),
                        balanceBefore = before,
                        balanceAfter = after
                    )
                )
            }
        }.filter { it.timestamp > 0L }.distinctBy { it.transactionId }.take(500)
    }.getOrElse { emptyList() }
}

private val rewardTransactionLock = Any()
private const val REWARD_REDEEM_DEBOUNCE_MS = 900L

/**
 * Atomically spends coins and updates the selected reward. The player balance,
 * reward state and redemption ledger are written in one SharedPreferences commit.
 */
internal fun redeemPersonalReward(
    context: Context,
    rewardId: String,
    now: Long = System.currentTimeMillis()
): RewardRedemptionCommit = synchronized(rewardTransactionLock) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val currentPlayer = loadPlayer(context)
    val currentRewards = loadPersonalRewards(context)
    val rewardIndex = currentRewards.indexOfFirst { it.id == rewardId }
    if (rewardIndex < 0) {
        return@synchronized RewardRedemptionCommit(
            status = RewardRedemptionStatus.InvalidReward,
            player = currentPlayer,
            rewards = currentRewards
        )
    }

    val lastRewardId = prefs.getString(KEY_LAST_REWARD_REDEEM_ID, "").orEmpty()
    val lastRedeemAt = prefs.getLong(KEY_LAST_REWARD_REDEEM_AT, 0L)
    if (lastRewardId == rewardId && now >= lastRedeemAt && now - lastRedeemAt < REWARD_REDEEM_DEBOUNCE_MS) {
        return@synchronized RewardRedemptionCommit(
            status = RewardRedemptionStatus.Duplicate,
            player = currentPlayer,
            rewards = currentRewards
        )
    }

    val decision = RewardEngine.redeem(currentPlayer, currentRewards[rewardIndex])
    if (decision.status != RewardRedemptionStatus.Success) {
        return@synchronized RewardRedemptionCommit(
            status = decision.status,
            player = currentPlayer,
            rewards = currentRewards
        )
    }

    val updatedRewards = currentRewards.toMutableList().also { it[rewardIndex] = decision.reward }
    val ledger = loadRewardRedemptions(context).toMutableList()
    val entry = RewardRedemptionEntry(
        transactionId = UUID.randomUUID().toString(),
        timestamp = now,
        rewardId = decision.reward.id,
        rewardTitle = decision.reward.title,
        price = decision.reward.price,
        reusable = decision.reward.reusable,
        balanceBefore = currentPlayer.coins,
        balanceAfter = decision.player.coins
    )
    ledger.add(0, entry)

    val committed = prefs.edit()
        .putInt(KEY_PLAYER_LEVEL, decision.player.level)
        .putInt(KEY_PLAYER_XP, decision.player.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, decision.player.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, decision.player.rank)
        .putInt(KEY_PLAYER_RANK_PROGRESS, decision.player.rankProgress)
        .putInt(KEY_PLAYER_CHESTS, decision.player.chests)
        .putInt(KEY_PLAYER_COINS, decision.player.coins)
        .putInt(KEY_PLAYER_COMBO, decision.player.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, decision.player.bestCombo)
        .putInt(KEY_PLAYER_LOGIN_STREAK, decision.player.loginStreak)
        .putInt(KEY_PLAYER_BEST_LOGIN_STREAK, decision.player.bestLoginStreak)
        .putString(KEY_PERSONAL_REWARDS, encodePersonalRewards(updatedRewards))
        .putString(KEY_REWARD_REDEMPTIONS, encodeRewardRedemptions(ledger))
        .putString(KEY_LAST_REWARD_REDEEM_ID, rewardId)
        .putLong(KEY_LAST_REWARD_REDEEM_AT, now)
        .commit()

    if (!committed) {
        return@synchronized RewardRedemptionCommit(
            status = RewardRedemptionStatus.StorageFailure,
            player = currentPlayer,
            rewards = currentRewards
        )
    }

    GamifyWidgetProvider.updateAll(context)
    RewardRedemptionCommit(
        status = RewardRedemptionStatus.Success,
        player = decision.player,
        rewards = updatedRewards,
        entry = entry
    )
}

internal fun loadDreamItems(context: Context): List<DreamItem> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_DREAMBOARD_ITEMS, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        val decoded = buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    DreamItem(
                        id = item.optString("id").ifBlank { "dream_$i" },
                        title = item.optString("title", ""),
                        year = item.optString("year", ""),
                        price = item.optString("price", ""),
                        imageUri = item.optString("imageUri", ""),
                        position = item.optInt("position", i)
                    )
                )
            }
        }
        val repaired = decoded.map { dream ->
            if (dream.imageUri.isBlank()) {
                dream
            } else {
                val parsed = runCatching { Uri.parse(dream.imageUri) }.getOrNull()
                if (parsed?.scheme == "file") {
                    val source = parsed.path?.let(::File)
                    if (source != null && !source.exists()) {
                        val candidate = File(File(context.filesDir, "dreamboard"), source.name)
                        if (candidate.exists()) dream.copy(imageUri = Uri.fromFile(candidate).toString()) else dream
                    } else {
                        dream
                    }
                } else {
                    dream
                }
            }
        }
        DreamboardEngine.normalize(repaired)
    }.getOrElse { emptyList() }
}

internal fun saveDreamItems(context: Context, dreams: List<DreamItem>) {
    val array = JSONArray()
    DreamboardEngine.normalize(dreams).forEach { dream ->
        array.put(
            JSONObject()
                .put("id", dream.id)
                .put("title", dream.title)
                .put("year", dream.year)
                .put("price", dream.price)
                .put("imageUri", dream.imageUri)
                .put("position", dream.position)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_DREAMBOARD_ITEMS, array.toString())
        .apply()
}

internal fun loadDreamBitmap(context: Context, uriString: String) = runCatching {
    if (uriString.isBlank()) return@runCatching null
    context.contentResolver.openInputStream(Uri.parse(uriString))?.use { stream ->
        BitmapFactory.decodeStream(stream)?.asImageBitmap()
    }
}.getOrNull()

internal fun loadDreamSourceBitmap(context: Context, uriString: String): Bitmap? = runCatching {
    if (uriString.isBlank()) return@runCatching null
    val uri = Uri.parse(uriString)
    if (uri.scheme == "file") {
        BitmapFactory.decodeFile(uri.path)
    } else {
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    }
}.getOrNull()

/**
 * Creates a deliberately low-detail, soft backdrop from the active Dreamboard image.
 * Downscaling then upscaling gives us a cross-version blur effect without relying on
 * Android 12 RenderEffect, so it also works on the app's minSdk 26 devices.
 */
internal fun loadDreamBackdropBitmap(context: Context, uriString: String) = runCatching {
    val source = loadDreamSourceBitmap(context, uriString) ?: return@runCatching null
    val tiny = Bitmap.createScaledBitmap(source, 28, 50, true)
    val soft = Bitmap.createScaledBitmap(tiny, 252, 448, true)
    if (source !== tiny) source.recycle()
    if (tiny !== soft) tiny.recycle()
    soft.asImageBitmap()
}.getOrNull()

internal fun saveDreamCrop(
    context: Context,
    source: Bitmap,
    viewport: IntSize,
    userScale: Float,
    offset: Offset
): String? = runCatching {
    if (viewport.width <= 0 || viewport.height <= 0) return@runCatching null
    val baseScale = max(
        viewport.width.toFloat() / source.width.toFloat(),
        viewport.height.toFloat() / source.height.toFloat()
    )
    val effectiveScale = (baseScale * userScale).coerceAtLeast(0.0001f)
    val cropW = (viewport.width / effectiveScale).coerceAtMost(source.width.toFloat())
    val cropH = (viewport.height / effectiveScale).coerceAtMost(source.height.toFloat())
    val centerX = source.width / 2f - offset.x / effectiveScale
    val centerY = source.height / 2f - offset.y / effectiveScale
    val left = (centerX - cropW / 2f).coerceIn(0f, (source.width - cropW).coerceAtLeast(0f))
    val top = (centerY - cropH / 2f).coerceIn(0f, (source.height - cropH).coerceAtLeast(0f))
    val x = left.roundToInt().coerceIn(0, source.width - 1)
    val y = top.roundToInt().coerceIn(0, source.height - 1)
    val w = cropW.roundToInt().coerceIn(1, source.width - x)
    val h = cropH.roundToInt().coerceIn(1, source.height - y)
    val cropped = Bitmap.createBitmap(source, x, y, w, h)
    val output = Bitmap.createScaledBitmap(cropped, 900, 1600, true)
    val dir = File(context.filesDir, "dreamboard").apply { mkdirs() }
    val file = File(dir, "dream_${System.currentTimeMillis()}_${System.nanoTime()}.jpg")
    FileOutputStream(file).use { out -> output.compress(Bitmap.CompressFormat.JPEG, 92, out) }
    if (output !== cropped) output.recycle()
    if (cropped !== source) cropped.recycle()
    Uri.fromFile(file).toString()
}.getOrNull()

internal fun deleteOwnedDreamImageIfUnused(
    context: Context,
    uriString: String,
    remainingDreams: List<DreamItem>
): Boolean = runCatching {
    if (uriString.isBlank()) return@runCatching false
    val uri = Uri.parse(uriString)
    if (uri.scheme != "file") return@runCatching false
    val file = uri.path?.let(::File)?.canonicalFile ?: return@runCatching false
    val dreamDir = File(context.filesDir, "dreamboard").canonicalFile
    val isOwned = file.path.startsWith(dreamDir.path + File.separator)
    if (!isOwned || !file.exists()) return@runCatching false
    val stillReferenced = remainingDreams.any { dream ->
        val remainingUri = runCatching { Uri.parse(dream.imageUri) }.getOrNull()
        remainingUri?.scheme == "file" && remainingUri.path?.let(::File)?.canonicalFile == file
    }
    if (stillReferenced) return@runCatching false
    file.delete()
}.getOrDefault(false)

internal fun pruneOwnedDreamImages(context: Context, dreams: List<DreamItem>) {
    val referenced = dreams.mapNotNull { dream ->
        val uri = runCatching { Uri.parse(dream.imageUri) }.getOrNull() ?: return@mapNotNull null
        if (uri.scheme != "file") return@mapNotNull null
        uri.path?.let(::File)?.canonicalFile?.path
    }.toSet()
    val dir = File(context.filesDir, "dreamboard")
    dir.listFiles()?.forEach { file ->
        runCatching {
            if (file.isFile && file.canonicalPath !in referenced) file.delete()
        }
    }
}

internal fun loadStringSet(context: Context, key: String): Set<String> =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getStringSet(key, emptySet())?.toSet() ?: emptySet()

internal fun saveStringSet(context: Context, key: String, values: Set<String>) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putStringSet(key, values).apply()
}

internal val missionTemplates = listOf(
    MissionTemplate("room_tidy", "مرتب کردن اتاق", "Daily", Mission("مرتب کردن اتاق", 15, 20, 10, repeat = MissionRepeat.Daily)),
    MissionTemplate("face_grooming", "اصلاح صورت", "Daily", Mission("اصلاح صورت", 15, 20, 10, repeat = MissionRepeat.Daily)),
    MissionTemplate("morning_exercise", "نرمش صبحگاهی", "Daily", Mission("نرمش صبحگاهی", 20, 25, 12, repeat = MissionRepeat.Daily)),
    MissionTemplate("morning_routine", "روتین صبح", "Daily", Mission("روتین صبح", 30, 35, 15, repeat = MissionRepeat.Daily)),
    MissionTemplate("long_term_goal", "هدف بلندمدت", "Daily", Mission("هدف بلندمدت", 30, 40, 18, repeat = MissionRepeat.Daily)),
    MissionTemplate("tree_work", "درختواره", "Daily", Mission("درختواره", 30, 40, 18, repeat = MissionRepeat.Daily)),
    MissionTemplate("time_schedule", "برنامه زمانی", "Daily", Mission("برنامه زمانی", 20, 28, 12, repeat = MissionRepeat.Daily)),
    MissionTemplate("record_breakers", "گروه رکوردشکن", "Daily", Mission("گروه رکوردشکن", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("work_groups", "گروه‌های کاری", "Daily", Mission("گروه‌های کاری", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("ideas_creativity", "ایده‌ها و خلاقیت‌ها", "Daily", Mission("ایده‌ها و خلاقیت‌ها", 30, 40, 18, repeat = MissionRepeat.Daily)),
    MissionTemplate("scenario_ai", "سناریو و AI", "Daily", Mission("سناریو و AI", 35, 45, 20, repeat = MissionRepeat.Daily)),
    MissionTemplate("execute_ideas", "انجام ایده‌ها", "Daily", Mission("انجام ایده‌ها", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("team_encouragement", "تشویق سازمان", "Daily", Mission("تشویق سازمان", 20, 28, 12, repeat = MissionRepeat.Daily)),
    MissionTemplate("team_followup", "پیگیری سازمان", "Daily", Mission("پیگیری سازمان", 30, 40, 18, repeat = MissionRepeat.Daily)),
    MissionTemplate("networking", "ارتباط‌سازی", "Daily", Mission("ارتباط‌سازی", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("pre_consultation", "پیش‌مشاوره", "Daily", Mission("پیش‌مشاوره", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("work_invite", "دعوت به کار", "Daily", Mission("دعوت به کار", 20, 30, 14, repeat = MissionRepeat.Daily)),
    MissionTemplate("product_intro", "معرفی محصول", "Daily", Mission("معرفی محصول", 20, 30, 14, repeat = MissionRepeat.Daily)),
    MissionTemplate("show_off", "شوآف", "Daily", Mission("شوآف", 20, 28, 12, repeat = MissionRepeat.Daily)),
    MissionTemplate("training", "آموزش دیدن", "Daily", Mission("آموزش دیدن", 30, 38, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("team_stats", "نوشتن آمار سازمان", "Daily", Mission("نوشتن آمار سازمان", 25, 35, 16, repeat = MissionRepeat.Daily)),
    MissionTemplate("night_routine", "روتین شب", "Daily", Mission("روتین شب", 25, 32, 14, repeat = MissionRepeat.Daily)),
    MissionTemplate("affirm_command", "فرمان دادن", "Daily", Mission("فرمان دادن", 15, 22, 10, repeat = MissionRepeat.Daily)),
    MissionTemplate("reading", "کتاب خواندن", "Daily", Mission("کتاب خواندن", 30, 40, 18, repeat = MissionRepeat.Daily)),
    MissionTemplate("hold_meeting", "جلسه برگزار کردن", "Daily", Mission("جلسه برگزار کردن", 45, 60, 24, repeat = MissionRepeat.Daily))
)


internal fun loadNotifications(context: Context): List<GameNotification> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_NOTIFICATIONS_CENTER, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    GameNotification(
                        id = item.optString("id", "n:$i"),
                        glyph = item.optString("glyph", "✦"),
                        title = item.optString("title", "Update"),
                        body = item.optString("body", ""),
                        timestamp = item.optLong("timestamp", System.currentTimeMillis()),
                        read = item.optBoolean("read", false)
                    )
                )
            }
        }
    }.getOrElse { emptyList() }
}

internal fun saveNotifications(context: Context, notifications: List<GameNotification>) {
    val array = JSONArray()
    notifications.take(100).forEach { n ->
        array.put(
            JSONObject()
                .put("id", n.id)
                .put("glyph", n.glyph)
                .put("title", n.title)
                .put("body", n.body)
                .put("timestamp", n.timestamp)
                .put("read", n.read)
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_NOTIFICATIONS_CENTER, array.toString())
        .apply()
}

internal fun applyDailyLogin(context: Context, player: PlayerState): DailyLoginEvent? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val today = LocalDate.now()
    val last = prefs.getString(KEY_LAST_LOGIN_DATE, null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    if (last == today) return null
    val streak = if (last == today.minusDays(1)) player.loginStreak + 1 else 1
    val milestoneBonus = when (streak) {
        3 -> 50
        7 -> 100
        14 -> 200
        30 -> 500
        else -> 0
    }
    val reward = 10 + milestoneBonus
    val milestone = if (milestoneBonus > 0) "$streak DAY MILESTONE" else null
    val updated = player.copy(
        coins = player.coins + reward,
        loginStreak = streak,
        bestLoginStreak = maxOf(player.bestLoginStreak, streak)
    )
    prefs.edit().putString(KEY_LAST_LOGIN_DATE, today.toString()).apply()
    savePlayer(context, updated)
    return DailyLoginEvent(streak, reward, milestone, updated)
}

internal fun recurrenceTimeText(mission: Mission): String =
    if (mission.reminderHour in 0..23 && mission.reminderMinute in 0..59)
        String.format(Locale.US, "%02d:%02d", mission.reminderHour, mission.reminderMinute)
    else ""

internal fun missionRecurrenceSummary(mission: Mission): String {
    val base = if (mission.repeat == MissionRepeat.Daily) "DAILY" else ""
    val time = recurrenceTimeText(mission)
    return listOf(base, time).filter { it.isNotBlank() }.joinToString(" • ")
}

internal fun isMissionScheduledToday(mission: Mission, date: LocalDate = LocalDate.now()): Boolean =
    mission.repeat == MissionRepeat.Daily

internal fun missionSubtaskProgressKey(mission: Mission, date: LocalDate = LocalDate.now()): String {
    val identity = mission.id.ifBlank { mission.title }
    return if (mission.repeat == MissionRepeat.Daily) "$identity|$date" else "$identity|once"
}

private fun legacyMissionSubtaskProgressKey(mission: Mission, date: LocalDate = LocalDate.now()): String =
    if (mission.repeat == MissionRepeat.Daily) "${mission.title}|$date" else "${mission.title}|once"

internal fun loadMissionSubtaskChecks(context: Context, mission: Mission): List<Boolean> {
    if (mission.subtasks.isEmpty()) return emptyList()
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}"
    return runCatching {
        val root = JSONObject(raw)
        val primaryKey = missionSubtaskProgressKey(mission)
        val legacyKey = legacyMissionSubtaskProgressKey(mission)
        val array = root.optJSONArray(primaryKey) ?: root.optJSONArray(legacyKey) ?: JSONArray()
        List(mission.subtasks.size) { index -> if (index < array.length()) array.optBoolean(index, false) else false }
    }.getOrDefault(List(mission.subtasks.size) { false })
}

internal fun saveMissionSubtaskChecks(context: Context, mission: Mission, checks: List<Boolean>) {
    if (mission.subtasks.isEmpty()) return
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val root = runCatching { JSONObject(prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}") }.getOrDefault(JSONObject())
    root.put(
        missionSubtaskProgressKey(mission),
        JSONArray().apply { mission.subtasks.indices.forEach { index -> put(checks.getOrElse(index) { false }) } }
    )
    prefs.edit().putString(KEY_SUBTASK_PROGRESS, root.toString()).apply()
}

internal fun migrateSubtaskProgressToMissionIds(context: Context, missions: List<Mission>) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val root = runCatching { JSONObject(prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}") }.getOrDefault(JSONObject())
    if (root.length() == 0) return
    val keys = buildList { root.keys().forEach { add(it) } }
    var changed = false
    missions.filter { it.id.isNotBlank() }.forEach { mission ->
        val legacyPrefix = "${mission.title}|"
        keys.filter { it.startsWith(legacyPrefix) }.forEach { oldKey ->
            val suffix = oldKey.removePrefix(mission.title)
            val newKey = mission.id + suffix
            if (!root.has(newKey)) {
                root.put(newKey, root.optJSONArray(oldKey) ?: JSONArray())
                changed = true
            }
        }
    }
    if (changed) prefs.edit().putString(KEY_SUBTASK_PROGRESS, root.toString()).apply()
}

internal fun performDailyResetIfNeeded(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val today = LocalDate.now().toString()
    val last = prefs.getString(KEY_LAST_DAILY_RESET_DATE, null)
    if (last == null) {
        prefs.edit().putString(KEY_LAST_DAILY_RESET_DATE, today).apply()
        return
    }
    if (last == today) return
    loadActiveTimer(context)?.takeIf { it.mission.repeat == MissionRepeat.Daily }?.let { clearActiveTimer(context) }
    val progressRoot = runCatching { JSONObject(prefs.getString(KEY_SUBTASK_PROGRESS, "{}") ?: "{}") }.getOrDefault(JSONObject())
    val cleaned = JSONObject()
    progressRoot.keys().forEach { key ->
        if (key.endsWith("|once") || key.endsWith("|$today")) cleaned.put(key, progressRoot.optJSONArray(key) ?: JSONArray())
    }
    prefs.edit()
        .putString(KEY_SUBTASK_PROGRESS, cleaned.toString())
        .putString(KEY_LAST_DAILY_RESET_DATE, today)
        .apply()
}

internal fun buildChallenges(history: List<MissionHistoryEntry>): List<Challenge> {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val todayEntries = history.filter { it.localDate(zone) == today }
    val weekEntries = history.filter { !it.localDate(zone).isBefore(weekStart) && !it.localDate(zone).isAfter(today) }
    val todayDone = todayEntries.count { it.result == MissionResult.Done }
    val todayMinutes = todayEntries.sumOf { it.focusSeconds } / 60
    val weekDone = weekEntries.count { it.result == MissionResult.Done }
    return listOf(
        Challenge("daily:$today:done3", "3 Missions Today", "Finish three missions", todayDone, 3, 120, 60, false),
        Challenge("daily:$today:focus90", "90 Focus Minutes", "Build a focused day", todayMinutes, 90, 150, 75, false),
        Challenge("weekly:$weekStart:done10", "10 Missions This Week", "Weekly consistency challenge", weekDone, 10, 350, 180, true)
    )
}

internal fun buildAchievements(player: PlayerState, history: List<MissionHistoryEntry>): List<Achievement> {
    val done = history.count { it.result == MissionResult.Done }
    val focusMinutes = history.sumOf { it.focusSeconds } / 60
    return listOf(
        Achievement("first_mission", "First Mission", "Complete your first mission", "✦", done, 1, 80, 40),
        Achievement("mission_10", "Momentum", "Complete 10 missions", "◆", done, 10, 180, 90),
        Achievement("focus_10h", "Deep Worker", "Accumulate 10 hours of focus", "◷", focusMinutes, 600, 250, 120),
        Achievement("combo_10", "Unbroken", "Reach a Combo of 10", "🔥", player.bestCombo, 10, 220, 110),
        Achievement("rank_10", "Rising Rank", "Reach Rank 10", "♜", player.rank, 10, 300, 150),
        Achievement("level_50", "Level 50", "Reach Level 50", "★", player.level, 50, 500, 250)
    )
}

internal fun loadActiveTimer(context: Context): ActiveTimerState? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    if (!prefs.getBoolean(KEY_TIMER_ACTIVE, false)) return null
    val persistedMission = Mission(
        title = prefs.getString(KEY_TIMER_TITLE, "Mission") ?: "Mission",
        durationMinutes = prefs.getInt(KEY_TIMER_DURATION, 45).coerceAtLeast(1),
        xpReward = prefs.getInt(KEY_TIMER_XP, 50).coerceAtLeast(0),
        coinReward = prefs.getInt(KEY_TIMER_COINS, 20).coerceAtLeast(0),
        isRankMission = prefs.getBoolean(KEY_TIMER_RANK, false),
        repeat = if ((prefs.getString(KEY_TIMER_REPEAT, MissionRepeat.None.name) ?: MissionRepeat.None.name) == MissionRepeat.None.name) MissionRepeat.None else MissionRepeat.Daily,
        reminderHour = prefs.getInt(KEY_TIMER_REMINDER_HOUR, -1).takeIf { it in 0..23 } ?: -1,
        reminderMinute = prefs.getInt(KEY_TIMER_REMINDER_MINUTE, -1).takeIf { it in 0..59 } ?: -1,
        subtasks = runCatching {
            val array = JSONArray(prefs.getString(KEY_TIMER_SUBTASKS, "[]") ?: "[]")
            buildList {
                for (i in 0 until array.length()) {
                    val value = array.optString(i, "").trim()
                    if (value.isNotEmpty()) add(value.take(120))
                }
            }
        }.getOrDefault(emptyList()),
        id = prefs.getString(KEY_TIMER_MISSION_ID, "") ?: ""
    )
    val mission = if (persistedMission.id.isNotBlank()) {
        persistedMission
    } else {
        val matchingId = loadMissions(context).firstOrNull { it.title == persistedMission.title }?.id.orEmpty()
        persistedMission.copy(id = matchingId)
    }
    val checkedSubtasks = runCatching {
        val array = JSONArray(prefs.getString(KEY_TIMER_SUBTASK_CHECKS, "[]") ?: "[]")
        List(mission.subtasks.size) { index -> if (index < array.length()) array.optBoolean(index, false) else false }
    }.getOrDefault(List(mission.subtasks.size) { false })
    return ActiveTimerState(
        mission = mission,
        remainingSeconds = prefs.getInt(KEY_TIMER_REMAINING, mission.durationMinutes * 60).coerceAtLeast(0),
        endAtMillis = prefs.getLong(KEY_TIMER_END_AT, 0L),
        isRunning = prefs.getBoolean(KEY_TIMER_RUNNING, false),
        sessionId = prefs.getLong(KEY_TIMER_SESSION, 0L).takeIf { it > 0L }
            ?: (prefs.getLong(KEY_TIMER_END_AT, 0L) - prefs.getInt(KEY_TIMER_DURATION, 45).coerceAtLeast(1) * 60_000L).coerceAtLeast(1L),
        checkedSubtasks = checkedSubtasks,
        endAtElapsedRealtime = prefs.getLong(KEY_TIMER_END_ELAPSED, 0L).coerceAtLeast(0L),
        bootCount = prefs.getInt(KEY_TIMER_BOOT_COUNT, -1)
    )
}

internal fun saveActiveTimer(context: Context, state: ActiveTimerState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, true)
        .putString(KEY_TIMER_TITLE, state.mission.title)
        .putString(KEY_TIMER_MISSION_ID, state.mission.id)
        .putInt(KEY_TIMER_DURATION, state.mission.durationMinutes)
        .putInt(KEY_TIMER_XP, state.mission.xpReward)
        .putInt(KEY_TIMER_COINS, state.mission.coinReward)
        .putBoolean(KEY_TIMER_RANK, state.mission.isRankMission)
        .putString(KEY_TIMER_REPEAT, state.mission.repeat.name)
        .putInt(KEY_TIMER_REMINDER_HOUR, state.mission.reminderHour)
        .putInt(KEY_TIMER_REMINDER_MINUTE, state.mission.reminderMinute)
        .putString(KEY_TIMER_SUBTASKS, JSONArray().apply { state.mission.subtasks.forEach { put(it) } }.toString())
        .putString(KEY_TIMER_SUBTASK_CHECKS, JSONArray().apply { state.checkedSubtasks.forEach { put(it) } }.toString())
        .putInt(KEY_TIMER_REMAINING, state.remainingSeconds.coerceAtLeast(0))
        .putLong(KEY_TIMER_END_AT, state.endAtMillis)
        .putLong(KEY_TIMER_END_ELAPSED, state.endAtElapsedRealtime)
        .putInt(KEY_TIMER_BOOT_COUNT, state.bootCount)
        .putBoolean(KEY_TIMER_RUNNING, state.isRunning)
        .putLong(KEY_TIMER_SESSION, state.sessionId)
        .apply()
}

internal fun currentBootCount(context: Context): Int = runCatching {
    Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
}.getOrDefault(-1)

internal fun withRunningTimerDeadline(
    context: Context,
    state: ActiveTimerState,
    seconds: Int
): ActiveTimerState {
    val safeSeconds = seconds.coerceAtLeast(1)
    val durationMillis = safeSeconds * 1000L
    return state.copy(
        remainingSeconds = safeSeconds,
        endAtMillis = System.currentTimeMillis() + durationMillis,
        endAtElapsedRealtime = SystemClock.elapsedRealtime() + durationMillis,
        bootCount = currentBootCount(context),
        isRunning = true
    )
}

internal fun remainingSeconds(
    context: Context,
    state: ActiveTimerState,
    now: Long = System.currentTimeMillis(),
    elapsedNow: Long = SystemClock.elapsedRealtime()
): Int {
    if (!state.isRunning) return state.remainingSeconds.coerceAtLeast(0)
    val sameBoot = state.bootCount >= 0 && state.bootCount == currentBootCount(context)
    val remainingMillis = if (sameBoot && state.endAtElapsedRealtime > 0L) {
        state.endAtElapsedRealtime - elapsedNow
    } else {
        state.endAtMillis - now
    }
    if (remainingMillis <= 0L) return 0
    return ceil(remainingMillis / 1000.0).toInt().coerceAtLeast(0)
}

/**
 * Restores an active timer after process death/backgrounding. While the phone
 * remains on the same boot, elapsedRealtime is authoritative so manual wall
 * clock changes cannot stretch or finish the session. After a reboot, the
 * persisted RTC end timestamp becomes the recovery fallback.
 */
internal fun recoverActiveTimer(context: Context, now: Long = System.currentTimeMillis()): ActiveTimerState? {
    val state = loadActiveTimer(context) ?: return null
    if (state.sessionId > 0L && loadHistory(context).any { it.sessionId == state.sessionId }) {
        clearActiveTimer(context)
        return null
    }
    if (!state.isRunning) return state

    val bootNow = currentBootCount(context)
    val hasAuthoritativeElapsedDeadline =
        state.bootCount >= 0 && state.bootCount == bootNow && state.endAtElapsedRealtime > 0L
    val recoveredRemaining = remainingSeconds(context, state, now)

    if (recoveredRemaining > 0) {
        if (hasAuthoritativeElapsedDeadline) {
            // IMPORTANT: never move a live deadline forward merely because UI code
            // asks for the current timer state. Re-anchoring on every read (for
            // example every 500 ms on Home) can repeatedly round the remaining
            // seconds up and make the visible timer appear frozen.
            return state.copy(remainingSeconds = recoveredRemaining)
        }

        // We only rebuild the elapsedRealtime deadline after a reboot / legacy
        // state where that monotonic clock anchor is unavailable. From this point
        // on the same stored deadline remains authoritative until pause/finish.
        val recovered = withRunningTimerDeadline(context, state, recoveredRemaining)
        saveActiveTimer(context, recovered)
        return recovered
    }

    val finished = state.copy(
        remainingSeconds = 0,
        endAtMillis = 0L,
        isRunning = false,
        endAtElapsedRealtime = 0L,
        bootCount = -1
    )
    saveActiveTimer(context, finished)
    cancelTimerAlarm(context)
    return finished
}

internal fun timerPendingIntent(context: Context, sessionId: Long = 0L): PendingIntent = PendingIntent.getBroadcast(
    context,
    TIMER_REQUEST_CODE,
    Intent(context, TimerFinishReceiver::class.java).apply {
        putExtra(EXTRA_TIMER_SESSION_ID, sessionId)
    },
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

internal fun cancelTimerAlarm(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timerPendingIntent(context))
}

internal fun scheduleTimerAlarm(context: Context, state: ActiveTimerState, settings: GameSettings) {
    cancelTimerAlarm(context)
    if (!settings.notificationsEnabled || !state.isRunning || state.endAtMillis <= System.currentTimeMillis()) return
    scheduleReliableAlarm(context, state.endAtMillis, timerPendingIntent(context, state.sessionId))
}

internal fun beginActiveTimer(context: Context, mission: Mission, settings: GameSettings): ActiveTimerState {
    cancelTimerFinishedNotification(context)
    val total = (mission.durationMinutes * 60).coerceAtLeast(1)
    val base = ActiveTimerState(
        mission = mission,
        remainingSeconds = total,
        endAtMillis = 0L,
        isRunning = true,
        sessionId = System.currentTimeMillis(),
        checkedSubtasks = loadMissionSubtaskChecks(context, mission)
    )
    val state = withRunningTimerDeadline(context, base, total)
    saveActiveTimer(context, state)
    scheduleTimerAlarm(context, state, settings)
    MissionMusicController.ensureForTimer(context, settings, state)
    return state
}

internal fun clearActiveTimer(context: Context) {
    MissionMusicController.stop()
    cancelTimerAlarm(context)
    cancelTimerFinishedNotification(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_TIMER_ACTIVE, false)
        .remove(KEY_TIMER_END_AT)
        .remove(KEY_TIMER_MISSION_ID)
        .remove(KEY_TIMER_REMAINING)
        .remove(KEY_TIMER_RUNNING)
        .remove(KEY_TIMER_END_ELAPSED)
        .remove(KEY_TIMER_BOOT_COUNT)
        .remove(KEY_TIMER_SESSION)
        .remove(KEY_TIMER_SUBTASKS)
        .remove(KEY_TIMER_SUBTASK_CHECKS)
        .remove("timer_deadline_hour")
        .remove("timer_deadline_minute")
        .remove("timer_notes")
        .apply()
}

internal fun playResultFeedback(context: Context, settings: GameSettings, result: MissionResult, levelUp: Boolean) {
    if (settings.soundEnabled) {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
        val toneType = when {
            levelUp -> ToneGenerator.TONE_PROP_ACK
            result == MissionResult.Done -> ToneGenerator.TONE_PROP_BEEP2
            result == MissionResult.Partial -> ToneGenerator.TONE_PROP_BEEP
            else -> ToneGenerator.TONE_PROP_NACK
        }
        tone.startTone(toneType, if (levelUp) 260 else 150)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 320L)
    }
    if (settings.vibrationEnabled) {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val pattern = if (levelUp) longArrayOf(0, 45, 55, 90) else longArrayOf(0, 45)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (levelUp) 140L else 45L)
            }
        }
    }
}


internal fun applyFreshStartV113IfNeeded(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    if (prefs.getBoolean(KEY_FRESH_START_V113, false)) return

    // Keep the user's configured missions, tree, timesheet, dreamboard and settings,
    // but start the game/progression layer as a true new run.
    clearActiveTimer(context)
    prefs.edit()
        .remove(KEY_HISTORY)
        .remove(KEY_CHALLENGE_CLAIMS)
        .remove(KEY_ACHIEVEMENT_CLAIMS)
        .remove(KEY_COMPLETED_MISSION_SESSIONS)
        .remove(KEY_LAST_COMPLETED_SESSION)
        .remove(KEY_SUBTASK_PROGRESS)
        .remove(KEY_LAST_LOGIN_DATE)
        .remove(KEY_NOTIFICATIONS_CENTER)
        .putBoolean(KEY_FRESH_START_V113, true)
        .apply()
    savePlayer(context, PlayerState())
}

internal fun expireComboIfNeeded(context: Context): Boolean {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val deadline = prefs.getLong(KEY_COMBO_EXPIRES_AT, 0L)
    if (deadline <= 0L || System.currentTimeMillis() < deadline) return false
    val combo = prefs.getInt(KEY_PLAYER_COMBO, 0)
    val editor = prefs.edit().remove(KEY_COMBO_EXPIRES_AT)
    if (combo > 0) editor.putInt(KEY_PLAYER_COMBO, 0)
    val committed = editor.commit()
    if (committed && combo > 0) GamifyWidgetProvider.updateAll(context)
    return committed && combo > 0
}

internal fun comboWindowRemainingSeconds(
    context: Context,
    player: PlayerState,
    settings: GameSettings
): Int {
    if (!settings.comboBoostEnabled || comboMultiplier(player.combo) <= 1f) return 0
    val deadline = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getLong(KEY_COMBO_EXPIRES_AT, 0L)
    if (deadline <= 0L) return 0
    return ((deadline - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
}

internal fun loadPlayer(context: Context): PlayerState {
    expireComboIfNeeded(context)
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return normalizePlayerProgression(
        PlayerState(
            level = prefs.getInt(KEY_PLAYER_LEVEL, 1),
            currentXp = prefs.getInt(KEY_PLAYER_XP, 0),
            nextLevelXp = prefs.getInt(KEY_PLAYER_NEXT_XP, 500),
            rank = prefs.getInt(KEY_PLAYER_RANK, 1),
            rankProgress = prefs.getInt(KEY_PLAYER_RANK_PROGRESS, 0),
            coins = prefs.getInt(KEY_PLAYER_COINS, 0),
            combo = prefs.getInt(KEY_PLAYER_COMBO, 0),
            bestCombo = prefs.getInt(KEY_PLAYER_BEST_COMBO, 0),
            chests = prefs.getInt(KEY_PLAYER_CHESTS, 0),
            loginStreak = prefs.getInt(KEY_PLAYER_LOGIN_STREAK, 0),
            bestLoginStreak = prefs.getInt(KEY_PLAYER_BEST_LOGIN_STREAK, 0)
        )
    )
}

internal fun savePlayer(context: Context, player: PlayerState) {
    val safe = normalizePlayerProgression(player)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putInt(KEY_PLAYER_LEVEL, safe.level)
        .putInt(KEY_PLAYER_XP, safe.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, safe.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, safe.rank)
        .putInt(KEY_PLAYER_RANK_PROGRESS, safe.rankProgress)
        .putInt(KEY_PLAYER_CHESTS, safe.chests)
        .putInt(KEY_PLAYER_COINS, safe.coins)
        .putInt(KEY_PLAYER_COMBO, safe.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, safe.bestCombo)
        .putInt(KEY_PLAYER_LOGIN_STREAK, safe.loginStreak)
        .putInt(KEY_PLAYER_BEST_LOGIN_STREAK, safe.bestLoginStreak)
        .apply()
    if (safe.combo <= 0) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_COMBO_EXPIRES_AT).apply()
    }
    GamifyWidgetProvider.updateAll(context)
}

internal fun loadMissions(context: Context): List<Mission> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_MISSIONS, null) ?: return normalizeMissionIdentities(listOf(defaultMission()))
    return runCatching {
        val array = JSONArray(raw)
        normalizeMissionIdentities(buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    Mission(
                        title = item.optString("title", "New Mission"),
                        durationMinutes = item.optInt("durationMinutes", 45).coerceAtLeast(1),
                        xpReward = item.optInt("xpReward", 50).coerceAtLeast(0),
                        coinReward = item.optInt("coinReward", 20).coerceAtLeast(0),
                        isRankMission = item.optBoolean("isRankMission", false),
                        repeat = if (item.optString("repeat", MissionRepeat.None.name) == MissionRepeat.None.name) MissionRepeat.None else MissionRepeat.Daily,
                        reminderHour = item.optInt("reminderHour", -1).takeIf { it in 0..23 } ?: -1,
                        reminderMinute = item.optInt("reminderMinute", -1).takeIf { it in 0..59 } ?: -1,
                        subtasks = buildList {
                            val subtaskArray = item.optJSONArray("subtasks") ?: JSONArray()
                            for (j in 0 until subtaskArray.length()) {
                                val value = subtaskArray.optString(j, "").trim()
                                if (value.isNotEmpty()) add(value.take(120))
                            }
                        },
                        id = item.optString("id", "")
                    )
                )
            }
        })
    }.getOrElse { normalizeMissionIdentities(listOf(defaultMission())) }
}

internal fun saveMissions(context: Context, missions: List<Mission>) {
    val normalized = normalizeMissionIdentities(missions)
    val array = JSONArray()
    normalized.forEach { mission ->
        array.put(
            JSONObject()
                .put("id", mission.id)
                .put("title", mission.title)
                .put("durationMinutes", mission.durationMinutes)
                .put("xpReward", mission.xpReward)
                .put("coinReward", mission.coinReward)
                .put("isRankMission", mission.isRankMission)
                .put("repeat", mission.repeat.name)
                .put("reminderHour", mission.reminderHour)
                .put("reminderMinute", mission.reminderMinute)
                .put("subtasks", JSONArray().apply { mission.subtasks.forEach { put(it) } })
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_MISSIONS, array.toString())
        .apply()
    // Editing, deleting, reordering, or changing a reminder immediately
    // invalidates the previous PendingIntent set.
    rescheduleMissionReminders(context, normalized, loadHistory(context), loadSettings(context))
}

internal fun loadHistory(context: Context): List<MissionHistoryEntry> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val result = runCatching { MissionResult.valueOf(item.optString("result", "Done")) }
                    .getOrDefault(MissionResult.Done)
                add(
                    MissionHistoryEntry(
                        timestamp = item.optLong("timestamp", System.currentTimeMillis()),
                        missionTitle = item.optString("missionTitle", "Mission"),
                        plannedMinutes = item.optInt("plannedMinutes", 0),
                        focusSeconds = item.optInt("focusSeconds", 0).coerceAtLeast(0),
                        result = result,
                        xpEarned = item.optInt("xpEarned", 0).coerceAtLeast(0),
                        coinsEarned = item.optInt("coinsEarned", 0).coerceAtLeast(0),
                        levelRewardCoins = item.optInt("levelRewardCoins", 0).coerceAtLeast(0),
                        missionId = item.optString("missionId", ""),
                        sessionId = item.optLong("sessionId", 0L).coerceAtLeast(0L),
                        rankStepsEarned = item.optInt("rankStepsEarned", 0).coerceAtLeast(0),
                        chestsEarned = item.optInt("chestsEarned", 0).coerceAtLeast(0),
                        comboBefore = item.optInt("comboBefore", -1),
                        comboAfter = item.optInt("comboAfter", -1),
                        bestComboBefore = item.optInt("bestComboBefore", -1),
                        comboDeadlineBefore = item.optLong("comboDeadlineBefore", -1L)
                    )
                )
            }
        }
    }.getOrElse { emptyList() }
}

private fun encodeHistory(history: List<MissionHistoryEntry>): String {
    val array = JSONArray()
    history.take(500).forEach { entry ->
        array.put(
            JSONObject()
                .put("timestamp", entry.timestamp)
                .put("missionTitle", entry.missionTitle)
                .put("plannedMinutes", entry.plannedMinutes)
                .put("focusSeconds", entry.focusSeconds)
                .put("result", entry.result.name)
                .put("xpEarned", entry.xpEarned)
                .put("coinsEarned", entry.coinsEarned)
                .put("levelRewardCoins", entry.levelRewardCoins)
                .put("missionId", entry.missionId)
                .put("sessionId", entry.sessionId)
                .put("rankStepsEarned", entry.rankStepsEarned)
                .put("chestsEarned", entry.chestsEarned)
                .put("comboBefore", entry.comboBefore)
                .put("comboAfter", entry.comboAfter)
                .put("bestComboBefore", entry.bestComboBefore)
                .put("comboDeadlineBefore", entry.comboDeadlineBefore)
        )
    }
    return array.toString()
}

internal fun saveHistory(context: Context, history: List<MissionHistoryEntry>) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_HISTORY, encodeHistory(history))
        .apply()
    // A terminal result before today's reminder should push the next alarm to
    // tomorrow instead of allowing a stale reminder to wake later today.
    rescheduleMissionReminders(context, loadMissions(context), history, loadSettings(context))
}

private data class XpRollback(
    val level: Int,
    val currentXp: Int,
    val nextLevelXp: Int,
    val levelsLost: Int
)

private fun rollbackXp(player: PlayerState, xpToRemove: Int): XpRollback {
    var level = player.level.coerceAtLeast(1)
    var currentXp = player.currentXp.coerceAtLeast(0)
    var nextLevelXp = player.nextLevelXp.coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
    var remaining = xpToRemove.coerceAtLeast(0)
    var levelsLost = 0

    while (remaining > currentXp && level > 1) {
        remaining -= currentXp
        level -= 1
        nextLevelXp = (nextLevelXp - ProgressionRules.LEVEL_XP_STEP)
            .coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
        currentXp = nextLevelXp
        levelsLost += 1
    }
    currentXp = (currentXp - remaining).coerceAtLeast(0)
    return XpRollback(level, currentXp, nextLevelXp, levelsLost)
}

private data class RankRollback(
    val rank: Int,
    val rankProgress: Int,
    val ranksLost: Int
)

private fun rollbackRankSteps(player: PlayerState, stepsToRemove: Int): RankRollback {
    var rank = player.rank.coerceIn(1, ProgressionRules.MAX_RANK)
    var progress = player.rankProgress.coerceAtLeast(0)
    var ranksLost = 0
    repeat(stepsToRemove.coerceAtLeast(0)) {
        if (progress > 0) {
            progress -= 1
        } else if (rank > 1) {
            rank -= 1
            progress = (rankRequirement(rank) - 1).coerceAtLeast(0)
            ranksLost += 1
        }
    }
    return RankRollback(rank, progress, ranksLost)
}

/**
 * Restores a resolved mission card back to Active and reverses the progression
 * granted by that result. The history row is removed, so daily/non-daily card
 * state immediately becomes active again.
 */
internal fun restoreMissionResult(
    context: Context,
    mission: Mission,
    entry: MissionHistoryEntry
): PlayerState? = synchronized(missionResultLock) {
    if (entry.result == MissionResult.Defer) return@synchronized null

    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val historyBefore = loadHistory(context)
    val targetIndex = historyBefore.indexOfFirst { candidate ->
        if (entry.sessionId > 0L) {
            candidate.sessionId == entry.sessionId
        } else {
            candidate.timestamp == entry.timestamp &&
                candidate.missionTitle == entry.missionTitle &&
                candidate.result == entry.result
        }
    }
    if (targetIndex < 0) return@synchronized null

    val target = historyBefore[targetIndex]
    val historyAfter = historyBefore.filterIndexed { index, _ -> index != targetIndex }
    val current = loadPlayer(context)

    val xpRollback = rollbackXp(current, target.xpEarned)
    val inferredRankSteps = if (target.result == MissionResult.Done && mission.isRankMission) 1 else 0
    val rankSteps = if (target.rankStepsEarned > 0) target.rankStepsEarned else inferredRankSteps
    val rankRollback = rollbackRankSteps(current, rankSteps)
    val inferredLevelChests = (target.levelRewardCoins / ProgressionRules.LEVEL_UP_COIN_REWARD).coerceAtLeast(0)
    val chestsToRemove = if (target.chestsEarned > 0) {
        target.chestsEarned
    } else {
        inferredLevelChests + rankRollback.ranksLost
    }

    val hasLaterProgressionResult = historyBefore.any {
        it.timestamp > target.timestamp && it.result != MissionResult.Defer
    }
    var restoredCombo = current.combo
    var restoredBestCombo = current.bestCombo
    var restoreComboDeadline: Long? = null

    if (!hasLaterProgressionResult) {
        restoredCombo = when {
            target.comboBefore >= 0 -> target.comboBefore.coerceAtLeast(0)
            target.result == MissionResult.Done -> (current.combo - 1).coerceAtLeast(0)
            else -> current.combo
        }
        if (target.bestComboBefore >= 0 && target.comboAfter >= 0 && current.bestCombo <= target.comboAfter) {
            restoredBestCombo = max(target.bestComboBefore, restoredCombo)
        }

        if (target.comboDeadlineBefore >= 0L &&
            loadSettings(context).comboBoostEnabled &&
            comboMultiplier(restoredCombo) > 1f &&
            target.comboDeadlineBefore > System.currentTimeMillis()
        ) {
            restoreComboDeadline = target.comboDeadlineBefore
        } else if (target.comboBefore >= 0 && comboMultiplier(restoredCombo) > 1f) {
            // The prior combo window has already elapsed; do not resurrect it.
            restoredCombo = 0
        }
    }

    val restored = normalizePlayerProgression(
        current.copy(
            level = xpRollback.level,
            currentXp = xpRollback.currentXp,
            nextLevelXp = xpRollback.nextLevelXp,
            rank = rankRollback.rank,
            rankProgress = rankRollback.rankProgress,
            coins = (current.coins - target.coinsEarned).coerceAtLeast(0),
            combo = restoredCombo,
            bestCombo = max(restoredBestCombo, restoredCombo),
            chests = (current.chests - chestsToRemove).coerceAtLeast(0)
        )
    )

    val completedSessions = prefs.getStringSet(KEY_COMPLETED_MISSION_SESSIONS, emptySet())
        ?.toMutableSet() ?: mutableSetOf()
    if (target.sessionId > 0L) completedSessions.remove(target.sessionId.toString())

    val editor = prefs.edit()
        .putInt(KEY_PLAYER_LEVEL, restored.level)
        .putInt(KEY_PLAYER_XP, restored.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, restored.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, restored.rank)
        .putInt(KEY_PLAYER_RANK_PROGRESS, restored.rankProgress)
        .putInt(KEY_PLAYER_CHESTS, restored.chests)
        .putInt(KEY_PLAYER_COINS, restored.coins)
        .putInt(KEY_PLAYER_COMBO, restored.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, restored.bestCombo)
        .putString(KEY_HISTORY, encodeHistory(historyAfter))
        .putStringSet(KEY_COMPLETED_MISSION_SESSIONS, completedSessions)

    if (restoreComboDeadline != null) {
        editor.putLong(KEY_COMBO_EXPIRES_AT, restoreComboDeadline)
    } else if (!hasLaterProgressionResult || restored.combo <= 0) {
        editor.remove(KEY_COMBO_EXPIRES_AT)
    }

    if (!editor.commit()) return@synchronized null

    rescheduleMissionReminders(context, loadMissions(context), historyAfter, loadSettings(context))
    GamifyWidgetProvider.updateAll(context)
    restored
}

internal fun migrateState(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val current = prefs.getInt(KEY_SCHEMA_VERSION, 0)
    if (current >= CURRENT_SCHEMA_VERSION) return

    val legacyStarterTitles = mapOf(
        "Morning Routine" to "روتین صبح",
        "Long-Term Goal" to "هدف بلندمدت",
        "Work on the Genealogy" to "فکر روی ژینولوژی",
        "Timesheet" to "Time Sheet",
        "Record-Shekan, Work" to "گروه رکوردشکن و کاری",
        "Creativity, Scenario" to "خلاقیت و سناریو",
        "Team Follow-Up" to "Team Follow-UP",
        "Relation, Introduction" to "ارتباط‌سازی،معرفی",
        "Pre-Consultation & Invitation" to "پیش‌مشاوره،دعوت",
        "Write Team Statistics" to "نوشتن آمار",
        "Night Routine" to "روتین شب"
    )
    val safeMissions = normalizeMissionIdentities(
        loadMissions(context)
            .ifEmpty { listOf(defaultMission()) }
            .map { mission -> if (current < 8) mission.copy(title = legacyStarterTitles[mission.title] ?: mission.title) else mission }
    )
    migrateSubtaskProgressToMissionIds(context, safeMissions)
    val missionIdByTitle = safeMissions.groupBy { it.title }.mapValues { it.value.first().id }
    val safeHistory = loadHistory(context)
        .filter { it.timestamp > 0L }
        .map { entry ->
            val renamed = if (current < 8) {
                entry.copy(missionTitle = legacyStarterTitles[entry.missionTitle] ?: entry.missionTitle)
            } else entry
            renamed.copy(missionId = renamed.missionId.ifBlank { missionIdByTitle[renamed.missionTitle].orEmpty() })
        }
        .distinctBy { if (it.sessionId > 0L) "session:${it.sessionId}" else "${it.timestamp}|${it.missionId}|${it.missionTitle}|${it.result.name}" }
        .take(500)
    saveMissions(context, safeMissions)
    saveHistory(context, safeHistory)
    prefs.edit().putStringSet(
        KEY_COMPLETED_MISSION_SESSIONS,
        safeHistory.asSequence().map { it.sessionId }.filter { it > 0L }.take(200).map { it.toString() }.toSet()
    ).apply()
    savePlayer(context, loadPlayer(context))
    saveSettings(context, loadSettings(context))
    savePersonalRewards(context, loadPersonalRewards(context))
    val safeDreams = loadDreamItems(context)
    saveDreamItems(context, safeDreams)
    pruneOwnedDreamImages(context, safeDreams)
    val editor = prefs.edit().putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION)
    if (current in 1 until CURRENT_SCHEMA_VERSION && !prefs.contains(KEY_ONBOARDING_COMPLETE)) {
        editor.putBoolean(KEY_ONBOARDING_COMPLETE, true)
    }
    RETIRED_PREF_KEYS.forEach { editor.remove(it) }
    editor.apply()
}

private const val BACKUP_JSON_ENTRY = "backup.json"
private const val DREAM_IMAGE_ENTRY_PREFIX = "dreamboard/"
private const val MAX_LEGACY_BACKUP_BYTES = 12L * 1024L * 1024L
private const val MAX_DREAM_IMAGE_BYTES = 24L * 1024L * 1024L
private const val MAX_BACKUP_BUNDLE_BYTES = 220L * 1024L * 1024L

private fun buildBackupJson(context: Context): JSONObject {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val entries = JSONArray()
    val allEntries = prefs.all.entries.sortedBy { it.key }
    for (entry in allEntries) {
        val key = entry.key
        val value = entry.value
        if (!isBackupEligibleKey(key)) continue
        val item = JSONObject().put("key", key)
        when (value) {
            is String -> item.put("type", "string").put("value", value)
            is Int -> item.put("type", "int").put("value", value)
            is Long -> item.put("type", "long").put("value", value)
            is Float -> item.put("type", "float").put("value", value.toDouble())
            is Boolean -> item.put("type", "boolean").put("value", value)
            is Set<*> -> {
                val array = JSONArray()
                for (element in value) if (element is String) array.put(element)
                item.put("type", "stringSet").put("value", array)
            }
            else -> continue
        }
        entries.put(item)
    }
    return JSONObject()
        .put("format", "GamificationBackup")
        .put("bundleVersion", 1)
        .put("schemaVersion", CURRENT_SCHEMA_VERSION)
        .put("exportedAt", System.currentTimeMillis())
        .put("entries", entries)
}

private fun openDreamImageInput(context: Context, uriString: String): InputStream? = runCatching {
    if (uriString.isBlank()) return@runCatching null
    val parsed = Uri.parse(uriString)
    if (parsed.scheme == "file") {
        val path = parsed.path ?: return@runCatching null
        FileInputStream(File(path))
    } else {
        context.contentResolver.openInputStream(parsed)
    }
}.getOrNull()

private fun copyWithLimit(
    input: InputStream,
    writeChunk: (ByteArray, Int) -> Unit,
    maxBytes: Long
): Long {
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
    var total = 0L
    while (true) {
        val read = input.read(buffer)
        if (read <= 0) break
        total += read
        require(total <= maxBytes) { "Backup entry is too large" }
        writeChunk(buffer, read)
    }
    return total
}

private fun safeDreamEntryId(id: String, index: Int): String {
    val cleaned = id.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
    return cleaned.ifBlank { "dream_$index" }
}

internal fun exportBackup(context: Context, uri: Uri): Boolean = runCatching {
    val root = buildBackupJson(context)
    val dreamImageManifest = JSONArray()
    val dreams = DreamboardEngine.normalize(loadDreamItems(context))

    val output = context.contentResolver.openOutputStream(uri, "w")
        ?: error("Unable to open backup destination")
    ZipOutputStream(BufferedOutputStream(output)).use { zip ->
        dreams.forEachIndexed { index, dream ->
            val input = openDreamImageInput(context, dream.imageUri) ?: return@forEachIndexed
            input.use { imageInput ->
                val entryName = "$DREAM_IMAGE_ENTRY_PREFIX${safeDreamEntryId(dream.id, index)}_$index.img"
                zip.putNextEntry(ZipEntry(entryName))
                copyWithLimit(
                    input = imageInput,
                    writeChunk = { bytes, count -> zip.write(bytes, 0, count) },
                    maxBytes = MAX_DREAM_IMAGE_BYTES
                )
                zip.closeEntry()
                dreamImageManifest.put(
                    JSONObject()
                        .put("id", dream.id)
                        .put("entry", entryName)
                )
            }
        }

        root.put("dreamImages", dreamImageManifest)
        val jsonBytes = root.toString(2).toByteArray(Charsets.UTF_8)
        zip.putNextEntry(ZipEntry(BACKUP_JSON_ENTRY))
        zip.write(jsonBytes)
        zip.closeEntry()
    }
}.isSuccess

private fun stageBackupEntries(root: JSONObject): MutableList<Triple<String, String, Any>> {
    require(root.optString("format") == "GamificationBackup") { "Not a Gamification backup" }
    val version = root.optInt("schemaVersion", 1)
    require(version in 1..CURRENT_SCHEMA_VERSION) { "Backup version is newer than this app" }
    val entries = root.getJSONArray("entries")
    require(entries.length() <= 1000) { "Backup contains too many entries" }

    val staged = mutableListOf<Triple<String, String, Any>>()
    for (i in 0 until entries.length()) {
        val item = entries.getJSONObject(i)
        val key = item.getString("key")
        require(key.length in 1..120) { "Invalid backup key" }
        if (!isBackupEligibleKey(key)) continue
        val type = item.getString("type")
        val value: Any = when (type) {
            "string" -> item.optString("value", "").take(2_000_000)
            "int" -> item.optInt("value", 0)
            "long" -> item.optLong("value", 0L)
            "float" -> item.optDouble("value", 0.0).toFloat()
            "boolean" -> item.optBoolean("value", false)
            "stringSet" -> {
                val a = item.optJSONArray("value") ?: JSONArray()
                require(a.length() <= 500) { "Backup set is too large" }
                buildSet { for (j in 0 until a.length()) add(a.optString(j).take(500)) }
            }
            else -> error("Unsupported backup value type")
        }
        staged += Triple(key, type, value)
    }
    return staged
}

private fun rewriteDreamboardImageUris(
    raw: String,
    restoredUris: Map<String, String>,
    clearMissing: Boolean
): String = runCatching {
    val array = JSONArray(raw)
    for (i in 0 until array.length()) {
        val item = array.getJSONObject(i)
        val id = item.optString("id").ifBlank { "dream_$i" }
        val restored = restoredUris[id]
        if (restored != null) {
            item.put("imageUri", restored)
        } else if (clearMissing) {
            item.put("imageUri", "")
        }
    }
    array.toString()
}.getOrElse { raw }

private fun applyStagedBackup(
    context: Context,
    stagedEntries: List<Triple<String, String, Any>>
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val editor = prefs.edit().clear()
    stagedEntries.forEach { (key, type, value) ->
        when (type) {
            "string" -> editor.putString(key, value as String)
            "int" -> editor.putInt(key, value as Int)
            "long" -> editor.putLong(key, value as Long)
            "float" -> editor.putFloat(key, value as Float)
            "boolean" -> editor.putBoolean(key, value as Boolean)
            "stringSet" -> editor.putStringSet(key, (value as Set<*>).filterIsInstance<String>().toSet())
        }
    }
    editor.putBoolean(KEY_TIMER_ACTIVE, false)
        .putInt(KEY_SCHEMA_VERSION, 0)
        .apply()
    cancelTimerAlarm(context)
    migrateState(context)
}

private fun importLegacyJsonBackup(context: Context, input: InputStream) {
    val out = ByteArrayOutputStream()
    input.use { source ->
        copyWithLimit(
            input = source,
            writeChunk = { bytes, count -> out.write(bytes, 0, count) },
            maxBytes = MAX_LEGACY_BACKUP_BYTES
        )
    }
    val root = JSONObject(out.toString(Charsets.UTF_8.name()))
    applyStagedBackup(context, stageBackupEntries(root))
}

private fun importZipBackup(context: Context, input: InputStream) {
    val tempDir = File(context.cacheDir, "gamify_restore_${UUID.randomUUID()}").apply { mkdirs() }
    try {
        var root: JSONObject? = null
        val extractedImages = mutableMapOf<String, File>()
        var entryCount = 0
        var totalBytes = 0L

        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entryCount++
                require(entryCount <= 500) { "Backup contains too many files" }
                val name = entry.name
                require(name.length in 1..180 && !name.contains("..") && !name.contains('\\')) {
                    "Invalid backup file path"
                }
                if (entry.isDirectory) {
                    zip.closeEntry()
                    continue
                }

                when {
                    name == BACKUP_JSON_ENTRY -> {
                        val out = ByteArrayOutputStream()
                        totalBytes += copyWithLimit(
                            input = zip,
                            writeChunk = { bytes, count -> out.write(bytes, 0, count) },
                            maxBytes = MAX_LEGACY_BACKUP_BYTES
                        )
                        root = JSONObject(out.toString(Charsets.UTF_8.name()))
                    }
                    name.startsWith(DREAM_IMAGE_ENTRY_PREFIX) -> {
                        val temp = File(tempDir, "image_${extractedImages.size}.bin")
                        FileOutputStream(temp).use { fileOut ->
                            totalBytes += copyWithLimit(
                                input = zip,
                                writeChunk = { bytes, count -> fileOut.write(bytes, 0, count) },
                                maxBytes = MAX_DREAM_IMAGE_BYTES
                            )
                        }
                        extractedImages[name] = temp
                    }
                }
                require(totalBytes <= MAX_BACKUP_BUNDLE_BYTES) { "Backup bundle is too large" }
                zip.closeEntry()
            }
        }

        val backupRoot = root ?: error("Backup metadata is missing")
        var staged = stageBackupEntries(backupRoot)
        val manifest = backupRoot.optJSONArray("dreamImages") ?: JSONArray()
        val restoredUris = mutableMapOf<String, String>()
        val finalDir = File(context.filesDir, "dreamboard").apply { mkdirs() }
        val restoreStamp = System.currentTimeMillis()

        for (i in 0 until manifest.length()) {
            val item = manifest.optJSONObject(i) ?: continue
            val id = item.optString("id")
            val entryName = item.optString("entry")
            if (id.isBlank() || entryName.isBlank()) continue
            val temp = extractedImages[entryName] ?: continue
            val finalFile = File(
                finalDir,
                "restore_${restoreStamp}_${safeDreamEntryId(id, i)}_$i.img"
            )
            temp.inputStream().use { source ->
                FileOutputStream(finalFile).use { dest -> source.copyTo(dest) }
            }
            restoredUris[id] = Uri.fromFile(finalFile).toString()
        }

        staged = staged.map { (key, type, value) ->
            if (key == KEY_DREAMBOARD_ITEMS && type == "string") {
                Triple(
                    key,
                    type,
                    rewriteDreamboardImageUris(
                        raw = value as String,
                        restoredUris = restoredUris,
                        clearMissing = true
                    )
                )
            } else {
                Triple(key, type, value)
            }
        }.toMutableList()

        applyStagedBackup(context, staged)
    } finally {
        runCatching { tempDir.deleteRecursively() }
    }
}

internal fun importBackup(context: Context, uri: Uri): String = runCatching {
    val source = context.contentResolver.openInputStream(uri)
        ?: error("Unable to open backup")
    BufferedInputStream(source).use { buffered ->
        buffered.mark(8)
        val signature = ByteArray(4)
        val read = buffered.read(signature)
        buffered.reset()
        val isZip = read == 4 &&
            signature[0] == 0x50.toByte() &&
            signature[1] == 0x4B.toByte() &&
            signature[2] == 0x03.toByte() &&
            signature[3] == 0x04.toByte()

        if (isZip) {
            importZipBackup(context, buffered)
        } else {
            importLegacyJsonBackup(context, buffered)
        }
    }
    // TimeSheet data is a normal persisted preference, so it is already part
    // of the full backup. Refresh native alarms immediately after restore.
    rescheduleTimeSheetReminders(context)
    "Backup restored"
}.getOrElse { it.message ?: "Import failed" }

internal fun resetGameData(context: Context) {
    cancelTimerAlarm(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    migrateState(context)
    rescheduleTimeSheetReminders(context)
}

private val missionResultLock = Any()

/**
 * Commits one mission result as a single persisted state transition.
 *
 * Player progression, history, the completed-session marker and timer cleanup
 * are written in one SharedPreferences commit. This prevents rapid double taps
 * or a second result source from granting XP/coins twice for the same session.
 */
internal fun finalizeActiveMissionSession(
    context: Context,
    result: MissionResult,
    focusSeconds: Int
): MissionSessionCommit? = synchronized(missionResultLock) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val timer = loadActiveTimer(context) ?: return@synchronized null
    val sessionId = timer.sessionId.coerceAtLeast(1L)
    val historyBefore = loadHistory(context)
    val completedSessions = prefs.getStringSet(KEY_COMPLETED_MISSION_SESSIONS, emptySet())
        ?.toMutableSet() ?: mutableSetOf()

    val alreadyCommitted = sessionId.toString() in completedSessions ||
        historyBefore.any { it.sessionId == sessionId && sessionId > 0L }
    if (alreadyCommitted) {
        clearActiveTimer(context)
        val existing = historyBefore.firstOrNull { it.sessionId == sessionId } ?: return@synchronized null
        val currentPlayer = loadPlayer(context)
        val neutralOutcome = MissionOutcome(
            player = currentPlayer,
            xpGain = 0,
            missionCoinGain = 0,
            levelsGained = 0,
            levelRewardCoins = 0,
            comboBefore = currentPlayer.combo,
            comboAfter = currentPlayer.combo,
            rewardMultiplier = 1f,
            ranksGained = 0,
            chestsEarned = 0
        )
        return@synchronized MissionSessionCommit(
            sessionId = sessionId,
            mission = timer.mission,
            result = existing.result,
            beforePlayer = currentPlayer,
            outcome = neutralOutcome,
            entry = existing,
            history = historyBefore,
            duplicate = true
        )
    }

    val beforePlayer = loadPlayer(context)
    val settings = loadSettings(context)
    val previousComboDeadline = prefs.getLong(KEY_COMBO_EXPIRES_AT, 0L)
    val outcome = applyMissionResult(beforePlayer, timer.mission, result, settings)
    val entry = MissionHistoryEntry(
        timestamp = System.currentTimeMillis(),
        missionTitle = timer.mission.title,
        plannedMinutes = timer.mission.durationMinutes,
        focusSeconds = focusSeconds.coerceAtLeast(0),
        result = result,
        xpEarned = outcome.xpGain,
        coinsEarned = outcome.missionCoinGain + outcome.levelRewardCoins,
        levelRewardCoins = outcome.levelRewardCoins,
        missionId = timer.mission.id,
        sessionId = sessionId,
        rankStepsEarned = outcome.ranksGained,
        chestsEarned = outcome.chestsEarned,
        comboBefore = outcome.comboBefore,
        comboAfter = outcome.comboAfter,
        bestComboBefore = beforePlayer.bestCombo,
        comboDeadlineBefore = previousComboDeadline
    )
    val historyAfter = buildList {
        add(entry)
        historyBefore.asSequence()
            .filterNot { it.sessionId > 0L && it.sessionId == sessionId }
            .take(499)
            .forEach { add(it) }
    }

    completedSessions += sessionId.toString()
    val retainedSessionIds = historyAfter.asSequence()
        .map { it.sessionId }
        .filter { it > 0L }
        .take(200)
        .map { it.toString() }
        .toMutableSet()
    retainedSessionIds += sessionId.toString()

    val comboDeadlineAfter = when {
        result == MissionResult.Done && settings.comboBoostEnabled && comboMultiplier(outcome.player.combo) > 1f ->
            System.currentTimeMillis() + COMBO_WINDOW_MS
        outcome.player.combo <= 0 || !settings.comboBoostEnabled || comboMultiplier(outcome.player.combo) <= 1f -> 0L
        else -> previousComboDeadline
    }

    val committed = prefs.edit()
        .putInt(KEY_PLAYER_LEVEL, outcome.player.level)
        .putInt(KEY_PLAYER_XP, outcome.player.currentXp)
        .putInt(KEY_PLAYER_NEXT_XP, outcome.player.nextLevelXp)
        .putInt(KEY_PLAYER_RANK, outcome.player.rank)
        .putInt(KEY_PLAYER_RANK_PROGRESS, outcome.player.rankProgress)
        .putInt(KEY_PLAYER_CHESTS, outcome.player.chests)
        .putInt(KEY_PLAYER_COINS, outcome.player.coins)
        .putInt(KEY_PLAYER_COMBO, outcome.player.combo)
        .putInt(KEY_PLAYER_BEST_COMBO, outcome.player.bestCombo)
        .putInt(KEY_PLAYER_LOGIN_STREAK, outcome.player.loginStreak)
        .putInt(KEY_PLAYER_BEST_LOGIN_STREAK, outcome.player.bestLoginStreak)
        .apply {
            if (comboDeadlineAfter > 0L) putLong(KEY_COMBO_EXPIRES_AT, comboDeadlineAfter)
            else remove(KEY_COMBO_EXPIRES_AT)
        }
        .putString(KEY_HISTORY, encodeHistory(historyAfter))
        .putStringSet(KEY_COMPLETED_MISSION_SESSIONS, retainedSessionIds)
        .putBoolean(KEY_TIMER_ACTIVE, false)
        .remove(KEY_TIMER_END_AT)
        .remove(KEY_TIMER_MISSION_ID)
        .remove(KEY_TIMER_REMAINING)
        .remove(KEY_TIMER_RUNNING)
        .remove(KEY_TIMER_END_ELAPSED)
        .remove(KEY_TIMER_BOOT_COUNT)
        .remove(KEY_TIMER_SESSION)
        .remove(KEY_TIMER_SUBTASKS)
        .remove(KEY_TIMER_SUBTASK_CHECKS)
        .commit()

    if (!committed) return@synchronized null
    // A mission card has been resolved. Stop its soundtrack immediately;
    // the next card starts a fresh soundtrack session from the beginning.
    MissionMusicController.stop()
    cancelTimerAlarm(context)
    cancelTimerFinishedNotification(context)
    rescheduleMissionReminders(context, loadMissions(context), historyAfter, settings)
    GamifyWidgetProvider.updateAll(context)

    MissionSessionCommit(
        sessionId = sessionId,
        mission = timer.mission,
        result = result,
        beforePlayer = beforePlayer,
        outcome = outcome,
        entry = entry,
        history = historyAfter,
        duplicate = false
    )
}

internal fun MissionHistoryEntry.localDate(zoneId: ZoneId = ZoneId.systemDefault()): LocalDate =
    Instant.ofEpochMilli(timestamp).atZone(zoneId).toLocalDate()
