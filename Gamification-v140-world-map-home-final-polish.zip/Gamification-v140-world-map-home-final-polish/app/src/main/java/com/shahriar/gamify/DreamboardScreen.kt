package com.shahriar.gamify

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import java.time.LocalDate

@Composable
internal fun DreamboardDialog(
    player: PlayerState,
    dreams: List<DreamItem>,
    onAdd: (DreamItem) -> Unit,
    onUpdate: (DreamItem) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var editorId by remember { mutableStateOf<String?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var fullscreenId by remember { mutableStateOf<String?>(null) }
    val ordered = DreamboardEngine.normalize(dreams)
    val pagerState = rememberPagerState(pageCount = { ordered.size + 1 })
    val activeDream = ordered.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF071019))
        ) {
            DreamboardBackdrop(activeDream)

            BoxWithConstraints(Modifier.fillMaxSize()) {
                val sidePadding = 34.dp
                val cardWidth = maxWidth - (sidePadding * 2f)
                val cardHeight = cardWidth * (16f / 9f)

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                        TopGameHud(player = player, rewardCue = null)
                    }

                    Spacer(Modifier.height(4.dp))

                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(cardHeight),
                        contentPadding = PaddingValues(horizontal = sidePadding),
                        pageSpacing = 14.dp,
                        verticalAlignment = Alignment.Top
                    ) { page ->
                        val distance = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                            .coerceIn(0f, 1f)
                        val pageScale = 1f - (0.075f * distance)
                        val pageAlpha = 1f - (0.30f * distance)

                        if (page < ordered.size) {
                            val dream = ordered[page]
                            DreamboardCard(
                                dream = dream,
                                onTap = { fullscreenId = dream.id },
                                onLongPress = { editorId = dream.id; showEditor = true },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            )
                        } else {
                            AddDreamCard(
                                onClick = { editorId = null; showEditor = true },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            )
                        }
                    }

                    if (ordered.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        DreamPageIndicator(
                            currentIndex = pagerState.currentPage,
                            total = ordered.size
                        )
                    }
                }
            }
        }
    }

    fullscreenId?.let { id ->
        DreamFullscreenDialog(
            dreams = ordered,
            initialId = id,
            onDismiss = { fullscreenId = null }
        )
    }

    if (showEditor) {
        val existing = editorId?.let { id -> dreams.firstOrNull { it.id == id } }
        DreamEditorDialog(
            initial = existing,
            totalCount = dreams.size,
            onDismiss = { showEditor = false },
            onDelete = existing?.let { dream ->
                {
                    onDelete(dream.id)
                    showEditor = false
                }
            },
            onSave = { item ->
                if (existing == null) onAdd(item) else onUpdate(item)
                showEditor = false
            }
        )
    }
}

@Composable
private fun DreamboardCard(
    dream: DreamItem,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }
    Card(
        modifier = modifier.pointerInput(dream.id) {
            detectTapGestures(
                onTap = { onTap() },
                onLongPress = { onLongPress() }
            )
        },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111A24)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x665F6D7C))
    ) {
        Box(Modifier.fillMaxSize()) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = dream.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF223244), Color(0xFF0F1721)))
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("DREAM", color = Color(0x55FFFFFF), fontSize = 32.sp, fontWeight = FontWeight.Black)
                }
            }

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(92.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD8000000))))
            )

            DreamMetadataOverlay(
                dream = dream,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun DreamboardBackdrop(dream: DreamItem?) {
    val context = LocalContext.current
    val backdrop = remember(dream?.imageUri) {
        dream?.imageUri?.takeIf { it.isNotBlank() }?.let { loadDreamBackdropBitmap(context, it) }
    }

    if (backdrop != null) {
        Image(
            bitmap = backdrop,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.10f
                    scaleY = 1.10f
                    alpha = 0.70f
                },
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF142235), Color(0xFF071019), Color(0xFF04080D))
                    )
                )
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xB002060A),
                        Color(0x76040A10),
                        Color(0xD0070C12)
                    )
                )
            )
    )

    DreamGeometryBackdrop()
}

@Composable
private fun DreamGeometryBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val squareStroke = Color(0x154A6A84)
        val squareFill = Color(0x091C3346)
        val triangleStroke = Color(0x13F5C857)
        val triangleFill = Color(0x08F5C857)

        val squareSpecs = listOf(
            floatArrayOf(0.05f, 0.11f, 0.18f),
            floatArrayOf(0.73f, 0.08f, 0.14f),
            floatArrayOf(0.12f, 0.56f, 0.20f),
            floatArrayOf(0.69f, 0.50f, 0.23f),
            floatArrayOf(0.34f, 0.76f, 0.16f),
            floatArrayOf(0.79f, 0.82f, 0.13f)
        )
        squareSpecs.forEachIndexed { index, spec ->
            val side = size.width * spec[2]
            val left = size.width * spec[0]
            val top = size.height * spec[1]
            val radius = side * 0.18f
            drawRoundRect(
                color = if (index % 2 == 0) squareFill else Color.Transparent,
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(side, side),
                cornerRadius = CornerRadius(radius, radius)
            )
            drawRoundRect(
                color = squareStroke,
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(side, side),
                cornerRadius = CornerRadius(radius, radius),
                style = Stroke(width = 1.1.dp.toPx())
            )
        }

        val triangleSpecs = listOf(
            floatArrayOf(0.45f, 0.17f, 0.15f),
            floatArrayOf(0.02f, 0.35f, 0.17f),
            floatArrayOf(0.57f, 0.68f, 0.18f),
            floatArrayOf(0.18f, 0.88f, 0.12f),
            floatArrayOf(0.83f, 0.30f, 0.13f)
        )
        triangleSpecs.forEachIndexed { index, spec ->
            val side = size.width * spec[2]
            val x = size.width * spec[0]
            val y = size.height * spec[1]
            val triangle = Path().apply {
                moveTo(x + side * 0.5f, y)
                lineTo(x + side, y + side)
                lineTo(x, y + side)
                close()
            }
            drawPath(triangle, if (index % 2 == 0) triangleFill else Color.Transparent)
            drawPath(triangle, triangleStroke, style = Stroke(width = 1.0.dp.toPx()))
        }

        drawCircle(Color(0x0CF5C857), radius = size.width * 0.30f, center = Offset(size.width * 0.50f, size.height * 0.48f))
    }
}

@Composable
private fun DreamPageIndicator(
    currentIndex: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    if (total <= 0) return
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(total) { index ->
            val active = currentIndex == index
            Box(
                modifier = Modifier
                    .width(if (active) 20.dp else 7.dp)
                    .height(7.dp)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                    .background(if (active) Gold else Color(0xFF5A606D))
            )
        }
    }
}

@Composable
private fun DreamMetadataOverlay(
    dream: DreamItem,
    modifier: Modifier = Modifier,
    roomy: Boolean = false
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    horizontal = if (roomy) 16.dp else 12.dp,
                    vertical = if (roomy) 18.dp else 14.dp
                ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DreamMetadataLabel(
                modifier = Modifier.weight(1f),
                alignment = Alignment.CenterStart
            ) {
                Text(
                    dream.price.filter(Char::isDigit).let { if (it.isBlank()) "" else "$it \$" },
                    color = GoldSoft,
                    fontSize = if (roomy) 14.sp else 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Start,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            DreamMetadataLabel(
                modifier = Modifier.weight(0.82f),
                alignment = Alignment.Center
            ) {
                Text(
                    dream.year.trim().let { if (it.isBlank()) "" else "سال $it" },
                    color = Color.White,
                    fontSize = if (roomy) 13.sp else 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
            DreamMetadataLabel(
                modifier = Modifier.weight(1.45f),
                alignment = Alignment.CenterEnd
            ) {
                Text(
                    dream.title,
                    color = Color.White,
                    fontSize = if (roomy) 16.sp else 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun DreamMetadataLabel(
    modifier: Modifier = Modifier,
    alignment: Alignment = Alignment.Center,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x76050A0F), Color(0x9A05090E))
                )
            )
            .border(0.7.dp, Color(0x28FFFFFF), androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
            .padding(horizontal = 7.dp, vertical = 5.dp),
        contentAlignment = alignment
    ) {
        content()
    }
}

@Composable
private fun DreamFullscreenDialog(
    dreams: List<DreamItem>,
    initialId: String,
    onDismiss: () -> Unit
) {
    if (dreams.isEmpty()) return
    val initialIndex = dreams.indexOfFirst { it.id == initialId }.let { if (it < 0) 0 else it }
    val pagerState = rememberPagerState(
        initialPage = initialIndex,
        pageCount = { dreams.size }
    )
    val activeDream = dreams.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            DreamboardBackdrop(activeDream)

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp),
                pageSpacing = 8.dp,
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                val dream = dreams[page]
                val context = LocalContext.current
                val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .padding(
                            top = 14.dp,
                            bottom = 14.dp,
                            start = 4.dp,
                            end = 4.dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f),
                        color = Color(0xFF0B1118),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0x44FFFFFF))
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = dream.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color(0xFF223244), Color(0xFF0F1721))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "DREAM",
                                        color = Color(0x55FFFFFF),
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Box(
                                Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .height(116.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color(0xE8000000))
                                        )
                                    )
                            )
                            DreamMetadataOverlay(
                                dream = dream,
                                modifier = Modifier.align(Alignment.BottomCenter),
                                roomy = true
                            )
                        }
                    }
                }
            }

            DreamPageIndicator(
                currentIndex = pagerState.currentPage,
                total = dreams.size,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 10.dp)
            )
        }
    }
}

@Composable
private fun AddDreamCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xC9101A25),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x667E8C9E))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xCC152534), Color(0xD90B1520), Color(0xEE071019))
                    )
                )
        ) {
            Canvas(Modifier.matchParentSize()) {
                val gridStroke = Color(0x0F69829A)
                val accentStroke = Color(0x0FF5C857)
                val cell = size.width / 5.5f
                var x = -cell * 0.4f
                while (x < size.width) {
                    var y = cell * 0.25f
                    while (y < size.height) {
                        drawRoundRect(
                            color = gridStroke,
                            topLeft = Offset(x, y),
                            size = androidx.compose.ui.geometry.Size(cell * 0.72f, cell * 0.72f),
                            cornerRadius = CornerRadius(cell * 0.12f, cell * 0.12f),
                            style = Stroke(width = 0.8.dp.toPx())
                        )
                        y += cell * 2.25f
                    }
                    x += cell * 2.05f
                }
                val tri = Path().apply {
                    moveTo(size.width * 0.76f, size.height * 0.20f)
                    lineTo(size.width * 0.90f, size.height * 0.32f)
                    lineTo(size.width * 0.69f, size.height * 0.35f)
                    close()
                }
                drawPath(tri, accentStroke, style = Stroke(width = 1.dp.toPx()))
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                DreamEmptyIllustration(
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .aspectRatio(1.22f)
                )

                Spacer(Modifier.height(34.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.82f)
                        .height(64.dp)
                        .clickable(onClick = onClick),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(19.dp),
                    color = Gold,
                    shadowElevation = 14.dp,
                    border = BorderStroke(1.dp, GoldSoft)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("+", color = Color(0xFF211800), fontSize = 34.sp, fontWeight = FontWeight.Light)
                        Spacer(Modifier.width(14.dp))
                        Text(
                            "Add Dream",
                            color = Color(0xFF211800),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DreamEmptyIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val gold = Color(0xFFF7C948)
        val goldSoft = Color(0xFFFFD96B)
        val frame = Color(0xFFE7EDF4)
        val deep = Color(0xFF0A1520)
        val cardW = size.width * 0.30f
        val cardH = size.height * 0.52f

        drawCircle(
            color = Color(0x22F7C948),
            radius = size.minDimension * 0.34f,
            center = Offset(size.width * 0.50f, size.height * 0.63f)
        )
        drawCircle(
            color = Color(0x12F7C948),
            radius = size.minDimension * 0.44f,
            center = Offset(size.width * 0.50f, size.height * 0.63f)
        )

        fun dreamCard(cx: Float, cy: Float, angle: Float, fill: Color, icon: Int) {
            rotate(degrees = angle, pivot = Offset(cx, cy)) {
                val left = cx - cardW / 2f
                val top = cy - cardH / 2f
                drawRoundRect(
                    color = fill,
                    topLeft = Offset(left, top),
                    size = androidx.compose.ui.geometry.Size(cardW, cardH),
                    cornerRadius = CornerRadius(cardW * 0.08f, cardW * 0.08f)
                )
                drawRoundRect(
                    color = frame.copy(alpha = 0.86f),
                    topLeft = Offset(left, top),
                    size = androidx.compose.ui.geometry.Size(cardW, cardH),
                    cornerRadius = CornerRadius(cardW * 0.08f, cardW * 0.08f),
                    style = Stroke(width = 2.1.dp.toPx())
                )

                val iconCenter = Offset(cx, cy)
                when (icon) {
                    0 -> {
                        // Minimal car silhouette.
                        drawRoundRect(
                            color = Color(0xFFEAF0F5),
                            topLeft = Offset(cx - cardW * 0.28f, cy - cardH * 0.04f),
                            size = androidx.compose.ui.geometry.Size(cardW * 0.56f, cardH * 0.17f),
                            cornerRadius = CornerRadius(cardW * 0.06f, cardW * 0.06f)
                        )
                        val roof = Path().apply {
                            moveTo(cx - cardW * 0.18f, cy - cardH * 0.04f)
                            lineTo(cx - cardW * 0.07f, cy - cardH * 0.16f)
                            lineTo(cx + cardW * 0.15f, cy - cardH * 0.16f)
                            lineTo(cx + cardW * 0.23f, cy - cardH * 0.04f)
                            close()
                        }
                        drawPath(roof, Color(0xFFDDE7EF))
                        drawCircle(deep, radius = cardW * 0.055f, center = Offset(cx - cardW * 0.18f, cy + cardH * 0.13f))
                        drawCircle(deep, radius = cardW * 0.055f, center = Offset(cx + cardW * 0.18f, cy + cardH * 0.13f))
                    }
                    1 -> {
                        // Minimal modern home.
                        drawRect(
                            color = Color(0xFFE1E7EB),
                            topLeft = Offset(cx - cardW * 0.25f, cy - cardH * 0.11f),
                            size = androidx.compose.ui.geometry.Size(cardW * 0.50f, cardH * 0.30f)
                        )
                        val roof = Path().apply {
                            moveTo(cx - cardW * 0.31f, cy - cardH * 0.11f)
                            lineTo(cx, cy - cardH * 0.27f)
                            lineTo(cx + cardW * 0.31f, cy - cardH * 0.11f)
                            close()
                        }
                        drawPath(roof, Color(0xFF34485B))
                        drawRect(
                            color = goldSoft.copy(alpha = 0.88f),
                            topLeft = Offset(cx - cardW * 0.07f, cy + cardH * 0.02f),
                            size = androidx.compose.ui.geometry.Size(cardW * 0.14f, cardH * 0.17f)
                        )
                    }
                    else -> {
                        // Minimal plane mark.
                        val plane = Path().apply {
                            moveTo(iconCenter.x - cardW * 0.30f, iconCenter.y + cardH * 0.02f)
                            lineTo(iconCenter.x + cardW * 0.31f, iconCenter.y - cardH * 0.03f)
                            lineTo(iconCenter.x + cardW * 0.04f, iconCenter.y - cardH * 0.13f)
                            lineTo(iconCenter.x - cardW * 0.02f, iconCenter.y - cardH * 0.13f)
                            lineTo(iconCenter.x + cardW * 0.07f, iconCenter.y - cardH * 0.03f)
                            lineTo(iconCenter.x - cardW * 0.12f, iconCenter.y - cardH * 0.02f)
                            lineTo(iconCenter.x - cardW * 0.23f, iconCenter.y + cardH * 0.10f)
                            lineTo(iconCenter.x - cardW * 0.29f, iconCenter.y + cardH * 0.10f)
                            close()
                        }
                        drawPath(plane, Color(0xFFEAF0F5))
                    }
                }
            }
        }

        dreamCard(size.width * 0.30f, size.height * 0.42f, -12f, Color(0xFF132334), 0)
        dreamCard(size.width * 0.50f, size.height * 0.32f, 0f, Color(0xFF1A3550), 1)
        dreamCard(size.width * 0.71f, size.height * 0.42f, 13f, Color(0xFF14517C), 2)

        // Open box.
        val boxTopY = size.height * 0.62f
        val box = Path().apply {
            moveTo(size.width * 0.30f, boxTopY)
            lineTo(size.width * 0.70f, boxTopY)
            lineTo(size.width * 0.64f, size.height * 0.88f)
            lineTo(size.width * 0.36f, size.height * 0.88f)
            close()
        }
        drawPath(box, Color(0xFF07131E))
        drawPath(box, Color(0x805A7187), style = Stroke(width = 1.4.dp.toPx()))

        val leftFlap = Path().apply {
            moveTo(size.width * 0.30f, boxTopY)
            lineTo(size.width * 0.49f, size.height * 0.71f)
            lineTo(size.width * 0.40f, size.height * 0.78f)
            lineTo(size.width * 0.22f, size.height * 0.68f)
            close()
        }
        val rightFlap = Path().apply {
            moveTo(size.width * 0.70f, boxTopY)
            lineTo(size.width * 0.51f, size.height * 0.71f)
            lineTo(size.width * 0.60f, size.height * 0.78f)
            lineTo(size.width * 0.78f, size.height * 0.68f)
            close()
        }
        drawPath(leftFlap, Color(0xFF0E2030))
        drawPath(rightFlap, Color(0xFF0E2030))
        drawPath(leftFlap, Color(0x805A7187), style = Stroke(width = 1.2.dp.toPx()))
        drawPath(rightFlap, Color(0x805A7187), style = Stroke(width = 1.2.dp.toPx()))

        drawCircle(gold, radius = 3.8.dp.toPx(), center = Offset(size.width * 0.18f, size.height * 0.22f))
        drawCircle(goldSoft, radius = 2.7.dp.toPx(), center = Offset(size.width * 0.82f, size.height * 0.18f))
        drawCircle(gold, radius = 2.4.dp.toPx(), center = Offset(size.width * 0.85f, size.height * 0.54f))
    }
}

@Composable
private fun DreamCropDialog(
    sourceUri: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val context = LocalContext.current
    val source = remember(sourceUri) { loadDreamSourceBitmap(context, sourceUri) }
    var scale by remember(sourceUri) { mutableStateOf(1f) }
    var offset by remember(sourceUri) { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            color = GamifyColors.Surface,
            shape = GamifyShapes.Dialog
        ) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Crop", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 16f)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .onSizeChanged { viewport = it }
                        .pointerInput(sourceUri, viewport) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 4f)
                                if (source != null && viewport.width > 0 && viewport.height > 0) {
                                    val baseScale = max(
                                        viewport.width.toFloat() / source.width.toFloat(),
                                        viewport.height.toFloat() / source.height.toFloat()
                                    )
                                    val scaledW = source.width * baseScale * newScale
                                    val scaledH = source.height * baseScale * newScale
                                    val maxX = ((scaledW - viewport.width) / 2f).coerceAtLeast(0f)
                                    val maxY = ((scaledH - viewport.height) / 2f).coerceAtLeast(0f)
                                    offset = Offset(
                                        (offset.x + pan.x).coerceIn(-maxX, maxX),
                                        (offset.y + pan.y).coerceIn(-maxY, maxY)
                                    )
                                } else {
                                    offset += pan
                                }
                                scale = newScale
                            }
                        }
                ) {
                    if (source != null && viewport.width > 0 && viewport.height > 0) {
                        val imageBitmap = remember(source) { source.asImageBitmap() }
                        Canvas(Modifier.fillMaxSize()) {
                            val baseScale = max(
                                size.width / source.width.toFloat(),
                                size.height / source.height.toFloat()
                            )
                            val effectiveScale = baseScale * scale
                            val drawWidth = source.width * effectiveScale
                            val drawHeight = source.height * effectiveScale
                            val left = ((size.width - drawWidth) / 2f + offset.x).roundToInt()
                            val top = ((size.height - drawHeight) / 2f + offset.y).roundToInt()
                            drawImage(
                                image = imageBitmap,
                                srcOffset = IntOffset.Zero,
                                srcSize = IntSize(source.width, source.height),
                                dstOffset = IntOffset(left, top),
                                dstSize = IntSize(
                                    drawWidth.roundToInt().coerceAtLeast(1),
                                    drawHeight.roundToInt().coerceAtLeast(1)
                                )
                            )
                        }
                    } else if (source == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Unable to load image", color = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel", color = TextSoft)
                    }
                    Button(
                        onClick = {
                            val bitmap = source ?: return@Button
                            saveDreamCrop(context, bitmap, viewport, scale, offset)?.let(onSave)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                    ) { Text("Save", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun DreamEditorDialog(
    initial: DreamItem?,
    totalCount: Int,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (DreamItem) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var year by remember(initial?.id) { mutableStateOf(initial?.year.orEmpty()) }
    var price by remember(initial?.id) { mutableStateOf(initial?.price?.filter(Char::isDigit).orEmpty()) }
    var imageUri by remember(initial?.id) { mutableStateOf(initial?.imageUri.orEmpty()) }
    val maxPosition = if (initial == null) totalCount else (totalCount - 1).coerceAtLeast(0)
    var position by remember(initial?.id, totalCount) {
        mutableIntStateOf((initial?.position ?: totalCount).coerceIn(0, maxPosition))
    }
    var positionMenu by remember { mutableStateOf(false) }
    var yearMenu by remember { mutableStateOf(false) }
    var pendingCropUri by remember { mutableStateOf<String?>(null) }
    val originalImageUri = initial?.imageUri.orEmpty()
    val currentPersianYear = remember {
        val today = LocalDate.now()
        today.year - if (today.monthValue > 3 || (today.monthValue == 3 && today.dayOfMonth >= 21)) 621 else 622
    }
    val persianYears = remember(currentPersianYear) { (currentPersianYear..(currentPersianYear + 10)).toList() }

    fun discardUnsavedCrop() {
        if (imageUri.isNotBlank() && imageUri != originalImageUri) {
            deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
        }
    }

    fun dismissEditor() {
        discardUnsavedCrop()
        onDismiss()
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pendingCropUri = uri.toString()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = { dismissEditor() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                color = Color.Transparent,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.60f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF152235),
                                    Color(0xFF09131E),
                                    Color(0xFF11100D),
                                    Color(0xFF071019)
                                )
                            )
                        )
                ) {
                    Canvas(Modifier.matchParentSize()) {
                        val grid = 34.dp.toPx()
                        val lineColor = Color(0x12E7C45C)
                        var x = 0f
                        while (x < size.width) {
                            drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 0.7.dp.toPx())
                            x += grid
                        }
                        var y = 0f
                        while (y < size.height) {
                            drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 0.7.dp.toPx())
                            y += grid
                        }
                        drawCircle(Color(0x18F4C95D), radius = size.width * 0.42f, center = Offset(size.width * 0.10f, 0f))
                        drawCircle(Color(0x0FEA8E33), radius = size.width * 0.36f, center = Offset(size.width, size.height * 0.72f))
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = gamifyDialogMaxHeight())
                            .padding(GamifySpacing.Md),
                        verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
                    ) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    if (initial == null) "رویای جدید" else "ویرایش رویا",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.align(Alignment.CenterStart).padding(end = 48.dp)
                                )
                                DreamImagePickerButton(
                                    hasImage = imageUri.isNotBlank(),
                                    onClick = { imagePicker.launch(arrayOf("image/*")) },
                                    modifier = Modifier.align(Alignment.Center)
                                )
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .size(36.dp)
                                        .clickable { dismissEditor() },
                                    shape = androidx.compose.foundation.shape.CircleShape,
                                    color = Color(0x551D2A38),
                                    border = BorderStroke(1.dp, Color(0x556B7D90))
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("×", color = Color(0xFFE8EDF3), fontSize = 22.sp, fontWeight = FontWeight.Light)
                                    }
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    "عنوان رویا :",
                                    color = Color(0xFFE7ECF3),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = title,
                                    onValueChange = { title = it.take(80) },
                                    placeholder = { Text("جای خالی") },
                                    singleLine = true,
                                    colors = readableOutlinedFieldColors(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = GamifyDimens.FieldMinHeight),
                                    shape = GamifyShapes.Field
                                )
                            }
                        }

                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("سال", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Box {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(GamifyDimens.FieldMinHeight)
                                                .clickable { yearMenu = true },
                                            color = GamifyColors.SurfaceInput,
                                            shape = GamifyShapes.Field,
                                            border = BorderStroke(1.dp, GamifyColors.Border)
                                        ) {
                                            Row(
                                                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    if (year.isBlank()) "انتخاب سال" else year,
                                                    color = if (year.isBlank()) TextSoft else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text("⌄", color = GoldSoft, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        DropdownMenu(expanded = yearMenu, onDismissRequest = { yearMenu = false }) {
                                            persianYears.forEach { value ->
                                                DropdownMenuItem(
                                                    text = { Text(value.toString()) },
                                                    onClick = {
                                                        year = value.toString()
                                                        yearMenu = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("قیمت", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    OutlinedTextField(
                                        value = formatDreamMoneyInput(price),
                                        onValueChange = { price = it.filter(Char::isDigit).take(15) },
                                        placeholder = { Text("25,000") },
                                        singleLine = true,
                                        trailingIcon = { Text("\$", color = GoldSoft, fontWeight = FontWeight.Bold) },
                                        colors = readableOutlinedFieldColors(),
                                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                                        shape = GamifyShapes.Field
                                    )
                                }
                            }
                        }

                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("انتخاب جایگاه", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Box {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(GamifyDimens.FieldMinHeight)
                                            .clickable { positionMenu = true },
                                        color = GamifyColors.SurfaceInput,
                                        shape = GamifyShapes.Field,
                                        border = BorderStroke(1.dp, GamifyColors.Border)
                                    ) {
                                        Row(
                                            Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                "جایگاه ${position + 1}",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text("⌄", color = GoldSoft, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    DropdownMenu(expanded = positionMenu, onDismissRequest = { positionMenu = false }) {
                                        for (i in 0..maxPosition) {
                                            DropdownMenuItem(
                                                text = { Text("جایگاه ${i + 1}") },
                                                onClick = { position = i; positionMenu = false }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        onSave(
                                            DreamItem(
                                                id = initial?.id ?: DreamboardEngine.newId(),
                                                title = title.trim(),
                                                year = year.trim(),
                                                price = price.filter(Char::isDigit),
                                                imageUri = imageUri,
                                                position = position
                                            )
                                        )
                                    },
                                    modifier = Modifier.weight(1.4f).height(GamifyDimens.ButtonHeight),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                    shape = GamifyShapes.Field
                                ) { Text("ذخیره", fontWeight = FontWeight.ExtraBold) }
                                onDelete?.let { deleteAction ->
                                    TextButton(
                                        onClick = {
                                            discardUnsavedCrop()
                                            deleteAction()
                                        },
                                        modifier = Modifier.height(GamifyDimens.ButtonHeight)
                                    ) {
                                        Text("حذف", color = Color(0xFFFF8D8D), fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingCropUri?.let { uri ->
        DreamCropDialog(
            sourceUri = uri,
            onDismiss = { pendingCropUri = null },
            onSave = { croppedUri ->
                if (imageUri.isNotBlank() && imageUri != originalImageUri && imageUri != croppedUri) {
                    deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
                }
                imageUri = croppedUri
                pendingCropUri = null
            }
        )
    }
}

@Composable
private fun DreamImagePickerButton(
    hasImage: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(54.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .background(Color(0xB30A121C))
            .border(
                1.dp,
                if (hasImage) Gold else Color(0x88E6C969),
                androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(26.dp)) {
            val stroke = 1.8.dp.toPx()
            drawRoundRect(
                color = Gold,
                topLeft = Offset(size.width * 0.10f, size.height * 0.14f),
                size = androidx.compose.ui.geometry.Size(size.width * 0.80f, size.height * 0.68f),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                style = Stroke(width = stroke)
            )
            drawCircle(
                color = GoldSoft,
                radius = size.width * 0.08f,
                center = Offset(size.width * 0.67f, size.height * 0.33f)
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.20f, size.height * 0.67f),
                end = Offset(size.width * 0.42f, size.height * 0.44f),
                strokeWidth = stroke
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.42f, size.height * 0.44f),
                end = Offset(size.width * 0.58f, size.height * 0.59f),
                strokeWidth = stroke
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.58f, size.height * 0.59f),
                end = Offset(size.width * 0.76f, size.height * 0.42f),
                strokeWidth = stroke
            )
        }
        if (hasImage) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 3.dp, y = (-3).dp)
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Gold),
                contentAlignment = Alignment.Center
            ) {
                Text("✓", color = Color(0xFF211800), fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

private fun formatDreamMoneyInput(raw: String): String {
    val digits = raw.filter(Char::isDigit).take(15)
    if (digits.isBlank()) return ""
    return digits.reversed().chunked(3).joinToString(",").reversed()
}
