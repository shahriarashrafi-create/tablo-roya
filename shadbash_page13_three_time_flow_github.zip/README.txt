shadbash - Three Time Song Flow

Changes:
- Removed the round-page text that showed exact playback seconds.
- Removed the top chips for team count and total round count.
- Round title is now larger and more game-like, using Persian ordinal labels such as راند اول / راند دوم.
- Song Manager now asks for three times:
  1) Start time
  2) Stop time (question cut)
  3) Final time (includes the next lyric / answer)
- Initial Play runs from Start to Stop.
- Guess timer changed from 20 seconds to 10 seconds.
- Removed «جواب درست مخفی است».
- Replaced «نمایش جواب درست» with «بریم ادامه‌شو بشنویم».
- Tapping that button replays the song from Start to Final time.
- Only after the replay finishes does the saved correct answer appear with Correct / Wrong buttons.
- Existing persistent song storage, random no-repeat song order, results, final winner, and Import/Export remain.
- No song-swap feature is included.
