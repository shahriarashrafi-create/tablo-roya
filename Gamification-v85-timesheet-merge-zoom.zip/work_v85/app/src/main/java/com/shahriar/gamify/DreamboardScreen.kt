package com.shahriar.gamify

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import java.time.LocalDate

@Composable
internal fun DreamboardDialog(
    player: PlayerState,
    dreams: List<DreamItem>,
    onAdd: (DreamItem) -> Unit,
    onUpdate: (DreamItem) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var editorId by remember { mutableStateOf<String?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var fullscreenId by remember { mutableStateOf<String?>(null) }
    val ordered = DreamboardEngine.normalize(dreams)
    val pagerState = rememberPagerState(pageCount = { ordered.size + 1 })
    val activeDream = ordered.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF071019))
        ) {
            DreamboardBackdrop(activeDream)

            BoxWithConstraints(Modifier.fillMaxSize()) {
                val sidePadding = 34.dp
                val cardWidth = maxWidth - (sidePadding * 2f)
                val cardHeight = cardWidth * (16f / 9f)

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                        TopGameHud(player = player, rewardCue = null)
                    }

                    Spacer(Modifier.height(4.dp))

                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(cardHeight),
                        contentPadding = PaddingValues(horizontal = sidePadding),
                        pageSpacing = 14.dp,
                        verticalAlignment = Alignment.Top
                    ) { page ->
                        val distance = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                            .coerceIn(0f, 1f)
                        val pageScale = 1f - (0.075f * distance)
                        val pageAlpha = 1f - (0.30f * distance)

                        if (page < ordered.size) {
                            val dream = ordered[page]
                            DreamboardCard(
                                dream = dream,
                                onTap = { fullscreenId = dream.id },
                                onLongPress = { editorId = dream.id; showEditor = true },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            )
                        } else {
                            AddDreamCard(
                                onClick = { editorId = null; showEditor = true },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            )
                        }
                    }

                    if (ordered.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        DreamPageIndicator(
                            currentIndex = pagerState.currentPage,
                            total = ordered.size
                        )
                    }
                }
            }
        }
    }

    fullscreenId?.let { id ->
        DreamFullscreenDialog(
            dreams = ordered,
            initialId = id,
            onDismiss = { fullscreenId = null }
        )
    }

    if (showEditor) {
        val existing = editorId?.let { id -> dreams.firstOrNull { it.id == id } }
        DreamEditorDialog(
            initial = existing,
            totalCount = dreams.size,
            onDismiss = { showEditor = false },
            onDelete = existing?.let { dream ->
                {
                    onDelete(dream.id)
                    showEditor = false
                }
            },
            onSave = { item ->
                if (existing == null) onAdd(item) else onUpdate(item)
                showEditor = false
            }
        )
    }
}

@Composable
private fun DreamboardCard(
    dream: DreamItem,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }
    Card(
        modifier = modifier.pointerInput(dream.id) {
            detectTapGestures(
                onTap = { onTap() },
                onLongPress = { onLongPress() }
            )
        },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111A24)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x665F6D7C))
    ) {
        Box(Modifier.fillMaxSize()) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = dream.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF223244), Color(0xFF0F1721)))
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("DREAM", color = Color(0x55FFFFFF), fontSize = 32.sp, fontWeight = FontWeight.Black)
                }
            }

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(92.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD8000000))))
            )

            DreamMetadataOverlay(
                dream = dream,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun DreamboardBackdrop(dream: DreamItem?) {
    val context = LocalContext.current
    val backdrop = remember(dream?.imageUri) {
        dream?.imageUri?.takeIf { it.isNotBlank() }?.let { loadDreamBackdropBitmap(context, it) }
    }

    if (backdrop != null) {
        Image(
            bitmap = backdrop,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.10f
                    scaleY = 1.10f
                    alpha = 0.74f
                },
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF142235), Color(0xFF071019), Color(0xFF04080D))
                    )
                )
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xAA02060A),
                        Color(0x72040A10),
                        Color(0xC9070C12)
                    )
                )
            )
    )
}

@Composable
private fun DreamPageIndicator(
    currentIndex: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    if (total <= 0) return
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(total) { index ->
            val active = currentIndex == index
            Box(
                modifier = Modifier
                    .width(if (active) 20.dp else 7.dp)
                    .height(7.dp)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                    .background(if (active) Gold else Color(0xFF5A606D))
            )
        }
    }
}

@Composable
private fun DreamMetadataOverlay(
    dream: DreamItem,
    modifier: Modifier = Modifier,
    roomy: Boolean = false
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    horizontal = if (roomy) 16.dp else 12.dp,
                    vertical = if (roomy) 18.dp else 14.dp
                ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DreamMetadataLabel(
                modifier = Modifier.weight(1f),
                alignment = Alignment.CenterStart
            ) {
                Text(
                    dream.price.filter(Char::isDigit).let { if (it.isBlank()) "" else "$it \$" },
                    color = GoldSoft,
                    fontSize = if (roomy) 14.sp else 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Start,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            DreamMetadataLabel(
                modifier = Modifier.weight(0.82f),
                alignment = Alignment.Center
            ) {
                Text(
                    dream.year.trim().let { if (it.isBlank()) "" else "سال $it" },
                    color = Color.White,
                    fontSize = if (roomy) 13.sp else 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
            DreamMetadataLabel(
                modifier = Modifier.weight(1.45f),
                alignment = Alignment.CenterEnd
            ) {
                Text(
                    dream.title,
                    color = Color.White,
                    fontSize = if (roomy) 16.sp else 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun DreamMetadataLabel(
    modifier: Modifier = Modifier,
    alignment: Alignment = Alignment.Center,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x76050A0F), Color(0x9A05090E))
                )
            )
            .border(0.7.dp, Color(0x28FFFFFF), androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
            .padding(horizontal = 7.dp, vertical = 5.dp),
        contentAlignment = alignment
    ) {
        content()
    }
}

@Composable
private fun DreamFullscreenDialog(
    dreams: List<DreamItem>,
    initialId: String,
    onDismiss: () -> Unit
) {
    if (dreams.isEmpty()) return
    val initialIndex = dreams.indexOfFirst { it.id == initialId }.let { if (it < 0) 0 else it }
    val pagerState = rememberPagerState(
        initialPage = initialIndex,
        pageCount = { dreams.size }
    )
    val activeDream = dreams.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            DreamboardBackdrop(activeDream)

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp),
                pageSpacing = 8.dp,
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                val dream = dreams[page]
                val context = LocalContext.current
                val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .padding(
                            top = 14.dp,
                            bottom = 14.dp,
                            start = 4.dp,
                            end = 4.dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f),
                        color = Color(0xFF0B1118),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0x44FFFFFF))
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = dream.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color(0xFF223244), Color(0xFF0F1721))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "DREAM",
                                        color = Color(0x55FFFFFF),
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Box(
                                Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .height(116.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color(0xE8000000))
                                        )
                                    )
                            )
                            DreamMetadataOverlay(
                                dream = dream,
                                modifier = Modifier.align(Alignment.BottomCenter),
                                roomy = true
                            )
                        }
                    }
                }
            }

            DreamPageIndicator(
                currentIndex = pagerState.currentPage,
                total = dreams.size,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 10.dp)
            )
        }
    }
}

@Composable
private fun AddDreamCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = Color(0xFF101923),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x667E8C9E))
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF172432), Color(0xFF09111A)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("+", color = Gold, fontSize = 54.sp, fontWeight = FontWeight.Light)
                Text("Add Dream", color = Color(0xFFD9E1EA), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun DreamCropDialog(
    sourceUri: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val context = LocalContext.current
    val source = remember(sourceUri) { loadDreamSourceBitmap(context, sourceUri) }
    var scale by remember(sourceUri) { mutableStateOf(1f) }
    var offset by remember(sourceUri) { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            color = GamifyColors.Surface,
            shape = GamifyShapes.Dialog
        ) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Crop", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 16f)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .onSizeChanged { viewport = it }
                        .pointerInput(sourceUri, viewport) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 4f)
                                if (source != null && viewport.width > 0 && viewport.height > 0) {
                                    val baseScale = max(
                                        viewport.width.toFloat() / source.width.toFloat(),
                                        viewport.height.toFloat() / source.height.toFloat()
                                    )
                                    val scaledW = source.width * baseScale * newScale
                                    val scaledH = source.height * baseScale * newScale
                                    val maxX = ((scaledW - viewport.width) / 2f).coerceAtLeast(0f)
                                    val maxY = ((scaledH - viewport.height) / 2f).coerceAtLeast(0f)
                                    offset = Offset(
                                        (offset.x + pan.x).coerceIn(-maxX, maxX),
                                        (offset.y + pan.y).coerceIn(-maxY, maxY)
                                    )
                                } else {
                                    offset += pan
                                }
                                scale = newScale
                            }
                        }
                ) {
                    if (source != null && viewport.width > 0 && viewport.height > 0) {
                        val imageBitmap = remember(source) { source.asImageBitmap() }
                        Canvas(Modifier.fillMaxSize()) {
                            val baseScale = max(
                                size.width / source.width.toFloat(),
                                size.height / source.height.toFloat()
                            )
                            val effectiveScale = baseScale * scale
                            val drawWidth = source.width * effectiveScale
                            val drawHeight = source.height * effectiveScale
                            val left = ((size.width - drawWidth) / 2f + offset.x).roundToInt()
                            val top = ((size.height - drawHeight) / 2f + offset.y).roundToInt()
                            drawImage(
                                image = imageBitmap,
                                srcOffset = IntOffset.Zero,
                                srcSize = IntSize(source.width, source.height),
                                dstOffset = IntOffset(left, top),
                                dstSize = IntSize(
                                    drawWidth.roundToInt().coerceAtLeast(1),
                                    drawHeight.roundToInt().coerceAtLeast(1)
                                )
                            )
                        }
                    } else if (source == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Unable to load image", color = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel", color = TextSoft)
                    }
                    Button(
                        onClick = {
                            val bitmap = source ?: return@Button
                            saveDreamCrop(context, bitmap, viewport, scale, offset)?.let(onSave)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                    ) { Text("Save", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun DreamEditorDialog(
    initial: DreamItem?,
    totalCount: Int,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (DreamItem) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var year by remember(initial?.id) { mutableStateOf(initial?.year.orEmpty()) }
    var price by remember(initial?.id) { mutableStateOf(initial?.price?.filter(Char::isDigit).orEmpty()) }
    var imageUri by remember(initial?.id) { mutableStateOf(initial?.imageUri.orEmpty()) }
    val maxPosition = if (initial == null) totalCount else (totalCount - 1).coerceAtLeast(0)
    var position by remember(initial?.id, totalCount) {
        mutableIntStateOf((initial?.position ?: totalCount).coerceIn(0, maxPosition))
    }
    var positionMenu by remember { mutableStateOf(false) }
    var yearMenu by remember { mutableStateOf(false) }
    var pendingCropUri by remember { mutableStateOf<String?>(null) }
    val originalImageUri = initial?.imageUri.orEmpty()
    val currentPersianYear = remember {
        val today = LocalDate.now()
        today.year - if (today.monthValue > 3 || (today.monthValue == 3 && today.dayOfMonth >= 21)) 621 else 622
    }
    val persianYears = remember(currentPersianYear) { (currentPersianYear..(currentPersianYear + 10)).toList() }

    fun discardUnsavedCrop() {
        if (imageUri.isNotBlank() && imageUri != originalImageUri) {
            deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
        }
    }

    fun dismissEditor() {
        discardUnsavedCrop()
        onDismiss()
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pendingCropUri = uri.toString()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = { dismissEditor() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                color = Color.Transparent,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.60f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF152235),
                                    Color(0xFF09131E),
                                    Color(0xFF11100D),
                                    Color(0xFF071019)
                                )
                            )
                        )
                ) {
                    Canvas(Modifier.matchParentSize()) {
                        val grid = 34.dp.toPx()
                        val lineColor = Color(0x12E7C45C)
                        var x = 0f
                        while (x < size.width) {
                            drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 0.7.dp.toPx())
                            x += grid
                        }
                        var y = 0f
                        while (y < size.height) {
                            drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 0.7.dp.toPx())
                            y += grid
                        }
                        drawCircle(Color(0x18F4C95D), radius = size.width * 0.42f, center = Offset(size.width * 0.10f, 0f))
                        drawCircle(Color(0x0FEA8E33), radius = size.width * 0.36f, center = Offset(size.width, size.height * 0.72f))
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = gamifyDialogMaxHeight())
                            .padding(GamifySpacing.Md),
                        verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    if (initial == null) "رویای جدید" else "ویرایش رویا",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                DreamImagePickerButton(
                                    hasImage = imageUri.isNotBlank(),
                                    onClick = { imagePicker.launch(arrayOf("image/*")) }
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    "عنوان رویا :",
                                    color = Color(0xFFE7ECF3),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = title,
                                    onValueChange = { title = it.take(80) },
                                    placeholder = { Text("جای خالی") },
                                    singleLine = true,
                                    colors = readableOutlinedFieldColors(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = GamifyDimens.FieldMinHeight),
                                    shape = GamifyShapes.Field
                                )
                            }
                        }

                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("سال", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Box {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(GamifyDimens.FieldMinHeight)
                                                .clickable { yearMenu = true },
                                            color = GamifyColors.SurfaceInput,
                                            shape = GamifyShapes.Field,
                                            border = BorderStroke(1.dp, GamifyColors.Border)
                                        ) {
                                            Row(
                                                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    if (year.isBlank()) "انتخاب سال" else year,
                                                    color = if (year.isBlank()) TextSoft else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text("⌄", color = GoldSoft, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        DropdownMenu(expanded = yearMenu, onDismissRequest = { yearMenu = false }) {
                                            persianYears.forEach { value ->
                                                DropdownMenuItem(
                                                    text = { Text(value.toString()) },
                                                    onClick = {
                                                        year = value.toString()
                                                        yearMenu = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("قیمت", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    OutlinedTextField(
                                        value = formatDreamMoneyInput(price),
                                        onValueChange = { price = it.filter(Char::isDigit).take(15) },
                                        placeholder = { Text("25,000") },
                                        singleLine = true,
                                        trailingIcon = { Text("\$", color = GoldSoft, fontWeight = FontWeight.Bold) },
                                        colors = readableOutlinedFieldColors(),
                                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                                        shape = GamifyShapes.Field
                                    )
                                }
                            }
                        }

                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("انتخاب جایگاه", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Box {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(GamifyDimens.FieldMinHeight)
                                            .clickable { positionMenu = true },
                                        color = GamifyColors.SurfaceInput,
                                        shape = GamifyShapes.Field,
                                        border = BorderStroke(1.dp, GamifyColors.Border)
                                    ) {
                                        Row(
                                            Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                "جایگاه ${position + 1}",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text("⌄", color = GoldSoft, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    DropdownMenu(expanded = positionMenu, onDismissRequest = { positionMenu = false }) {
                                        for (i in 0..maxPosition) {
                                            DropdownMenuItem(
                                                text = { Text("جایگاه ${i + 1}") },
                                                onClick = { position = i; positionMenu = false }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        onSave(
                                            DreamItem(
                                                id = initial?.id ?: DreamboardEngine.newId(),
                                                title = title.trim(),
                                                year = year.trim(),
                                                price = price.filter(Char::isDigit),
                                                imageUri = imageUri,
                                                position = position
                                            )
                                        )
                                    },
                                    modifier = Modifier.weight(1.4f).height(GamifyDimens.ButtonHeight),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                    shape = GamifyShapes.Field
                                ) { Text("ذخیره", fontWeight = FontWeight.ExtraBold) }
                                TextButton(onClick = { dismissEditor() }, modifier = Modifier.weight(1f).height(GamifyDimens.ButtonHeight)) {
                                    Text("انصراف", color = TextSoft)
                                }
                                onDelete?.let { deleteAction ->
                                    TextButton(
                                        onClick = {
                                            discardUnsavedCrop()
                                            deleteAction()
                                        },
                                        modifier = Modifier.height(GamifyDimens.ButtonHeight)
                                    ) {
                                        Text("حذف", color = Color(0xFFFF8D8D), fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingCropUri?.let { uri ->
        DreamCropDialog(
            sourceUri = uri,
            onDismiss = { pendingCropUri = null },
            onSave = { croppedUri ->
                if (imageUri.isNotBlank() && imageUri != originalImageUri && imageUri != croppedUri) {
                    deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
                }
                imageUri = croppedUri
                pendingCropUri = null
            }
        )
    }
}

@Composable
private fun DreamImagePickerButton(
    hasImage: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(54.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .background(Color(0xB30A121C))
            .border(
                1.dp,
                if (hasImage) Gold else Color(0x88E6C969),
                androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(26.dp)) {
            val stroke = 1.8.dp.toPx()
            drawRoundRect(
                color = Gold,
                topLeft = Offset(size.width * 0.10f, size.height * 0.14f),
                size = androidx.compose.ui.geometry.Size(size.width * 0.80f, size.height * 0.68f),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                style = Stroke(width = stroke)
            )
            drawCircle(
                color = GoldSoft,
                radius = size.width * 0.08f,
                center = Offset(size.width * 0.67f, size.height * 0.33f)
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.20f, size.height * 0.67f),
                end = Offset(size.width * 0.42f, size.height * 0.44f),
                strokeWidth = stroke
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.42f, size.height * 0.44f),
                end = Offset(size.width * 0.58f, size.height * 0.59f),
                strokeWidth = stroke
            )
            drawLine(
                color = Gold,
                start = Offset(size.width * 0.58f, size.height * 0.59f),
                end = Offset(size.width * 0.76f, size.height * 0.42f),
                strokeWidth = stroke
            )
        }
        if (hasImage) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 3.dp, y = (-3).dp)
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Gold),
                contentAlignment = Alignment.Center
            ) {
                Text("✓", color = Color(0xFF211800), fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

private fun formatDreamMoneyInput(raw: String): String {
    val digits = raw.filter(Char::isDigit).take(15)
    if (digits.isBlank()) return ""
    return digits.reversed().chunked(3).joinToString(",").reversed()
}
