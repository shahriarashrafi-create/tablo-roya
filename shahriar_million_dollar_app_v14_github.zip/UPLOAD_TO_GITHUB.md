# ساخت APK نسخه ۱۴

1. ZIP را Extract کن و محتوایش را داخل ریشه Repository قرار بده.
2. Push کن یا Workflow **Build Android APK** را از Actions اجرا کن.
3. بعد از Build، Artifact با نام `shahriar-million-path-v14-apk` را دانلود کن.
