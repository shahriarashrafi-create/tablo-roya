package com.shahriar.gamify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private const val KEY_TIMESHEET_STATE = "timesheet_state_v1"
private const val TS_MIN_HOUR = 7
private const val TS_MAX_HOUR = 24
private const val TS_MAX_WEEK_OFFSET = 10
private const val TS_MIN_ZOOM = 0.15f
private const val TS_MAX_ZOOM = 5.0f
private const val TS_REMINDER_PREF_KEY = "timesheet_reminder_keys"
internal const val EXTRA_TIMESHEET_REMINDER_TITLE = "timesheet_reminder_title"
internal const val EXTRA_TIMESHEET_REMINDER_TIME = "timesheet_reminder_time"
private val TS_DAYS = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")

private data class TimeSheetEvent(
    val id: Long,
    val day: Int,
    val startHour: Int,
    val endHour: Int,
    val title: String,
    val status: String = "planned",
    val recurring: Boolean = false,
    val reminder: Boolean = false,
    val templateId: Long = 0L
)

private data class TimeSheetState(
    val weekOffset: Int = 0,
    val zoom: Float = 1f,
    val weeks: Map<String, List<TimeSheetEvent>> = emptyMap(),
    val templates: List<TimeSheetEvent> = emptyList(),
    val nextId: Long = 1L
)

private data class TsJalaliDate(val year: Int, val month: Int, val day: Int)

private val tsJalaliMonthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

private fun tsGregorianToJalali(date: LocalDate): TsJalaliDate {
    var gy = date.year - 1600
    val gm = date.monthValue - 1
    val gd = date.dayOfMonth - 1
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
    for (i in 0 until gm) gDayNo += gDays[i]
    val originalYear = date.year
    val leap = originalYear % 400 == 0 || (originalYear % 4 == 0 && originalYear % 100 != 0)
    if (gm > 1 && leap) gDayNo++
    gDayNo += gd

    var jDayNo = gDayNo - 79
    val jNp = jDayNo / 12053
    jDayNo %= 12053
    var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
    jDayNo %= 1461
    if (jDayNo >= 366) {
        jy += (jDayNo - 1) / 365
        jDayNo = (jDayNo - 1) % 365
    }
    var jm = 0
    while (jm < 11 && jDayNo >= jDays[jm]) {
        jDayNo -= jDays[jm]
        jm++
    }
    return TsJalaliDate(jy, jm + 1, jDayNo + 1)
}

private fun tsPersianDigits(text: String): String {
    val latin = "0123456789"
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    return buildString(text.length) {
        text.forEach { ch -> append(if (ch in latin) persian[latin.indexOf(ch)] else ch) }
    }
}

private fun tsDateShort(date: LocalDate): String {
    val j = tsGregorianToJalali(date)
    return tsPersianDigits(String.format(Locale.US, "%02d/%02d", j.month, j.day))
}

private fun tsWeekLabel(start: LocalDate): String {
    val end = start.plusDays(6)
    val a = tsGregorianToJalali(start)
    val b = tsGregorianToJalali(end)
    return if (a.year == b.year && a.month == b.month) {
        "${tsPersianDigits(a.day.toString())} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[a.month - 1]} ${tsPersianDigits(a.year.toString())}"
    } else {
        "${tsPersianDigits(a.day.toString())} ${tsJalaliMonthNames[a.month - 1]} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[b.month - 1]}"
    }
}

private fun tsBaseSaturday(today: LocalDate = LocalDate.now()): LocalDate {
    val daysBack = (today.dayOfWeek.value - 6 + 7) % 7
    return today.minusDays(daysBack.toLong())
}

private fun tsWeekStart(offset: Int): LocalDate = tsBaseSaturday().plusWeeks(offset.toLong())
private fun tsWeekKey(start: LocalDate): String = start.toString()

private fun timeSheetEventToJson(event: TimeSheetEvent) = JSONObject()
    .put("id", event.id)
    .put("day", event.day)
    .put("startHour", event.startHour)
    .put("endHour", event.endHour)
    .put("title", event.title)
    .put("status", event.status)
    .put("recurring", event.recurring)
    .put("reminder", event.reminder)
    .put("templateId", event.templateId)

private fun timeSheetStateToJson(state: TimeSheetState): String {
    val weeksObject = JSONObject()
    state.weeks.forEach { (key, events) ->
        weeksObject.put(key, JSONArray().also { array -> events.forEach { array.put(timeSheetEventToJson(it)) } })
    }
    val templates = JSONArray().also { array -> state.templates.forEach { array.put(timeSheetEventToJson(it)) } }
    return JSONObject()
        .put("formatVersion", 2)
        .put("weekOffset", state.weekOffset)
        .put("zoom", state.zoom.toDouble())
        .put("weeks", weeksObject)
        .put("templates", templates)
        .put("nextId", state.nextId)
        .toString()
}

private fun parseTimeSheetEvent(obj: JSONObject): TimeSheetEvent? {
    val title = obj.optString("title").trim()
    if (title.isBlank()) return null
    val start = obj.optInt("startHour", TS_MIN_HOUR).coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)
    val end = obj.optInt("endHour", start + 1).coerceIn(start + 1, TS_MAX_HOUR)
    return TimeSheetEvent(
        id = obj.optLong("id", 0L).takeIf { it > 0L } ?: System.currentTimeMillis(),
        day = obj.optInt("day", 0).coerceIn(0, 6),
        startHour = start,
        endHour = end,
        title = title,
        status = obj.optString("status", "planned").takeIf { it in setOf("planned", "done", "missed") } ?: "planned",
        recurring = obj.optBoolean("recurring", false),
        reminder = obj.optBoolean("reminder", false),
        templateId = obj.optLong("templateId", 0L)
    )
}

private fun parseTimeSheetArray(array: JSONArray?): List<TimeSheetEvent> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val event = array.optJSONObject(i)?.let(::parseTimeSheetEvent) ?: continue
        add(event)
    }
}

private fun loadTimeSheetState(context: Context): TimeSheetState = runCatching {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TIMESHEET_STATE, null)
        ?: return@runCatching TimeSheetState()
    val root = JSONObject(raw)
    val weeksObj = root.optJSONObject("weeks")
    val weeks = linkedMapOf<String, List<TimeSheetEvent>>()
    if (weeksObj != null) {
        val keys = weeksObj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            weeks[key] = parseTimeSheetArray(weeksObj.optJSONArray(key))
        }
    }
    TimeSheetState(
        weekOffset = root.optInt("weekOffset", 0).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET),
        zoom = root.optDouble("zoom", 1.0).toFloat().coerceIn(TS_MIN_ZOOM, TS_MAX_ZOOM),
        weeks = weeks,
        templates = parseTimeSheetArray(root.optJSONArray("templates")),
        nextId = root.optLong("nextId", 1L).coerceAtLeast(1L)
    )
}.getOrDefault(TimeSheetState())

private fun saveTimeSheetState(context: Context, state: TimeSheetState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_TIMESHEET_STATE, timeSheetStateToJson(state))
        .apply()
}

private fun tsDisplayedEvents(state: TimeSheetState, weekStart: LocalDate): List<TimeSheetEvent> {
    val weekEvents = state.weeks[tsWeekKey(weekStart)].orEmpty()
    // A weekly event with templateId > 0 is an override for this occurrence of
    // a fixed weekly template (for example its Done/Missed state). Do not draw
    // the template a second time underneath the override.
    val overriddenTemplateIds = weekEvents.mapNotNull { it.templateId.takeIf { id -> id > 0L } }.toSet()
    val fixed = state.templates
        .filterNot { it.id in overriddenTemplateIds }
        .map { template ->
            template.copy(
                id = -template.id,
                recurring = true,
                templateId = template.id,
                status = "planned"
            )
        }
    return (fixed + weekEvents)
        .sortedWith(compareBy<TimeSheetEvent> { it.day }.thenBy { it.startHour }.thenBy { it.endHour })
}

private fun tsStatusLabel(status: String): String = when (status) {
    "done" -> "انجام شد"
    "missed" -> "انجام نشد"
    else -> "برنامه‌ریزی‌شده"
}

private fun tsOverlaps(aDay: Int, aStart: Int, aEnd: Int, event: TimeSheetEvent): Boolean =
    aDay == event.day && aStart < event.endHour && aEnd > event.startHour

private fun tsHasConflict(
    state: TimeSheetState,
    weekStart: LocalDate,
    day: Int,
    startHour: Int,
    endHour: Int,
    recurring: Boolean,
    editing: TimeSheetEvent?
): Boolean {
    val editingTemplateId = editing?.templateId?.takeIf { it > 0L }
        ?: editing?.takeIf { it.recurring && it.id > 0L }?.id
    val editingExplicitId = editing?.takeIf { !it.recurring && it.id > 0L }?.id

    fun isSameLogical(event: TimeSheetEvent): Boolean {
        if (editingTemplateId != null) {
            return event.templateId == editingTemplateId || (event.recurring && event.id == editingTemplateId)
        }
        if (editingExplicitId != null) return event.id == editingExplicitId
        return false
    }

    if (recurring) {
        val templateConflict = state.templates.any { event ->
            !isSameLogical(event) && tsOverlaps(day, startHour, endHour, event)
        }
        if (templateConflict) return true
        return state.weeks.values.flatten().any { event ->
            !isSameLogical(event) && tsOverlaps(day, startHour, endHour, event)
        }
    }

    return tsDisplayedEvents(state, weekStart).any { event ->
        !isSameLogical(event) && tsOverlaps(day, startHour, endHour, event)
    }
}

@Composable
internal fun TimeSheetDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current.applicationContext
    var state by remember { mutableStateOf(loadTimeSheetState(context)) }
    var editorSeed by remember { mutableStateOf<TimeSheetEvent?>(null) }
    var editorOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        rescheduleTimeSheetReminders(context, state)
    }

    fun commit(next: TimeSheetState) {
        state = next
        saveTimeSheetState(context, next)
        rescheduleTimeSheetReminders(context, next)
    }

    fun changeWeek(delta: Int) {
        val nextOffset = (state.weekOffset + delta).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET)
        if (nextOffset != state.weekOffset) commit(state.copy(weekOffset = nextOffset))
    }

    val weekStart = tsWeekStart(state.weekOffset)

    fun setOccurrenceStatus(event: TimeSheetEvent, status: String) {
        val cleanStatus = status.takeIf { it in setOf("planned", "done", "missed") } ?: "planned"
        val key = tsWeekKey(weekStart)
        val weekList = state.weeks[key].orEmpty()
        val templateId = event.templateId.takeIf { it > 0L }
            ?: event.takeIf { it.recurring && it.id < 0L }?.id?.let { -it }

        if (templateId != null) {
            // Fixed weekly programs keep their template untouched. Per-week
            // completion state is stored as a lightweight occurrence override.
            val existing = weekList.firstOrNull { it.templateId == templateId }
            if (cleanStatus == "planned") {
                commit(state.copy(weeks = state.weeks + (key to weekList.filterNot { it.templateId == templateId })))
            } else {
                val template = state.templates.firstOrNull { it.id == templateId }
                val source = template ?: event
                val override = TimeSheetEvent(
                    id = existing?.id ?: state.nextId,
                    day = source.day,
                    startHour = source.startHour,
                    endHour = source.endHour,
                    title = source.title,
                    status = cleanStatus,
                    recurring = true,
                    reminder = source.reminder,
                    templateId = templateId
                )
                val updated = if (existing != null) {
                    weekList.map { if (it.id == existing.id) override else it }
                } else weekList + override
                commit(
                    state.copy(
                        weeks = state.weeks + (key to updated),
                        nextId = if (existing == null) state.nextId + 1 else state.nextId
                    )
                )
            }
        } else if (event.id > 0L) {
            val updated = weekList.map { if (it.id == event.id) it.copy(status = cleanStatus) else it }
            commit(state.copy(weeks = state.weeks + (key to updated)))
        }
    }
    val events = tsDisplayedEvents(state, weekStart)

    BackHandler(onBack = onDismiss)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF07101A)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF07101A), Color(0xFF0A1623), Color(0xFF060B12))
                        )
                    )
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                TimeSheetBackground()
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TimeSheetHeader(onDismiss)
                        TimeSheetWeekNav(
                            weekOffset = state.weekOffset,
                            onPrevious = { changeWeek(-1) },
                            onNext = { changeWeek(1) },
                            onCurrent = { commit(state.copy(weekOffset = 0)) }
                        )
                        TimeSheetStats(events)
                        TimeSheetLegend()
                        TimeSheetBoard(
                            weekStart = weekStart,
                            events = events,
                            zoom = state.zoom,
                            onZoomChanged = { nextZoom ->
                                val clean = nextZoom.coerceIn(TS_MIN_ZOOM, TS_MAX_ZOOM)
                                if (kotlin.math.abs(clean - state.zoom) > 0.01f) commit(state.copy(zoom = clean))
                            },
                            modifier = Modifier.weight(1f),
                            onCellClick = { day, hour, event ->
                                editorSeed = event ?: TimeSheetEvent(
                                    id = 0L,
                                    day = day,
                                    startHour = hour,
                                    endHour = (hour + 1).coerceAtMost(TS_MAX_HOUR),
                                    title = ""
                                )
                                editorOpen = true
                            }
                        )
                    }
                }
            }
        }
    }

    if (editorOpen) {
        val seed = editorSeed
        if (seed != null) {
            TimeSheetEventEditor(
                seed = seed,
                weekStart = weekStart,
                state = state,
                onDismiss = { editorOpen = false; editorSeed = null },
                onStatusChange = { event, status ->
                    setOccurrenceStatus(event, status)
                },
                onDelete = { event ->
                    val templateId = event.templateId.takeIf { it > 0L }
                        ?: event.takeIf { it.recurring && it.id > 0L }?.id
                    val next = if (templateId != null) {
                        state.copy(templates = state.templates.filterNot { it.id == templateId })
                    } else {
                        val key = tsWeekKey(weekStart)
                        state.copy(weeks = state.weeks + (key to state.weeks[key].orEmpty().filterNot { it.id == event.id }))
                    }
                    commit(next)
                    editorOpen = false
                    editorSeed = null
                },
                onSave = { title, day, startHour, endHour, recurring, reminder, status ->
                    val editing = seed.takeIf { it.id != 0L }
                    if (recurring) {
                        val existingTemplateId = editing?.templateId?.takeIf { it > 0L }
                            ?: editing?.takeIf { it.recurring && it.id > 0L }?.id
                        val templateId = existingTemplateId ?: state.nextId
                        val template = TimeSheetEvent(
                            id = templateId,
                            day = day,
                            startHour = startHour,
                            endHour = endHour,
                            title = title,
                            recurring = true,
                            reminder = reminder,
                            templateId = 0L
                        )
                        val key = tsWeekKey(weekStart)
                        val weekList = state.weeks[key].orEmpty()
                        val cleanedWeek = if (editing != null) {
                            weekList.filterNot { stored ->
                                (editing.id > 0L && stored.id == editing.id) ||
                                    (existingTemplateId != null && stored.templateId == existingTemplateId)
                            }
                        } else weekList
                        val templates = if (existingTemplateId != null) {
                            state.templates.map { if (it.id == existingTemplateId) template else it }
                        } else state.templates + template
                        var nextState = state.copy(
                            templates = templates,
                            weeks = state.weeks + (key to cleanedWeek),
                            nextId = if (existingTemplateId == null) state.nextId + 1 else state.nextId
                        )
                        if (status != "planned") {
                            val override = TimeSheetEvent(
                                id = nextState.nextId,
                                day = day,
                                startHour = startHour,
                                endHour = endHour,
                                title = title,
                                status = status,
                                recurring = true,
                                reminder = reminder,
                                templateId = templateId
                            )
                            nextState = nextState.copy(
                                weeks = nextState.weeks + (key to (nextState.weeks[key].orEmpty() + override)),
                                nextId = nextState.nextId + 1
                            )
                        }
                        commit(nextState)
                    } else {
                        val existingTemplateId = editing?.templateId?.takeIf { it > 0L }
                            ?: editing?.takeIf { it.recurring && it.id > 0L }?.id
                        val key = tsWeekKey(weekStart)
                        val explicitId = editing?.takeIf { !it.recurring && it.id > 0L }?.id ?: state.nextId
                        val event = TimeSheetEvent(
                            id = explicitId,
                            day = day,
                            startHour = startHour,
                            endHour = endHour,
                            title = title,
                            status = status,
                            recurring = false,
                            reminder = reminder,
                            templateId = 0L
                        )
                        val list = state.weeks[key].orEmpty()
                        val cleanedList = if (existingTemplateId != null) list.filterNot { it.templateId == existingTemplateId } else list
                        val updatedList = if (editing != null && !editing.recurring && editing.id > 0L) {
                            cleanedList.map { if (it.id == editing.id) event else it }
                        } else cleanedList + event
                        commit(
                            state.copy(
                                templates = if (existingTemplateId != null) state.templates.filterNot { it.id == existingTemplateId } else state.templates,
                                weeks = state.weeks + (key to updatedList),
                                nextId = if (editing == null || editing.recurring) state.nextId + 1 else state.nextId
                            )
                        )
                    }
                    editorOpen = false
                    editorSeed = null
                }
            )
        }
    }
}

@Composable
private fun TimeSheetBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(
            color = Color(0x0AF2C957),
            radius = size.width * 0.42f,
            center = Offset(size.width * 0.12f, size.height * 0.16f)
        )
        drawCircle(
            color = Color(0x082A72C7),
            radius = size.width * 0.54f,
            center = Offset(size.width * 0.94f, size.height * 0.72f)
        )

        // Large, very subtle game-board grid. It keeps the screen playful without
        // competing with the actual time grid.
        val cellW = size.width / 5f
        val cellH = size.height / 8f
        for (x in 0..5) {
            for (y in 0..8) {
                if ((x + y) % 2 == 0) {
                    drawRect(
                        color = Color(0x032D638E),
                        topLeft = Offset(x * cellW, y * cellH),
                        size = Size(cellW, cellH)
                    )
                }
            }
        }
        drawCircle(
            color = Color(0x0FE7C45A),
            radius = size.width * 0.10f,
            center = Offset(size.width * 0.84f, size.height * 0.18f),
            style = Stroke(width = 1.5f)
        )
    }
}

@Composable
private fun TimeSheetHeader(onDismiss: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(42.dp)) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(28.dp)
                .background(Color(0xB2101B28), CircleShape)
                .border(1.dp, Color(0x66586B7E), CircleShape)
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Text("✕", color = Color(0xFFE8C65D), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("تایم‌شیت", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Box(
                Modifier.size(30.dp)
                    .background(Color(0x1FE8C65D), RoundedCornerShape(9.dp))
                    .border(1.dp, Color(0x55E8C65D), RoundedCornerShape(9.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("▦", color = Color(0xFFE8C65D), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TimeSheetWeekNav(
    weekOffset: Int,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onCurrent: () -> Unit
) {
    val start = tsWeekStart(weekOffset)
    Surface(
        color = Color(0xC50C1723),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x6BE0C25C))
    ) {
        Row(
            Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TimeSheetNavButton(
                text = "بعد  →",
                enabled = weekOffset < TS_MAX_WEEK_OFFSET,
                onClick = onNext
            )
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(tsWeekLabel(start), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                if (weekOffset != 0) {
                    Text(
                        "بازگشت به این هفته",
                        color = Color(0xFFE8C65D),
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 3.dp).clickable(onClick = onCurrent)
                    )
                } else {
                    Text("این هفته", color = Color(0xFF8D9AAA), fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
            TimeSheetNavButton(
                text = "←  قبل",
                enabled = weekOffset > -TS_MAX_WEEK_OFFSET,
                onClick = onPrevious
            )
        }
    }
}

@Composable
private fun TimeSheetNavButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .width(78.dp)
            .height(38.dp)
            .background(if (enabled) Color(0xFF111E2C) else Color(0x88101820), RoundedCornerShape(12.dp))
            .border(1.dp, if (enabled) Color(0x555B6E82) else Color(0x223E4C5A), RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color.White else Color(0xFF56616D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TimeSheetStats(events: List<TimeSheetEvent>) {
    val planned = events.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) }
    val done = events.filter { it.status == "done" }.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) }
    val missed = events.filter { it.status == "missed" }.sumOf { (it.endHour - it.startHour).coerceAtLeast(0) }
    val free = (7 * (TS_MAX_HOUR - TS_MIN_HOUR) - planned).coerceAtLeast(0)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TimeSheetStatCard("برنامه", tsPersianDigits(planned.toString()), Color(0xFFE8C65D), Modifier.weight(1f))
        TimeSheetStatCard("انجام شد", tsPersianDigits(done.toString()), Color(0xFF55D69A), Modifier.weight(1f))
        TimeSheetStatCard("انجام نشد", tsPersianDigits(missed.toString()), Color(0xFFE26D67), Modifier.weight(1f))
        TimeSheetStatCard("آزاد", tsPersianDigits(free.toString()), Color(0xFF76B9F2), Modifier.weight(1f))
    }
}

@Composable
private fun TimeSheetStatCard(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.height(62.dp),
        color = Color(0xB20E1925),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(
            Modifier.fillMaxSize().padding(vertical = 8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, color = accent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Color(0xFF9BA8B6), fontSize = 8.sp)
        }
    }
}

@Composable
private fun TimeSheetLegend() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TimeSheetLegendItem("برنامه", Color(0xFFE8C65D), Modifier.weight(1f))
        TimeSheetLegendItem("انجام شد", Color(0xFF55D69A), Modifier.weight(1f))
        TimeSheetLegendItem("انجام نشد", Color(0xFFE26D67), Modifier.weight(1f))
        TimeSheetLegendItem("↻ ثابت", Color(0xFF91B9FF), Modifier.weight(1f))
    }
}

@Composable
private fun TimeSheetLegendItem(label: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.height(28.dp),
        color = Color(0x8B0D1824),
        shape = RoundedCornerShape(9.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.22f))
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(6.dp).background(accent, CircleShape))
            Spacer(Modifier.width(4.dp))
            Text(label, color = Color(0xFFAAB5C0), fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun TimeSheetBoard(
    weekStart: LocalDate,
    events: List<TimeSheetEvent>,
    zoom: Float,
    onZoomChanged: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onCellClick: (day: Int, hour: Int, event: TimeSheetEvent?) -> Unit
) {
    val horizontal = rememberScrollState()
    val vertical = rememberScrollState()
    val scope = rememberCoroutineScope()
    var localZoom by remember(zoom) { mutableStateOf(zoom.coerceIn(TS_MIN_ZOOM, TS_MAX_ZOOM)) }

    LaunchedEffect(zoom) {
        if (kotlin.math.abs(localZoom - zoom) > 0.01f) localZoom = zoom.coerceIn(TS_MIN_ZOOM, TS_MAX_ZOOM)
    }

    // Keep pinch zoom fluid. Persist only after the gesture settles instead of
    // writing SharedPreferences on every tiny scale delta.
    LaunchedEffect(localZoom) {
        delay(220)
        if (kotlin.math.abs(localZoom - zoom) > 0.01f) onZoomChanged(localZoom)
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xC0091420),
        shape = RoundedCornerShape(22.dp),
        border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0x786D6749))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures(panZoomLock = false) { _, pan, gestureZoom, _ ->
                        val nextZoom = (localZoom * gestureZoom).coerceIn(TS_MIN_ZOOM, TS_MAX_ZOOM)
                        if (kotlin.math.abs(nextZoom - localZoom) > 0.001f) {
                            localZoom = nextZoom
                        }
                        if (pan.x != 0f || pan.y != 0f) {
                            scope.launch { horizontal.scrollBy(-pan.x) }
                            scope.launch { vertical.scrollBy(-pan.y) }
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val cellW = size.width / 5f
                val cellH = size.height / 7f
                for (x in 0..5) {
                    for (y in 0..7) {
                        if ((x + y) % 2 == 0) {
                            drawRect(Color(0x031A69A6), Offset(x * cellW, y * cellH), Size(cellW, cellH))
                        }
                    }
                }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .horizontalScroll(horizontal)
                    .verticalScroll(vertical)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy((5f * localZoom).dp)
            ) {
                TimeSheetHourHeader(localZoom)
                for (day in 0..6) {
                    TimeSheetDayRow(
                        day = day,
                        date = weekStart.plusDays(day.toLong()),
                        events = events.filter { it.day == day },
                        zoom = localZoom,
                        onCellClick = onCellClick
                    )
                }
            }

            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                color = Color(0xD30B1521),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x55E8C65D))
            ) {
                Text(
                    "${tsPersianDigits((localZoom * 100).toInt().toString())}٪",
                    color = Color(0xFFE8C65D),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun TimeSheetHourHeader(zoom: Float) {
    val dayWidth = (94f * zoom).dp
    val cellWidth = (60f * zoom).dp
    val height = (34f * zoom).dp
    Row(horizontalArrangement = Arrangement.spacedBy((4f * zoom).dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(dayWidth).height(height).background(Color(0xFF132130), RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("روز", color = Color(0xFFE8C65D), fontSize = (10f * zoom).coerceIn(7f, 12f).sp, fontWeight = FontWeight.Bold)
        }
        for (hour in TS_MIN_HOUR until TS_MAX_HOUR) {
            Box(
                Modifier.width(cellWidth).height(height).background(Color(0xFF111D29), RoundedCornerShape(9.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${tsPersianDigits(hour.toString())}-${tsPersianDigits((hour + 1).toString())}",
                    color = Color(0xFFB7C1CB),
                    fontSize = (8f * zoom).coerceIn(6f, 10f).sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun TimeSheetDayRow(
    day: Int,
    date: LocalDate,
    events: List<TimeSheetEvent>,
    zoom: Float,
    onCellClick: (day: Int, hour: Int, event: TimeSheetEvent?) -> Unit
) {
    val isToday = date == LocalDate.now()
    val dayWidth = (94f * zoom).dp
    val rowHeight = (54f * zoom).dp
    Row(horizontalArrangement = Arrangement.spacedBy((4f * zoom).dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(
            modifier = Modifier.width(dayWidth).height(rowHeight),
            color = if (isToday) Color(0x34E6C14F) else Color(0xFF101C29),
            shape = RoundedCornerShape(11.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isToday) Color(0xA7E8C65D) else Color(0x334A5D71))
        ) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (isToday) "${TS_DAYS[day]} • امروز" else TS_DAYS[day],
                    color = if (isToday) Color(0xFFFFE18B) else Color.White,
                    fontSize = (10f * zoom).coerceIn(7f, 12f).sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(tsDateShort(date), color = Color(0xFF8996A4), fontSize = (8f * zoom).coerceIn(6f, 10f).sp)
            }
        }
        var hour = TS_MIN_HOUR
        while (hour < TS_MAX_HOUR) {
            val event = events.firstOrNull { hour >= it.startHour && hour < it.endHour }
            if (event != null && hour == event.startHour) {
                val spanHours = (event.endHour - event.startHour).coerceAtLeast(1)
                TimeSheetHourCell(
                    hour = hour,
                    event = event,
                    isStart = true,
                    isToday = isToday,
                    zoom = zoom,
                    spanHours = spanHours,
                    onClick = { onCellClick(day, hour, event) }
                )
                hour += spanHours
            } else if (event == null) {
                TimeSheetHourCell(
                    hour = hour,
                    event = null,
                    isStart = false,
                    isToday = isToday,
                    zoom = zoom,
                    spanHours = 1,
                    onClick = { onCellClick(day, hour, null) }
                )
                hour += 1
            } else {
                hour += 1
            }
        }
    }
}

@Composable
private fun TimeSheetHourCell(
    hour: Int,
    event: TimeSheetEvent?,
    isStart: Boolean,
    isToday: Boolean,
    zoom: Float,
    spanHours: Int = 1,
    onClick: () -> Unit
) {
    val bg = when (event?.status) {
        "done" -> Color(0xD3227A5F)
        "missed" -> Color(0xD3833642)
        "planned" -> Color(0xD38B6B1A)
        else -> if (isToday) Color(0x2BE8C65D) else Color(0xCC0B1521)
    }
    val border = when (event?.status) {
        "done" -> Color(0xFF69E7B0)
        "missed" -> Color(0xFFFF8B88)
        "planned" -> Color(0xFFFFD869)
        else -> if (isToday) Color(0x72E8C65D) else Color(0x36506477)
    }
    val gap = 4f * zoom
    val width = ((60f * spanHours) + (gap * (spanHours - 1))).dp
    Surface(
        modifier = Modifier.width(width).height((54f * zoom).dp).clickable(onClick = onClick),
        color = bg,
        shape = RoundedCornerShape(9.dp),
        border = androidx.compose.foundation.BorderStroke(if (event != null) 1.4.dp else 1.dp, border)
    ) {
        Box(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
            when {
                event != null && isStart -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(
                            event.title,
                            color = Color.White,
                            fontSize = (8.8f * zoom).coerceIn(6.5f, 11.5f).sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(2.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (event.recurring) Text("↻", color = Color(0xFFFFE18B), fontSize = (8f * zoom).coerceIn(6f, 10f).sp)
                            if (event.reminder) Text("◷", color = Color(0xFF9ED6FF), fontSize = (8f * zoom).coerceIn(6f, 10f).sp)
                            Text(
                                "${tsPersianDigits(event.startHour.toString())}-${tsPersianDigits(event.endHour.toString())}",
                                color = Color(0xFFDCE4EC),
                                fontSize = (7.5f * zoom).coerceIn(6f, 9.5f).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                event == null -> {
                    Text("＋", color = if (isToday) Color(0xFF8E8258) else Color(0xFF455568), fontSize = (12f * zoom).coerceIn(8f, 15f).sp)
                }
            }
        }
    }
}

private fun timeSheetReminderPendingIntent(
    context: Context,
    occurrenceKey: String,
    title: String,
    timeLabel: String
): PendingIntent {
    val intent = Intent(context, TimeSheetReminderReceiver::class.java).apply {
        data = Uri.parse("gamify://timesheet-reminder/${Uri.encode(occurrenceKey)}")
        putExtra(EXTRA_TIMESHEET_REMINDER_TITLE, title)
        putExtra(EXTRA_TIMESHEET_REMINDER_TIME, timeLabel)
    }
    return PendingIntent.getBroadcast(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun cancelTimeSheetReminder(context: Context, occurrenceKey: String) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timeSheetReminderPendingIntent(context, occurrenceKey, "", ""))
}

internal fun rescheduleTimeSheetReminders(context: Context) {
    rescheduleTimeSheetReminders(context, loadTimeSheetState(context))
}

private fun rescheduleTimeSheetReminders(
    context: Context,
    state: TimeSheetState,
    nowMillis: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault()
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val oldKeys = prefs.getStringSet(TS_REMINDER_PREF_KEY, emptySet()).orEmpty().toSet()
    oldKeys.forEach { cancelTimeSheetReminder(context, it) }

    val settings = loadSettings(context)
    if (!settings.notificationsEnabled) {
        prefs.edit().remove(TS_REMINDER_PREF_KEY).apply()
        return
    }

    val scheduled = linkedSetOf<String>()
    fun schedule(event: TimeSheetEvent, date: LocalDate, logicalId: Long) {
        if (!event.reminder || event.status != "planned") return
        val start = ZonedDateTime.of(date, LocalTime.of(event.startHour, 0), zone)
        val triggerAt = start.minusMinutes(5).toInstant().toEpochMilli()
        if (triggerAt <= nowMillis) return
        val key = "$logicalId@${date}"
        val timeLabel = "${TS_DAYS[event.day]} ${tsDateShort(date)} • ${tsPersianDigits(event.startHour.toString())}:۰۰"
        scheduleReliableAlarm(context, triggerAt, timeSheetReminderPendingIntent(context, key, event.title, timeLabel))
        scheduled += key
    }

    // One-time entries can live in any of the persisted week buckets.
    state.weeks.forEach { (weekKey, entries) ->
        val weekStart = runCatching { LocalDate.parse(weekKey) }.getOrNull() ?: return@forEach
        entries.filter { !it.recurring && it.templateId == 0L }.forEach { event ->
            schedule(event, weekStart.plusDays(event.day.toLong()), event.id)
        }
    }

    // Fixed weekly templates are scheduled for the current week and the next
    // ten weeks. Per-week done/missed overrides suppress that occurrence.
    val base = tsBaseSaturday()
    for (weekOffset in 0..TS_MAX_WEEK_OFFSET) {
        val weekStart = base.plusWeeks(weekOffset.toLong())
        val key = tsWeekKey(weekStart)
        val overrides = state.weeks[key].orEmpty()
        state.templates.forEach { template ->
            if (!template.reminder) return@forEach
            val override = overrides.firstOrNull { it.templateId == template.id }
            val occurrence = if (override != null) template.copy(status = override.status) else template
            schedule(occurrence, weekStart.plusDays(template.day.toLong()), template.id)
        }
    }

    prefs.edit().putStringSet(TS_REMINDER_PREF_KEY, scheduled).apply()
}

@Composable
private fun TimeSheetEventEditor(
    seed: TimeSheetEvent,
    weekStart: LocalDate,
    state: TimeSheetState,
    onDismiss: () -> Unit,
    onStatusChange: (TimeSheetEvent, String) -> Unit,
    onDelete: (TimeSheetEvent) -> Unit,
    onSave: (title: String, day: Int, startHour: Int, endHour: Int, recurring: Boolean, reminder: Boolean, status: String) -> Unit
) {
    var title by remember(seed.id, seed.day, seed.startHour) { mutableStateOf(seed.title) }
    var day by remember(seed.id, seed.day) { mutableStateOf(seed.day) }
    var startHour by remember(seed.id, seed.startHour) { mutableStateOf(seed.startHour) }
    var endHour by remember(seed.id, seed.startHour, seed.endHour) {
        mutableStateOf(
            if (seed.id == 0L) (seed.startHour + 1).coerceAtMost(TS_MAX_HOUR)
            else seed.endHour.coerceAtLeast(seed.startHour + 1).coerceAtMost(TS_MAX_HOUR)
        )
    }
    var recurring by remember(seed.id, seed.recurring) { mutableStateOf(if (seed.id == 0L) true else seed.recurring) }
    var reminder by remember(seed.id, seed.reminder) { mutableStateOf(seed.reminder) }
    var status by remember(seed.id, seed.status) { mutableStateOf(seed.status) }
    var dayExpanded by remember { mutableStateOf(false) }
    var startExpanded by remember { mutableStateOf(false) }
    var endExpanded by remember { mutableStateOf(false) }

    val cleanTitle = title.trim()
    val timeInvalid = endHour <= startHour
    val conflict = if (!timeInvalid && cleanTitle.isNotBlank()) {
        tsHasConflict(
            state = state,
            weekStart = weekStart,
            day = day,
            startHour = startHour,
            endHour = endHour,
            recurring = recurring,
            editing = seed.takeIf { it.id != 0L }
        )
    } else false
    val canSave = cleanTitle.isNotBlank() && !timeInvalid && !conflict
    val isEditing = seed.id != 0L

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = onDismiss) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.Transparent,
                shape = RoundedCornerShape(26.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x88E8C65D))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF152235),
                                    Color(0xFF09131E),
                                    Color(0xFF11100D),
                                    Color(0xFF071019)
                                )
                            )
                        )
                ) {
                    // Dream-editor inspired background: soft checker/grid plus
                    // translucent square/circle accents.
                    Canvas(Modifier.matchParentSize()) {
                        val cell = 38.dp.toPx()
                        var row = 0
                        var y = 0f
                        while (y < size.height + cell) {
                            var col = 0
                            var x = 0f
                            while (x < size.width + cell) {
                                if ((row + col) % 2 == 0) {
                                    drawRect(
                                        color = Color(0x09F2C957),
                                        topLeft = Offset(x, y),
                                        size = Size(cell, cell)
                                    )
                                } else {
                                    drawRect(
                                        color = Color(0x061C5C91),
                                        topLeft = Offset(x, y),
                                        size = Size(cell, cell)
                                    )
                                }
                                x += cell
                                col++
                            }
                            y += cell
                            row++
                        }
                        drawCircle(Color(0x18F4C95D), radius = size.width * 0.34f, center = Offset(size.width * 0.08f, size.height * 0.10f))
                        drawCircle(Color(0x102E76C9), radius = size.width * 0.31f, center = Offset(size.width * 0.94f, size.height * 0.74f))
                        drawRect(
                            Color(0x0EE58B35),
                            topLeft = Offset(size.width * 0.72f, size.height * 0.16f),
                            size = Size(size.width * 0.18f, size.width * 0.18f)
                        )
                    }

                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 650.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(18.dp),
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(Modifier.fillMaxWidth()) {
                                Text(
                                    if (isEditing) "ویرایش برنامه" else "برنامه جدید",
                                    color = Color.White,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.Center)
                                        .padding(end = 40.dp)
                                )
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .size(28.dp)
                                        .clickable(onClick = onDismiss),
                                    color = Color(0x66172230),
                                    shape = CircleShape,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x44586B7E))
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("×", color = Color(0xFFE8EDF3), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it.take(80) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("عنوان برنامه", fontSize = 10.sp) },
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(textAlign = TextAlign.Right, fontSize = 17.sp),
                            colors = gamifyTextFieldColors(),
                            shape = RoundedCornerShape(14.dp)
                        )

                        Box(Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { dayExpanded = true },
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    "روز: ${TS_DAYS[day]}",
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Right
                                )
                            }
                            DropdownMenu(expanded = dayExpanded, onDismissRequest = { dayExpanded = false }) {
                                TS_DAYS.forEachIndexed { index, name ->
                                    DropdownMenuItem(
                                        text = { Text(name, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right) },
                                        onClick = { day = index; dayExpanded = false }
                                    )
                                }
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { startExpanded = true },
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(
                                        "شروع ${tsPersianDigits(startHour.toString())}:۰۰",
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Right,
                                        fontSize = 11.sp
                                    )
                                }
                                DropdownMenu(expanded = startExpanded, onDismissRequest = { startExpanded = false }) {
                                    for (h in TS_MIN_HOUR until TS_MAX_HOUR) {
                                        DropdownMenuItem(
                                            text = { Text("${tsPersianDigits(h.toString())}:۰۰") },
                                            onClick = {
                                                startHour = h
                                                endHour = (h + 1).coerceAtMost(TS_MAX_HOUR)
                                                startExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { endExpanded = true },
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(
                                        "پایان ${tsPersianDigits(endHour.toString())}:۰۰",
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Right,
                                        fontSize = 11.sp
                                    )
                                }
                                DropdownMenu(expanded = endExpanded, onDismissRequest = { endExpanded = false }) {
                                    for (h in (startHour + 1)..TS_MAX_HOUR) {
                                        DropdownMenuItem(
                                            text = { Text("${tsPersianDigits(h.toString())}:۰۰") },
                                            onClick = { endHour = h; endExpanded = false }
                                        )
                                    }
                                }
                            }
                        }

                        if (isEditing) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("وضعیت برنامه", color = Color(0xFFB8C2CD), fontSize = 9.sp, textAlign = TextAlign.Right)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(
                                        "planned" to "برنامه",
                                        "done" to "انجام شد",
                                        "missed" to "انجام نشد"
                                    ).forEach { (value, label) ->
                                        val selected = status == value
                                        val accent = when (value) {
                                            "done" -> Color(0xFF55D69A)
                                            "missed" -> Color(0xFFE26D67)
                                            else -> Color(0xFFE8C65D)
                                        }
                                        Surface(
                                            modifier = Modifier.weight(1f).height(40.dp).clickable {
                                                status = value
                                                onStatusChange(seed, value)
                                            },
                                            color = if (selected) accent.copy(alpha = 0.20f) else Color(0x66111D29),
                                            shape = RoundedCornerShape(12.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) accent else Color(0x3D526478))
                                        ) {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(label, color = if (selected) accent else Color(0xFFA3AFBB), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0x7A111D29),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3D526478))
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End
                            ) {
                                Text(
                                    "برنامه ثابت هفتگی",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.weight(1f)
                                )
                                Checkbox(checked = recurring, onCheckedChange = { recurring = it })
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0x7A111D29),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3D526478))
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End
                            ) {
                                Text(
                                    "یادآوری ۵ دقیقه قبل",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.weight(1f)
                                )
                                Checkbox(checked = reminder, onCheckedChange = { reminder = it })
                            }
                        }

                        if (conflict) {
                            Text(
                                "این بازه با یک برنامه دیگر تداخل دارد.",
                                color = Color(0xFFE57972),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onSave(cleanTitle, day, startHour, endHour, recurring, reminder, status) },
                                enabled = canSave,
                                modifier = Modifier.weight(1f).height(46.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8C65D), contentColor = Color(0xFF211800)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(if (isEditing) "ذخیره تغییرات" else "ثبت برنامه", fontWeight = FontWeight.ExtraBold)
                            }
                            if (isEditing) {
                                OutlinedButton(
                                    onClick = { onDelete(seed) },
                                    modifier = Modifier.width(92.dp).height(46.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text("حذف", color = Color(0xFFE57972))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
