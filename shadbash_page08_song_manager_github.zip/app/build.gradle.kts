plugins {
    id("com.android.application")
}

android {
    namespace = "com.shahriar.nextbeat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shahriar.shadbash"
        minSdk = 24
        targetSdk = 35
        versionCode = 11
        versionName = "1.0.0-shadbash-song-manager"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
