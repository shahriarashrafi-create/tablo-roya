shadbash - Song Manager Design

Changes in this ZIP:
- Removed the hardcoded Reza Sadeghi song and its hardcoded answer.
- Added a full «مدیریت آهنگ‌ها» page.
- New song form includes:
  - audio file picker
  - song title
  - singer name
  - start second
  - end second
  - correct answer after the cut
- Added song list with:
  - select for game
  - edit
  - delete
- Main home button «مدیریت آهنگ‌ها» now opens this new page.
- Round page now reads its display data from the selected song instead of a fixed hardcoded song.
- This version focuses on UI/flow design for song management.
- Next step can be implementing real local saving of uploaded files and real playback from selected start/end times.
