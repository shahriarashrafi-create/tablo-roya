# Hero Realms Android v1.1

نسخه اصلاح‌شده برای اندروید و GitHub Actions.

تغییرات پایداری:
- WebView/renderer recovery برای جلوگیری از بسته‌شدن برنامه در صورت کرش GPU.
- حالت Safe Graphics به‌صورت خودکار در صورت از کار افتادن renderer.
- تنظیم کیفیت تطبیقی روی موبایل برای حفظ گرافیک بالا و پایداری بهتر.
- حالت تمام‌صفحه و Landscape.
- نسخه 1.1.0 / versionCode 2.

برای GitHub: همین ZIP را در workflow ساخت APK استفاده کنید.
