# Gamification v22

Applied the requested lower-half refinements:
- Removed the mission header row entirely (no more "مأموریت بعدی", "کلاسیک", or "Focus x2")
- Centered the mission title inside the card for a cleaner, more premium composition
- Removed the mission description/subtitle to reduce clutter
- Tightened the mission card vertically with smaller padding and more compact spacing
- Reworked the reward row into a centered, cleaner stat strip
- Slightly reduced the primary CTA height/text size for a tighter visual balance
- Reduced the secondary Change control footprint so it feels more like a secondary action
- Moved the page dots closer to the mission card
- Tightened the bottom navigation height and reduced icon/label sizing for a more compact footer
- Bumped app version to 0.22 / versionCode 22
