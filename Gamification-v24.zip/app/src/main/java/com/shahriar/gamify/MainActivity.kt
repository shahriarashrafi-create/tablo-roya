package com.shahriar.gamify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0C1320)
private val Gold = Color(0xFFF7C948)
private val GoldSoft = Color(0xFFFCE9A7)
private val TextSoft = Color(0xFFD8DFE8)
private val Divider = Color(0xFF2A3440)
private val Blue = Color(0xFF5CA3FF)

private val motivationalQuotes = listOf(
    "Small steps build great futures.",
    "Discipline creates freedom.",
    "Keep moving forward.",
    "Win the next moment.",
    "Progress over perfection.",
    "Build the life you want.",
    "Focus. Execute. Grow.",
    "Your future starts today.",
    "One mission at a time.",
    "Consistency beats intensity.",
    "Become stronger every day.",
    "Do the hard thing first.",
    "Make today count.",
    "Your habits shape your destiny.",
    "Keep the promise to yourself.",
    "Action creates confidence.",
    "Great things take repetition.",
    "Earn your next level.",
    "Stay focused on the mission.",
    "Become who you said you would.",
    "Momentum changes everything.",
    "Show up and do the work.",
    "Every effort adds up.",
    "Your discipline is your power.",
    "Start before you feel ready.",
    "Keep building your future.",
    "One focused hour can change a day.",
    "Progress is always earned.",
    "Make your future proud.",
    "Train your mind to finish.",
    "Growth begins with action.",
    "Your next level needs you.",
    "Build momentum, not excuses.",
    "Today is another chance to grow.",
    "Focus turns goals into reality.",
    "Keep going when it gets hard.",
    "Success is built in small moments.",
    "Make discipline your advantage.",
    "Your actions define your path.",
    "Push beyond your comfort zone.",
    "Finish what you started.",
    "Create a life worth leveling up.",
    "Stay consistent. Stay dangerous.",
    "The mission is simple: improve.",
    "Build yourself every single day.",
    "Your future rewards consistency.",
    "Focus now. Celebrate later.",
    "Every mission makes you stronger.",
    "Become better than yesterday.",
    "Keep climbing. Your peak is ahead."
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val coins: Int = 1320,
    val combo: Int = 12
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val ringColors: List<Color>
)

private enum class WorldButtonType { Quest, Map, Inbox, Shop }
private enum class BottomNavType { Home, Missions, Stats, Settings }

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", Color(0xFF6D3C1D), Color(0xFFF2C56F)),
    RankTier(6, 10, "Explorer", Color(0xFF7D1E1A), Color(0xFFF5CC62)),
    RankTier(11, 15, "Seeker", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value)

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val player = remember { PlayerState() }
    var quoteIndex by remember { mutableIntStateOf(motivationalQuotes.indices.random()) }
    val quote = motivationalQuotes[quoteIndex]

    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                GameBottomNavigation(
                    selected = tab,
                    onSelect = { i ->
                        tab = i
                        if (i == 0) {
                            var next = motivationalQuotes.indices.random()
                            if (motivationalQuotes.size > 1) {
                                while (next == quoteIndex) next = motivationalQuotes.indices.random()
                            }
                            quoteIndex = next
                        }
                    }
                )
            }
        ) { pad ->
            if (tab == 0) {
                // Keep the world background flowing underneath the translucent bottom navigation.
                // Only the top system inset is applied here; the nav itself handles its own safe area.
                GameHome(
                    player = player,
                    quote = quote,
                    modifier = Modifier.padding(top = pad.calculateTopPadding())
                )
            } else {
                Box(
                    modifier = Modifier
                        .padding(top = pad.calculateTopPadding())
                        .fillMaxSize()
                        .background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(listOf("", "کارها", "آمار", "تنظیمات")[tab], color = Color.White, fontSize = 24.sp)
                }
            }
        }
    }
}

@Composable
private fun GameBottomNavigation(selected: Int, onSelect: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x520B1119),
                        Color(0xB20A1018),
                        Color(0xE2080D14)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0x55E5C87A), Color.Transparent)
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(size.width, 1.dp.toPx())
                )
            }
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(BottomNavType.Home, "خانه", 0),
                Triple(BottomNavType.Missions, "کارها", 1),
                Triple(BottomNavType.Stats, "آمار", 2),
                Triple(BottomNavType.Settings, "تنظیمات", 3)
            )
            items.forEach { (type, title, index) ->
                BottomNavItem(
                    type = type,
                    title = title,
                    selected = selected == index,
                    onClick = { onSelect(index) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    type: BottomNavType,
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconColor = if (selected) Gold else Color(0xFFB3BBC7)
    val textColor = if (selected) GoldSoft else Color(0xFFA6AFBC)

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(width = 46.dp, height = 30.dp)
                .drawBehind {
                    if (selected) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color(0x38F6C84C), Color(0x12F6C84C), Color.Transparent),
                                center = center,
                                radius = size.width * 0.52f
                            ),
                            radius = size.width * 0.52f,
                            center = center
                        )
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, Gold.copy(alpha = 0.85f), Color.Transparent)
                            ),
                            topLeft = Offset(size.width * 0.16f, 0f),
                            size = Size(size.width * 0.68f, 1.5.dp.toPx()),
                            cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            BottomNavIcon(type = type, color = iconColor)
        }
        Spacer(Modifier.height(1.dp))
        Text(
            text = title,
            color = textColor,
            fontSize = 9.5.sp,
            lineHeight = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun BottomNavIcon(type: BottomNavType, color: Color) {
    Canvas(modifier = Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.5.dp.toPx()
        when (type) {
            BottomNavType.Home -> {
                // Compact gamepad icon.
                val body = Path().apply {
                    moveTo(w * 0.22f, h * 0.42f)
                    cubicTo(w * 0.28f, h * 0.24f, w * 0.42f, h * 0.23f, w * 0.50f, h * 0.31f)
                    cubicTo(w * 0.58f, h * 0.23f, w * 0.72f, h * 0.24f, w * 0.78f, h * 0.42f)
                    lineTo(w * 0.88f, h * 0.70f)
                    cubicTo(w * 0.91f, h * 0.80f, w * 0.82f, h * 0.88f, w * 0.73f, h * 0.81f)
                    lineTo(w * 0.60f, h * 0.70f)
                    lineTo(w * 0.40f, h * 0.70f)
                    lineTo(w * 0.27f, h * 0.81f)
                    cubicTo(w * 0.18f, h * 0.88f, w * 0.09f, h * 0.80f, w * 0.12f, h * 0.70f)
                    close()
                }
                drawPath(body, color = color, style = Stroke(width = stroke))
                drawLine(color, Offset(w * 0.31f, h * 0.48f), Offset(w * 0.31f, h * 0.64f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(w * 0.23f, h * 0.56f), Offset(w * 0.39f, h * 0.56f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.67f, h * 0.51f))
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.75f, h * 0.60f))
            }
            BottomNavType.Missions -> {
                drawLine(color, Offset(w * 0.26f, h * 0.16f), Offset(w * 0.26f, h * 0.84f), strokeWidth = stroke, cap = StrokeCap.Round)
                val flag = Path().apply {
                    moveTo(w * 0.28f, h * 0.20f)
                    lineTo(w * 0.74f, h * 0.24f)
                    lineTo(w * 0.64f, h * 0.45f)
                    lineTo(w * 0.74f, h * 0.61f)
                    lineTo(w * 0.28f, h * 0.56f)
                    close()
                }
                drawPath(flag, color = color, style = Stroke(width = stroke))
            }
            BottomNavType.Stats -> {
                drawRoundRect(color = color, topLeft = Offset(w * 0.16f, h * 0.56f), size = Size(w * 0.14f, h * 0.28f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.43f, h * 0.38f), size = Size(w * 0.14f, h * 0.46f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.70f, h * 0.20f), size = Size(w * 0.14f, h * 0.64f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
            }
            BottomNavType.Settings -> {
                drawCircle(color = color, radius = w * 0.23f, center = center, style = Stroke(width = stroke))
                drawCircle(color = color, radius = w * 0.07f, center = center)
                val cx = center.x
                val cy = center.y
                val r1 = w * 0.30f
                val r2 = w * 0.42f
                listOf(0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f).forEach { a ->
                    val rad = Math.toRadians(a.toDouble())
                    val p1 = Offset(cx + cos(rad).toFloat() * r1, cy + sin(rad).toFloat() * r1)
                    val p2 = Offset(cx + cos(rad).toFloat() * r2, cy + sin(rad).toFloat() * r2)
                    drawLine(color, p1, p2, strokeWidth = stroke, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun GameHome(player: PlayerState, quote: String, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = "World Background",
            modifier = Modifier
                .fillMaxSize(),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.TopCenter
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x6A081118),
                        Color(0x140A1118),
                        Color(0x120B1118),
                        Color(0x46091018),
                        Color(0xD8091018)
                    ),
                    startY = 0f,
                    endY = size.height
                )
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0x4C050B12),
                        Color(0x14050B12),
                        Color(0x00050B12),
                        Color(0x14050B12),
                        Color(0x4C050B12)
                    )
                )
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x18FFFFFF), Color(0x08FFFFFF), Color.Transparent)
                ),
                topLeft = Offset(0f, 0f),
                size = Size(size.width, size.height * 0.14f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            TopGameHud(player)
            Spacer(Modifier.height(8.dp))
            WorldStage(player = player, quote = quote, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun WorldStage(player: PlayerState, quote: String, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(type = WorldButtonType.Quest, label = "Quests", badge = "1")
            SideWorldButton(type = WorldButtonType.Map, label = "Map")
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(type = WorldButtonType.Inbox, label = "Inbox")
            SideWorldButton(type = WorldButtonType.Shop, label = "Shop")
        }

        HeadlineBlock(
            quote = quote,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp, start = 76.dp, end = 76.dp)
        )

        MissionCard(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 6.dp, end = 6.dp, bottom = 116.dp)
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 88.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PageDot(active = true)
            PageDot(active = false)
            PageDot(active = false)
        }
    }
}

@Composable
private fun HeadlineBlock(quote: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = quote.uppercase(Locale.US),
            color = Color(0xFFF8EFD8),
            textAlign = TextAlign.Center,
            fontSize = 9.6.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 12.sp,
            letterSpacing = 1.1.sp,
            style = androidx.compose.ui.text.TextStyle(
                shadow = Shadow(
                    color = Color(0xFF10151D),
                    offset = Offset(0f, 1.6f),
                    blurRadius = 6f
                )
            ),
            modifier = Modifier.drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(listOf(Color.Transparent, Color(0x12000000), Color.Transparent)),
                    topLeft = Offset(-10.dp.toPx(), -2.dp.toPx()),
                    size = Size(size.width + 20.dp.toPx(), size.height + 4.dp.toPx())
                )
            }
        )
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0x00E9C969), Color(0xA5E8C96D), Color(0xCCEFD98A))
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .padding(horizontal = 7.dp)
                    .size(11.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val diamond = Path().apply {
                        moveTo(size.width * 0.5f, 0f)
                        lineTo(size.width, size.height * 0.5f)
                        lineTo(size.width * 0.5f, size.height)
                        lineTo(0f, size.height * 0.5f)
                        close()
                    }
                    drawPath(diamond, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0B0), Color(0xFFE3BE53))))
                    drawPath(diamond, color = Color(0xFFF9E9B3), style = Stroke(width = 1.dp.toPx()))
                    drawCircle(brush = Brush.radialGradient(listOf(Color(0x70FFF2BF), Color.Transparent)), radius = size.minDimension * 0.55f)
                }
            }
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xCCEFD98A), Color(0xA5E8C96D), Color(0x00E9C969))
                        )
                    )
            )
        }
    }
}

@Composable
private fun PageDot(active: Boolean) {
    Box(
        modifier = Modifier
            .size(if (active) 10.dp else 8.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(if (active) Gold else Color(0xFF5A606D))
    )
}

@Composable
private fun SideWorldButton(type: WorldButtonType, label: String, badge: String? = null) {
    Box {
        Column(
            modifier = Modifier
                .width(44.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .background(Color(0x94090E14))
                .border(0.8.dp, Color(0x34E5C87A), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .padding(vertical = 5.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            WorldButtonIcon(type)
            Text(label, color = Color.White, fontSize = 8.sp, textAlign = TextAlign.Center, lineHeight = 8.sp)
        }
        if (badge != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 1.dp, y = (-2).dp)
                    .size(13.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0xFFEE4B4B)),
                contentAlignment = Alignment.Center
            ) {
                Text(badge, color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun WorldButtonIcon(type: WorldButtonType) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.3.dp.toPx()
        when (type) {
            WorldButtonType.Quest -> {
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.20f, h * 0.18f),
                    size = Size(w * 0.56f, h * 0.56f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawLine(Color(0xFF805A1A), Offset(w * 0.30f, h * 0.34f), Offset(w * 0.64f, h * 0.34f), strokeWidth = stroke)
                drawLine(Color(0xFF805A1A), Offset(w * 0.30f, h * 0.48f), Offset(w * 0.60f, h * 0.48f), strokeWidth = stroke)
                drawLine(Color(0xFF805A1A), Offset(w * 0.28f, h * 0.62f), Offset(w * 0.56f, h * 0.62f), strokeWidth = stroke)
                drawCircle(Color(0xFFD29B42), radius = w * 0.10f, center = Offset(w * 0.24f, h * 0.26f))
                drawCircle(Color(0xFFD29B42), radius = w * 0.10f, center = Offset(w * 0.76f, h * 0.68f))
            }
            WorldButtonType.Map -> {
                val path = Path().apply {
                    moveTo(w * 0.18f, h * 0.68f)
                    lineTo(w * 0.18f, h * 0.26f)
                    lineTo(w * 0.40f, h * 0.18f)
                    lineTo(w * 0.56f, h * 0.30f)
                    lineTo(w * 0.78f, h * 0.22f)
                    lineTo(w * 0.78f, h * 0.64f)
                    lineTo(w * 0.56f, h * 0.72f)
                    lineTo(w * 0.40f, h * 0.60f)
                    close()
                }
                drawPath(path, color = Color(0xFFE8C06A))
                drawLine(Color(0xFF815A17), Offset(w * 0.40f, h * 0.19f), Offset(w * 0.40f, h * 0.60f), strokeWidth = stroke)
                drawLine(Color(0xFF815A17), Offset(w * 0.56f, h * 0.30f), Offset(w * 0.56f, h * 0.71f), strokeWidth = stroke)
                drawCircle(Color(0xFFB53A31), radius = w * 0.09f, center = Offset(w * 0.54f, h * 0.42f))
            }
            WorldButtonType.Inbox -> {
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.16f, h * 0.28f),
                    size = Size(w * 0.68f, h * 0.40f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawLine(Color(0xFF7B5414), Offset(w * 0.18f, h * 0.30f), Offset(w * 0.50f, h * 0.52f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.82f, h * 0.30f), Offset(w * 0.50f, h * 0.52f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.18f, h * 0.67f), Offset(w * 0.40f, h * 0.48f), strokeWidth = stroke)
                drawLine(Color(0xFF7B5414), Offset(w * 0.82f, h * 0.67f), Offset(w * 0.60f, h * 0.48f), strokeWidth = stroke)
            }
            WorldButtonType.Shop -> {
                drawRoundRect(
                    color = Color(0xFFB86A2F),
                    topLeft = Offset(w * 0.18f, h * 0.34f),
                    size = Size(w * 0.64f, h * 0.34f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.14f, h * 0.22f),
                    size = Size(w * 0.72f, h * 0.20f),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
                drawLine(Color(0xFF7B3E11), Offset(w * 0.50f, h * 0.22f), Offset(w * 0.50f, h * 0.68f), strokeWidth = stroke)
                drawRoundRect(
                    color = Color(0xFFF7D883),
                    topLeft = Offset(w * 0.44f, h * 0.42f),
                    size = Size(w * 0.12f, h * 0.12f),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun MissionCard(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x66D8B55E), androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xD80B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(listOf(Color(0xDE0D1420), Color(0xD30A1017)))
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "۲۵ دقیقه تمرکز",
                color = Color.White,
                fontSize = 23.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Reward("★  +50 XP", Gold)
                Spacer(Modifier.width(18.dp))
                Reward("◉  +20 سکه", Color.White)
                Spacer(Modifier.width(18.dp))
                Reward("◷  25 دقیقه", TextSoft)
            }
            Button(
                onClick = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
            ) {
                Text("▶   شروع مأموریت", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun TopGameHud(player: PlayerState) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(21.dp))
                .background(Brush.verticalGradient(listOf(Color(0xBC101722), Color(0xA7080D14))))
                .drawBehind {
                    val stroke = 1.2.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xAAEED68A), Color(0xAAAF7A1E), Color(0xAAF1D57D), Color(0xAA996716))
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(Color(0x12FFF4C8), Color.Transparent, Color(0x0AFFF4C8))),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 3.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1.68f), verticalAlignment = Alignment.CenterVertically) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        XpBar(progress)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP",
                            color = Color(0xFFE8EBEF),
                            fontSize = 8.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.16f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text("Rank ${player.rank}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 11.sp)
                        Text(rankTier.title, color = rankTier.secondary, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.00f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(formatNumber(player.coins), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Today", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(0.82f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    FlameBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(player.combo.toString(), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text("Combo", color = GoldSoft, fontSize = 7.sp, lineHeight = 6.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(41.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f
            drawCircle(brush = Brush.sweepGradient(tier.ringColors), radius = radius, style = Stroke(width = stroke))
            drawCircle(color = Color(0xFF10141B), radius = size.minDimension * 0.36f)
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )
            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                drawCircle(
                    color = GoldSoft,
                    radius = dotR,
                    center = Offset(cx + cos(rad).toFloat() * ringR, cy + sin(rad).toFloat() * ringR)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
            .background(Color(0xFF242B34))
            .border(1.dp, Color(0x805E4A20), androidx.compose.foundation.shape.RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

private fun DrawScope.starPath(center: Offset, outerRadius: Float, innerRadius: Float, points: Int = 5): Path {
    val path = Path()
    val angle = Math.PI / points
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val theta = i * angle - Math.PI / 2
        val x = center.x + cos(theta).toFloat() * r
        val y = center.y + sin(theta).toFloat() * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                lineTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.80f, h * 0.66f)
                quadraticBezierTo(w * 0.66f, h * 0.87f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.87f, w * 0.20f, h * 0.66f)
                lineTo(w * 0.14f, h * 0.18f)
                close()
            }
            drawPath(shield, brush = Brush.verticalGradient(listOf(tier.secondary.copy(alpha = 0.18f), tier.primary)))
            drawPath(shield, color = tier.secondary, style = Stroke(width = 1.6f))
            val inner = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.77f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.61f)
                quadraticBezierTo(w * 0.61f, h * 0.77f, w * 0.50f, h * 0.83f)
                quadraticBezierTo(w * 0.39f, h * 0.77f, w * 0.28f, h * 0.61f)
                lineTo(w * 0.23f, h * 0.24f)
                close()
            }
            drawPath(inner, color = Color(0x14FFFFFF))
            val star = starPath(Offset(w * 0.50f, h * 0.44f), outerRadius = w * 0.17f, innerRadius = w * 0.07f)
            drawPath(star, color = GoldSoft)
        }
    }
}

@Composable
private fun CoinBadge() {
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFF0B5), Color(0xFFF5C84F), Color(0xFFC88715))),
                radius = size.minDimension / 2f,
                center = center
            )
            drawCircle(color = Color(0x30FFFFFF), radius = size.minDimension * 0.34f, center = Offset(center.x, center.y - 1.dp.toPx()))
            drawCircle(color = Color(0xB9784B0A), radius = size.minDimension / 2f - 0.6.dp.toPx(), center = center, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(color = Color(0xFFFCE9A7), radius = size.minDimension / 2f - 1.4.dp.toPx(), center = center, style = Stroke(width = 0.8.dp.toPx()))
            val star = starPath(center, outerRadius = size.minDimension * 0.18f, innerRadius = size.minDimension * 0.08f)
            drawPath(star, color = Color(0xFF7A4E00))
        }
    }
}

@Composable
private fun FlameBadge() {
    Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))))
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(inner, brush = Brush.verticalGradient(listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))))
        }
    }
}

@Composable
private fun HudDivider() {
    Box(Modifier.width(1.dp).height(31.dp).background(Divider))
}

@Composable
private fun Reward(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
}
