package com.shahriar.gamify

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * Owns the energetic mission soundtrack for the active timer session.
 * The bundled track is exactly two minutes long and MediaPlayer loops it
 * until the mission ends or sound is disabled.
 */
internal object MissionMusicController {
    private var player: MediaPlayer? = null
    private var playingSessionId: Long = 0L

    @Synchronized
    fun ensureForTimer(context: Context, settings: GameSettings, state: ActiveTimerState?) {
        if (!settings.soundEnabled || state == null || !state.isRunning || remainingSeconds(context, state) <= 0) {
            stop()
            return
        }

        val current = player
        if (playingSessionId == state.sessionId && current != null && current.isPlaying) return

        stop()
        val appContext = context.applicationContext
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val mediaPlayer = MediaPlayer.create(appContext, R.raw.mission_energy_loop, attributes, 0) ?: return
        mediaPlayer.isLooping = true
        mediaPlayer.setVolume(0.72f, 0.72f)
        mediaPlayer.setOnErrorListener { mp, _, _ ->
            runCatching { mp.release() }
            synchronized(this) {
                if (player === mp) {
                    player = null
                    playingSessionId = 0L
                }
            }
            true
        }
        mediaPlayer.start()
        player = mediaPlayer
        playingSessionId = state.sessionId
    }

    @Synchronized
    fun stop() {
        val current = player
        player = null
        playingSessionId = 0L
        if (current != null) {
            runCatching { if (current.isPlaying) current.stop() }
            runCatching { current.release() }
        }
    }
}
