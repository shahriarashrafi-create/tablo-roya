NextBeat - Page 01
صفحه اول اپ «بیت بعدی!»
Android WebView project
Package: com.shahriar.nextbeat
Version: 0.1.0-page01

این ZIP یک پروژه Android/Gradle مستقل است و برای Workflow عمومی قبلی که ZIP را Extract کرده
و assembleDebug اجرا می‌کند آماده شده است.
