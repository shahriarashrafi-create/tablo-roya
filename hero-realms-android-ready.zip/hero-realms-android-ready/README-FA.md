# Hero Realms Android — فایل آماده GitHub Actions

این ZIP یک پروژه واقعی Android/Gradle است، نه پروژه Vite/Web ساده.

فایل‌های `gradlew`، `settings.gradle` و `app/build.gradle` داخل پروژه هستند؛ بنابراین Workflow شما در مرحله **Find Android project** باید آن را پیدا کند.

## برای همان Workflow که در GitHub داری
1. همین ZIP را بدون تغییر در Repository آپلود کن.
2. Workflow **Build APK from uploaded ZIP** را اجرا کن.
3. پروژه از داخل ZIP پیدا می‌شود و `assembleDebug` اجرا می‌شود.
4. APK خروجی باید در artifact همان Run قرار بگیرد.

## نکته
در اولین Build، Gradle و Three.js از اینترنت دانلود می‌شوند. GitHub Actions معمولاً این دسترسی را دارد. فایل نهایی APK، Three.js را داخل خودش دارد و بازی برای اجرا به CDN احتیاج ندارد.

## کنترل‌ها
- موبایل: دکمه‌های جهت برای حرکت، شمشیر برای حمله، فلش برای Dash، ماه برای روز/شب؛ روی محیط بازی بکش تا دوربین بچرخد.
- دسکتاپ: WASD، Space، Q، N و Drag.
