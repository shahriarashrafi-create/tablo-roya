shadbash - Page 05 card

Changes in this ZIP:
- Default team count changed to 2.
- The icon at the top of the ready/start page is larger.
- First-round page redesigned with a more polished game-like look.
- Removed the texts «شروع نوبت‌ها» and «نوبت شروع».
- Typography styled in a more gaming-like direction inspired by Kamran-style bold headers.
- Added the next page: song card / playback screen with song card, wave area, lyric area, and action buttons.
- Existing back behavior remains: one back per step, and double back on home exits the app.
- Compatible with the existing ZIP-based workflow.
