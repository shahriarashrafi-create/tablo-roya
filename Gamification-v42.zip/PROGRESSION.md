# Gamification v42 Progress

- Added persistent subtask progress per mission/day and Home card progress such as 3/5.
- Mission execution now highlights READY when every subtask is checked and emphasizes Finish Mission.
- Added optional mission Deadline (HH:MM); overdue unfinished missions automatically become red/missed and move behind active cards.
- Added persistent mission Notes in Add/Edit Mission and displayed Notes inside the running mission screen.
- Added daily reset handling at the local day boundary: daily cards return to active/yellow state, daily subtask checks reset, original card order is restored, and stale daily timer state is cleared.
- Migrated persistence/backup schema to v9.
- Bumped app version to 0.42 (versionCode 42).
