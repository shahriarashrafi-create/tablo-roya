package com.shahriar.gamify

import androidx.compose.ui.graphics.Color

/**
 * Core application models.
 *
 * Kept separate from Compose UI so mission/progression/storage code can evolve
 * without turning MainActivity into the application data layer.
 */
data class PlayerState(
    val level: Int = 1,
    val currentXp: Int = 0,
    val nextLevelXp: Int = 500,
    val rank: Int = 1,
    val rankProgress: Int = 0,
    val coins: Int = 0,
    val combo: Int = 0,
    val bestCombo: Int = 0,
    val chests: Int = 0,
    val loginStreak: Int = 0,
    val bestLoginStreak: Int = 0
)

enum class MissionRepeat { None, Daily }

/** User-facing mission importance. Stage 26 makes this the canonical reward tier. */
enum class MissionImportance { Low, Medium, High }

data class Mission(
    val title: String,
    val durationMinutes: Int,
    val xpReward: Int,
    val coinReward: Int,
    val isRankMission: Boolean = false,
    val repeat: MissionRepeat = MissionRepeat.None,
    val reminderHour: Int = -1,
    val reminderMinute: Int = -1,
    val subtasks: List<String> = emptyList(),
    val id: String = "",
    val importance: MissionImportance = MissionImportance.Medium
)

internal enum class AppScreen { Home, Mission }
enum class MissionResult { Done, Partial, Fail, Defer }

data class MissionHistoryEntry(
    val timestamp: Long,
    val missionTitle: String,
    val plannedMinutes: Int,
    val focusSeconds: Int,
    val result: MissionResult,
    val xpEarned: Int,
    val coinsEarned: Int,
    val levelRewardCoins: Int,
    val missionId: String = "",
    val sessionId: Long = 0L,
    val rankStepsEarned: Int = 0,
    val chestsEarned: Int = 0,
    val comboBefore: Int = -1,
    val comboAfter: Int = -1,
    val bestComboBefore: Int = -1,
    val comboDeadlineBefore: Long = -1L
)

internal data class MissionSessionCommit(
    val sessionId: Long,
    val mission: Mission,
    val result: MissionResult,
    val beforePlayer: PlayerState,
    val outcome: MissionOutcome,
    val entry: MissionHistoryEntry,
    val history: List<MissionHistoryEntry>,
    val duplicate: Boolean = false
)

data class MissionOutcome(
    val player: PlayerState,
    val xpGain: Int,
    val missionCoinGain: Int,
    val levelsGained: Int,
    val levelRewardCoins: Int,
    val comboBefore: Int,
    val comboAfter: Int,
    val rewardMultiplier: Float,
    val ranksGained: Int,
    val chestsEarned: Int
)

data class RankUpEvent(
    val fromRank: Int,
    val toRank: Int,
    val chestsEarned: Int
)

internal enum class AchievementCategory { Mission, Focus, Combo, Rank, Level, Consistency }

internal data class Achievement(
    val id: String,
    val title: String,
    val subtitle: String,
    val glyph: String,
    val category: AchievementCategory,
    val tier: Int,
    val progress: Int,
    val goal: Int,
    val xpReward: Int,
    val coinReward: Int
)

/** Stage 90: one canonical projection for every Achievement surface. */
internal data class AchievementCollectionSummary(
    val completed: Int,
    val total: Int,
    val claimable: Int,
    val overallProgress: Float,
    val categoryProgress: Map<AchievementCategory, Pair<Int, Int>>,
    val masteredCategories: Set<AchievementCategory>
)

internal data class ShopReward(
    val id: String,
    val title: String,
    val subtitle: String,
    val price: Int
)

internal data class PersonalReward(
    val id: String,
    val title: String,
    val price: Int,
    val reusable: Boolean = false,
    val completed: Boolean = false,
    val redeemCount: Int = 0,
    val position: Int = 0
)

internal data class RewardRedemptionEntry(
    val transactionId: String,
    val timestamp: Long,
    val rewardId: String,
    val rewardTitle: String,
    val price: Int,
    val reusable: Boolean,
    val balanceBefore: Int,
    val balanceAfter: Int
)

internal data class RewardRedemptionCommit(
    val status: RewardRedemptionStatus,
    val player: PlayerState,
    val rewards: List<PersonalReward>,
    val entry: RewardRedemptionEntry? = null
)

internal data class DreamItem(
    val id: String,
    val title: String,
    val year: String,
    val price: String,
    val imageUri: String = "",
    val position: Int = 0,
    val linkedMissionId: String = "",
    val missionCompletionTarget: Int = 0,
    val goalCelebrated: Boolean = false,
    val goalRewardClaimed: Boolean = false,
    val achievedAtMillis: Long = 0L
)

internal data class ProfileLoadout(
    val avatar: String = "crown",
    val title: String = "Pathfinder",
    val frame: String = "default",
    val badge: String = "none"
)

internal data class WorldRegion(
    val name: String,
    val subtitle: String,
    val minLevel: Int,
    val tint: Color
)

internal data class MissionTemplate(
    val id: String,
    val title: String,
    val subtitle: String,
    val mission: Mission
)

internal data class GameNotification(
    val id: String,
    val glyph: String,
    val title: String,
    val body: String,
    val timestamp: Long,
    val read: Boolean = false
)

internal data class OnboardingProfile(
    val name: String = "Player",
    val activeStart: String = "07:00",
    val activeEnd: String = "23:00"
)

data class LevelUpEvent(
    val fromLevel: Int,
    val toLevel: Int,
    val rewardCoins: Int
)

internal enum class AppThemeMode { Classic, Midnight, Obsidian }

internal data class GameSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val treeStatsReminderEnabled: Boolean = true,
    val treeStatsReminderHour: Int = 22,
    val treeStatsReminderMinute: Int = 0,
    val reducedMotion: Boolean = false,
    val comboBoostEnabled: Boolean = true,
    val themeMode: AppThemeMode = AppThemeMode.Midnight
)

internal data class ActiveTimerState(
    val mission: Mission,
    val remainingSeconds: Int,
    val endAtMillis: Long,
    val isRunning: Boolean,
    val sessionId: Long,
    val checkedSubtasks: List<Boolean> = List(mission.subtasks.size) { false },
    val endAtElapsedRealtime: Long = 0L,
    val bootCount: Int = -1
)

internal data class MissionTerminalAnimation(
    val mission: Mission,
    val result: MissionResult
)

internal data class MissionCompletionAnimation(
    val mission: Mission,
    val fromPlayer: PlayerState,
    val toPlayer: PlayerState,
    val xpGain: Int,
    val coinGain: Int,
    val levelUp: LevelUpEvent?,
    val rankUp: RankUpEvent?
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val ringColors: List<Color>
)
