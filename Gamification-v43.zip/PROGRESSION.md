# Gamification v43 Progress

- Fixed clipped Reminder Hour input with a compact custom field.
- Removed Deadline and Notes from mission editing and disabled deadline-based mission failure.
- Fixed clipped Add Subtask input during mission execution.
- Reordered running-mission subtasks for RTL: checkbox right, text right-aligned, delete on left.
- Removed Pause/Resume button; tapping the timer now toggles pause/resume.
- Replaced Finish/result flow with one action row: large Done button plus icon-only Later and Failed buttons.

# Gamification v42 Progress

- Added persistent subtask progress per mission/day and Home card progress such as 3/5.
- Mission execution now highlights READY when every subtask is checked and emphasizes Finish Mission.
- Added optional mission Deadline (HH:MM); overdue unfinished missions automatically become red/missed and move behind active cards.
- Added persistent mission Notes in Add/Edit Mission and displayed Notes inside the running mission screen.
- Added daily reset handling at the local day boundary: daily cards return to active/yellow state, daily subtask checks reset, original card order is restored, and stale daily timer state is cleared.
- Migrated persistence/backup schema to v9.
- Bumped app version to 0.42 (versionCode 42).
