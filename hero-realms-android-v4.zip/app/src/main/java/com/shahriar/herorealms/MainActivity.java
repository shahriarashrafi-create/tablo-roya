package com.shahriar.herorealms;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView webView;
    private boolean retriedSafeMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 16, 13));
        setContentView(root);

        try {
            createWebView(false);
        } catch (Throwable t) {
            showFatal("Game engine could not start.\n" + t.getClass().getSimpleName());
        }
    }

    private void createWebView(boolean safeMode) {
        if (webView != null) {
            root.removeView(webView);
            try { webView.stopLoading(); } catch (Throwable ignored) {}
            try { webView.destroy(); } catch (Throwable ignored) {}
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 16, 13));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    showFatal("Game files could not be loaded.");
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // A WebGL/WebView renderer can occasionally be killed by a GPU driver.
                // Recover once in reduced-GPU mode instead of letting Android close the app.
                if (!retriedSafeMode) {
                    retriedSafeMode = true;
                    root.postDelayed(() -> {
                        try { createWebView(true); }
                        catch (Throwable t) { showFatal("Graphics engine restarted unsuccessfully."); }
                    }, 250);
                } else {
                    showFatal("Graphics engine stopped. Please reopen the game.");
                }
                return true;
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        String url = "file:///android_asset/index.html" + (safeMode ? "?safe=1" : "");
        webView.loadUrl(url);
    }

    private void showFatal(String message) {
        if (root == null) return;
        root.removeAllViews();
        TextView error = new TextView(this);
        error.setText("HERO REALMS\n\n" + message + "\n\nClose and reopen the app.");
        error.setTextColor(Color.WHITE);
        error.setTextSize(18f);
        error.setGravity(Gravity.CENTER);
        error.setPadding(48, 48, 48, 48);
        root.addView(error, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            try { webView.onResume(); webView.resumeTimers(); } catch (Throwable ignored) {}
        }
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            try { webView.onPause(); webView.pauseTimers(); } catch (Throwable ignored) {}
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try { webView.stopLoading(); } catch (Throwable ignored) {}
            try { webView.destroy(); } catch (Throwable ignored) {}
            webView = null;
        }
        super.onDestroy();
    }
}
