
const canvas = document.querySelector('#game');
const params = new URLSearchParams(location.search);
const safeMode = params.get('safe') === '1';
const mobileGpu = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: !safeMode,
  alpha: false,
  powerPreference: safeMode ? 'default' : 'high-performance',
  preserveDrawingBuffer: false,
  stencil: false
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, safeMode ? 1 : (mobileGpu ? 1.25 : 1.7)));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = safeMode ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
if ('outputColorSpace' in renderer && THREE.SRGBColorSpace) renderer.outputColorSpace = THREE.SRGBColorSpace;
else if (THREE.sRGBEncoding) renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9cb9a9);
scene.fog = new THREE.FogExp2(0x9cb9a9, 0.011);

const camera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.1, 500);

const clock = new THREE.Clock();
const up = new THREE.Vector3(0, 1, 0);
const tmpV = new THREE.Vector3();
const tmpV2 = new THREE.Vector3();
const tmpQ = new THREE.Quaternion();
const worldSize = 150;
let gameStarted = false;
let gameOver = false;
let dayMode = true;
let elapsed = 0;

// ---------- UI ----------
const ui = {
  crystals: document.querySelector('#crystals'),
  score: document.querySelector('#score'),
  hpBar: document.querySelector('#hpBar'),
  hpText: document.querySelector('#hpText'),
  staminaBar: document.querySelector('#staminaBar'),
  level: document.querySelector('#level'),
  bossBar: document.querySelector('#bossBar'),
  bossHp: document.querySelector('#bossHp'),
  toast: document.querySelector('#toast'),
  startScreen: document.querySelector('#startScreen'),
  endScreen: document.querySelector('#endScreen'),
  endKicker: document.querySelector('#endKicker'),
  endTitle: document.querySelector('#endTitle'),
  endText: document.querySelector('#endText'),
};

let toastTimer;
function toast(text) {
  ui.toast.textContent = text;
  ui.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ui.toast.classList.remove('show'), 1800);
}

// ---------- Lights / atmosphere ----------
const hemi = new THREE.HemisphereLight(0xc8e5d8, 0x243025, 1.8);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xfff1c8, 4.2);
sun.position.set(-42, 68, 34);
sun.castShadow = true;
sun.shadow.mapSize.set(safeMode ? 512 : (mobileGpu ? 1024 : 2048), safeMode ? 512 : (mobileGpu ? 1024 : 2048));
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 180;
sun.shadow.camera.left = -75;
sun.shadow.camera.right = 75;
sun.shadow.camera.top = 75;
sun.shadow.camera.bottom = -75;
sun.shadow.bias = -0.0003;
scene.add(sun);

const moon = new THREE.DirectionalLight(0x87aaff, 0);
moon.position.set(35, 54, -26);
scene.add(moon);

// Sky dome
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(260, 32, 20),
  new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      topColor: { value: new THREE.Color(0x6d9f9c) },
      bottomColor: { value: new THREE.Color(0xd9c9a2) },
      offset: { value: 20.0 },
      exponent: { value: 0.62 },
    },
    vertexShader: `varying vec3 vWorldPosition; void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vWorldPosition=wp.xyz; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader: `uniform vec3 topColor; uniform vec3 bottomColor; uniform float offset; uniform float exponent; varying vec3 vWorldPosition; void main(){ float h=normalize(vWorldPosition+vec3(0.0,offset,0.0)).y; float f=pow(max(h,0.0),exponent); gl_FragColor=vec4(mix(bottomColor,topColor,f),1.0); }`,
  })
);
scene.add(sky);

// ---------- Terrain ----------
function terrainHeight(x, z) {
  const edge = Math.max(0, (Math.hypot(x, z) - 46) / 30);
  const undulation = Math.sin(x * 0.085) * 1.25 + Math.cos(z * 0.072) * 1.15 + Math.sin((x + z) * 0.048) * 1.1;
  const detail = Math.sin(x * 0.19 + z * 0.14) * 0.33;
  return undulation + detail + edge * edge * 14;
}

const terrainSegments = safeMode ? 64 : (mobileGpu ? 96 : 150);
const terrainGeo = new THREE.PlaneGeometry(worldSize, worldSize, terrainSegments, terrainSegments);
terrainGeo.rotateX(-Math.PI / 2);
const pos = terrainGeo.attributes.position;
const colors = [];
const c = new THREE.Color();
for (let i = 0; i < pos.count; i++) {
  const x = pos.getX(i), z = pos.getZ(i);
  const y = terrainHeight(x, z);
  pos.setY(i, y);
  const radial = Math.hypot(x, z);
  if (y > 9 || radial > 67) c.set(0x69725e);
  else if (y < -1.3) c.set(0x476a4d);
  else c.setHSL(0.29 + Math.sin(x * .03) * .012, .28, .30 + Math.sin(z * .07) * .025);
  colors.push(c.r, c.g, c.b);
}
terrainGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
terrainGeo.computeVertexNormals();
const terrain = new THREE.Mesh(terrainGeo, new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.94,
  metalness: 0.02,
}));
terrain.receiveShadow = true;
scene.add(terrain);

// Lake
const lakeY = -0.65;
const lake = new THREE.Mesh(
  new THREE.CircleGeometry(16, 64),
  new THREE.MeshPhysicalMaterial({ color: 0x315e60, roughness: .18, metalness: .05, transparent: true, opacity: .82, clearcoat: .7, clearcoatRoughness: .16 })
);
lake.rotation.x = -Math.PI / 2;
lake.position.set(-28, lakeY, 15);
scene.add(lake);

// Water rings for subtle detail
for (let i = 0; i < 5; i++) {
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(2.6 + i * 2.4, 2.64 + i * 2.4, 64),
    new THREE.MeshBasicMaterial({ color: 0x8fb8ac, transparent: true, opacity: .12, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(-28, lakeY + .025 + i * .004, 15);
  scene.add(ring);
}

// ---------- Environment helpers ----------
function addStone(x, z, s = 1, rot = 0) {
  const m = new THREE.Mesh(
    new THREE.DodecahedronGeometry(1.2 * s, 0),
    new THREE.MeshStandardMaterial({ color: 0x687167, roughness: .98, metalness: .02 })
  );
  m.scale.set(1.25, .75, 1);
  m.rotation.set(.1, rot, .07);
  m.position.set(x, terrainHeight(x, z) + .55 * s, z);
  m.castShadow = m.receiveShadow = true;
  scene.add(m);
}

for (let i = 0; i < 65; i++) {
  const a = i * 2.399;
  const r = 18 + ((i * 17) % 52);
  const x = Math.cos(a) * r, z = Math.sin(a) * r;
  if (Math.hypot(x + 28, z - 15) < 18) continue;
  addStone(x, z, .35 + (i % 5) * .11, a);
}

// Instanced trees
const trunkGeo = new THREE.CylinderGeometry(.22, .34, 3.4, 7);
const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4f3d2c, roughness: 1 });
const crownGeo = new THREE.ConeGeometry(1.55, 4.2, 9);
const crownMat = new THREE.MeshStandardMaterial({ color: 0x274b35, roughness: .92 });
const treeCount = safeMode ? 65 : (mobileGpu ? 95 : 125);
const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
const crowns = new THREE.InstancedMesh(crownGeo, crownMat, treeCount);
trunks.castShadow = trunks.receiveShadow = true;
crowns.castShadow = true;
const dummy = new THREE.Object3D();
let ti = 0;
for (let i = 0; i < 240 && ti < treeCount; i++) {
  const a = i * 2.731;
  const r = 24 + ((i * 29) % 45);
  const x = Math.cos(a) * r, z = Math.sin(a) * r;
  if (Math.hypot(x + 28, z - 15) < 21 || Math.hypot(x - 32, z + 22) < 10) continue;
  const y = terrainHeight(x, z);
  const scale = .75 + (i % 7) * .07;
  dummy.position.set(x, y + 1.7 * scale, z);
  dummy.rotation.y = a * .3;
  dummy.scale.setScalar(scale);
  dummy.updateMatrix(); trunks.setMatrixAt(ti, dummy.matrix);
  dummy.position.y = y + 4.15 * scale;
  dummy.rotation.y = a;
  dummy.scale.set(scale, scale * 1.06, scale);
  dummy.updateMatrix(); crowns.setMatrixAt(ti, dummy.matrix);
  ti++;
}
scene.add(trunks, crowns);

// Grass tufts
const grassGeo = new THREE.ConeGeometry(.12, .75, 4);
const grassMat = new THREE.MeshStandardMaterial({ color: 0x58734a, roughness: 1 });
const grassCount = safeMode ? 140 : (mobileGpu ? 260 : 420);
const grass = new THREE.InstancedMesh(grassGeo, grassMat, grassCount);
grass.receiveShadow = true;
for (let i = 0; i < grassCount; i++) {
  const a = i * 2.414;
  const r = 7 + ((i * 13) % 55);
  const x = Math.cos(a) * r + Math.sin(i) * 5;
  const z = Math.sin(a) * r + Math.cos(i * .73) * 5;
  const y = terrainHeight(x, z);
  dummy.position.set(x, y + .35, z);
  dummy.rotation.set(0, a, (i % 3 - 1) * .08);
  const s = .65 + (i % 6) * .11;
  dummy.scale.set(s, s, s);
  dummy.updateMatrix(); grass.setMatrixAt(i, dummy.matrix);
}
scene.add(grass);

// Ancient ruins / portal area
function pillar(x, z, h = 5) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x74776d, roughness: .92 });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(.62, .76, h, 8), mat);
  const cap = new THREE.Mesh(new THREE.BoxGeometry(1.7, .38, 1.7), mat);
  const base = new THREE.Mesh(new THREE.BoxGeometry(1.6, .35, 1.6), mat);
  shaft.position.y = h / 2 + .35;
  cap.position.y = h + .45;
  base.position.y = .18;
  [shaft, cap, base].forEach(m => { m.castShadow = m.receiveShadow = true; g.add(m); });
  g.position.set(x, terrainHeight(x, z), z);
  scene.add(g);
}
for (const p of [[27,-28,5.5],[37,-28,5.5],[27,-18,4.6],[37,-18,4.6]]) pillar(...p);

const altar = new THREE.Mesh(
  new THREE.CylinderGeometry(5.2, 5.8, .7, 10),
  new THREE.MeshStandardMaterial({ color: 0x5b6058, roughness: .9 })
);
altar.position.set(32, terrainHeight(32, -23) + .2, -23);
altar.receiveShadow = altar.castShadow = true;
scene.add(altar);

// fireflies / ambient particles
const particleCount = safeMode ? 70 : (mobileGpu ? 130 : 220);
const pGeo = new THREE.BufferGeometry();
const pPos = new Float32Array(particleCount * 3);
for (let i = 0; i < particleCount; i++) {
  const a = Math.random() * Math.PI * 2, r = 8 + Math.random() * 65;
  pPos[i*3] = Math.cos(a) * r;
  pPos[i*3+1] = 1 + Math.random() * 12;
  pPos[i*3+2] = Math.sin(a) * r;
}
pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
const particles = new THREE.Points(pGeo, new THREE.PointsMaterial({ color: 0xe2d58d, size: .1, transparent: true, opacity: .45, depthWrite: false }));
scene.add(particles);

// ---------- Character creation ----------
function shadowed(mesh) { mesh.castShadow = true; mesh.receiveShadow = true; return mesh; }

function makeSword() {
  const sword = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({color:0xdce7eb,roughness:.16,metalness:1});
  const darkMetal = new THREE.MeshStandardMaterial({color:0x27313a,roughness:.3,metalness:.82});
  const gold = new THREE.MeshStandardMaterial({color:0xcaa95a,roughness:.26,metalness:.9});
  const leather = new THREE.MeshStandardMaterial({color:0x3b271d,roughness:.86,metalness:.05});
  const bladeGeo = new THREE.CylinderGeometry(.055,.10,1.12,4);
  bladeGeo.rotateY(Math.PI/4);
  const blade = shadowed(new THREE.Mesh(bladeGeo, metal));
  blade.position.y=-.68;
  blade.scale.z=.38;
  const fuller = shadowed(new THREE.Mesh(new THREE.BoxGeometry(.025,.78,.012), darkMetal));
  fuller.position.set(0,-.70,.043);
  const guard = shadowed(new THREE.Mesh(new THREE.BoxGeometry(.56,.075,.12), gold));
  const grip = shadowed(new THREE.Mesh(new THREE.CylinderGeometry(.065,.075,.38,10), leather));
  grip.position.y=.22;
  const pommel = shadowed(new THREE.Mesh(new THREE.SphereGeometry(.105,12,8), gold));
  pommel.position.y=.46;
  sword.add(blade,fuller,guard,grip,pommel);
  return sword;
}

function createHero() {
  const root = new THREE.Group();
  const fallback = new THREE.Group();
  const armor = new THREE.MeshStandardMaterial({ color: 0x324c5f, roughness: .45, metalness: .62 });
  const armorDark = new THREE.MeshStandardMaterial({ color: 0x172733, roughness: .55, metalness: .55 });
  const leather = new THREE.MeshStandardMaterial({ color: 0x5f3f2b, roughness: .9 });
  const gold = new THREE.MeshStandardMaterial({ color: 0xc7a95b, roughness: .35, metalness: .8 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xc99977, roughness: .8 });

  const body = shadowed(new THREE.Mesh(new THREE.CapsuleGeometry(.62, 1.15, 5, 10), armor));
  body.position.y = 1.7; fallback.add(body);
  const belt = shadowed(new THREE.Mesh(new THREE.CylinderGeometry(.66,.66,.18,12), leather));
  belt.position.y = 1.25; fallback.add(belt);
  const head = shadowed(new THREE.Mesh(new THREE.SphereGeometry(.43, 16, 12), skin));
  head.position.y = 2.85; fallback.add(head);
  const helmet = shadowed(new THREE.Mesh(new THREE.SphereGeometry(.48, 16, 10, 0, Math.PI*2, 0, Math.PI*.62), armorDark));
  helmet.position.y = 2.96; fallback.add(helmet);
  const crest = shadowed(new THREE.Mesh(new THREE.BoxGeometry(.1,.38,.52), gold));
  crest.position.set(0,3.35,.03); fallback.add(crest);

  const leftArm = new THREE.Group(), rightArm = new THREE.Group();
  const armGeo = new THREE.CapsuleGeometry(.18,.78,4,7);
  const la = shadowed(new THREE.Mesh(armGeo, armor)); la.position.y=-.48; leftArm.add(la);
  const ra = shadowed(new THREE.Mesh(armGeo, armor)); ra.position.y=-.48; rightArm.add(ra);
  leftArm.position.set(-.78,2.25,0); rightArm.position.set(.78,2.25,0);
  fallback.add(leftArm,rightArm);

  const leftLeg = new THREE.Group(), rightLeg = new THREE.Group();
  const legGeo = new THREE.CapsuleGeometry(.22,.82,4,7);
  const ll=shadowed(new THREE.Mesh(legGeo,armorDark));ll.position.y=-.52;leftLeg.add(ll);
  const rl=shadowed(new THREE.Mesh(legGeo,armorDark));rl.position.y=-.52;rightLeg.add(rl);
  leftLeg.position.set(-.28,.93,0);rightLeg.position.set(.28,.93,0);fallback.add(leftLeg,rightLeg);

  const sword = makeSword();
  sword.rotation.z=-.18;sword.position.set(0,-1.03,0);rightArm.add(sword);
  const shield = shadowed(new THREE.Mesh(new THREE.CylinderGeometry(.48,.58,.12,8), new THREE.MeshStandardMaterial({color:0x6e492e,roughness:.75,metalness:.1})));
  shield.rotation.x=Math.PI/2; shield.position.set(0,-.55,-.33); leftArm.add(shield);

  fallback.scale.setScalar(.92);
  root.add(fallback);

  const slash = new THREE.Mesh(
    new THREE.RingGeometry(1.15, 2.05, 40, 1, -.9, 1.8),
    new THREE.MeshBasicMaterial({color:0xffe49b,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending})
  );
  slash.visible=false; slash.position.set(0,1.75,1.05); slash.rotation.set(0,0,-.35); root.add(slash);

  root.userData = {
    fallback, body, leftArm, rightArm, leftLeg, rightLeg, sword, slash,
    hitMeshes:[body], realLoaded:false, model:null, mixer:null, action:null, actions:{}, currentAction:null, rig:{},
    attackTime:0, attackDuration:.42, attackIndex:-1, attackQueued:false, attackHitDone:false,
    comboExpire:0, dashTime:0, walkTime:0, slashTime:0
  };
  return root;
}

function loadHeroModel() {
  const u=hero.userData;
  if (!THREE.GLTFLoader) { toast('مدل هیرو در دسترس نیست'); return; }
  const loader=new THREE.GLTFLoader();
  loader.load('models/HeroKnightExtreme.glb', gltf=>{
    const model=gltf.scene;
    model.rotation.y=Math.PI;
    model.traverse(o=>{
      if(o.isMesh){
        o.castShadow=true;o.receiveShadow=true;
        if(o.material){
          o.material=o.material.clone();
          if('roughness' in o.material && typeof o.material.roughness==='number') o.material.roughness=Math.min(.72,Math.max(.24,o.material.roughness));
          if('metalness' in o.material && typeof o.material.metalness==='number') o.material.metalness=Math.min(1,Math.max(.05,o.material.metalness));
          u.hitMeshes.push(o);
        }
      }
    });
    model.updateMatrixWorld(true);
    let box=new THREE.Box3().setFromObject(model), size=box.getSize(new THREE.Vector3());
    const targetHeight=3.25;
    const scale=targetHeight/Math.max(.01,size.y);
    model.scale.setScalar(scale);
    model.updateMatrixWorld(true);
    box=new THREE.Box3().setFromObject(model);
    model.position.y-=box.min.y;
    u.fallback.visible=false;
    u.model=model;u.realLoaded=true;
    hero.add(model);

    if(gltf.animations&&gltf.animations.length){
      u.mixer=new THREE.AnimationMixer(model);
      const clips=gltf.animations;
      const pick=(needles)=>{
        for(const n of needles){
          const q=n.toLowerCase();
          const exact=clips.find(c=>c.name.toLowerCase()===q); if(exact) return exact;
          const partial=clips.find(c=>c.name.toLowerCase().includes(q)); if(partial) return partial;
        }
        return null;
      };
      const make=(key,names,loop=true)=>{
        const clip=pick(names); if(!clip) return null;
        const a=u.mixer.clipAction(clip); a.enabled=true;
        if(loop){a.setLoop(THREE.LoopRepeat,Infinity);} else {a.setLoop(THREE.LoopOnce,1);a.clampWhenFinished=true;}
        u.actions[key]=a; return a;
      };
      make('idle',['Idle_A','Idle']);
      make('walk',['Walking_A','Walk','Walking']);
      make('run',['Running_A','Run','Running']);
      make('attack1',['1H_Melee_Attack_Chop','Attack_Chop','Attack (1h)','Attack']);
      make('attack2',['1H_Melee_Attack_Slice_Diagonal','Attack_Slice_Diagonal','Attack - Combo']);
      make('attack3',['1H_Melee_Attack_Slice_Horizontal','Attack_Slice_Horizontal','Heavy Attack']);
      make('dash',['Dash_Front','Dash Front','Roll'],false);
      make('defeat',['Defeat','Death'],false);
      u.currentAction=u.actions.idle||u.actions.walk||u.actions.run||null;
      if(u.currentAction){u.currentAction.reset().fadeIn(.01).play();}
    }
    toast('هیرو آماده شد');
  },undefined,err=>{
    console.warn('Hero model failed',err);
    toast('مدل اصلی بارگذاری نشد');
  });
}

function playHeroLoop(name, fade=.14){
  const u=hero.userData, next=u.actions&&u.actions[name];
  if(!next || u.currentAction===next) return;
  const prev=u.currentAction;
  next.reset().setEffectiveTimeScale(1).setEffectiveWeight(1).fadeIn(fade).play();
  if(prev) prev.fadeOut(fade);
  u.currentAction=next;
}

function playHeroOneShot(name, speed=1){
  const u=hero.userData, next=u.actions&&u.actions[name];
  if(!next) return false;
  const prev=u.currentAction;
  next.reset().setEffectiveTimeScale(speed).setEffectiveWeight(1).fadeIn(.06).play();
  if(prev&&prev!==next) prev.fadeOut(.06);
  u.currentAction=next;
  return true;
}

function createEnemy(scale=1, boss=false) {
  const root = new THREE.Group();
  const stone = new THREE.MeshStandardMaterial({ color: boss ? 0x594f50 : 0x5c665c, roughness: .84, metalness: .12 });
  const glow = new THREE.MeshStandardMaterial({ color: boss ? 0xff6a4e : 0xe1c568, emissive: boss ? 0x6b160b : 0x5a4d12, emissiveIntensity: 1.6, roughness:.35 });
  const body=shadowed(new THREE.Mesh(new THREE.DodecahedronGeometry(.86,1),stone));body.scale.set(1,1.35,.78);body.position.y=1.55;root.add(body);
  const head=shadowed(new THREE.Mesh(new THREE.DodecahedronGeometry(.52,1),stone));head.position.y=2.75;root.add(head);
  const e1=shadowed(new THREE.Mesh(new THREE.SphereGeometry(.085,8,6),glow));e1.position.set(-.19,2.8,.44);root.add(e1);
  const e2=e1.clone();e2.position.x=.19;root.add(e2);
  const armGeo=new THREE.CapsuleGeometry(.18,.9,4,6);
  const l=shadowed(new THREE.Mesh(armGeo,stone));l.position.set(-.85,1.6,0);l.rotation.z=-.22;root.add(l);
  const r=shadowed(new THREE.Mesh(armGeo,stone));r.position.set(.85,1.6,0);r.rotation.z=.22;root.add(r);
  root.scale.setScalar(scale);
  root.userData={ body, leftArm:l, rightArm:r, hp: boss?420:80, maxHp:boss?420:80, speed:boss?3.3:2.8+Math.random()*.8, damage:boss?26:12, aggro:boss?26:15, attackCooldown:0, hitFlash:0, boss, dead:false };
  return root;
}

const hero = createHero();
hero.position.set(0, terrainHeight(0, 12), 12);
scene.add(hero);
loadHeroModel();

const enemies=[];
const enemySpawns=[[-13,-10],[10,-18],[19,7],[-8,31],[-38,-12],[43,15],[-25,38],[3,44]];
for(const [x,z] of enemySpawns){const e=createEnemy(.85,false);e.position.set(x,terrainHeight(x,z),z);scene.add(e);enemies.push(e);}
const boss = createEnemy(1.65,true);
boss.position.set(32,terrainHeight(32,-23)+.35,-23);
scene.add(boss); enemies.push(boss);

// crystals
const crystalMat = new THREE.MeshPhysicalMaterial({ color:0x72dbe3, emissive:0x1c8792, emissiveIntensity:1.45, roughness:.18, metalness:.25, clearcoat:1 });
const crystals=[];
const crystalSpawns=[[-18,4],[8,-4],[-6,-28],[25,24],[-38,31],[47,35],[51,-8],[-49,-27],[4,52],[-2,22]];
for(let i=0;i<crystalSpawns.length;i++){
  const [x,z]=crystalSpawns[i];
  const g=new THREE.Group();
  const core=shadowed(new THREE.Mesh(new THREE.OctahedronGeometry(.58,0),crystalMat));core.scale.y=1.45;g.add(core);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.8,.035,6,32),new THREE.MeshBasicMaterial({color:0xaef9ff,transparent:true,opacity:.65}));ring.rotation.x=Math.PI/2;g.add(ring);
  g.position.set(x,terrainHeight(x,z)+1.15,z);g.userData={baseY:g.position.y,collected:false,phase:i*.6};scene.add(g);crystals.push(g);
}

// ---------- Player/game state ----------
const state={ hp:100,maxHp:100,stamina:100,maxStamina:100,score:0,crystals:0,level:1,invuln:0 };
const keys={};
let cameraYaw=0.1, cameraPitch=.28, cameraDistance=8.7;
let rightDrag=false, prevMouseX=0, prevMouseY=0, cameraKick=0;
const joystick={x:0,y:0,magnitude:0,active:false,pointerId:null,originX:0,originY:0};

function updateHUD(){
  ui.crystals.textContent=`${state.crystals}/${crystals.length}`;
  ui.score.textContent=state.score;
  ui.hpBar.style.width=`${Math.max(0,state.hp/state.maxHp*100)}%`;
  ui.hpText.textContent=`${Math.ceil(Math.max(0,state.hp))} / ${state.maxHp}`;
  ui.staminaBar.style.width=`${Math.max(0,state.stamina/state.maxStamina*100)}%`;
  ui.level.textContent=state.level;
  ui.bossHp.style.width=`${Math.max(0,boss.userData.hp/boss.userData.maxHp*100)}%`;
}
updateHUD();

function damagePlayer(amount, source) {
  if(state.invuln>0 || gameOver) return;
  state.hp-=amount; state.invuln=.45;
  for(const m of hero.userData.hitMeshes){ if(m&&m.material&&m.material.emissive) m.material.emissive.set(0x551111); }
  toast(source ? `${source} -${amount} جان` : `-${amount} جان`);
  if(state.hp<=0){ state.hp=0; playHeroOneShot('defeat',1); endGame(false); }
  updateHUD();
}

function startAttack(index){
  const u=hero.userData;
  const key=`attack${index+1}`;
  const a=u.actions&&u.actions[key];
  const duration=a&&a.getClip?THREE.MathUtils.clamp(a.getClip().duration/1.22,.40,.78):.46;
  u.attackDuration=duration;u.attackIndex=index;u.attackTime=duration;u.attackQueued=false;u.attackHitDone=false;u.comboExpire=0;
  playHeroOneShot(key,1.22);
  document.querySelector('#touchAttack')?.classList.remove('combo-ready');
}

function performAttackHit(){
  const u=hero.userData;
  const forward=new THREE.Vector3(0,0,1).applyQuaternion(hero.quaternion).normalize();
  let landed=false;
  const damages=[38,46,62], ranges=[3.2,3.45,3.7], arcs=[.02,-.1,-.2];
  for(const e of enemies){
    if(e.userData.dead) continue;
    const to=e.position.clone().sub(hero.position);to.y=0;
    const d=to.length();
    if(d<ranges[u.attackIndex] && forward.dot(to.normalize())>arcs[u.attackIndex]){
      const dmg=e.userData.boss?Math.round(damages[u.attackIndex]*.72):damages[u.attackIndex];
      e.userData.hp-=dmg;e.userData.hitFlash=.20;landed=true;
      const knock=e.position.clone().sub(hero.position).setY(0).normalize().multiplyScalar(e.userData.boss ? .18 : .45);
      e.position.add(knock);
      state.score+=e.userData.boss?30:15;
      if(e.userData.boss) ui.bossBar.classList.remove('hidden');
      if(e.userData.hp<=0){
        e.userData.dead=true;state.score+=e.userData.boss?700:120;
        toast(e.userData.boss?'نگهبان سنگی شکست خورد!':'دشمن شکست خورد');
        if(e.userData.boss){ui.bossBar.classList.add('hidden');maybeWin();}
      }
    }
  }
  if(landed){cameraKick=Math.max(cameraKick,.18);u.slashTime=.13;}
  else u.slashTime=.08;
  updateHUD();
}

function attack(){
  if(!gameStarted||gameOver) return;
  const u=hero.userData;
  if(u.attackTime>0){
    const p=1-u.attackTime/u.attackDuration;
    if(p>.36){u.attackQueued=true;document.querySelector('#touchAttack')?.classList.add('combo-ready');}
    return;
  }
  const next=u.comboExpire>0?((u.attackIndex+1)%3):0;
  startAttack(next);
}

function dash(){
  if(!gameStarted||gameOver||hero.userData.dashTime>0||state.stamina<35) return;
  hero.userData.dashTime=.34;state.stamina-=35;state.invuln=.34;playHeroOneShot('dash',1.12);updateHUD();
}

function toggleDayNight(){
  dayMode=!dayMode;
  if(dayMode){
    scene.background.set(0x9cb9a9);scene.fog.color.set(0x9cb9a9);sun.intensity=4.2;moon.intensity=0;hemi.intensity=1.8;
    sky.material.uniforms.topColor.value.set(0x6d9f9c);sky.material.uniforms.bottomColor.value.set(0xd9c9a2);renderer.toneMappingExposure=1.05;
    particles.material.opacity=.45;
    toast('روز');
  } else {
    scene.background.set(0x08131f);scene.fog.color.set(0x0d1b27);sun.intensity=.12;moon.intensity=2.4;hemi.intensity=.55;
    sky.material.uniforms.topColor.value.set(0x071222);sky.material.uniforms.bottomColor.value.set(0x253b49);renderer.toneMappingExposure=.78;
    particles.material.opacity=.9;
    toast('شب');
  }
}

function maybeWin(){
  if(state.crystals===crystals.length && boss.userData.dead) endGame(true);
  else if(state.crystals===crystals.length) toast('حالا نگهبان سنگی را شکست بده');
  else if(boss.userData.dead) toast('همه کریستال‌ها را پیدا کن');
}
function endGame(win){
  gameOver=true;
  ui.endKicker.textContent=win?'ماموریت کامل شد':'قهرمان سقوط کرد';
  ui.endTitle.textContent=win?'پیروزی':'شکست';
  ui.endText.textContent=win?`همه ${crystals.length} کریستال را پیدا کردی و نگهبان را شکست دادی. امتیاز نهایی: ${state.score}`:`امتیاز تو ${state.score} شد. دوباره تلاش کن و از دَش برای فرار از ضربه‌ها استفاده کن.`;
  ui.endScreen.classList.add('show');
}

// ---------- Input ----------
addEventListener('keydown',e=>{
  keys[e.code]=true;
  if(e.code==='Space'){e.preventDefault();attack();}
  if(e.code==='KeyQ') dash();
  if(e.code==='KeyN') toggleDayNight();
});
addEventListener('keyup',e=>keys[e.code]=false);
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('pointerdown',e=>{
  const isTouch=e.pointerType==='touch';
  const cameraTouch=isTouch&&e.clientX>innerWidth*.50;
  if(e.button===2 || cameraTouch){rightDrag=true;prevMouseX=e.clientX;prevMouseY=e.clientY;canvas.setPointerCapture?.(e.pointerId);}
});
canvas.addEventListener('pointerup',()=>{rightDrag=false;});
canvas.addEventListener('pointercancel',()=>{rightDrag=false;});
canvas.addEventListener('pointermove',e=>{
  if(!rightDrag)return;
  const dx=e.clientX-prevMouseX,dy=e.clientY-prevMouseY;prevMouseX=e.clientX;prevMouseY=e.clientY;
  cameraYaw-=dx*.006;cameraPitch=THREE.MathUtils.clamp(cameraPitch-dy*.0045,-.12,.65);
});
canvas.addEventListener('wheel',e=>{cameraDistance=THREE.MathUtils.clamp(cameraDistance+Math.sign(e.deltaY)*.7,5.2,12.5);},{passive:true});

const movePad=document.querySelector('#movePad');
function setMoveVector(e){
  const max=74;
  let dx=e.clientX-joystick.originX,dy=e.clientY-joystick.originY;
  const len=Math.hypot(dx,dy);
  const clamped=Math.min(max,len);
  if(len>0){dx=dx/len*clamped;dy=dy/len*clamped;}
  joystick.x=THREE.MathUtils.clamp(dx/max,-1,1);
  joystick.y=THREE.MathUtils.clamp(-dy/max,-1,1);
  joystick.magnitude=Math.min(1,len/max);
}
function resetJoystick(){
  joystick.x=0;joystick.y=0;joystick.magnitude=0;joystick.active=false;joystick.pointerId=null;
}
movePad?.addEventListener('pointerdown',e=>{
  e.preventDefault();e.stopPropagation();
  joystick.active=true;joystick.pointerId=e.pointerId;joystick.originX=e.clientX;joystick.originY=e.clientY;
  movePad.setPointerCapture?.(e.pointerId);
  joystick.x=0;joystick.y=0;joystick.magnitude=0;
});
movePad?.addEventListener('pointermove',e=>{
  if(joystick.active&&e.pointerId===joystick.pointerId){e.preventDefault();e.stopPropagation();setMoveVector(e);}
});
for(const ev of ['pointerup','pointercancel','lostpointercapture']) movePad?.addEventListener(ev,e=>{
  if(joystick.pointerId===null||e.pointerId===joystick.pointerId){e.preventDefault();e.stopPropagation();resetJoystick();}
});

document.querySelector('#touchAttack')?.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();attack();});
document.querySelector('#touchDash')?.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();dash();});

document.querySelector('#startBtn').addEventListener('click',()=>{ui.startScreen.classList.remove('show');gameStarted=true;toast('ماموریت آغاز شد');});
document.querySelector('#restartBtn').addEventListener('click',()=>location.reload());

// ---------- Update ----------
function updateHero(dt){
  const u=hero.userData;
  u.comboExpire=Math.max(0,u.comboExpire-dt);
  u.dashTime=Math.max(0,u.dashTime-dt);
  u.slashTime=Math.max(0,u.slashTime-dt);
  state.invuln=Math.max(0,state.invuln-dt);
  if(state.invuln<=0){for(const m of u.hitMeshes){if(m&&m.material&&m.material.emissive)m.material.emissive.set(0x000000);}}

  let ix=0,iz=0,inputMag=0;
  if(joystick.active&&joystick.magnitude>.05){ix=joystick.x;iz=joystick.y;inputMag=joystick.magnitude;}
  else{
    if(keys.KeyW||keys.ArrowUp) iz+=1;
    if(keys.KeyS||keys.ArrowDown) iz-=1;
    if(keys.KeyA||keys.ArrowLeft) ix-=1;
    if(keys.KeyD||keys.ArrowRight) ix+=1;
    inputMag=Math.min(1,Math.hypot(ix,iz));
  }
  const inputLen=Math.hypot(ix,iz);
  const moving=inputLen>.04;
  const autoSprint=joystick.active&&inputMag>.78;
  const sprint=(autoSprint||keys.ShiftLeft||keys.ShiftRight)&&state.stamina>4&&moving;

  if(moving){
    ix/=inputLen;iz/=inputLen;
    const camForward=new THREE.Vector3(Math.sin(cameraYaw),0,Math.cos(cameraYaw));
    const camRight=new THREE.Vector3(-camForward.z,0,camForward.x);
    const dir=camForward.multiplyScalar(iz).add(camRight.multiplyScalar(ix)).normalize();
    const targetAngle=Math.atan2(dir.x,dir.z);
    const diff=THREE.MathUtils.euclideanModulo(targetAngle-hero.rotation.y+Math.PI,Math.PI*2)-Math.PI;
    hero.rotation.y+=diff*Math.min(1,dt*(u.attackTime>0?6:11));
    let speed=sprint?8.7:THREE.MathUtils.lerp(2.7,5.8,Math.max(.25,inputMag));
    if(u.attackTime>0)speed*=.58;
    if(u.dashTime>0)speed=17.5;
    const nx=hero.position.x+dir.x*speed*dt,nz=hero.position.z+dir.z*speed*dt;
    const safeR=Math.hypot(nx,nz)<70, lakeDist=Math.hypot(nx+28,nz-15);
    if(safeR&&lakeDist>14.8){hero.position.x=nx;hero.position.z=nz;}
    if(sprint)state.stamina=Math.max(0,state.stamina-24*dt);
    u.walkTime+=dt*(sprint?12:8.5);
  }else{
    u.walkTime+=dt*2;state.stamina=Math.min(state.maxStamina,state.stamina+22*dt);
  }
  if(!sprint)state.stamina=Math.min(state.maxStamina,state.stamina+10*dt);

  // Attack timing, combo queue and hit frame.
  if(u.attackTime>0){
    u.attackTime=Math.max(0,u.attackTime-dt);
    const p=1-u.attackTime/u.attackDuration;
    if(!u.attackHitDone&&p>=.34){u.attackHitDone=true;performAttackHit();}
    if(u.attackTime<=0){
      if(u.attackQueued){startAttack((u.attackIndex+1)%3);}
      else{u.comboExpire=.34;document.querySelector('#touchAttack')?.classList.remove('combo-ready');}
    }
  }

  hero.position.y=terrainHeight(hero.position.x,hero.position.z)+.05;

  if(u.realLoaded&&u.mixer){
    if(u.attackTime<=0&&u.dashTime<=0){
      playHeroLoop(moving?(sprint?'run':'walk'):'idle',.13);
    }else if(u.dashTime>0&&u.actions.dash&&u.currentAction!==u.actions.dash){
      playHeroOneShot('dash',1.12);
    }
    u.mixer.update(dt);
  }else{
    const walkAmp=moving?.55:.05;
    u.leftLeg.rotation.x=Math.sin(u.walkTime)*walkAmp;u.rightLeg.rotation.x=-Math.sin(u.walkTime)*walkAmp;
    u.leftArm.rotation.x=-Math.sin(u.walkTime)*walkAmp*.65;
    if(u.attackTime<=0)u.rightArm.rotation.x=Math.sin(u.walkTime)*walkAmp*.45;
    if(u.attackTime>0){const p=1-u.attackTime/u.attackDuration;u.rightArm.rotation.x=-1.0-Math.sin(p*Math.PI)*1.55;u.rightArm.rotation.z=-.25-Math.sin(p*Math.PI)*.65;}else u.rightArm.rotation.z=0;
  }

  if(u.slash){
    u.slash.visible=u.slashTime>0;
    u.slash.material.opacity=u.slashTime>0?Math.min(.8,u.slashTime/.13*.8):0;
    u.slash.rotation.z=(u.attackIndex===1?.8:-.55)+(1-u.slashTime/.13)*.55;
    u.slash.rotation.x=u.attackIndex===2?0:-.22;
  }
  updateHUD();
}

function updateEnemies(dt){
  for(const e of enemies){
    const d=e.userData;
    d.attackCooldown=Math.max(0,d.attackCooldown-dt);d.hitFlash=Math.max(0,d.hitFlash-dt);
    if(d.dead){
      e.rotation.z=THREE.MathUtils.lerp(e.rotation.z,Math.PI/2,dt*3);
      e.position.y-=dt*.35;
      e.traverse(o=>{if(o.material&&'opacity'in o.material){o.material.transparent=true;o.material.opacity=Math.max(0,o.material.opacity-dt*.25);}});
      continue;
    }
    if(d.hitFlash>0)e.scale.multiplyScalar(1+dt*.4); else {
      const base=d.boss?1.65:.85;
      const current=e.scale.x;e.scale.setScalar(THREE.MathUtils.lerp(current,base,dt*7));
    }
    tmpV.copy(hero.position).sub(e.position);tmpV.y=0;
    const dist=tmpV.length();
    if(dist<d.aggro&&dist>2.3){
      tmpV.normalize();
      const speed=d.speed*(d.boss&&d.hp<d.maxHp*.45?1.25:1);
      const nx=e.position.x+tmpV.x*speed*dt,nz=e.position.z+tmpV.z*speed*dt;
      if(Math.hypot(nx+28,nz-15)>15.5){e.position.x=nx;e.position.z=nz;}
      const target=Math.atan2(tmpV.x,tmpV.z);let diff=THREE.MathUtils.euclideanModulo(target-e.rotation.y+Math.PI,Math.PI*2)-Math.PI;e.rotation.y+=diff*Math.min(1,dt*5);
      d.leftArm.rotation.x=Math.sin(elapsed*7+d.speed)*.4;d.rightArm.rotation.x=-d.leftArm.rotation.x;
    }
    if(dist<=2.45&&d.attackCooldown<=0){
      d.attackCooldown=d.boss?1.15:1.45;
      damagePlayer(d.damage,d.boss?'ضربه نگهبان':'ضربه دشمن');
    }
    e.position.y=terrainHeight(e.position.x,e.position.z)+(d.boss ? .35 : 0);
    if(d.boss&&dist<28&&!d.dead)ui.bossBar.classList.remove('hidden');
  }
}

function updateCrystals(dt){
  for(const g of crystals){
    if(g.userData.collected)continue;
    g.rotation.y+=dt*1.8;g.children[1].rotation.z+=dt*.85;g.position.y=g.userData.baseY+Math.sin(elapsed*2+g.userData.phase)*.16;
    if(g.position.distanceTo(hero.position)<1.65){
      g.userData.collected=true;g.visible=false;state.crystals++;state.score+=100;
      state.level=1+Math.floor(state.crystals/4);state.maxHp=100+(state.level-1)*10;state.hp=Math.min(state.maxHp,state.hp+18);
      toast(`کریستال ${state.crystals}/${crystals.length} پیدا شد`);updateHUD();maybeWin();
    }
  }
}

function updateCamera(dt){
  const target=hero.position.clone().add(new THREE.Vector3(0,2.05,0));
  const horizontal=Math.cos(cameraPitch)*cameraDistance;
  const desired=new THREE.Vector3(
    target.x-Math.sin(cameraYaw)*horizontal,
    target.y+Math.sin(cameraPitch)*cameraDistance+1.1,
    target.z-Math.cos(cameraYaw)*horizontal
  );
  if(cameraKick>0){desired.x+=Math.sin(elapsed*92)*cameraKick;desired.y+=Math.sin(elapsed*117)*cameraKick*.45;cameraKick*=Math.exp(-dt*18);}
  camera.position.lerp(desired,1-Math.exp(-dt*7));
  camera.lookAt(target);
}

function animateEnvironment(){
  lake.material.opacity=.79+Math.sin(elapsed*1.4)*.025;
  particles.rotation.y=elapsed*.015;
  particles.position.y=Math.sin(elapsed*.22)*.25;
}

function loop(){
  requestAnimationFrame(loop);
  const dt=Math.min(clock.getDelta(),.033);
  elapsed+=dt;
  if(gameStarted&&!gameOver){updateHero(dt);updateEnemies(dt);updateCrystals(dt);}
  animateEnvironment();updateCamera(dt);
  renderer.render(scene,camera);
}
loop();

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight,false);renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));
});
