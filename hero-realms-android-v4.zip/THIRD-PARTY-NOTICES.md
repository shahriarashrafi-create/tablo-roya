# Third-party notices

## Hero Knight Extreme GLB
Source repository: `JiangShan118/3d-texture-generator-examples`
Runtime file: `models/quality-comparison/extreme.glb`
Underlying geometry, rig and animation set: Kay Lousberg / KayKit character and animation assets, CC0 1.0 Universal.
The source repository describes the generated GLB as a derivative of the CC0 KayKit test asset and provides it for evaluation, learning and integration testing. Its texture-generation prompt is described upstream as dark royal knight armor with black steel, deep blue enamel and gold trim.

## three.js / GLTFLoader
Source: `mrdoob/three.js`, release r146.
License: MIT.

The Android Gradle build downloads these runtime assets during APK compilation and bundles them inside the APK so the installed game can run offline.
