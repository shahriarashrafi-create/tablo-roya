@echo off
setlocal
set GRADLE_VERSION=8.7
set BASE_DIR=%~dp0
set CACHE_DIR=%BASE_DIR%.gradle-bootstrap
set DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%
set ZIP_FILE=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%ZIP_FILE%' '%CACHE_DIR%'"
)
call "%DIST_DIR%\bin\gradle.bat" %*
