# Gamification v21

Applied the full round of upper-half refinements:
- Moved Quests/Map further left and Inbox/Shop further right
- Reduced side action button footprint: smaller width, tighter padding, smaller icon-label gap, smaller notification badge, and slightly higher placement
- Removed region labels (Knowledge/Freedom/Health/Discipline/Wealth) for a cleaner world scene
- Reworked center headline to show only one motivational sentence at a time
- Home screen headline now changes randomly from the 50 motivational English phrases whenever Home is opened/tapped
- Reduced headline size, tightened spacing to the decorative gold divider, and removed the secondary subtitle line
- Added stronger contrast/readability to the headline using a subtle dark shadow/outline feel
- Redesigned the gold divider and center diamond to feel more premium and visible
- Kept the world scene clean under the top HUD while preserving the smaller side controls
- Bumped app version to 0.21 / versionCode 21
