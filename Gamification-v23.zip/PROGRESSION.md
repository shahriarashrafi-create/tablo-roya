# Gamification v23 Progress

Changes applied in this version:
- Removed the Change button from the home mission card to keep focus on Start Mission.
- Raised the mission card and page dots higher above the bottom navigation.
- Added navigation bar safe-area padding to the bottom navigation to avoid overlap with the phone system bar.
- Reduced the visual heaviness of the bottom navigation background.
- Tightened the world side buttons slightly so they take less space.
- Kept the motivational headline randomization on Home tab re-entry.
