# آپلود نسخه ۱۷ روی GitHub

1. ZIP را Extract کن.
2. همه فایل‌ها را در ریشه Repository قرار بده.
3. Push کن یا Workflow **Build Android APK** را از Actions اجرا کن.
4. از Artifacts فایل **shahriar-million-path-v17-apk** را دانلود کن.
