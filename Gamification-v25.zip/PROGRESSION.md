# Gamification v24

Bottom navigation rebuild:
- Replaced Material NavigationBar with a custom bottom navigation layer.
- The world background now continues behind the bottom navigation instead of stopping above it.
- The dark/faded navigation treatment is drawn underneath the icons and labels, not over them.
- Added Android navigation-bar safe-area padding so the app navigation sits fully above the phone system bar.
- Added a subtle glass-like vertical gradient and a thin premium top divider.
- Replaced emoji/text navigation icons with custom-drawn Home, Missions, Stats, and Settings icons.
- Selected tab now uses a soft gold glow plus a thin gold accent, without the previous large selection blob.
- Improved inactive icon/text contrast so the footer no longer looks blacked out.
- Raised the mission card and page dots so they remain clearly separated from the bottom navigation.
- Bumped app version to 0.24 / versionCode 24.
