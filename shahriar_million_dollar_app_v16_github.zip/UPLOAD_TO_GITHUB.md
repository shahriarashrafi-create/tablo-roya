# ساخت APK نسخه ۱۶

محتویات ZIP را در ریشه Repository آپلود کن. سپس از GitHub Actions، workflow ساخت APK را اجرا کن و Artifact با نام `shahriar-million-path-v16-apk` را دانلود کن.
