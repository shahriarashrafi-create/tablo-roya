# Gamification Progression (v6)

## Top HUD
1. **Level + XP**
2. **Rank**
3. **Coins**
4. **Combo**

---

## Rank Tiers
Every **5 ranks** gets a different title and emblem:

| Rank | Title | Emblem |
|---|---|---|
| 1-5 | Novice | ✦ |
| 6-10 | Explorer | ★ |
| 11-15 | Seeker | ◆ |
| 16-20 | Vanguard | ⬟ |
| 21-25 | Warrior | ⚔ |
| 26-30 | Commander | ♛ |
| 31-35 | Champion | ✹ |
| 36-40 | Master | ✪ |
| 41-45 | Guardian | 🛡 |
| 46-50 | Conqueror | ☀ |
| 51-55 | Strategist | ⌘ |
| 56-60 | Myth Hunter | ✷ |
| 61-65 | General | ⚜ |
| 66-70 | Ruler | ♚ |
| 71-75 | Legend | ✴ |
| 76-80 | Immortal | ∞ |
| 81-85 | Meteor | ☄ |
| 86-90 | Cosmic | ✺ |
| 91-95 | Eternal | ✵ |
| 96-100 | Arcane | ☬ |

---

## Level Tiers (1-100)

| Levels | Title | Emblem |
|---|---|---|
| 1-10 | Initiate | ◉ |
| 11-20 | Apprentice | ✦ |
| 21-30 | Seeker | ✧ |
| 31-40 | Pathfinder | ✶ |
| 41-50 | Builder | ◆ |
| 51-60 | Steadfast | ⬟ |
| 61-70 | Pioneer | ✪ |
| 71-80 | Hero | ✹ |
| 81-90 | Noble | ✴ |
| 91-100 | Legend | ☼ |
