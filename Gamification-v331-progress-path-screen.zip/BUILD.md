# Build verification

This project is pinned to Java 17, Android SDK 35, and Gradle 8.9.

## Local
Run:

```sh
./scripts/verify-project.sh
```

The project-local `gradlew` launcher downloads the pinned Gradle distribution on first use and then runs `:app:assembleDebug`.

## CI
`.github/workflows/android-build.yml` installs Android SDK 35 and Java 17, runs the same verification script, and uploads `app-debug.apk`.

The launcher is intentionally self-contained so ZIP snapshots build without requiring a preinstalled Gradle executable.


## v52 verification note
The project structure and Kotlin delimiter balance were checked after the Step 2B UI audit. Full local Gradle compilation could not run in this environment because `services.gradle.org` DNS resolution is unavailable; the repository wrapper and CI workflow remain the authoritative build check.

## v54 verification note
Step 3B was checked with Kotlin delimiter validation and a standalone MissionEngine behavior test covering Active/Later/Done ordering. Full Android Gradle compilation is still unavailable in this execution environment because `services.gradle.org` cannot be resolved here; CI remains the full APK build check.

## v55 verification note
Step 4A adds a pure `RewardEngine` that was behavior-tested independently with Kotlin 1.9 for One-time success/blocking, Termless repeatability, balance deduction, and insufficient-coin rejection. The full Android build could not run here because `services.gradle.org` DNS resolution is unavailable; the project Gradle wrapper/CI remains the full APK build check.


## v56 verification note
Step 4B extends the pure RewardEngine with deterministic position normalization/upsert/removal behavior and keeps coin spending on the same atomic storage path. Structural Kotlin checks and standalone reward-order behavior tests are run before packaging. Full Android Gradle compilation may still require network access to the pinned Gradle distribution/Android dependencies when not already cached.

## v57 verification note
Step 5A extracted the Dreamboard UI and added a pure `DreamboardEngine`. The engine was compiled and behavior-tested independently for insert/move/remove ordering, position normalization, metadata sanitation and duplicate-ID repair. Kotlin parser passes found no syntax errors in the edited Android files; full Android compilation still requires the Gradle/Android dependency set to be available in the build environment.


## v58 verification note
Step 5B was checked with Kotlin syntax/error scanning on the edited files, ZIP/XML structural validation, and static checks for the new Dreamboard backup bundle paths. Full Android Gradle compilation was attempted, but this execution environment cannot resolve `services.gradle.org`, so the pinned Gradle distribution and Android dependencies could not be downloaded here.

## v59 verification
- `ProgressionEngine.kt` was compiled independently with Kotlin/JVM test stubs and passed smoke assertions for XP/Level/Rank/Combo transitions.
- The full Android Gradle build was attempted in the generation environment, but the wrapper could not resolve `services.gradle.org`; CI/project wrapper remain configured for a normal networked build.

## v60 verification note
Step 6B adds `ProgressionAnimation.kt`; it was compiled independently with Kotlin/JVM stubs and smoke-tested for XP level rollover, Coin interpolation, Combo interpolation, Rank interpolation, and duration planning. Kotlin delimiter/static scans were also run across the edited source. Full Android Gradle compilation still depends on access to the pinned Gradle/Android dependency distribution in a networked build environment.

## v61 verification note
Step 8A adds Android alarm/receiver code plus schema 19 timer metadata. Kotlin syntax scanning found no parser errors in the new scheduler/receiver sources, AndroidManifest XML was validated, and scheduling/state transitions were statically checked for timer pause/resume, reboot expiry, time/timezone change, reminder edit/delete and terminal mission results. A full Android Gradle build was attempted, but this execution environment still cannot resolve `services.gradle.org`, so the pinned Gradle distribution cannot be downloaded here.


## v62 Step 8B checks
- Verify `MissionResultReceiver` is declared non-exported in the manifest.
- Verify timer-finish actions use distinct immutable PendingIntents carrying the timer session ID.
- Verify notification actions only delegate to `finalizeActiveMissionSession()` and do not mutate Player/History directly.
- Verify the timer-finished notification is cancelled on result commit/new timer/explicit timer clear.


## v327 verification
- Removed active Streak, Chest, Inventory and Owned Rewards code paths; schema advanced to 155 so retired preference keys are removed during migration.
- Combo rules were synchronized to one source: Done #5 is the first x1.5 reward; Done #1-4 remain x1; Fail/Partial reset; Defer preserves.
- `Models.kt`, `RewardEngine.kt` and `ProgressionEngine.kt` were compiled together with a minimal Compose Color stub and a Combo smoke test passed for Done #1-6, Defer, Partial and Fail.
- Kotlin parser checks reported no syntax errors in `MainActivity.kt` or `GameStorage.kt`.
- Full Android Gradle build could not run in this environment because `services.gradle.org` could not be resolved.

## v329 verification
- Android metadata: versionCode 154 / versionName 1.54.
- BuildConfig generation is explicitly enabled for the Settings release label.
- Static integration checks confirm no `Release 0.86`, `1.53`, or Monday-based Personal League formula remains.
- Full Gradle verification still requires network access to the Gradle distribution host.

## v330 final verification
- Android metadata: versionCode 155 / versionName 1.55.
- Final stabilization keeps the v326 timer cleanup, v327 x1.5 Combo cleanup, v328 Tree migration, and v329 Saturday-week integration intact.
- Tree storage now tolerates missing/corrupt snapshot history without dropping current people data.
