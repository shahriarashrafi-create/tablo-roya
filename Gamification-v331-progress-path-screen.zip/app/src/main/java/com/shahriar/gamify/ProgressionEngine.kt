package com.shahriar.gamify

import kotlin.math.max

/**
 * Single source of truth for XP, Level, Rank and Combo progression.
 *
 * Storage owns persistence only; UI reads PlayerState only. All progression
 * mutations must enter through this file so mission rewards and bonus rewards
 * cannot drift into separate formulas over time.
 */
internal object ProgressionRules {
    const val MIN_LEVEL_XP = 500
    const val LEVEL_XP_STEP = 500
    const val LEVEL_UP_COIN_REWARD = 100
    const val MAX_RANK = 100
    // Five consecutive Done missions activate a flat x1.5 boost.
    // The fifth Done itself is boosted; subsequent Done missions stay boosted while the combo window remains alive.
    const val COMBO_ACTIVATION_COUNT = 5
    const val COMBO_ACTIVE_MULTIPLIER = 1.5f

    fun nextLevelThreshold(currentThreshold: Int): Int =
        currentThreshold.coerceAtLeast(MIN_LEVEL_XP) + LEVEL_XP_STEP
}


/** Stage 80: one canonical read model for every progression surface. */
internal data class ProgressionSummary(
    val levelProgress: Float,
    val xpRemaining: Int,
    val rankProgressFraction: Float,
    val rankRequirement: Int,
    val rankRemaining: Int,
    val isMaxRank: Boolean,
    val comboMultiplier: Float,
    val comboActive: Boolean
)

internal fun progressionSummary(player: PlayerState): ProgressionSummary {
    val safe = normalizePlayerProgression(player)
    val isMax = safe.rank >= ProgressionRules.MAX_RANK
    val requirement = if (isMax) 1 else rankRequirement(safe.rank)
    val rankFraction = if (isMax) 1f else (safe.rankProgress.toFloat() / requirement.toFloat()).coerceIn(0f, 1f)
    val multiplier = comboMultiplier(safe.combo)
    return ProgressionSummary(
        levelProgress = (safe.currentXp.toFloat() / safe.nextLevelXp.toFloat()).coerceIn(0f, 1f),
        xpRemaining = (safe.nextLevelXp - safe.currentXp).coerceAtLeast(0),
        rankProgressFraction = rankFraction,
        rankRequirement = requirement,
        rankRemaining = if (isMax) 0 else (requirement - safe.rankProgress).coerceAtLeast(0),
        isMaxRank = isMax,
        comboMultiplier = multiplier,
        comboActive = multiplier > 1f
    )
}

/** Combo reward multiplier used only for a successfully completed mission. */
internal fun comboMultiplier(combo: Int): Float =
    if (combo >= ProgressionRules.COMBO_ACTIVATION_COUNT) ProgressionRules.COMBO_ACTIVE_MULTIPLIER else 1.0f

/** Number of completed Rank Missions required to advance from [rank]. */
internal fun rankRequirement(rank: Int): Int =
    if (rank >= 10) 10 else rank.coerceAtLeast(1)

/**
 * Sanitizes persisted/imported progression without inventing rewards.
 * nextLevelXp remains the player's canonical threshold so existing saves keep
 * their current progress curve; every future level then follows one +500 rule.
 */
internal fun normalizePlayerProgression(player: PlayerState): PlayerState {
    val safeLevel = player.level.coerceAtLeast(1)
    val safeThreshold = player.nextLevelXp.coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
    val safeRank = player.rank.coerceIn(1, ProgressionRules.MAX_RANK)
    val safeCombo = player.combo.coerceAtLeast(0)
    return player.copy(
        level = safeLevel,
        currentXp = player.currentXp.coerceIn(0, safeThreshold - 1),
        nextLevelXp = safeThreshold,
        rank = safeRank,
        rankProgress = if (safeRank >= ProgressionRules.MAX_RANK) {
            0
        } else {
            player.rankProgress.coerceIn(0, rankRequirement(safeRank) - 1)
        },
        coins = player.coins.coerceAtLeast(0),
        combo = safeCombo,
        bestCombo = max(safeCombo, player.bestCombo.coerceAtLeast(0))
    )
}

private data class LevelAdvance(
    val level: Int,
    val currentXp: Int,
    val nextLevelXp: Int,
    val levelsGained: Int,
    val levelRewardCoins: Int
)

/** The only XP -> Level conversion path in the app. */
private fun advanceXp(player: PlayerState, xpGain: Int): LevelAdvance {
    var level = player.level
    var xp = player.currentXp + xpGain.coerceAtLeast(0)
    var threshold = player.nextLevelXp.coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
    var levelsGained = 0

    while (xp >= threshold) {
        xp -= threshold
        level += 1
        levelsGained += 1
        threshold = ProgressionRules.nextLevelThreshold(threshold)
    }

    return LevelAdvance(
        level = level,
        currentXp = xp,
        nextLevelXp = threshold,
        levelsGained = levelsGained,
        levelRewardCoins = levelsGained * ProgressionRules.LEVEL_UP_COIN_REWARD
    )
}

private fun comboAfterResult(player: PlayerState, result: MissionResult): Int = when (result) {
    MissionResult.Done -> player.combo + 1
    MissionResult.Partial -> 0
    MissionResult.Fail -> 0
    MissionResult.Defer -> player.combo
}

/**
 * Canonical mission progression transition.
 *
 * - Done: advances Combo and can earn XP/Coin (Combo boost may apply).
 * - Later/Defer: changes no progression value.
 * - Failed: resets Combo and awards nothing.
 * - Rank only advances on Done for a Rank Mission.
 */
internal fun applyMissionResult(
    player: PlayerState,
    mission: Mission,
    result: MissionResult
): MissionOutcome {
    val before = normalizePlayerProgression(player)
    val comboAfter = comboAfterResult(before, result)
    val rewardMultiplier = if (result == MissionResult.Done) {
        // Combo becomes active on Done #5, so the fifth successful mission is boosted too.
        comboMultiplier(comboAfter)
    } else {
        1.0f
    }

    val baseXp = when (result) {
        MissionResult.Done -> mission.xpReward
        MissionResult.Partial -> mission.xpReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }.coerceAtLeast(0)

    val baseCoins = when (result) {
        MissionResult.Done -> mission.coinReward
        MissionResult.Partial -> mission.coinReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }.coerceAtLeast(0)

    val xpGain = (baseXp * rewardMultiplier).toInt().coerceAtLeast(0)
    val missionCoinGain = (baseCoins * rewardMultiplier).toInt().coerceAtLeast(0)
    val levelAdvance = advanceXp(before, xpGain)

    var rank = before.rank
    var rankProgress = before.rankProgress
    var ranksGained = 0
    if (mission.isRankMission && result == MissionResult.Done && rank < ProgressionRules.MAX_RANK) {
        rankProgress += 1
        while (rank < ProgressionRules.MAX_RANK && rankProgress >= rankRequirement(rank)) {
            rankProgress -= rankRequirement(rank)
            rank += 1
            ranksGained += 1
        }
        if (rank >= ProgressionRules.MAX_RANK) rankProgress = 0
    }

    val updated = before.copy(
        level = levelAdvance.level,
        currentXp = levelAdvance.currentXp,
        nextLevelXp = levelAdvance.nextLevelXp,
        rank = rank,
        rankProgress = rankProgress,
        coins = before.coins + missionCoinGain + levelAdvance.levelRewardCoins,
        combo = comboAfter,
        bestCombo = max(before.bestCombo, comboAfter)
    )

    return MissionOutcome(
        player = updated,
        xpGain = xpGain,
        missionCoinGain = missionCoinGain,
        levelsGained = levelAdvance.levelsGained,
        levelRewardCoins = levelAdvance.levelRewardCoins,
        comboBefore = before.combo,
        comboAfter = comboAfter,
        rewardMultiplier = rewardMultiplier,
        ranksGained = ranksGained
    )
}

/**
 * Canonical non-mission XP/Coin reward path (for example an Achievement).
 * It can level the player, but never changes Rank or Combo.
 */
internal fun applyBonusReward(
    player: PlayerState,
    xpGain: Int,
    coinGain: Int
): Pair<PlayerState, LevelUpEvent?> {
    val before = normalizePlayerProgression(player)
    val advance = advanceXp(before, xpGain)
    val updated = before.copy(
        level = advance.level,
        currentXp = advance.currentXp,
        nextLevelXp = advance.nextLevelXp,
        coins = before.coins + coinGain.coerceAtLeast(0) + advance.levelRewardCoins
    )
    val event = if (advance.levelsGained > 0) {
        LevelUpEvent(before.level, advance.level, advance.levelRewardCoins)
    } else {
        null
    }
    return updated to event
}

/** UI event projection; progression itself has already been committed. */
internal fun levelUpEventFor(before: PlayerState, outcome: MissionOutcome): LevelUpEvent? =
    if (outcome.levelsGained > 0) {
        LevelUpEvent(before.level, outcome.player.level, outcome.levelRewardCoins)
    } else {
        null
    }

/** UI event projection; session de-duplication guarantees this is surfaced once. */
internal fun rankUpEventFor(before: PlayerState, outcome: MissionOutcome): RankUpEvent? =
    if (outcome.ranksGained > 0) {
        RankUpEvent(before.rank, outcome.player.rank)
    } else {
        null
    }
