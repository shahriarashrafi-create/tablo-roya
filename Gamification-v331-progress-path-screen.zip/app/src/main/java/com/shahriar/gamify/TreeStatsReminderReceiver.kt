package com.shahriar.gamify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

internal const val TREE_STATS_CHANNEL_ID = "tree_stats_daily_reminder"
internal const val TREE_STATS_NOTIFICATION_ID = 31_220
internal const val ACTION_TREE_STATS_REMIND = "com.shahriar.gamify.action.TREE_STATS_REMIND"
internal const val ACTION_TREE_STATS_ACK = "com.shahriar.gamify.action.TREE_STATS_ACK"
internal const val ACTION_TREE_STATS_REPOST = "com.shahriar.gamify.action.TREE_STATS_REPOST"

internal const val KEY_TREE_STATS_REMINDER_ENABLED = "tree_stats_reminder_enabled"
internal const val KEY_TREE_STATS_REMINDER_HOUR = "tree_stats_reminder_hour"
internal const val KEY_TREE_STATS_REMINDER_MINUTE = "tree_stats_reminder_minute"

private const val KEY_TREE_STATS_RECORDED_DATE = "tree_stats_recorded_date"
private const val KEY_TREE_STATS_RECORDED_IDS = "tree_stats_recorded_ids"
private const val KEY_TREE_STATS_ACK_DATE = "tree_stats_ack_date"

internal fun treeStatsReminderEnabled(context: Context): Boolean =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getBoolean(KEY_TREE_STATS_REMINDER_ENABLED, true)

internal fun treeStatsReminderHour(context: Context): Int =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_TREE_STATS_REMINDER_HOUR, 22)
        .coerceIn(0, 23)

internal fun treeStatsReminderMinute(context: Context): Int =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getInt(KEY_TREE_STATS_REMINDER_MINUTE, 0)
        .coerceIn(0, 59)

/** Records an explicit PV/GPV save for one person for today's daily check. */
internal fun markTreePersonStatsRecorded(
    context: Context,
    personId: String,
    date: LocalDate = LocalDate.now()
) {
    if (personId.isBlank()) return
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val key = date.toString()
    val ids = if (prefs.getString(KEY_TREE_STATS_RECORDED_DATE, null) == key) {
        prefs.getStringSet(KEY_TREE_STATS_RECORDED_IDS, emptySet()).orEmpty().toMutableSet()
    } else {
        mutableSetOf()
    }
    ids += personId
    prefs.edit()
        .putString(KEY_TREE_STATS_RECORDED_DATE, key)
        .putStringSet(KEY_TREE_STATS_RECORDED_IDS, ids)
        .apply()
}

internal fun markTreeStatsAcknowledged(context: Context, date: LocalDate = LocalDate.now()) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_TREE_STATS_ACK_DATE, date.toString())
        .apply()
}

internal fun treeStatsAcknowledgedToday(context: Context, date: LocalDate = LocalDate.now()): Boolean =
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(KEY_TREE_STATS_ACK_DATE, null) == date.toString()

internal fun treeStatsCompleteToday(context: Context, date: LocalDate = LocalDate.now()): Boolean {
    val personIds = currentTreePersonIds(context)
    if (personIds.isEmpty()) return true
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    if (prefs.getString(KEY_TREE_STATS_RECORDED_DATE, null) != date.toString()) return false
    val recorded = prefs.getStringSet(KEY_TREE_STATS_RECORDED_IDS, emptySet()).orEmpty()
    return personIds.all { it in recorded }
}

private fun currentTreePersonIds(context: Context): Set<String> =
    runCatching { treePersonIdsForStats(context) }.getOrDefault(emptySet())

private fun treeStatsReminderPendingIntent(context: Context): PendingIntent {
    val intent = Intent(context, TreeStatsReminderReceiver::class.java).apply {
        action = ACTION_TREE_STATS_REMIND
        data = Uri.parse("gamify://tree-stats/remind")
    }
    return PendingIntent.getBroadcast(
        context,
        31_220,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun treeStatsAckPendingIntent(context: Context): PendingIntent {
    val intent = Intent(context, TreeStatsReminderReceiver::class.java).apply {
        action = ACTION_TREE_STATS_ACK
        data = Uri.parse("gamify://tree-stats/ack")
    }
    return PendingIntent.getBroadcast(
        context,
        31_221,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun treeStatsRepostPendingIntent(context: Context): PendingIntent {
    val intent = Intent(context, TreeStatsReminderReceiver::class.java).apply {
        action = ACTION_TREE_STATS_REPOST
        data = Uri.parse("gamify://tree-stats/repost")
    }
    return PendingIntent.getBroadcast(
        context,
        31_222,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun treeStatsContentPendingIntent(context: Context): PendingIntent {
    val intent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    return PendingIntent.getActivity(
        context,
        31_223,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

internal fun scheduleTreeStatsReminder(
    context: Context,
    nowMillis: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault()
) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
    val pendingIntent = treeStatsReminderPendingIntent(context)
    if (!treeStatsReminderEnabled(context)) {
        alarmManager.cancel(pendingIntent)
        cancelTreeStatsReminderNotification(context)
        return
    }

    val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
    val time = LocalTime.of(treeStatsReminderHour(context), treeStatsReminderMinute(context))
    var candidate = ZonedDateTime.of(now.toLocalDate(), time, zone)
    if (!candidate.toInstant().isAfter(now.toInstant())) candidate = candidate.plusDays(1)
    scheduleReliableAlarm(context, candidate.toInstant().toEpochMilli(), pendingIntent)
}

/**
 * Called on app start / reboot. If today's configured time already passed and the
 * user still has unfinished tree stats, restore the persistent notification.
 */
internal fun restoreTreeStatsReminder(context: Context, nowMillis: Long = System.currentTimeMillis()) {
    if (!treeStatsReminderEnabled(context)) {
        scheduleTreeStatsReminder(context, nowMillis)
        return
    }
    val zone = ZoneId.systemDefault()
    val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
    val todayTrigger = ZonedDateTime.of(
        now.toLocalDate(),
        LocalTime.of(treeStatsReminderHour(context), treeStatsReminderMinute(context)),
        zone
    )
    if (!now.toInstant().isBefore(todayTrigger.toInstant()) &&
        !treeStatsAcknowledgedToday(context, now.toLocalDate()) &&
        !treeStatsCompleteToday(context, now.toLocalDate())
    ) {
        postTreeStatsReminderNotification(context)
    }
    scheduleTreeStatsReminder(context, nowMillis, zone)
}

internal fun cancelTreeStatsReminderNotification(context: Context) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.cancel(TREE_STATS_NOTIFICATION_ID)
}

private fun ensureTreeStatsChannel(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.createNotificationChannel(
        NotificationChannel(
            TREE_STATS_CHANNEL_ID,
            "آمار روزانه درختواره",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "یادآوری ثبت آمار روزانه افراد درختواره"
            enableVibration(true)
        }
    )
}

internal fun postTreeStatsReminderNotification(context: Context) {
    if (!treeStatsReminderEnabled(context)) return
    val today = LocalDate.now()
    if (treeStatsAcknowledgedToday(context, today) || treeStatsCompleteToday(context, today)) {
        cancelTreeStatsReminderNotification(context)
        return
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return

    ensureTreeStatsChannel(context)
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(context, TREE_STATS_CHANNEL_ID)
    } else {
        @Suppress("DEPRECATION")
        Notification.Builder(context)
    }

    builder
        .setSmallIcon(R.drawable.ic_launcher_legacy)
        .setContentTitle("آمارهای امروز رو ثبت کردی؟")
        .setContentText("آمار فردبه‌فرد PV و GPV درختواره رو ثبت کن.")
        .setContentIntent(treeStatsContentPendingIntent(context))
        .setDeleteIntent(treeStatsRepostPendingIntent(context))
        .setOngoing(true)
        .setAutoCancel(false)
        .setOnlyAlertOnce(true)
        .setCategory(Notification.CATEGORY_REMINDER)
        .setPriority(Notification.PRIORITY_DEFAULT)
        .setVisibility(Notification.VISIBILITY_PUBLIC)
        .addAction(
            Notification.Action.Builder(
                R.drawable.ic_done_action,
                "✅ ثبت شد",
                treeStatsAckPendingIntent(context)
            ).build()
        )

    val notification = builder.build().apply {
        flags = flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR
    }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.notify(TREE_STATS_NOTIFICATION_ID, notification)
}

class TreeStatsReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_TREE_STATS_ACK -> {
                markTreeStatsAcknowledged(context)
                cancelTreeStatsReminderNotification(context)
                scheduleTreeStatsReminder(context)
            }
            ACTION_TREE_STATS_REPOST -> {
                if (!treeStatsAcknowledgedToday(context)) postTreeStatsReminderNotification(context)
                scheduleTreeStatsReminder(context)
            }
            ACTION_TREE_STATS_REMIND, null -> {
                postTreeStatsReminderNotification(context)
                scheduleTreeStatsReminder(context)
            }
        }
    }
}
