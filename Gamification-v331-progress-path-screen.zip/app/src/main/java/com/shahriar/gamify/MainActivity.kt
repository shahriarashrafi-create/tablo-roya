package com.shahriar.gamify

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.CalendarContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt
import kotlin.math.max

private val motivationalQuotes = listOf(
    "Small steps build great futures.",
    "Discipline creates freedom.",
    "Keep moving forward.",
    "Win the next moment.",
    "Progress over perfection.",
    "Build the life you want.",
    "Focus. Execute. Grow.",
    "Your future starts today.",
    "One mission at a time.",
    "Consistency beats intensity.",
    "Become stronger every day.",
    "Do the hard thing first.",
    "Make today count.",
    "Your habits shape your destiny.",
    "Keep the promise to yourself.",
    "Action creates confidence.",
    "Great things take repetition.",
    "Earn your next level.",
    "Stay focused on the mission.",
    "Become who you said you would.",
    "Momentum changes everything.",
    "Show up and do the work.",
    "Every effort adds up.",
    "Your discipline is your power.",
    "Start before you feel ready.",
    "Keep building your future.",
    "One focused hour can change a day.",
    "Progress is always earned.",
    "Make your future proud.",
    "Train your mind to finish.",
    "Growth begins with action.",
    "Your next level needs you.",
    "Build momentum, not excuses.",
    "Today is another chance to grow.",
    "Focus turns goals into reality.",
    "Keep going when it gets hard.",
    "Success is built in small moments.",
    "Make discipline your advantage.",
    "Your actions define your path.",
    "Push beyond your comfort zone.",
    "Finish what you started.",
    "Create a life worth leveling up.",
    "Stay consistent. Stay dangerous.",
    "The mission is simple: improve.",
    "Build yourself every single day.",
    "Your future rewards consistency.",
    "Focus now. Celebrate later.",
    "Every mission makes you stronger.",
    "Become better than yesterday.",
    "Keep climbing. Your peak is ahead."
)

class MainActivity : ComponentActivity() {
    private var resumeGeneration by mutableIntStateOf(0)
    private var requestedOpenMissionId by mutableStateOf<String?>(null)
    private var openMissionGeneration by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreTreeStatsReminder(applicationContext)
        consumeOpenMissionIntent(intent)
        setContent {
            App(
                resumeGeneration = resumeGeneration,
                requestedOpenMissionId = requestedOpenMissionId,
                openMissionGeneration = openMissionGeneration
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeOpenMissionIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        resumeGeneration += 1
        // Stage 39: resume the same session track only when a mission is still active.
        val recoveredMission = recoverActiveTimer(applicationContext)
        MissionMusicController.ensureForTimer(
            applicationContext,
            loadSettings(applicationContext),
            recoveredMission
        )
        if (recoveredMission != null && recoveredMission.isRunning && remainingSeconds(applicationContext, recoveredMission) > 0) {
            MissionSessionService.start(applicationContext)
        }
    }

    override fun onStop() {
        // v302: MissionSessionService owns the active session. Leaving a screen,
        // backgrounding the app or locking the phone must not pause timer/music.
        super.onStop()
    }

    private fun consumeOpenMissionIntent(source: Intent?) {
        val missionId = source?.getStringExtra(EXTRA_OPEN_MISSION_ID)?.trim().orEmpty()
        if (missionId.isBlank()) return
        requestedOpenMissionId = missionId
        openMissionGeneration += 1
        source?.removeExtra(EXTRA_OPEN_MISSION_ID)
    }
}

// Stage 63: lightweight daily state surfaced directly on the world map.
internal enum class WorldNodeState { Normal, Active, Pending, Completed }
private enum class BottomNavType { Home, Stats, Settings, Profile }
private enum class ProgressionNoticeKind { Level, Rank }

private data class ProgressionNotice(
    val kind: ProgressionNoticeKind,
    val newValue: Int,
    val rankLabel: String,
    val fromValue: Int = newValue,
    val rewardCoins: Int = 0,
    val nextLevelXp: Int = 0
)

private fun persianRankLabel(rank: Int): String = when (rank.coerceIn(1, 100)) {
    in 1..5 -> "تازه‌کار"
    in 6..10 -> "کاوشگر"
    in 11..15 -> "جستجوگر"
    in 16..20 -> "پیشتاز"
    in 21..25 -> "جنگجو"
    in 26..30 -> "فرمانده"
    in 31..35 -> "قهرمان"
    in 36..40 -> "استاد"
    in 41..45 -> "نگهبان"
    in 46..50 -> "فاتح"
    in 51..55 -> "استراتژیست"
    in 56..60 -> "شکارچی اسطوره"
    in 61..65 -> "ژنرال"
    in 66..70 -> "فرمانروا"
    in 71..75 -> "افسانه"
    in 76..80 -> "جاودانه"
    in 81..85 -> "شهاب"
    in 86..90 -> "کیهانی"
    in 91..95 -> "ابدی"
    else -> "اسرارآمیز"
}

private fun levelProgressionNotice(event: LevelUpEvent, finalPlayer: PlayerState): ProgressionNotice = ProgressionNotice(
    kind = ProgressionNoticeKind.Level,
    newValue = event.toLevel,
    rankLabel = persianRankLabel(finalPlayer.rank),
    fromValue = event.fromLevel,
    rewardCoins = event.rewardCoins,
    nextLevelXp = finalPlayer.nextLevelXp
)

private fun rankProgressionNotice(event: RankUpEvent): ProgressionNotice = ProgressionNotice(
    kind = ProgressionNoticeKind.Rank,
    newValue = event.toRank,
    rankLabel = persianRankLabel(event.toRank),
    fromValue = event.fromRank,
    nextLevelXp = if (event.toRank >= ProgressionRules.MAX_RANK) 0 else rankRequirement(event.toRank)
)

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", Color(0xFF6D3C1D), Color(0xFFF2C56F)),
    RankTier(6, 10, "Explorer", Color(0xFF7D1E1A), Color(0xFFF5CC62)),
    RankTier(11, 15, "Seeker", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value)
private val rewardHistoryDateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
private fun formatRewardRedemptionTime(timestamp: Long): String =
    Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).format(rewardHistoryDateFormatter)

@Composable
fun App(
    resumeGeneration: Int = 0,
    requestedOpenMissionId: String? = null,
    openMissionGeneration: Int = 0
) {
    val context = LocalContext.current.applicationContext
    remember { migrateState(context); applyFreshStartV113IfNeeded(context); performDailyResetIfNeeded(context); Unit }
    val restoredTimer = remember { recoverActiveTimer(context) }
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf(AppScreen.Home) }
    var player by remember { mutableStateOf(loadPlayer(context)) }
    var settings by remember { mutableStateOf(loadSettings(context)) }
    var quoteIndex by remember { mutableIntStateOf(motivationalQuotes.indices.random()) }
    var activeMission by remember { mutableStateOf(restoredTimer?.mission) }
    var missionStartConflict by remember { mutableStateOf<ActiveTimerState?>(null) }
    var completionAnimation by remember { mutableStateOf<MissionCompletionAnimation?>(null) }
    var terminalAnimation by remember { mutableStateOf<MissionTerminalAnimation?>(null) }
    var hudRewardCue by remember { mutableStateOf<HudRewardCue?>(null) }
    var progressionNotice by remember { mutableStateOf<ProgressionNotice?>(null) }
    val progressionNoticeChannel = remember { Channel<ProgressionNotice>(Channel.UNLIMITED) }
    var achievementUnlockNotice by remember { mutableStateOf<Achievement?>(null) }
    val achievementUnlockChannel = remember { Channel<Achievement>(Channel.UNLIMITED) }
    val seenAchievementUnlocks = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_ACHIEVEMENT_UNLOCK_SEEN)) } }
    var masteryNotice by remember { mutableStateOf<AchievementCategory?>(null) }
    val masteryNoticeChannel = remember { Channel<AchievementCategory>(Channel.UNLIMITED) }
    val seenMasteryCategories = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_ACHIEVEMENT_MASTERY_SEEN)) } }
    var showShop by remember { mutableStateOf(false) }
    var showWorldMap by remember { mutableStateOf(false) }
    var showMissions by remember { mutableStateOf(false) }
    var showDreamboard by remember { mutableStateOf(false) }
    var showTree by remember { mutableStateOf(false) }
    var showTimeSheet by remember { mutableStateOf(false) }
    var requestedMissionIndex by remember { mutableStateOf<Int?>(null) }
    var requestedMissionNonce by remember { mutableIntStateOf(0) }
    val personalRewards = remember { mutableStateListOf<PersonalReward>().also { it.addAll(loadPersonalRewards(context)) } }
    val rewardRedemptions = remember { mutableStateListOf<RewardRedemptionEntry>().also { it.addAll(loadRewardRedemptions(context)) } }
    val dreamItems = remember { mutableStateListOf<DreamItem>().also { it.addAll(loadDreamItems(context)) } }
    val claimedAchievements = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_ACHIEVEMENT_CLAIMS)) } }
    val showcasedAchievements = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_ACHIEVEMENT_SHOWCASE).take(3)) } }
    val quote = motivationalQuotes[quoteIndex]
    val missions = remember {
        mutableStateListOf<Mission>().also { it.addAll(loadMissions(context)) }
    }
    val history = remember {
        mutableStateListOf<MissionHistoryEntry>().also { it.addAll(loadHistory(context)) }
    }

    fun focusRunningMissionCard() {
        val running = recoverActiveTimer(context) ?: return
        if (remainingSeconds(context, running) <= 0) return
        val runningIndex = missions.indexOfFirst { mission ->
            (running.mission.id.isNotBlank() && mission.id == running.mission.id) ||
                (running.mission.id.isBlank() && mission.title == running.mission.title)
        }
        if (runningIndex >= 0) {
            requestedMissionIndex = runningIndex
            requestedMissionNonce += 1
        }
    }

    var observedExternalResultRevision by remember {
        mutableStateOf(externalMissionResultRevision(context))
    }
    var externalResultSignal by remember { mutableStateOf(observedExternalResultRevision) }

    DisposableEffect(context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_EXTERNAL_MISSION_RESULT_REVISION) {
                externalResultSignal = externalMissionResultRevision(context)
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    // Combo boost is a 30-minute chain. If that window expires while the app
    // is open, reset the live Combo immediately so the HUD and Home stay honest.
    LaunchedEffect(Unit) {
        while (true) {
            if (expireComboIfNeeded(context)) {
                player = loadPlayer(context)
                hudRewardCue = null
            }
            delay(1000L)
        }
    }

    val notifications = remember {
        mutableStateListOf<GameNotification>().also { it.addAll(loadNotifications(context)) }
    }
    var onboardingComplete by remember { mutableStateOf(isOnboardingComplete(context)) }

    LaunchedEffect(terminalAnimation) {
        val animation = terminalAnimation ?: return@LaunchedEffect
        val wait = if (settings.reducedMotion) 120L else if (animation.result == MissionResult.Fail) 900L else 650L
        delay(wait)
        terminalAnimation = null
        // Stage 50: every terminal result returns to the same mission flow.
        // The source mission index is already stored by completeMission; the tower
        // resolves that stable identity after smart ordering has moved the card.
        showMissions = true
        requestedMissionNonce += 1
    }

    if (!onboardingComplete) {
        GamifyTheme {
            OnboardingScreen(
                onFinish = { profile, templateIds ->
                    saveOnboardingProfile(context, profile)
                    val additions = missionTemplates.filter { it.id in templateIds }.map { it.mission }
                    missions.clear()
                    val initialMissions = if (additions.isNotEmpty()) additions else listOf(defaultMission())
                    missions.addAll(normalizeMissionIdentities(initialMissions))
                    saveMissions(context, missions)
                    onboardingComplete = true
                }
            )
        }
        return
    }

    LaunchedEffect(resumeGeneration, externalResultSignal) {
        // Always evaluate the day boundary when the app comes back to foreground.
        // This covers the common case where the process stays alive across midnight.
        performDailyResetIfNeeded(context)

        val revision = externalMissionResultRevision(context)
        val externalResultChanged = revision != observedExternalResultRevision
        if (externalResultChanged) {
            observedExternalResultRevision = revision
            player = loadPlayer(context)
            history.clear(); history.addAll(loadHistory(context))
            completionAnimation = null
            terminalAnimation = null
            hudRewardCue = null

            // Stage 41: a result committed from the notification is authoritative.
            // Bring every visible layer back in sync as soon as the app resumes,
            // then reveal the affected card in the mission tower instead of leaving
            // the user on a stale execution screen.
            externalMissionResultEvent(context)?.takeIf { it.revision == revision }?.let { event ->
                val index = missions.indexOfFirst { candidate ->
                    (event.missionId.isNotBlank() && candidate.id == event.missionId) ||
                        history.any { entry ->
                            entry.sessionId == event.sessionId &&
                                ((entry.missionId.isNotBlank() && candidate.id == entry.missionId) ||
                                    (entry.missionId.isBlank() && candidate.title == entry.missionTitle))
                        }
                }
                activeMission = null
                screen = AppScreen.Home
                tab = 0
                showShop = false
                showWorldMap = false
                showDreamboard = false
                showTree = false
                showTimeSheet = false
                showMissions = true
                if (index >= 0) {
                    requestedMissionIndex = index
                    requestedMissionNonce += 1
                }
                val latest = history.firstOrNull { it.sessionId == event.sessionId }
                if (event.result == MissionResult.Done && latest != null) {
                    val totalCoins = latest.coinsEarned.coerceAtLeast(0)
                    val label = buildString {
                        if (latest.xpEarned > 0) append("+${formatNumber(latest.xpEarned)} XP")
                        if (totalCoins > 0) {
                            if (isNotEmpty()) append(" • ")
                            append("+${formatNumber(totalCoins)} Coin")
                        }
                    }
                    if (label.isNotBlank()) hudRewardCue = HudRewardCue(ProgressionVisualStep.Xp, label)
                }
            }
        }

        // Re-read the authoritative timer whenever the app returns to foreground.
        // The countdown itself is deadline based, so time spent on another screen,
        // with the keyboard open, or while the app is backgrounded is never lost.
        val recovered = recoverActiveTimer(context)
        activeMission = recovered?.mission
        MissionMusicController.ensureForTimer(context, settings, recovered)
        if (recovered == null && screen == AppScreen.Mission) {
            screen = AppScreen.Home
        }

        // Reconcile alarms after resume so reminders and an active mission timer are
        // restored after time changes, app updates, process death, or alarm revocation.
        synchronizeScheduledAlarms(context, settings)
        scheduleTreeStatsReminder(context)
    }

    // Whenever the player actually returns to an unobstructed Home screen,
    // reveal the running mission card without reordering the carousel.
    LaunchedEffect(
        screen,
        tab,
        showShop,
        showWorldMap,
        showMissions,
        showDreamboard,
        showTree,
        showTimeSheet,
        resumeGeneration
    ) {
        val homeVisible = screen == AppScreen.Home && tab == 0 &&
            !showShop && !showWorldMap && !showMissions &&
            !showDreamboard && !showTree && !showTimeSheet
        if (homeVisible) focusRunningMissionCard()
    }

    LaunchedEffect(openMissionGeneration, requestedOpenMissionId) {
        val missionId = requestedOpenMissionId?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        val recovered = recoverActiveTimer(context)
        if (recovered != null && recovered.mission.id == missionId) {
            activeMission = recovered.mission
            screen = AppScreen.Mission
            tab = 0
            showShop = false
            showWorldMap = false
            showMissions = false
            showDreamboard = false
            showTree = false
            showTimeSheet = false
        } else {
            val baseIndex = missions.indexOfFirst { it.id == missionId }
            if (baseIndex >= 0) {
                requestedMissionIndex = baseIndex
                requestedMissionNonce += 1
                tab = 0
                screen = AppScreen.Home
                showShop = false
                showWorldMap = false
                showMissions = false
                showDreamboard = false
                showTree = false
                showTimeSheet = false
            }
        }
    }

    fun pushNotification(id: String, glyph: String, title: String, body: String) {
        if (notifications.none { it.id == id }) {
            notifications.add(0, GameNotification(id, glyph, title, body, System.currentTimeMillis(), false))
            while (notifications.size > 100) notifications.removeAt(notifications.lastIndex)
            saveNotifications(context, notifications)
        }
    }

    fun enqueueProgressionNotices(levelUp: LevelUpEvent?, rankUp: RankUpEvent?, finalPlayer: PlayerState) {
        levelUp?.let { progressionNoticeChannel.trySend(levelProgressionNotice(it, finalPlayer)) }
        rankUp?.let { progressionNoticeChannel.trySend(rankProgressionNotice(it)) }
    }

    LaunchedEffect(progressionNoticeChannel) {
        for (notice in progressionNoticeChannel) {
            progressionNotice = notice
            while (progressionNotice != null) delay(80L)
            delay(if (settings.reducedMotion) 40L else 120L)
        }
    }

    // Stage 84: announce an achievement exactly once, at the moment it first becomes unlocked.
    // Existing installs are seeded silently so an upgrade never floods the player with old unlocks.
    LaunchedEffect(player.level, player.rank, player.bestCombo, history.size) {
        val unlocked = buildAchievements(player, history).filter { it.progress >= it.goal }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_ACHIEVEMENT_UNLOCK_SEEN)) {
            seenAchievementUnlocks.clear()
            seenAchievementUnlocks.addAll(unlocked.map { it.id })
            saveStringSet(context, KEY_ACHIEVEMENT_UNLOCK_SEEN, seenAchievementUnlocks.toSet())
        } else {
            unlocked.filter { it.id !in seenAchievementUnlocks }.forEach { achievement ->
                seenAchievementUnlocks.add(achievement.id)
                saveStringSet(context, KEY_ACHIEVEMENT_UNLOCK_SEEN, seenAchievementUnlocks.toSet())
                achievementUnlockChannel.trySend(achievement)
            }
        }
    }

    LaunchedEffect(achievementUnlockChannel) {
        for (achievement in achievementUnlockChannel) {
            while (progressionNotice != null || achievementUnlockNotice != null) delay(80L)
            achievementUnlockNotice = achievement
            delay(if (settings.reducedMotion) 1700L else 2800L)
            if (achievementUnlockNotice?.id == achievement.id) achievementUnlockNotice = null
            delay(120L)
        }
    }

    // Stage 87: celebrate category mastery once, after the regular progression/unlock queue clears.
    LaunchedEffect(player.level, player.rank, player.bestCombo, history.size) {
        val achievements = buildAchievements(player, history)
        val mastered = AchievementCategory.entries.filter { category ->
            val categoryAchievements = achievements.filter { it.category == category }
            categoryAchievements.isNotEmpty() && categoryAchievements.all { it.progress >= it.goal }
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_ACHIEVEMENT_MASTERY_SEEN)) {
            seenMasteryCategories.clear()
            seenMasteryCategories.addAll(mastered.map { it.name })
            saveStringSet(context, KEY_ACHIEVEMENT_MASTERY_SEEN, seenMasteryCategories.toSet())
        } else {
            mastered.filter { it.name !in seenMasteryCategories }.forEach { category ->
                seenMasteryCategories.add(category.name)
                saveStringSet(context, KEY_ACHIEVEMENT_MASTERY_SEEN, seenMasteryCategories.toSet())
                masteryNoticeChannel.trySend(category)
            }
        }
    }

    LaunchedEffect(masteryNoticeChannel) {
        for (category in masteryNoticeChannel) {
            while (progressionNotice != null || achievementUnlockNotice != null || masteryNotice != null) delay(80L)
            masteryNotice = category
            delay(if (settings.reducedMotion) 1900L else 3300L)
            if (masteryNotice == category) masteryNotice = null
            delay(140L)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted && (settings.notificationsEnabled || settings.treeStatsReminderEnabled)) {
            settings = settings.copy(
                notificationsEnabled = false,
                treeStatsReminderEnabled = false
            )
            saveSettings(context, settings)
            synchronizeScheduledAlarms(context, settings)
            scheduleTreeStatsReminder(context)
        } else if (granted) {
            synchronizeScheduledAlarms(context, settings)
            scheduleTreeStatsReminder(context)
        }
    }

    LaunchedEffect(settings.notificationsEnabled, settings.treeStatsReminderEnabled) {
        val anyNotificationEnabled = settings.notificationsEnabled || settings.treeStatsReminderEnabled
        if (anyNotificationEnabled &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            synchronizeScheduledAlarms(context, settings)
            scheduleTreeStatsReminder(context)
        }
    }

    LaunchedEffect(Unit) {
        val today = currentMissionDay(context)
        missions.forEachIndexed { index, mission ->
            val due = isMissionScheduledToday(mission, today) &&
                missionCardState(mission, history, today) == MissionCardState.Active
            if (due && mission.repeat != MissionRepeat.None) {
                pushNotification(
                    id = "due:$today:$index:${mission.title}",
                    glyph = "◷",
                    title = "Mission due today",
                    body = "${mission.title}${recurrenceTimeText(mission).takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}"
                )
            }
        }
        synchronizeScheduledAlarms(context, settings)
    }

    fun completeMission(result: MissionResult, focusSeconds: Int) {
        val committed = finalizeActiveMissionSession(context, result, focusSeconds)
        if (committed == null) {
            player = loadPlayer(context)
            history.clear(); history.addAll(loadHistory(context))
            activeMission = null
            hudRewardCue = null
            screen = AppScreen.Home
            return
        }

        history.clear(); history.addAll(committed.history)
        activeMission = null
        screen = AppScreen.Home

        // v300: terminal cards move to the tail of the tower. After Done/Fail the
        // carousel must advance to the next actionable mission instead of following
        // the card that just moved to the end. Defer keeps its own queue behavior.
        val completedMissionIndex = missions.indexOfFirst { candidate ->
            (committed.mission.id.isNotBlank() && candidate.id == committed.mission.id) ||
                (committed.mission.id.isBlank() && candidate.title == committed.mission.title)
        }
        if (result == MissionResult.Defer && completedMissionIndex >= 0) {
            requestedMissionIndex = completedMissionIndex
            requestedMissionNonce += 1
        } else if (result == MissionResult.Done || result == MissionResult.Fail) {
            val nextActiveIndex = missions.indices.firstOrNull { sourceIndex ->
                sourceIndex != completedMissionIndex &&
                    missionDayStateForCurrentDay(context, missions[sourceIndex], committed.history) in
                    setOf(MissionDayState.Active, MissionDayState.Later)
            }
            requestedMissionIndex = nextActiveIndex
            requestedMissionNonce += 1
        }

        // Stage 31: Later/Defer is a queue action, not a terminal completion.
        // Return directly to Mission Tower after the timer session is cleared so
        // another mission can be started immediately. The deferred mission is
        // derived as Active/Later by MissionEngine and is placed behind the
        // untouched active cards for today. Starting it again creates a fresh
        // timer with the mission's full configured duration.
        if (result == MissionResult.Defer) {
            // Stage 35: show a short reset/return beat before the card re-enters
            // the available queue. The queue itself is still derived by MissionEngine.
            terminalAnimation = MissionTerminalAnimation(committed.mission, MissionResult.Defer)
        }

        if (committed.duplicate) {
            player = loadPlayer(context)
            completionAnimation = null
            hudRewardCue = null
            return
        }

        val outcome = committed.outcome
        val beforePlayer = committed.beforePlayer
        val mission = committed.mission
        val nextLevelEvent = levelUpEventFor(beforePlayer, outcome)
        val nextRankEvent = rankUpEventFor(beforePlayer, outcome)

        playResultFeedback(
            context = context,
            settings = settings,
            result = result,
            levelUp = outcome.levelsGained > 0
        )

        if (outcome.ranksGained > 0) {
            pushNotification(
                "rank:${outcome.player.rank}:${System.currentTimeMillis()}",
                "♜",
                "Rank Up!",
                "You reached Rank ${outcome.player.rank}."
            )
        }
        if (outcome.levelsGained > 0) {
            pushNotification(
                "level:${outcome.player.level}:${System.currentTimeMillis()}",
                "★",
                "Level Up!",
                "Level ${outcome.player.level} • +${outcome.levelRewardCoins} Coins"
            )
        }

        if (result == MissionResult.Done) {
            // The committed PlayerState is already persisted. The UI intentionally
            // starts at the pre-result snapshot and reveals each reward on the HUD
            // in a fixed XP -> Coin -> Combo -> Level -> Rank sequence.
            player = beforePlayer
            hudRewardCue = null
            completionAnimation = MissionCompletionAnimation(
                mission = mission,
                fromPlayer = beforePlayer,
                toPlayer = outcome.player,
                xpGain = outcome.xpGain,
                coinGain = outcome.missionCoinGain + outcome.levelRewardCoins,
                levelUp = nextLevelEvent,
                rankUp = nextRankEvent
            )
        } else {
            player = outcome.player
            completionAnimation = null
            hudRewardCue = null
            if (result == MissionResult.Fail) {
                terminalAnimation = MissionTerminalAnimation(mission, MissionResult.Fail)
            }
            enqueueProgressionNotices(nextLevelEvent, nextRankEvent, outcome.player)
        }
    }

    LaunchedEffect(completionAnimation) {
        val animation = completionAnimation ?: return@LaunchedEffect
        if (settings.reducedMotion) {
            player = animation.toPlayer
            hudRewardCue = null
            delay(120L)
        } else {
            // v300: a slower, clearer reward beat. The overlay visibly flies the
            // reward tokens toward the HUD while these two phases reveal the
            // matching HUD values. Progression notices still follow afterwards.
            val total = missionCompletionAnimationDurationMillis(animation).toLong()
            val xpPhase = (total * 0.52f).toLong()
            val coinPhase = total - xpPhase
            val frameDelay = 30L

            suspend fun animate(step: ProgressionVisualStep, cue: String, duration: Long) {
                hudRewardCue = HudRewardCue(step, cue)
                val frames = (duration / frameDelay).toInt().coerceAtLeast(1)
                for (frame in 1..frames) {
                    player = interpolateProgressionStep(
                        base = player,
                        from = animation.fromPlayer,
                        to = animation.toPlayer,
                        step = step,
                        fraction = frame.toFloat() / frames.toFloat()
                    )
                    delay(frameDelay)
                }
            }

            player = animation.fromPlayer
            if (animation.xpGain > 0 || animation.fromPlayer.level != animation.toPlayer.level) {
                animate(
                    ProgressionVisualStep.Xp,
                    if (animation.xpGain > 0) "+${formatNumber(animation.xpGain)} XP" else "XP",
                    xpPhase
                )
            } else {
                delay(xpPhase)
            }
            if (animation.coinGain != 0) {
                animate(
                    ProgressionVisualStep.Coins,
                    "${if (animation.coinGain > 0) "+" else ""}${formatNumber(animation.coinGain)} Coins",
                    coinPhase
                )
            } else {
                delay(coinPhase)
            }
        }

        player = animation.toPlayer
        hudRewardCue = null
        completionAnimation = null
        enqueueProgressionNotices(animation.levelUp, animation.rankUp, animation.toPlayer)
        // Stage 50: Done follows the same closed loop as Fail/Defer. The reward
        // animation finishes first, then the user lands back in Mission Tower.
        showMissions = true
        requestedMissionNonce += 1
    }

    GamifyTheme {
        Box(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    if (screen == AppScreen.Home) {
                        GameBottomNavigation(
                            selected = tab,
                            onSelect = { i ->
                                tab = i
                                if (i == 0) {
                                    var next = motivationalQuotes.indices.random()
                                    if (motivationalQuotes.size > 1) {
                                        while (next == quoteIndex) next = motivationalQuotes.indices.random()
                                    }
                                    quoteIndex = next
                                    focusRunningMissionCard()
                                }
                            }
                        )
                    }
                }
            ) { pad ->
                when (screen) {
                    AppScreen.Mission -> {
                        val mission = activeMission ?: recoverActiveTimer(context)?.mission ?: missions.firstOrNull() ?: defaultMission()
                        MissionExecutionScreen(
                            mission = mission,
                            player = player,
                            settings = settings,
                            onExit = {
                                screen = AppScreen.Home
                                tab = 0
                                focusRunningMissionCard()
                            },
                            onResult = { result, focusSeconds ->
                                completeMission(result, focusSeconds)
                            },
                            modifier = Modifier.padding(top = pad.calculateTopPadding())
                        )
                    }
                    AppScreen.Home -> {
                        if (showMissions) {
                            // v299: Mission Tower is a child surface of Home. Hardware/system Back
                            // returns to Home instead of falling through to Activity exit.
                            BackHandler { showMissions = false }
                            MissionTowerScreen(
                                player = player,
                                hudRewardCue = hudRewardCue,
                                missions = missions,
                                history = history,
                                activeTimer = recoverActiveTimer(context),
                                focusMissionIndex = requestedMissionIndex,
                                focusRequest = requestedMissionNonce,
                                onStart = { mission ->
                                    val needsNotificationPermission = settings.notificationsEnabled &&
                                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                    if (needsNotificationPermission) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    val running = recoverActiveTimer(context)
                                    val sameRunningMission = running != null && (
                                        (mission.id.isNotBlank() && running.mission.id == mission.id) ||
                                            (mission.id.isBlank() && running.mission.title == mission.title)
                                        )
                                    if (running != null && !sameRunningMission && remainingSeconds(context, running) > 0) {
                                        missionStartConflict = running
                                    } else {
                                        val timerForMusic = if (!sameRunningMission) beginActiveTimer(context, mission, settings) else running
                                        MissionMusicController.ensureForTimer(context, settings, timerForMusic)
                                        activeMission = mission
                                        showMissions = false
                                        screen = AppScreen.Mission
                                        tab = 0
                                    }
                                },
                                onCreateMission = { position, mission ->
                                    val normalized = normalizeMissionIdentities(listOf(mission)).first()
                                    missions.add(position.coerceIn(0, missions.size), normalized)
                                    saveMissions(context, missions)
                                },
                                onEditMission = { position, updated ->
                                    val oldIndex = missions.indexOfFirst { it.id == updated.id && updated.id.isNotBlank() }
                                        .takeIf { it >= 0 } ?: missions.indexOfFirst { it.title == updated.title }
                                    if (oldIndex >= 0) missions.removeAt(oldIndex)
                                    missions.add(position.coerceIn(0, missions.size), updated)
                                    saveMissions(context, missions)
                                },
                                onDeleteMission = { index ->
                                    if (index in missions.indices) { missions.removeAt(index); saveMissions(context, missions) }
                                },
                                onHome = { showMissions = false },
                                modifier = Modifier.padding(top = pad.calculateTopPadding())
                            )
                        } else when (tab) {
                            0 -> {
                                GameHome(
                                    player = player,
                                    hudRewardCue = hudRewardCue,
                                    missions = missions,
                                    settings = settings,
                                    onOpenDreamboard = { showDreamboard = true },
                                    onOpenTree = { showTree = true },
                                    onOpenTimeSheet = { showTimeSheet = true },
                                    onOpenShop = { showShop = true },
                                    onOpenWorldMap = { showWorldMap = true },
                                    onOpenMissions = { showMissions = true },
                                    history = history,
                                    modifier = Modifier.padding(top = pad.calculateTopPadding())
                                )
                            }
                            1 -> {
                                StatsScreen(
                                    player = player,
                                    history = history,
                                    settings = settings,
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                            2 -> {
                                SettingsScreen(
                                    settings = settings,
                                    onSettingsChange = { updated ->
                                        settings = updated
                                        saveSettings(context, updated)
                                        MissionMusicController.ensureForTimer(context, updated, recoverActiveTimer(context))
                                        val anyNotificationEnabled = updated.notificationsEnabled || updated.treeStatsReminderEnabled
                                        val needsPermission = anyNotificationEnabled &&
                                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                        if (needsPermission) {
                                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            synchronizeScheduledAlarms(context, updated)
                                            scheduleTreeStatsReminder(context)
                                        }
                                    },
                                    onDataRestored = {
                                        player = loadPlayer(context)
                                        settings = loadSettings(context)
                                        missions.clear(); missions.addAll(loadMissions(context))
                                        history.clear(); history.addAll(loadHistory(context))
                                        personalRewards.clear(); personalRewards.addAll(loadPersonalRewards(context))
                                        rewardRedemptions.clear(); rewardRedemptions.addAll(loadRewardRedemptions(context))
                                        claimedAchievements.clear(); claimedAchievements.addAll(loadStringSet(context, KEY_ACHIEVEMENT_CLAIMS))
                                        showcasedAchievements.clear(); showcasedAchievements.addAll(loadStringSet(context, KEY_ACHIEVEMENT_SHOWCASE).take(3))
                                        notifications.clear(); notifications.addAll(loadNotifications(context))
                                        onboardingComplete = isOnboardingComplete(context)
                                        activeMission = null
                                        completionAnimation = null
                                        hudRewardCue = null
                                        progressionNotice = null
                                        while (progressionNoticeChannel.tryReceive().isSuccess) { }
                                        tab = 0
                                        screen = AppScreen.Home
                                        synchronizeScheduledAlarms(context, settings)
                                        scheduleTreeStatsReminder(context)
                                    },
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                            else -> {
                                ProfileProgressScreen(
                                    player = player,
                                    history = history,
                                    settings = settings,
                                    claimedAchievements = claimedAchievements.toSet(),
                                    showcasedAchievementIds = showcasedAchievements.toList(),
                                    onToggleShowcase = { achievement ->
                                        if (achievement.progress >= achievement.goal) {
                                            if (achievement.id in showcasedAchievements) showcasedAchievements.remove(achievement.id)
                                            else if (showcasedAchievements.size < 3) showcasedAchievements.add(achievement.id)
                                            saveStringSet(context, KEY_ACHIEVEMENT_SHOWCASE, showcasedAchievements.toSet())
                                        }
                                    },
                                    onClaimAchievement = { achievement ->
                                        if (achievement.id !in claimedAchievements && achievement.progress >= achievement.goal) {
                                            claimedAchievements.add(achievement.id)
                                            saveStringSet(context, KEY_ACHIEVEMENT_CLAIMS, claimedAchievements.toSet())
                                            val (updated, event) = applyBonusReward(player, achievement.xpReward, achievement.coinReward)
                                            player = updated
                                            savePlayer(context, player)
                                            enqueueProgressionNotices(event, null, updated)
                                        }
                                    },
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                        }
                    }
                }
            }

            completionAnimation?.let { animation ->
                MissionCompletionFlight(
                    mission = animation.mission,
                    xpGain = animation.xpGain,
                    coinGain = animation.coinGain,
                    reducedMotion = settings.reducedMotion,
                    durationMillis = missionCompletionAnimationDurationMillis(animation),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(start = 20.dp, end = 20.dp, bottom = 150.dp)
                )
            }

            terminalAnimation?.let { animation ->
                MissionTerminalTransition(
                    mission = animation.mission,
                    result = animation.result,
                    reducedMotion = settings.reducedMotion,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(start = 20.dp, end = 20.dp, bottom = 150.dp)
                )
            }

            progressionNotice?.let { notice ->
                ProgressionNoticeOverlay(
                    notice = notice,
                    reducedMotion = settings.reducedMotion,
                    onContinue = { progressionNotice = null },
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 70.dp)
                )
            }
            achievementUnlockNotice?.let { achievement ->
                AchievementUnlockToast(
                    achievement = achievement,
                    reducedMotion = settings.reducedMotion,
                    onDismiss = { achievementUnlockNotice = null },
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 76.dp)
                )
            }
            masteryNotice?.let { category ->
                AchievementMasteryCelebration(
                    category = category,
                    reducedMotion = settings.reducedMotion,
                    onDismiss = { masteryNotice = null },
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 72.dp)
                )
            }
            if (showShop) {
                ShopDialog(
                    player = player,
                    rewards = personalRewards,
                    redemptions = rewardRedemptions,
                    onAdd = { reward ->
                        val updated = RewardEngine.upsertAtPosition(personalRewards, reward)
                        personalRewards.clear()
                        personalRewards.addAll(updated)
                        savePersonalRewards(context, updated)
                    },
                    onUpdate = { _, reward ->
                        val updated = RewardEngine.upsertAtPosition(personalRewards, reward)
                        personalRewards.clear()
                        personalRewards.addAll(updated)
                        savePersonalRewards(context, updated)
                    },
                    onDelete = { index ->
                        personalRewards.getOrNull(index)?.let { removed ->
                            val updated = RewardEngine.removeAndNormalize(personalRewards, removed.id)
                            personalRewards.clear()
                            personalRewards.addAll(updated)
                            savePersonalRewards(context, updated)
                        }
                    },
                    onRedeem = { _, reward ->
                        val commit = redeemPersonalReward(context, reward.id)
                        if (commit.status == RewardRedemptionStatus.Success) {
                            player = commit.player
                            personalRewards.clear()
                            personalRewards.addAll(commit.rewards)
                            commit.entry?.let { entry ->
                                rewardRedemptions.removeAll { it.transactionId == entry.transactionId }
                                rewardRedemptions.add(0, entry)
                                while (rewardRedemptions.size > 500) rewardRedemptions.removeAt(rewardRedemptions.lastIndex)
                            }
                        }
                        commit.status
                    },
                    onDismiss = { showShop = false }
                )
            }
            if (showDreamboard) {
                DreamboardDialog(
                    player = player,
                    dreams = dreamItems,
                    missions = missions,
                    history = history,
                    onAdd = { dream ->
                        val updated = DreamboardEngine.insert(dreamItems, dream)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                    },
                    onUpdate = { dream ->
                        val previous = dreamItems.firstOrNull { it.id == dream.id }
                        val updated = DreamboardEngine.update(dreamItems, dream)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                        previous?.imageUri
                            ?.takeIf { it.isNotBlank() && it != dream.imageUri }
                            ?.let { deleteOwnedDreamImageIfUnused(context, it, updated) }
                    },
                    onClaimGoalReward = { dream, xpReward, coinReward ->
                        val currentDream = dreamItems.firstOrNull { it.id == dream.id }
                        if (currentDream == null || currentDream.goalRewardClaimed) {
                            false
                        } else {
                            val updatedDream = currentDream.copy(goalRewardClaimed = true, achievedAtMillis = System.currentTimeMillis())
                            val updatedDreams = DreamboardEngine.update(dreamItems, updatedDream)
                            dreamItems.clear()
                            dreamItems.addAll(updatedDreams)
                            saveDreamItems(context, updatedDreams)
                            val (updatedPlayer, event) = applyBonusReward(player, xpReward, coinReward)
                            player = updatedPlayer
                            savePlayer(context, updatedPlayer)
                            enqueueProgressionNotices(event, null, updatedPlayer)
                            true
                        }
                    },
                    onDelete = { dreamId ->
                        val previous = dreamItems.firstOrNull { it.id == dreamId }
                        val updated = DreamboardEngine.remove(dreamItems, dreamId)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                        previous?.imageUri
                            ?.takeIf { it.isNotBlank() }
                            ?.let { deleteOwnedDreamImageIfUnused(context, it, updated) }
                    },
                    onDismiss = { showDreamboard = false },
                    onHome = { showDreamboard = false; screen = AppScreen.Home; tab = 0 }
                )
            }
            if (showTree) {
                // v311: Keep the established genealogy/tree module as the only Tree UI.
                // The established genealogy/tree module is the only Tree data source and UI.
                LegacyTreeDialog(
                    onDismiss = { showTree = false }
                )
            }
            if (showTimeSheet) {
                TimeSheetDialog(
                    player = player,
                    onDismiss = { showTimeSheet = false },
                    onHome = { showTimeSheet = false; screen = AppScreen.Home; tab = 0 },
                    onLaunchMission = { mission ->
                        val needsNotificationPermission = settings.notificationsEnabled &&
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        if (needsNotificationPermission) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        val running = recoverActiveTimer(context)
                        val sameRunningMission = running != null && (
                            (mission.id.isNotBlank() && running.mission.id == mission.id) ||
                                (mission.id.isBlank() && running.mission.title == mission.title)
                            )
                        if (running != null && !sameRunningMission && remainingSeconds(context, running) > 0) {
                            missionStartConflict = running
                        } else {
                            val timerForMusic = if (!sameRunningMission) beginActiveTimer(context, mission, settings) else running
                            MissionMusicController.ensureForTimer(context, settings, timerForMusic)
                            activeMission = mission
                            showTimeSheet = false
                            showMissions = false
                            screen = AppScreen.Mission
                            tab = 0
                        }
                    }
                )
            }
            missionStartConflict?.let { running ->
                ActiveMissionConflictDialog(
                    runningMission = running.mission,
                    vibrationEnabled = settings.vibrationEnabled,
                    onContinue = {
                        activeMission = running.mission
                        showMissions = false
                        screen = AppScreen.Mission
                        tab = 0
                        missionStartConflict = null
                    },
                    onDismiss = { missionStartConflict = null }
                )
            }

            if (showWorldMap) {
                WorldProgressDialog(player = player, onDismiss = { showWorldMap = false })
            }
        }
    }
}

@Composable
private fun ActiveMissionConflictDialog(
    runningMission: Mission,
    vibrationEnabled: Boolean,
    onContinue: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    LaunchedEffect(runningMission.id, runningMission.title, vibrationEnabled) {
        if (vibrationEnabled) playConflictDialogVibration(context)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xF20B1520),
        shape = RoundedCornerShape(26.dp),
        title = {
            Text(
                "ماموریت در حال اجرا",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0x26151F2A),
                shape = RoundedCornerShape(15.dp),
                border = BorderStroke(1.dp, Color(0x55F7C948))
            ) {
                Text(
                    runningMission.title,
                    color = GoldSoft,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onContinue) {
                Text("Continue Mission", color = Gold, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("لغو", color = TextSoft)
            }
        }
    )
}

private fun playConflictDialogVibration(context: Context) {
    val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java).defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    if (!vibrator.hasVibrator()) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 40, 45, 55), -1))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(120L)
    }
}


// Stage 48: distinct tactile confirmation for terminal mission actions.
// Done feels crisp, Defer is a soft double pulse, and Fail is a firmer warning.
private fun playMissionResultVibration(context: Context, result: MissionResult) {
    val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java).defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    if (!vibrator.hasVibrator()) return
    val pattern = when (result) {
        MissionResult.Done -> longArrayOf(0, 28, 34, 42)
        MissionResult.Defer -> longArrayOf(0, 20, 45, 20)
        MissionResult.Fail -> longArrayOf(0, 55, 30, 70)
        MissionResult.Partial -> longArrayOf(0, 24)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(pattern, -1)
    }
}

@Composable
private fun MissionExecutionScreen(
    mission: Mission,
    player: PlayerState,
    settings: GameSettings,
    onExit: () -> Unit,
    onResult: (MissionResult, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current.applicationContext
    var timerState by remember(mission) {
        mutableStateOf(
            recoverActiveTimer(context)?.takeIf { state ->
                val sameId = state.mission.id.isNotBlank() && state.mission.id == mission.id
                sameId || (state.mission.id.isBlank() && state.mission.title == mission.title)
            } ?: beginActiveTimer(context, mission, settings)
        )
    }
    var remaining by remember(mission) { mutableIntStateOf(remainingSeconds(context, timerState)) }
    var choosingResult by remember(mission) { mutableStateOf(remaining <= 0) }
    var resultSubmitted by remember(timerState.sessionId) { mutableStateOf(false) }
    var missionMusicMuted by remember(timerState.sessionId) {
        mutableStateOf(MissionMusicController.isMuted(timerState.sessionId))
    }
    val executionSubtasks = remember(timerState.sessionId) {
        mutableStateListOf<String>().also { it.addAll(timerState.mission.subtasks) }
    }
    val checkedSubtasks = remember(timerState.sessionId) {
        mutableStateListOf<Boolean>().also { list ->
            executionSubtasks.indices.forEach { index ->
                list.add(timerState.checkedSubtasks.getOrElse(index) { false })
            }
        }
    }
    var newExecutionSubtask by remember(timerState.sessionId) { mutableStateOf("") }

    fun persistSubtaskState() {
        val updated = timerState.copy(
            mission = timerState.mission.copy(subtasks = executionSubtasks.toList()),
            checkedSubtasks = checkedSubtasks.toList()
        )
        timerState = updated
        saveActiveTimer(context, updated)
        saveMissionSubtaskChecks(context, updated.mission, updated.checkedSubtasks)
    }

    fun persistTimer(state: ActiveTimerState) {
        timerState = state
        remaining = remainingSeconds(context, state)
        saveActiveTimer(context, state)
        if (state.isRunning) scheduleTimerAlarm(context, state, settings) else cancelTimerAlarm(context)
    }

    // Leaving the mission screen must never pause or reset a running mission.
    // Persist the live countdown snapshot while preserving the original running
    // deadlines, then keep the finish alarm scheduled in the background.
    fun leaveMission() {
        val liveRemaining = remainingSeconds(context, timerState)
        val snapshot = timerState.copy(remainingSeconds = liveRemaining)
        timerState = snapshot
        remaining = liveRemaining
        saveActiveTimer(context, snapshot)
        if (snapshot.isRunning && liveRemaining > 0) {
            scheduleTimerAlarm(context, snapshot, settings)
        } else if (!snapshot.isRunning) {
            cancelTimerAlarm(context)
        }
        onExit()
    }

    BackHandler { leaveMission() }

    LaunchedEffect(timerState.isRunning, timerState.endAtMillis, choosingResult) {
        if (choosingResult || !timerState.isRunning) {
            remaining = remainingSeconds(context, timerState)
            return@LaunchedEffect
        }
        while (timerState.isRunning && !choosingResult) {
            val nowRemaining = remainingSeconds(context, timerState)
            remaining = nowRemaining
            if (nowRemaining <= 0) {
                // Use the same receiver path as AlarmManager so timer expiry also
                // posts the actionable notification while the app is foreground.
                TimerFinishReceiver.finishTimer(context, timerState.sessionId, notify = true)
                val ended = loadActiveTimer(context) ?: timerState.copy(
                    remainingSeconds = 0,
                    endAtMillis = 0L,
                    isRunning = false,
                    endAtElapsedRealtime = 0L,
                    bootCount = -1
                )
                timerState = ended
                remaining = 0
                choosingResult = true
                break
            }
            delay(250L)
        }
    }

    val totalSeconds = (mission.durationMinutes * 60).coerceAtLeast(1)
    val focusedSeconds = (totalSeconds - remaining).coerceIn(0, totalSeconds)
    val minutes = remaining / 60
    val seconds = remaining % 60
    val timerText = String.format(Locale.US, "%02d:%02d", minutes, seconds)
    val progress = remaining.toFloat() / totalSeconds.toFloat()
    val nextCombo = player.combo + 1
    // Done #5 activates Combo immediately, so the fifth successful mission is boosted.
    val boost = comboMultiplier(nextCombo)
    val previewXp = (mission.xpReward * boost).toInt()
    val previewCoins = (mission.coinReward * boost).toInt()
    val completedSubtasks = checkedSubtasks.count { it }
    val allSubtasksDone = executionSubtasks.isNotEmpty() && completedSubtasks == executionSubtasks.size
    val compactExecution = gamifyCompactScreen()
    val executionHorizontalPadding = if (compactExecution) GamifySpacing.Md else 22.dp
    val executionVerticalPadding = if (compactExecution) GamifySpacing.Md else 18.dp
    val timerDiameter = if (compactExecution) 214.dp else 226.dp
    val executionDensity = LocalDensity.current
    val missionImeOffset = with(executionDensity) { WindowInsets.ime.getBottom(this).toDp() }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xD80A1018), Color(0xE80A1018), Color(0xF40A1018))))
        )
        InternalGameBackdrop(strength = 0.42f)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = executionHorizontalPadding, vertical = executionVerticalPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameHud(player = player)
            Spacer(Modifier.height(if (compactExecution) 6.dp else 10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "‹ Back",
                    color = GoldSoft,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { leaveMission() }.padding(8.dp)
                )
                Text("MISSION", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Surface(
                    modifier = Modifier
                        .size(42.dp)
                        .clickable(enabled = settings.soundEnabled) {
                            missionMusicMuted = !missionMusicMuted
                            MissionMusicController.setMuted(
                                context = context,
                                settings = settings,
                                state = timerState,
                                muted = missionMusicMuted
                            )
                        },
                    shape = CircleShape,
                    color = Color(0x8A111A24),
                    border = BorderStroke(1.dp, if (missionMusicMuted || !settings.soundEnabled) Color(0x665F6D7C) else Gold.copy(alpha = 0.72f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            if (missionMusicMuted || !settings.soundEnabled) "🔇" else "🔊",
                            fontSize = 18.sp,
                            color = if (settings.soundEnabled) Color.White else TextSoft
                        )
                    }
                }
            }

            Spacer(Modifier.height(if (compactExecution) 10.dp else 18.dp))
            Text(
                mission.title,
                color = Color.White,
                fontSize = if (compactExecution) 21.sp else 25.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(9.dp))
            Text(
                if (boost > 1f) "+$previewXp XP   •   +$previewCoins Coins   •   Combo x${String.format(Locale.US, "%.2g", boost)}"
                else "+${mission.xpReward} XP   •   +${mission.coinReward} Coins",
                color = GoldSoft,
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(if (compactExecution) 8.dp else 12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xB8151D27),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x445F6D7C))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            if (allSubtasksDone) "$completedSubtasks/${executionSubtasks.size} • READY" else "$completedSubtasks/${executionSubtasks.size}",
                            color = if (allSubtasksDone) Color(0xFF86EFAC) else TextSoft,
                            fontSize = 8.sp,
                            fontWeight = if (allSubtasksDone) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    if (executionSubtasks.isNotEmpty()) {
                        Spacer(Modifier.height(3.dp))
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = if (compactExecution) 90.dp else 112.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            itemsIndexed(executionSubtasks) { index, subtask ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        "×",
                                        color = Color(0xFFFF8C8C),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable {
                                            executionSubtasks.removeAt(index)
                                            checkedSubtasks.removeAt(index)
                                            persistSubtaskState()
                                        }.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                    Text(
                                        subtask,
                                        color = if (checkedSubtasks[index]) Color(0xFF91A09B) else Color.White,
                                        fontSize = 11.sp,
                                        textDecoration = if (checkedSubtasks[index]) TextDecoration.LineThrough else TextDecoration.None,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Surface(
                                        modifier = Modifier.size(22.dp).clickable {
                                            checkedSubtasks[index] = !checkedSubtasks[index]
                                            persistSubtaskState()
                                        },
                                        color = if (checkedSubtasks[index]) Color(0xFF2F8D61) else Color(0xFF202B37),
                                        shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, if (checkedSubtasks[index]) Color(0xFF86EFAC) else Color(0xFF5C6876))
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            if (checkedSubtasks[index]) Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CompactSubtaskField(
                            value = newExecutionSubtask,
                            onValueChange = { newExecutionSubtask = it.take(120) },
                            onDone = {
                                val clean = newExecutionSubtask.trim()
                                if (clean.isNotEmpty()) {
                                    executionSubtasks.add(clean)
                                    checkedSubtasks.add(false)
                                    newExecutionSubtask = ""
                                    persistSubtaskState()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            modifier = Modifier.size(42.dp).clickable {
                                val clean = newExecutionSubtask.trim()
                                if (clean.isNotEmpty()) {
                                    executionSubtasks.add(clean)
                                    checkedSubtasks.add(false)
                                    newExecutionSubtask = ""
                                    persistSubtaskState()
                                }
                            },
                            color = Color(0x33F7C948),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Gold.copy(alpha = 0.65f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("+", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .requiredSize(timerDiameter)
                    .offset(y = missionImeOffset)
                    .clickable(enabled = !choosingResult) {
                        if (timerState.isRunning) {
                            val nowRemaining = remainingSeconds(context, timerState)
                            persistTimer(
                                timerState.copy(
                                    remainingSeconds = nowRemaining,
                                    endAtMillis = 0L,
                                    isRunning = false,
                                    endAtElapsedRealtime = 0L,
                                    bootCount = -1
                                )
                            )
                        } else {
                            val safeRemaining = remaining.coerceAtLeast(1)
                            persistTimer(
                                withRunningTimerDeadline(context, timerState, safeRemaining)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 9.dp.toPx()
                    drawCircle(color = Color(0x55000000), radius = size.minDimension * 0.45f)
                    drawCircle(
                        color = Color(0xFF28313D),
                        radius = size.minDimension * 0.45f,
                        style = Stroke(width = stroke)
                    )
                    val ringDiameter = size.minDimension * 0.90f
                    val ringLeft = (size.width - ringDiameter) / 2f
                    val ringTop = (size.height - ringDiameter) / 2f
                    drawArc(
                        brush = Brush.sweepGradient(listOf(GoldSoft, Gold, Color(0xFFE7A91C), GoldSoft)),
                        startAngle = -90f,
                        sweepAngle = 360f * progress,
                        useCenter = false,
                        topLeft = Offset(ringLeft, ringTop),
                        size = Size(ringDiameter, ringDiameter),
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(timerText, color = GamifyColors.TextPrimary, fontSize = if (compactExecution) 37.sp else 42.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        when {
                            choosingResult -> "COMPLETE"
                            timerState.isRunning -> "FOCUS"
                            else -> "PAUSED"
                        },
                        color = GoldSoft,
                        fontSize = 10.sp,
                        letterSpacing = 1.7.sp
                    )
                    if (!choosingResult) {
                        Spacer(Modifier.height(4.dp))
                        Text("${formatFocusTime(focusedSeconds)} focused", color = TextSoft, fontSize = 8.5.sp)
                    }
                }
            }

            Spacer(Modifier.height(if (compactExecution) 8.dp else 11.dp))

            Text(
                if (choosingResult) "زمان تمام شده؛ نتیجه مأموریت را ثبت کن" else "هر زمان نتیجه مشخص شد، می‌توانی مأموریت را ثبت کنی",
                color = if (choosingResult) GoldSoft else TextSoft,
                fontSize = 9.5.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = missionImeOffset)
                    .padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = missionImeOffset),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MissionResultAction(
                    glyph = "×",
                    label = "انجام نشد",
                    accent = Color(0xFFFF7278),
                    border = Color(0x88E36E73),
                    enabled = !resultSubmitted,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        resultSubmitted = true
                        playMissionResultVibration(context, MissionResult.Fail)
                        onResult(MissionResult.Fail, focusedSeconds)
                    }
                )
                MissionResultAction(
                    glyph = "↻",
                    label = "بعداً",
                    accent = Gold,
                    border = Color(0x66F1D487),
                    enabled = !resultSubmitted,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        resultSubmitted = true
                        playMissionResultVibration(context, MissionResult.Defer)
                        onResult(MissionResult.Defer, focusedSeconds)
                    }
                )
                MissionResultAction(
                    glyph = "✓",
                    label = "انجام شد",
                    accent = Color(0xFF86EFAC),
                    border = Color(0x7786EFAC),
                    enabled = !resultSubmitted,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        resultSubmitted = true
                        playMissionResultVibration(context, MissionResult.Done)
                        onResult(MissionResult.Done, focusedSeconds)
                    }
                )
            }
        }
    }
}

@Composable
private fun MissionResultAction(
    glyph: String,
    label: String,
    accent: Color,
    border: Color,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(58.dp)
            .clickable(enabled = enabled, onClick = onClick),
        color = Color(0xC0151B24),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (enabled) border else Color(0x335F6D7C))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(glyph, color = if (enabled) accent else TextSoft, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(1.dp))
            Text(label, color = if (enabled) Color.White else TextSoft, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}


private fun formatFocusTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val secs = safe % 60
    return when {
        hours > 0 -> String.format(Locale.US, "%dh %02dm", hours, minutes)
        minutes > 0 -> String.format(Locale.US, "%dm %02ds", minutes, secs)
        else -> String.format(Locale.US, "%ds", secs)
    }
}

private fun historyResultColor(result: MissionResult): Color = when (result) {
    MissionResult.Done -> Gold
    MissionResult.Partial -> Blue
    MissionResult.Fail -> Color(0xFFE67B7B)
    MissionResult.Defer -> Color(0xFFAAB3C0)
}

@Composable
private fun WeeklyComparisonRow(
    label: String,
    current: Long,
    previous: Long,
    currentText: String,
    previousText: String
) {
    val delta = current - previous
    val percent = when {
        previous > 0L -> ((delta.toDouble() / previous.toDouble()) * 100.0).toInt()
        current > 0L -> 100
        else -> 0
    }
    val trend = when {
        delta > 0L -> "▲ +${percent}%"
        delta < 0L -> "▼ ${percent}%"
        else -> "— 0%"
    }
    val trendColor = when {
        delta > 0L -> Color(0xFF77D49B)
        delta < 0L -> Color(0xFFE67B7B)
        else -> TextSoft
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("هفته قبل: $previousText", color = TextSoft, fontSize = 9.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(currentText, color = GoldSoft, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Text(trend, color = trendColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class AnalyticsDashboardSummary(
    val todayXp: Int,
    val todayFocusSeconds: Int,
    val todayDone: Int,
    val thirtyDayDone: Int,
    val thirtyDaySuccessRate: Int,
    val thirtyDayActiveDays: Int,
    val thirtyDayFocusSeconds: Int
)

private fun buildAnalyticsDashboardSummary(
    history: List<MissionHistoryEntry>,
    entriesByMissionDay: Map<LocalDate, List<MissionHistoryEntry>>,
    today: LocalDate
): AnalyticsDashboardSummary {
    val todayEntries = entriesByMissionDay[today].orEmpty()
    val recentDays = (0L..29L).map { today.minusDays(it) }.toSet()
    val recentEntries = recentDays.flatMap { entriesByMissionDay[it].orEmpty() }
    val done = recentEntries.count { it.result == MissionResult.Done }
    val resolved = recentEntries.count { it.result == MissionResult.Done || it.result == MissionResult.Fail }
    return AnalyticsDashboardSummary(
        todayXp = todayEntries.sumOf { it.xpEarned },
        todayFocusSeconds = todayEntries.sumOf { it.focusSeconds },
        todayDone = todayEntries.count { it.result == MissionResult.Done },
        thirtyDayDone = done,
        thirtyDaySuccessRate = if (resolved == 0) 0 else done * 100 / resolved,
        thirtyDayActiveDays = recentDays.count { entriesByMissionDay[it].orEmpty().isNotEmpty() },
        thirtyDayFocusSeconds = recentEntries.sumOf { it.focusSeconds }
    )
}

@Composable
private fun StatsScreen(
    player: PlayerState,
    history: List<MissionHistoryEntry>,
    settings: GameSettings,
    modifier: Modifier = Modifier
) {
    val zoneId = ZoneId.systemDefault()
    val context = LocalContext.current
    // Stage 80: daily stats use the same configured work-day boundary as Missions.
    val today = currentMissionDay(context)
    // Stage 110: one canonical day-index powers the analytics dashboard and its headline KPIs.
    val entriesByMissionDay = remember(history, today) { history.groupBy { it.missionDay(context) } }
    val analyticsSummary = remember(history, today, entriesByMissionDay) {
        buildAnalyticsDashboardSummary(history, entriesByMissionDay, today)
    }
    val todayEntries = entriesByMissionDay[today].orEmpty()
    val todayXp = analyticsSummary.todayXp
    val todayFocus = analyticsSummary.todayFocusSeconds
    val todayDone = analyticsSummary.todayDone
    val recordedXp = history.sumOf { it.xpEarned }
    val recordedCoins = history.sumOf { it.coinsEarned }
    val totalFocus = history.sumOf { it.focusSeconds }
    val totalDone = history.count { it.result == MissionResult.Done }
    val lastSevenDays = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val focusByDay = lastSevenDays.map { day ->
        history.asSequence()
            .filter { it.missionDay(context) == day }
            .sumOf { it.focusSeconds } / 60
    }
    // Stage 101: analytics projection for recent consistency and productivity trends.
    val lastThirtyDays = (29 downTo 0).map { today.minusDays(it.toLong()) }
    val thirtyDayEntries = lastThirtyDays.flatMap { entriesByMissionDay[it].orEmpty() }
    val thirtyDayDone = analyticsSummary.thirtyDayDone
    val completionRate = analyticsSummary.thirtyDaySuccessRate
    val activeDays = analyticsSummary.thirtyDayActiveDays
    val thirtyDayFocus = analyticsSummary.thirtyDayFocusSeconds
    val averageFocusPerActiveDay = if (activeDays == 0) 0 else thirtyDayFocus / activeDays
    val sevenDayXp = lastSevenDays.map { day -> entriesByMissionDay[day].orEmpty().sumOf { it.xpEarned } }
    val sevenDayDone = lastSevenDays.map { day -> entriesByMissionDay[day].orEmpty().count { it.result == MissionResult.Done } }

    // Stage 102: Saturday-based weekly comparison, aligned with Challenges and the app work week.
    val thisWeekStart = saturdayWeekStart(today)
    val lastWeekStart = thisWeekStart.minusWeeks(1)
    val lastWeekEnd = thisWeekStart.minusDays(1)
    val thisWeekEntries = history.filter {
        val day = it.missionDay(context)
        !day.isBefore(thisWeekStart) && !day.isAfter(today)
    }
    val lastWeekEntries = history.filter {
        val day = it.missionDay(context)
        !day.isBefore(lastWeekStart) && !day.isAfter(lastWeekEnd)
    }
    val thisWeekDone = thisWeekEntries.count { it.result == MissionResult.Done }
    val lastWeekDone = lastWeekEntries.count { it.result == MissionResult.Done }
    val thisWeekFocus = thisWeekEntries.sumOf { it.focusSeconds }
    val lastWeekFocus = lastWeekEntries.sumOf { it.focusSeconds }
    val thisWeekXp = thisWeekEntries.sumOf { it.xpEarned }
    val lastWeekXp = lastWeekEntries.sumOf { it.xpEarned }

    // Stage 103: Jalali month comparison. Current month is month-to-date; previous month is complete.
    val todayJalali = gregorianToJalali(today)
    val currentMonthStart = jalaliToGregorian(JalaliDate(todayJalali.year, todayJalali.month, 1))
    val previousMonthJalali = if (todayJalali.month > 1) {
        JalaliDate(todayJalali.year, todayJalali.month - 1, 1)
    } else {
        JalaliDate(todayJalali.year - 1, 12, 1)
    }
    val previousMonthStart = jalaliToGregorian(previousMonthJalali)
    val previousMonthEnd = currentMonthStart.minusDays(1)
    val currentMonthEntries = history.filter {
        val day = it.missionDay(context)
        !day.isBefore(currentMonthStart) && !day.isAfter(today)
    }
    val previousMonthEntries = history.filter {
        val day = it.missionDay(context)
        !day.isBefore(previousMonthStart) && !day.isAfter(previousMonthEnd)
    }
    val currentMonthDone = currentMonthEntries.count { it.result == MissionResult.Done }
    val previousMonthDone = previousMonthEntries.count { it.result == MissionResult.Done }
    val currentMonthFocus = currentMonthEntries.sumOf { it.focusSeconds }
    val previousMonthFocus = previousMonthEntries.sumOf { it.focusSeconds }
    val currentMonthXp = currentMonthEntries.sumOf { it.xpEarned }
    val previousMonthXp = previousMonthEntries.sumOf { it.xpEarned }
    val currentMonthActiveDays = (currentMonthStart.toEpochDay()..today.toEpochDay()).count { epoch ->
        entriesByMissionDay[LocalDate.ofEpochDay(epoch)].orEmpty().isNotEmpty()
    }
    val previousMonthActiveDays = (previousMonthStart.toEpochDay()..previousMonthEnd.toEpochDay()).count { epoch ->
        entriesByMissionDay[LocalDate.ofEpochDay(epoch)].orEmpty().isNotEmpty()
    }
    val currentMonthLabel = jalaliMonthNames[todayJalali.month - 1]
    val previousMonthLabel = jalaliMonthNames[previousMonthJalali.month - 1]

    // Stage 104: personal performance records derived from canonical mission-day history.
    val dailyPerformance = remember(history, today) {
        entriesByMissionDay.mapValues { (_, entries) ->
            Triple(
                entries.count { it.result == MissionResult.Done },
                entries.sumOf { it.xpEarned },
                entries.sumOf { it.focusSeconds }
            )
        }
    }
    val bestDayRecord = dailyPerformance.entries.maxWithOrNull(
        compareBy<Map.Entry<LocalDate, Triple<Int, Int, Int>>> { it.value.first }
            .thenBy { it.value.second }
            .thenBy { it.value.third }
    )
    val highestDailyXpRecord = dailyPerformance.entries.maxByOrNull { it.value.second }
    val mostDoneDayRecord = dailyPerformance.entries.maxByOrNull { it.value.first }
    val highestDailyFocusRecord = dailyPerformance.entries.maxByOrNull { it.value.third }
    val weeklyPerformance = remember(history, today) {
        history.groupBy { entry ->
            val day = entry.missionDay(context)
            saturdayWeekStart(day)
        }.mapValues { (_, entries) ->
            Triple(
                entries.count { it.result == MissionResult.Done },
                entries.sumOf { it.xpEarned },
                entries.sumOf { it.focusSeconds }
            )
        }
    }
    val bestWeekRecord = weeklyPerformance.entries.maxWithOrNull(
        compareBy<Map.Entry<LocalDate, Triple<Int, Int, Int>>> { it.value.first }
            .thenBy { it.value.second }
            .thenBy { it.value.third }
    )
    fun analyticsJalaliLabel(day: LocalDate?): String {
        if (day == null) return "—"
        val j = gregorianToJalali(day)
        return String.format(Locale.US, "%04d/%02d/%02d", j.year, j.month, j.day)
    }

    // Stage 105: 12-week productivity heatmap using the canonical work-day boundary.
    val heatmapEnd = today
    val heatmapStart = heatmapEnd.minusDays(83)
    val heatmapDays = (0L..83L).map { heatmapStart.plusDays(it) }
    val heatmapActivity = heatmapDays.associateWith { day ->
        val entries = entriesByMissionDay[day].orEmpty()
        val done = entries.count { it.result == MissionResult.Done }
        val focusMinutes = entries.sumOf { it.focusSeconds } / 60
        done * 20 + focusMinutes
    }
    val heatmapMaxActivity = (heatmapActivity.values.maxOrNull() ?: 0).coerceAtLeast(1)
    val heatmapActiveDays = heatmapActivity.count { it.value > 0 }
    // Stage 106: interactive heatmap day inspection. Selection is UI-only and does not mutate history.
    var selectedHeatmapDay by remember(today) { mutableStateOf<LocalDate?>(null) }
    val selectedHeatmapEntries = selectedHeatmapDay?.let { entriesByMissionDay[it].orEmpty() }.orEmpty()
    val selectedHeatmapDone = selectedHeatmapEntries.count { it.result == MissionResult.Done }
    val selectedHeatmapResolved = selectedHeatmapEntries.count { it.result == MissionResult.Done || it.result == MissionResult.Fail }
    val selectedHeatmapSuccessRate = if (selectedHeatmapResolved == 0) 0 else selectedHeatmapDone * 100 / selectedHeatmapResolved
    val selectedHeatmapFocus = selectedHeatmapEntries.sumOf { it.focusSeconds }
    val selectedHeatmapXp = selectedHeatmapEntries.sumOf { it.xpEarned }

    // Stage 107: performance trends compare recent windows without changing progression data.
    data class TrendWindow(val done: Int, val focus: Int, val xp: Int)
    fun trendWindow(days: List<LocalDate>): TrendWindow {
        val entries = days.flatMap { entriesByMissionDay[it].orEmpty() }
        return TrendWindow(
            done = entries.count { it.result == MissionResult.Done },
            focus = entries.sumOf { it.focusSeconds },
            xp = entries.sumOf { it.xpEarned }
        )
    }
    val recent7 = trendWindow((6 downTo 0).map { today.minusDays(it.toLong()) })
    val previous7 = trendWindow((13 downTo 7).map { today.minusDays(it.toLong()) })
    val recent30 = trendWindow((29 downTo 0).map { today.minusDays(it.toLong()) })
    val previous30 = trendWindow((59 downTo 30).map { today.minusDays(it.toLong()) })

    // Stage 108: best-time analysis from actual local completion timestamps.
    // Focus is attributed to the hour/daypart in which the mission result was recorded.
    data class TimeBucket(val done: Int = 0, val focus: Int = 0, val xp: Int = 0)
    fun bucket(entries: List<MissionHistoryEntry>): TimeBucket = TimeBucket(
        done = entries.count { it.result == MissionResult.Done },
        focus = entries.sumOf { it.focusSeconds },
        xp = entries.sumOf { it.xpEarned }
    )
    val timedHistory = remember(history, zoneId) {
        history.map { it to Instant.ofEpochMilli(it.timestamp).atZone(zoneId).hour }
    }
    val hourlyBuckets = (0..23).associateWith { hour ->
        bucket(timedHistory.filter { it.second == hour }.map { it.first })
    }
    val bestMissionHour = hourlyBuckets.maxWithOrNull(
        compareBy<Map.Entry<Int, TimeBucket>> { it.value.done }.thenBy { it.value.focus }.thenBy { it.value.xp }
    )?.takeIf { it.value.done > 0 }
    val bestFocusHour = hourlyBuckets.maxWithOrNull(
        compareBy<Map.Entry<Int, TimeBucket>> { it.value.focus }.thenBy { it.value.done }.thenBy { it.value.xp }
    )?.takeIf { it.value.focus > 0 }
    data class DayPart(val title: String, val range: String, val hours: IntRange)
    val dayParts = listOf(
        DayPart("MORNING", "06–12", 6..11),
        DayPart("AFTERNOON", "12–18", 12..17),
        DayPart("EVENING", "18–24", 18..23),
        DayPart("NIGHT", "00–06", 0..5)
    )
    val dayPartBuckets = dayParts.map { part ->
        part to bucket(timedHistory.filter { it.second in part.hours }.map { it.first })
    }
    val bestDayPart = dayPartBuckets.maxWithOrNull(
        compareBy<Pair<DayPart, TimeBucket>> { it.second.done }.thenBy { it.second.focus }.thenBy { it.second.xp }
    )?.takeIf { it.second.done > 0 || it.second.focus > 0 }
    fun hourLabel(hour: Int?): String = hour?.let { String.format(Locale.US, "%02d:00–%02d:00", it, (it + 1) % 24) } ?: "—"


    // Stage 109: mission performance analysis grouped by stable mission id when available.
    data class MissionPerformance(
        val title: String,
        val done: Int,
        val resolved: Int,
        val focus: Int,
        val xp: Int
    ) {
        val successRate: Int get() = if (resolved == 0) 0 else done * 100 / resolved
    }
    val missionPerformance = remember(history) {
        history
            .groupBy { entry -> entry.missionId.takeIf { it.isNotBlank() } ?: "title:${entry.missionTitle}" }
            .values
            .map { entries ->
                MissionPerformance(
                    title = entries.lastOrNull()?.missionTitle?.takeIf { it.isNotBlank() } ?: "Mission",
                    done = entries.count { it.result == MissionResult.Done },
                    resolved = entries.count { it.result == MissionResult.Done || it.result == MissionResult.Fail },
                    focus = entries.sumOf { it.focusSeconds },
                    xp = entries.sumOf { it.xpEarned }
                )
            }
    }
    val bestMissionByDone = missionPerformance.maxWithOrNull(compareBy<MissionPerformance> { it.done }.thenBy { it.successRate }.thenBy { it.xp })?.takeIf { it.done > 0 }
    val bestMissionByFocus = missionPerformance.maxWithOrNull(compareBy<MissionPerformance> { it.focus }.thenBy { it.done })?.takeIf { it.focus > 0 }
    val bestMissionByXp = missionPerformance.maxWithOrNull(compareBy<MissionPerformance> { it.xp }.thenBy { it.done })?.takeIf { it.xp > 0 }
    val bestMissionBySuccess = missionPerformance
        .filter { it.resolved >= 2 }
        .maxWithOrNull(compareBy<MissionPerformance> { it.successRate }.thenBy { it.done }.thenBy { it.resolved })

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xE40A1119), Color(0xF00A1119), Color(0xFA080D14))
                    )
                )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TopGameHud(player = player, rewardCue = null)
                    Text(
                        "ANALYTICS",
                        color = Gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.2.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Mission، Focus، XP و روند ۳۰ روز اخیر در یک نگاه",
                        color = TextSoft,
                        fontSize = 12.sp
                    )
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("TODAY XP", "+${formatNumber(todayXp)}", "XP", Modifier.weight(1f))
                    StatMetricCard("FOCUS", formatFocusTime(todayFocus), "today", Modifier.weight(1f))
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("DONE", todayDone.toString(), "today", Modifier.weight(1f))
                    StatMetricCard("BEST COMBO", player.bestCombo.toString(), "record", Modifier.weight(1f))
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("30 DAY OVERVIEW", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard("SUCCESS RATE", "$completionRate%", "done / resolved", Modifier.weight(1f))
                            StatMetricCard("ACTIVE DAYS", "$activeDays / 30", "work days", Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard("AVG FOCUS", formatFocusTime(averageFocusPerActiveDay), "per active day", Modifier.weight(1f))
                            StatMetricCard("MISSIONS", thirtyDayDone.toString(), "done in 30 days", Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("WEEKLY COMPARISON", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("این هفته در مقایسه با هفته قبل", color = TextSoft, fontSize = 10.sp)
                        }
                        WeeklyComparisonRow("MISSIONS", thisWeekDone.toLong(), lastWeekDone.toLong(), thisWeekDone.toString(), lastWeekDone.toString())
                        WeeklyComparisonRow("FOCUS", thisWeekFocus.toLong(), lastWeekFocus.toLong(), formatFocusTime(thisWeekFocus), formatFocusTime(lastWeekFocus))
                        WeeklyComparisonRow("XP", thisWeekXp.toLong(), lastWeekXp.toLong(), "+${formatNumber(thisWeekXp)}", "+${formatNumber(lastWeekXp)}")
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("MONTHLY COMPARISON", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("$currentMonthLabel تا امروز در مقایسه با $previousMonthLabel", color = TextSoft, fontSize = 10.sp)
                        }
                        WeeklyComparisonRow("MISSIONS", currentMonthDone.toLong(), previousMonthDone.toLong(), currentMonthDone.toString(), previousMonthDone.toString())
                        WeeklyComparisonRow("FOCUS", currentMonthFocus.toLong(), previousMonthFocus.toLong(), formatFocusTime(currentMonthFocus), formatFocusTime(previousMonthFocus))
                        WeeklyComparisonRow("XP", currentMonthXp.toLong(), previousMonthXp.toLong(), "+${formatNumber(currentMonthXp)}", "+${formatNumber(previousMonthXp)}")
                        WeeklyComparisonRow("ACTIVE DAYS", currentMonthActiveDays.toLong(), previousMonthActiveDays.toLong(), currentMonthActiveDays.toString(), previousMonthActiveDays.toString())
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("PERSONAL RECORDS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("بهترین رکوردهای ثبت‌شده بر اساس روز کاری", color = TextSoft, fontSize = 10.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard(
                                "BEST DAY",
                                bestDayRecord?.value?.first?.toString() ?: "—",
                                bestDayRecord?.let { "mission • ${analyticsJalaliLabel(it.key)}" } ?: "هنوز رکوردی نیست",
                                Modifier.weight(1f)
                            )
                            StatMetricCard(
                                "BEST WEEK",
                                bestWeekRecord?.value?.first?.toString() ?: "—",
                                bestWeekRecord?.let { "mission • از ${analyticsJalaliLabel(it.key)}" } ?: "هنوز رکوردی نیست",
                                Modifier.weight(1f)
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard(
                                "DAILY XP",
                                highestDailyXpRecord?.let { "+${formatNumber(it.value.second)}" } ?: "—",
                                highestDailyXpRecord?.let { analyticsJalaliLabel(it.key) } ?: "هنوز رکوردی نیست",
                                Modifier.weight(1f)
                            )
                            StatMetricCard(
                                "MOST DONE",
                                mostDoneDayRecord?.value?.first?.toString() ?: "—",
                                mostDoneDayRecord?.let { "mission • ${analyticsJalaliLabel(it.key)}" } ?: "هنوز رکوردی نیست",
                                Modifier.weight(1f)
                            )
                        }
                        StatMetricCard(
                            "DAILY FOCUS RECORD",
                            highestDailyFocusRecord?.let { formatFocusTime(it.value.third) } ?: "—",
                            highestDailyFocusRecord?.let { analyticsJalaliLabel(it.key) } ?: "هنوز رکوردی نیست",
                            Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("PERFORMANCE TRENDS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("روند ۷ و ۳۰ روزه • Mission / Focus / XP", color = TextSoft, fontSize = 9.5.sp)
                        }
                        Text("۷ روز اخیر نسبت به ۷ روز قبل", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            TrendMetricCard("MISSION", recent7.done, previous7.done, recent7.done.toString(), Modifier.weight(1f))
                            TrendMetricCard("FOCUS", recent7.focus, previous7.focus, formatFocusTime(recent7.focus), Modifier.weight(1f))
                            TrendMetricCard("XP", recent7.xp, previous7.xp, "+${formatNumber(recent7.xp)}", Modifier.weight(1f))
                        }
                        Text("۳۰ روز اخیر نسبت به ۳۰ روز قبل", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            TrendMetricCard("MISSION", recent30.done, previous30.done, recent30.done.toString(), Modifier.weight(1f))
                            TrendMetricCard("FOCUS", recent30.focus, previous30.focus, formatFocusTime(recent30.focus), Modifier.weight(1f))
                            TrendMetricCard("XP", recent30.xp, previous30.xp, "+${formatNumber(recent30.xp)}", Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("BEST TIME ANALYSIS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("پربازده‌ترین ساعت‌ها بر اساس زمان واقعی ثبت Mission و Focus", color = TextSoft, fontSize = 9.5.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard(
                                "BEST MISSION HOUR",
                                hourLabel(bestMissionHour?.key),
                                bestMissionHour?.let { "${it.value.done} done • ${formatFocusTime(it.value.focus)} focus" } ?: "هنوز داده‌ای نیست",
                                Modifier.weight(1f)
                            )
                            StatMetricCard(
                                "BEST FOCUS HOUR",
                                hourLabel(bestFocusHour?.key),
                                bestFocusHour?.let { "${formatFocusTime(it.value.focus)} • ${it.value.done} mission" } ?: "هنوز داده‌ای نیست",
                                Modifier.weight(1f)
                            )
                        }
                        bestDayPart?.let { (part, metrics) ->
                            Text("BEST DAYPART  ${part.title} • ${part.range}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${metrics.done} mission • ${formatFocusTime(metrics.focus)} focus • +${formatNumber(metrics.xp)} XP", color = TextSoft, fontSize = 9.5.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            dayPartBuckets.forEach { (part, metrics) ->
                                Column(
                                    modifier = Modifier.weight(1f).background(Color(0x6616202C), RoundedCornerShape(12.dp)).padding(horizontal = 6.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(part.title, color = if (bestDayPart?.first == part) GoldSoft else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Text(part.range, color = TextSoft, fontSize = 7.5.sp)
                                    Text("${metrics.done} • ${formatFocusTime(metrics.focus)}", color = TextSoft, fontSize = 7.5.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("MISSION PERFORMANCE", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text("عملکرد هر مأموریت بر اساس تاریخچه واقعی", color = TextSoft, fontSize = 9.5.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatMetricCard("MOST DONE", bestMissionByDone?.done?.toString() ?: "—", bestMissionByDone?.title ?: "هنوز داده‌ای نیست", Modifier.weight(1f))
                            StatMetricCard("MOST FOCUS", bestMissionByFocus?.let { formatFocusTime(it.focus) } ?: "—", bestMissionByFocus?.title ?: "هنوز داده‌ای نیست", Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatMetricCard("MOST XP", bestMissionByXp?.let { "+${formatNumber(it.xp)}" } ?: "—", bestMissionByXp?.title ?: "هنوز داده‌ای نیست", Modifier.weight(1f))
                            StatMetricCard("BEST SUCCESS", bestMissionBySuccess?.let { "${it.successRate}%" } ?: "—", bestMissionBySuccess?.let { "${it.title} • ${it.done}/${it.resolved}" } ?: "حداقل ۲ نتیجه لازم است", Modifier.weight(1f))
                        }
                        val topMissions = missionPerformance.sortedWith(
                            compareByDescending<MissionPerformance> { it.done }.thenByDescending { it.focus }.thenByDescending { it.xp }
                        ).take(5)
                        if (topMissions.isNotEmpty()) {
                            Text("TOP MISSIONS", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            topMissions.forEachIndexed { index, mission ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("${index + 1}. ${mission.title}", color = Color.White, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                    Text("${mission.done} done • ${mission.successRate}% • ${formatFocusTime(mission.focus)}", color = TextSoft, fontSize = 8.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("PRODUCTIVITY HEATMAP", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                                Text("۱۲ هفته اخیر • شدت بر اساس Mission + Focus", color = TextSoft, fontSize = 9.5.sp)
                            }
                            Text("$heatmapActiveDays active", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        ProductivityHeatmap(
                            days = heatmapDays,
                            activity = heatmapActivity,
                            maxActivity = heatmapMaxActivity,
                            today = today,
                            selectedDay = selectedHeatmapDay,
                            onDaySelected = { selectedHeatmapDay = it }
                        )
                        selectedHeatmapDay?.let { selectedDay ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xB516202C)),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, Color(0x4DE5C87A))
                            ) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Column {
                                            Text("DAY DETAILS", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                                            Text(analyticsJalaliLabel(selectedDay), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        }
                                        TextButton(onClick = { selectedHeatmapDay = null }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                                            Text("بستن", color = TextSoft, fontSize = 9.sp)
                                        }
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                        HeatmapDayMetric("MISSION", selectedHeatmapDone.toString(), Modifier.weight(1f))
                                        HeatmapDayMetric("FOCUS", formatFocusTime(selectedHeatmapFocus), Modifier.weight(1f))
                                        HeatmapDayMetric("XP", "+${formatNumber(selectedHeatmapXp)}", Modifier.weight(1f))
                                        HeatmapDayMetric("SUCCESS", "$selectedHeatmapSuccessRate%", Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                            Text("کم", color = TextSoft, fontSize = 8.sp)
                            Spacer(Modifier.width(5.dp))
                            listOf(0.10f, 0.28f, 0.46f, 0.66f, 0.88f).forEach { alpha ->
                                Box(Modifier.padding(horizontal = 1.5.dp).size(10.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(3.dp)).background(Gold.copy(alpha = alpha)))
                            }
                            Spacer(Modifier.width(5.dp))
                            Text("زیاد", color = TextSoft, fontSize = 8.sp)
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("7 DAY TREND", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${sevenDayDone.sum()} missions • +${formatNumber(sevenDayXp.sum())} XP", color = TextSoft, fontSize = 10.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            lastSevenDays.forEachIndexed { index, day ->
                                val intensity = (sevenDayDone[index] / (sevenDayDone.maxOrNull() ?: 1).coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .height(46.dp)
                                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                                            .background(Gold.copy(alpha = 0.12f + 0.68f * intensity)),
                                        contentAlignment = Alignment.Center
                                    ) { Text(sevenDayDone[index].toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                    Spacer(Modifier.height(4.dp))
                                    Text(day.dayOfWeek.name.take(1), color = if (day == today) GoldSoft else TextSoft, fontSize = 8.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("7 DAY FOCUS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Minutes focused each day", color = TextSoft, fontSize = 10.sp)
                            }
                            Text("${focusByDay.sum()} min", color = GoldSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(14.dp))
                        SevenDayFocusChart(days = lastSevenDays, minutes = focusByDay)
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x302D3948))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ALL TIME", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        StatLine("Recorded XP", formatNumber(recordedXp))
                        StatLine("Recorded Coins", formatNumber(recordedCoins))
                        StatLine("Focus Time", formatFocusTime(totalFocus))
                        StatLine("Missions Done", totalDone.toString())
                        StatLine("Current Level", player.level.toString())
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("MISSION HISTORY", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("${history.size} records", color = TextSoft, fontSize = 10.sp)
                }
            }

            if (history.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xA90D141E)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("No mission history yet", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("Finish a mission and your activity will appear here.", color = TextSoft, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(history, key = { if (it.sessionId > 0L) "session-${it.sessionId}" else "${it.timestamp}-${it.missionTitle}" }) { entry ->
                    MissionHistoryRow(entry)
                }
            }
        }
    }
}

@Composable
private fun TrendMetricCard(
    label: String,
    current: Int,
    previous: Int,
    value: String,
    modifier: Modifier = Modifier
) {
    val delta = current - previous
    val percent = when {
        previous > 0 -> (delta * 100f / previous).toInt()
        current > 0 -> 100
        else -> 0
    }
    val direction = when {
        delta > 0 -> "▲"
        delta < 0 -> "▼"
        else -> "•"
    }
    val directionColor = when {
        delta > 0 -> Color(0xFF7FE0A3)
        delta < 0 -> Color(0xFFFF8A8A)
        else -> TextSoft
    }
    Column(
        modifier = modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x66101822)).padding(horizontal = 8.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, color = TextSoft, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text("$direction ${kotlin.math.abs(percent)}%", color = directionColor, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProductivityHeatmap(
    days: List<LocalDate>,
    activity: Map<LocalDate, Int>,
    maxActivity: Int,
    today: LocalDate,
    selectedDay: LocalDate?,
    onDaySelected: (LocalDate) -> Unit
) {
    val weeks = days.chunked(7)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        weeks.forEach { week ->
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { day ->
                    val value = activity[day] ?: 0
                    val ratio = if (value <= 0) 0f else (value.toFloat() / maxActivity.toFloat()).coerceIn(0.12f, 1f)
                    val alpha = if (value <= 0) 0.08f else 0.20f + ratio * 0.72f
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                            .background(Gold.copy(alpha = alpha))
                            .then(
                                when {
                                    day == selectedDay -> Modifier.border(2.dp, Color.White, androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                                    day == today -> Modifier.border(1.dp, GoldSoft, androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                                    else -> Modifier
                                }
                            )
                            .clickable { onDaySelected(day) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HeatmapDayMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x66101822))
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(label, color = TextSoft, fontSize = 6.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    suffix: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(92.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 13.dp, vertical = 11.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSoft, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Column {
                Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(suffix, color = GoldSoft, fontSize = 8.5.sp)
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextSoft, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SevenDayFocusChart(days: List<LocalDate>, minutes: List<Int>) {
    val maxMinutes = (minutes.maxOrNull() ?: 0).coerceAtLeast(1)
    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(112.dp)) {
            val count = minutes.size.coerceAtLeast(1)
            val gap = 8.dp.toPx()
            val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(2.dp.toPx())
            val baseline = size.height - 4.dp.toPx()
            drawLine(
                color = Color(0x444B5664),
                start = Offset(0f, baseline),
                end = Offset(size.width, baseline),
                strokeWidth = 1.dp.toPx()
            )
            minutes.forEachIndexed { index, value ->
                val fraction = value.toFloat() / maxMinutes.toFloat()
                val barHeight = if (value == 0) 4.dp.toPx() else (size.height * 0.86f * fraction).coerceAtLeast(8.dp.toPx())
                val left = index * (barWidth + gap)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(GoldSoft, Gold, Color(0xFFC58D20))),
                    topLeft = Offset(left, baseline - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            days.forEach { day ->
                Text(
                    text = day.dayOfWeek.name.take(1),
                    color = if (day == LocalDate.now()) GoldSoft else TextSoft,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MissionHistoryRow(entry: MissionHistoryEntry) {
    val dateText = remember(entry.timestamp) {
        val formatter = DateTimeFormatter.ofPattern("MMM d • HH:mm", Locale.US)
        Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.systemDefault()).format(formatter)
    }
    val resultColor = historyResultColor(entry.result)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xBF0D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color(0x292D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(entry.missionTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(dateText, color = TextSoft, fontSize = 8.5.sp)
                }
                Spacer(Modifier.width(10.dp))
                Surface(
                    color = resultColor.copy(alpha = 0.16f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, resultColor.copy(alpha = 0.45f))
                ) {
                    Text(
                        entry.result.name.uppercase(Locale.US),
                        color = resultColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⏱ ${formatFocusTime(entry.focusSeconds)}", color = TextSoft, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("+${entry.xpEarned} XP", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    Text("+${entry.coinsEarned} Coins", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (entry.levelRewardCoins > 0) {
                Text(
                    "Includes +${entry.levelRewardCoins} level-up bonus coins",
                    color = Gold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ProfileProgressScreen(
    player: PlayerState,
    history: List<MissionHistoryEntry>,
    settings: GameSettings,
    claimedAchievements: Set<String>,
    showcasedAchievementIds: List<String>,
    onToggleShowcase: (Achievement) -> Unit,
    onClaimAchievement: (Achievement) -> Unit,
    modifier: Modifier = Modifier
) {
    val zoneId = ZoneId.systemDefault()
    val context = LocalContext.current
    val todayMissionDay = currentMissionDay(context)
    val achievements = buildAchievements(player, history)
    var achievementFilter by remember { mutableStateOf<AchievementCategory?>(null) }
    // Stage 85: a claim has its own short HUD reward-flight sequence. The
    // persisted reward is still applied by the canonical progression engine.
    var achievementClaimCue by remember { mutableStateOf<HudRewardCue?>(null) }
    var achievementClaimSequence by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    LaunchedEffect(achievementClaimSequence) {
        val reward = achievementClaimSequence ?: return@LaunchedEffect
        achievementClaimCue = HudRewardCue(ProgressionVisualStep.Xp, "+${reward.first} XP")
        kotlinx.coroutines.delay(650)
        achievementClaimCue = HudRewardCue(ProgressionVisualStep.Coins, "+${reward.second}")
        kotlinx.coroutines.delay(650)
        achievementClaimCue = null
        achievementClaimSequence = null
    }
    // Stage 90: filters, collection progress, mastery, showcase frames and claim counts
    // all read the same canonical Achievement projection.
    val achievementSummary = remember(achievements, claimedAchievements) {
        achievementCollectionSummary(achievements, claimedAchievements)
    }
    val completedAchievements = achievementSummary.completed
    val claimableAchievements = achievementSummary.claimable
    val categoryProgress = achievementSummary.categoryProgress
    val masteredCategories = achievementSummary.masteredCategories
    val overallAchievementProgress = achievementSummary.overallProgress
    val visibleAchievements = achievements.filter { achievementFilter == null || it.category == achievementFilter }
    val orderedAchievements = visibleAchievements.sortedWith(
        compareBy<Achievement> { achievement ->
            when {
                achievement.progress >= achievement.goal && achievement.id !in claimedAchievements -> 0
                achievement.id in claimedAchievements -> 2
                else -> 1
            }
        }.thenByDescending { achievement ->
            (achievement.progress.toFloat() / achievement.goal.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
        }
    )
    val totalFocusSeconds = history.sumOf { it.focusSeconds }
    val totalDone = history.count { it.result == MissionResult.Done }
    val recordedXp = history.sumOf { it.xpEarned }
    // Stage 79: personal bests are derived from canonical mission history so they
    // stay correct after restore/import and respect the configured work-day boundary.
    val dailyRecords = remember(history, todayMissionDay) {
        history.groupBy { it.missionDay(context) }.mapValues { (_, entries) ->
            Triple(
                entries.sumOf { it.xpEarned },
                entries.count { it.result == MissionResult.Done },
                entries.sumOf { it.focusSeconds }
            )
        }
    }
    val bestXpDay = dailyRecords.maxByOrNull { it.value.first }
    val bestDoneDay = dailyRecords.maxByOrNull { it.value.second }
    val bestFocusDay = dailyRecords.maxByOrNull { it.value.third }
    val longestFocusEntry = history.maxByOrNull { it.focusSeconds }
    val bestOverallDay = dailyRecords.maxWithOrNull(
        compareBy<Map.Entry<LocalDate, Triple<Int, Int, Int>>> { it.value.first }
            .thenBy { it.value.second }
            .thenBy { it.value.third }
    )
    val recordDateFormatter = remember { DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US) }
    val rankTier = currentRankTier(player.rank)
    // Stage 80: Profile and HUD share one canonical progression projection.
    val progression = progressionSummary(player)
    val levelProgress = progression.levelProgress
    val rankProgress = progression.rankProgressFraction
    var month by remember { mutableStateOf(YearMonth.now(zoneId)) }
    var selectedDate by remember { mutableStateOf(LocalDate.now(zoneId)) }

    val selectedEntries = history.filter { it.localDate(zoneId) == selectedDate }
    val selectedDone = selectedEntries.count { it.result == MissionResult.Done }
    val selectedFocus = selectedEntries.sumOf { it.focusSeconds }
    val selectedXp = selectedEntries.sumOf { it.xpEarned }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xDF09111A), Color(0xF20A1119), Color(0xFC080D14)))
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TopGameHud(player = player, rewardCue = achievementClaimCue)
                    Column {
                        Text("PROGRESS PROFILE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.0.sp)
                        Spacer(Modifier.height(3.dp))
                        Text("Level، Rank، XP، Combo و رکوردهای شخصی در یک نگاه", color = TextSoft, fontSize = 10.sp)
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                    ProfileMetric("COMBO", "🔥 ${player.combo}", "فعلی", Modifier.weight(1f))
                    ProfileMetric("BEST COMBO", player.bestCombo.toString(), "رکورد", Modifier.weight(1f))
                    ProfileMetric(
                        "BOOST",
                        if (comboMultiplier(player.combo) > 1f) "×1.5" else "${player.combo.coerceIn(0, ProgressionRules.COMBO_ACTIVATION_COUNT)}/${ProgressionRules.COMBO_ACTIVATION_COUNT}",
                        if (comboMultiplier(player.combo) > 1f) "فعال" else "تا فعال شدن",
                        Modifier.weight(1f)
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD40D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Color(0x48E5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(Brush.radialGradient(listOf(Gold.copy(alpha = 0.30f), Color(0xFF172230))))
                                    .border(1.dp, Gold.copy(alpha = 0.65f), androidx.compose.foundation.shape.CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("♛", color = GoldSoft, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("LEVEL ${player.level}  •  Pathfinder", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Rank ${player.rank} • ${rankTier.title}", color = rankTier.secondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text("$completedAchievements/${achievements.size} achievements unlocked", color = TextSoft, fontSize = 9.5.sp)
                            }
                            Text("♛", color = Gold, fontSize = 25.sp)
                        }

                        ProfileProgressRow("LEVEL XP", "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP", levelProgress, Gold)
                        ProfileProgressRow(
                            "RANK PROGRESS",
                            if (progression.isMaxRank) "MAX RANK" else "${player.rankProgress} / ${progression.rankRequirement} missions",
                            rankProgress,
                            rankTier.secondary
                        )
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                    ProfileMetric("DONE", totalDone.toString(), "missions", Modifier.weight(1f))
                    ProfileMetric("FOCUS", formatFocusTime(totalFocusSeconds), "total", Modifier.weight(1f))
                    ProfileMetric("BEST", player.bestCombo.toString(), "combo", Modifier.weight(1f))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                    ProfileMetric("RECORDED XP", formatNumber(recordedXp), "history", Modifier.weight(1f))
                    ProfileMetric("COINS", formatNumber(player.coins), "wallet", Modifier.weight(1f))
                    ProfileMetric("ACHIEVEMENTS", completedAchievements.toString(), "unlocked", Modifier.weight(1f))
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("BEST RECORDS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text("بهترین رکوردهای ثبت‌شده از تاریخچه واقعی مأموریت‌ها", color = TextSoft, fontSize = 8.5.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                        ProfileMetric(
                            "BEST DAY",
                            bestOverallDay?.key?.format(recordDateFormatter) ?: "—",
                            bestOverallDay?.let { "+${formatNumber(it.value.first)} XP" } ?: "بدون رکورد",
                            Modifier.weight(1f)
                        )
                        ProfileMetric(
                            "DAILY XP",
                            bestXpDay?.let { formatNumber(it.value.first) } ?: "0",
                            bestXpDay?.key?.format(recordDateFormatter) ?: "بهترین روز",
                            Modifier.weight(1f)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                        ProfileMetric(
                            "MISSIONS / DAY",
                            bestDoneDay?.value?.second?.toString() ?: "0",
                            bestDoneDay?.key?.format(recordDateFormatter) ?: "موفق",
                            Modifier.weight(1f)
                        )
                        ProfileMetric(
                            "LONGEST FOCUS",
                            longestFocusEntry?.let { formatFocusTime(it.focusSeconds) } ?: "0m",
                            longestFocusEntry?.missionTitle ?: "یک مأموریت",
                            Modifier.weight(1f)
                        )
                    }
                    bestFocusDay?.let { record ->
                        Text(
                            "بیشترین تمرکز روزانه: ${formatFocusTime(record.value.third)} • ${record.key.format(recordDateFormatter)}",
                            color = TextSoft,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ACHIEVEMENTS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text(
                            if (claimableAchievements > 0) "$claimableAchievements reward${if (claimableAchievements == 1) "" else "s"} ready to claim"
                            else "Milestones with permanent rewards",
                            color = if (claimableAchievements > 0) Gold else TextSoft,
                            fontSize = 8.5.sp,
                            fontWeight = if (claimableAchievements > 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                    Text("$completedAchievements/${achievements.size}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                }
            }

            item {
                val showcased = showcasedAchievementIds.mapNotNull { id -> achievements.firstOrNull { it.id == id && it.progress >= it.goal } }
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xD00D141E)), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Gold.copy(alpha = 0.34f))) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("ACHIEVEMENT SHOWCASE", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("تا ۳ مدال موردعلاقه روی پروفایل", color = TextSoft, fontSize = 8.sp)
                            }
                            Text("${showcased.size}/3", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        }
                        if (showcased.isEmpty()) Text("از Achievementهای Unlock شده، گزینه Showcase را بزن.", color = TextSoft, fontSize = 8.5.sp)
                        else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            showcased.forEach { achievement ->
                                Surface(
                                    modifier = Modifier.weight(1f).clickable { onToggleShowcase(achievement) },
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xB80D141E),
                                    border = BorderStroke(1.dp, achievementMedalAccent(achievement.tier, achievement.category in masteredCategories).copy(alpha = 0.46f))
                                ) {
                                    Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        AchievementMedalFrame(
                                            achievement = achievement,
                                            mastered = achievement.category in masteredCategories,
                                            modifier = Modifier.size(46.dp)
                                        )
                                        Spacer(Modifier.height(5.dp))
                                        Text(achievement.title, color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            if (achievement.category in masteredCategories) "MASTERED • TIER ${achievement.tier}" else "TIER ${achievement.tier}",
                                            color = achievementMedalAccent(achievement.tier, achievement.category in masteredCategories),
                                            fontSize = 6.8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            repeat(3 - showcased.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC9101822)),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, if (masteredCategories.isNotEmpty()) Gold.copy(alpha = 0.55f) else Color(0x354D6072))
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("ACHIEVEMENT MASTERY", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp)
                                Text(
                                    if (masteredCategories.isEmpty()) "اولین دسته را کامل کن" else "${masteredCategories.size}/${AchievementCategory.entries.size} دسته Mastered",
                                    color = TextSoft,
                                    fontSize = 8.5.sp
                                )
                            }
                            Text("${(overallAchievementProgress * 100).toInt()}%", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        }
                        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF27313C))) {
                            Box(Modifier.fillMaxWidth(overallAchievementProgress.coerceIn(0f, 1f)).fillMaxHeight().background(Gold))
                        }
                        if (masteredCategories.isNotEmpty()) {
                            Text(
                                masteredCategories.joinToString("  •  ") { "✓ ${achievementCategoryLabel(it)}" },
                                color = GoldSoft,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item {
                val filterScroll = rememberScrollState()
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(filterScroll),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    AchievementFilterPill(
                        label = "ALL",
                        progress = completedAchievements,
                        total = achievements.size,
                        selected = achievementFilter == null,
                        onClick = { achievementFilter = null }
                    )
                    AchievementCategory.entries.forEach { category ->
                        val progressPair = categoryProgress[category] ?: (0 to 0)
                        AchievementFilterPill(
                            label = achievementCategoryLabel(category),
                            progress = progressPair.first,
                            total = progressPair.second,
                            selected = achievementFilter == category,
                            onClick = { achievementFilter = category }
                        )
                    }
                }
            }

            item {
                val selected = achievementFilter
                if (selected != null) {
                    val progressPair = categoryProgress[selected] ?: (0 to 0)
                    val fraction = if (progressPair.second == 0) 0f else progressPair.first.toFloat() / progressPair.second.toFloat()
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${achievementCategoryLabel(selected)} PROGRESS", color = GoldSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            Text("${progressPair.first}/${progressPair.second}", color = Gold, fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF27313C))) {
                            Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().background(Gold))
                        }
                    }
                }
            }

            items(orderedAchievements, key = { it.id }) { achievement ->
                AchievementCard(
                    achievement = achievement,
                    claimed = achievement.id in claimedAchievements,
                    showcased = achievement.id in showcasedAchievementIds,
                    showcaseFull = showcasedAchievementIds.size >= 3,
                    onToggleShowcase = { onToggleShowcase(achievement) },
                    onClaim = {
                        if (achievement.progress >= achievement.goal && achievement.id !in claimedAchievements) {
                            achievementClaimSequence = achievement.xpReward to achievement.coinReward
                            onClaimAchievement(achievement)
                        }
                    }
                )
            }

            item {
                Spacer(Modifier.height(2.dp))
                Text("ACTIVITY CALENDAR", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("Tap a day to inspect its activity", color = TextSoft, fontSize = 9.sp)
            }

            item {
                ActivityCalendarCard(
                    month = month,
                    selectedDate = selectedDate,
                    history = history,
                    onPreviousMonth = {
                        month = month.minusMonths(1)
                        selectedDate = month.atDay(1)
                    },
                    onNextMonth = {
                        month = month.plusMonths(1)
                        selectedDate = month.atDay(1)
                    },
                    onSelectDate = { selectedDate = it }
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x332D3948))
                ) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(
                            selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.US)).uppercase(Locale.US),
                            color = GoldSoft,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$selectedDone done", color = Color.White, fontSize = 11.sp)
                            Text(formatFocusTime(selectedFocus), color = TextSoft, fontSize = 11.sp)
                            Text("+$selectedXp XP", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (selectedEntries.isEmpty()) {
                            Text("No missions recorded on this day.", color = TextSoft, fontSize = 9.5.sp)
                        } else {
                            selectedEntries.take(3).forEach { entry ->
                                Text("• ${entry.missionTitle}  —  ${entry.result.name}", color = TextSoft, fontSize = 9.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileProgressRow(label: String, value: String, progress: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Box(
            Modifier.fillMaxWidth().height(6.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color(0xFF26313D))
        ) {
            Box(
                Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().background(color)
            )
        }
    }
}

@Composable
private fun ProfileMetric(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(78.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xC70D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
        border = BorderStroke(1.dp, Color(0x302D3948))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(9.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = TextSoft, fontSize = 7.2.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp, textAlign = TextAlign.Center)
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(subtitle, color = GoldSoft, fontSize = 7.5.sp)
        }
    }
}

private fun achievementCategoryLabel(category: AchievementCategory): String = when (category) {
    AchievementCategory.Mission -> "MISSION"
    AchievementCategory.Focus -> "FOCUS"
    AchievementCategory.Combo -> "COMBO"
    AchievementCategory.Rank -> "RANK"
    AchievementCategory.Level -> "LEVEL"
}

@Composable
private fun AchievementFilterPill(
    label: String,
    progress: Int,
    total: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (selected) Gold.copy(alpha = 0.18f) else Color(0xB80D141E),
        border = BorderStroke(1.dp, if (selected) Gold.copy(alpha = 0.82f) else Color(0x302D3948))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = if (selected) GoldSoft else TextSoft, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text("$progress/$total", color = if (selected) Gold else TextSoft.copy(alpha = 0.8f), fontSize = 7.5.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

private fun achievementMedalAccent(tier: Int, mastered: Boolean): Color {
    if (mastered) return Color(0xFFFFD76A)
    return when (tier.coerceIn(1, 4)) {
        1 -> Color(0xFFB9C2CC)
        2 -> Color(0xFFC99362)
        3 -> Color(0xFFE5C87A)
        else -> Color(0xFFB8A7FF)
    }
}

@Composable
private fun AchievementMedalFrame(
    achievement: Achievement,
    mastered: Boolean,
    modifier: Modifier = Modifier,
    unlocked: Boolean = true
) {
    val accent = if (unlocked) achievementMedalAccent(achievement.tier, mastered) else TextSoft.copy(alpha = 0.55f)
    val frameWidth = when {
        mastered -> 2.5.dp
        achievement.tier >= 4 -> 2.dp
        achievement.tier >= 2 -> 1.5.dp
        else -> 1.dp
    }
    val glowAlpha = when {
        mastered -> 0.28f
        achievement.tier >= 4 -> 0.22f
        achievement.tier >= 3 -> 0.17f
        else -> 0.10f
    }
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(accent.copy(alpha = glowAlpha), Color(0xFF17212C))))
            .border(frameWidth, accent.copy(alpha = if (unlocked) 0.92f else 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(achievement.glyph, color = accent, fontSize = 19.sp, fontWeight = FontWeight.Black)
        if (mastered) {
            Text("✦", color = Color.White.copy(alpha = 0.88f), fontSize = 7.sp, modifier = Modifier.align(Alignment.TopEnd).padding(5.dp))
        }
    }
}

@Composable
private fun AchievementCard(
    achievement: Achievement,
    claimed: Boolean,
    showcased: Boolean,
    showcaseFull: Boolean,
    onToggleShowcase: () -> Unit,
    onClaim: () -> Unit
) {
    val complete = achievement.progress >= achievement.goal
    val progress = (achievement.progress.toFloat() / achievement.goal.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
    val remaining = (achievement.goal - achievement.progress).coerceAtLeast(0)
    val stateLabel = when {
        claimed -> "CLAIMED"
        complete -> "READY"
        else -> "${(progress * 100).toInt()}%"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (complete) Color(0xD61B1A10) else Color(0xC90D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, if (complete) Gold.copy(alpha = 0.55f) else Color(0x302D3948))
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AchievementMedalFrame(
                achievement = achievement,
                mastered = false,
                unlocked = complete,
                modifier = Modifier.size(42.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(achievement.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(stateLabel, color = if (complete) Gold else TextSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Text(achievement.subtitle, color = TextSoft, fontSize = 8.7.sp)
                Text(
                    "${achievement.category.name.uppercase(Locale.US)} • TIER ${achievement.tier}",
                    color = GoldSoft.copy(alpha = 0.82f),
                    fontSize = 7.4.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    if (complete) {
                        if (claimed) "Reward collected" else "Achievement unlocked — reward ready"
                    } else {
                        "$remaining remaining • ${achievement.progress.coerceAtMost(achievement.goal)}/${achievement.goal}"
                    },
                    color = if (complete && !claimed) GoldSoft else TextSoft.copy(alpha = 0.86f),
                    fontSize = 7.8.sp,
                    fontWeight = if (complete && !claimed) FontWeight.SemiBold else FontWeight.Normal
                )
                Box(
                    Modifier.fillMaxWidth().height(4.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color(0xFF27313C))
                ) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(if (complete) Gold else Color(0xFF718096)))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("+${achievement.xpReward} XP • +${achievement.coinReward} Coins", color = GoldSoft, fontSize = 8.5.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (complete) {
                            TextButton(onClick = onToggleShowcase, enabled = showcased || !showcaseFull, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                                Text(if (showcased) "Featured" else "Showcase", color = if (showcased) Gold else TextSoft, fontSize = 7.8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        TextButton(onClick = onClaim, enabled = complete && !claimed, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text(if (claimed) "Claimed" else if (complete) "Claim" else "Locked", color = if (complete && !claimed) Gold else TextSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActivityCalendarCard(
    month: YearMonth,
    selectedDate: LocalDate,
    history: List<MissionHistoryEntry>,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDate: (LocalDate) -> Unit
) {
    val zoneId = ZoneId.systemDefault()
    val firstOffset = month.atDay(1).dayOfWeek.value - 1
    val days = month.lengthOfMonth()
    val weekCount = (firstOffset + days + 6) / 7
    val focusByDay = (1..days).associateWith { day ->
        val date = month.atDay(day)
        history.asSequence().filter { it.localDate(zoneId) == date }.sumOf { it.focusSeconds } / 60
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xD00D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPreviousMonth, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("‹", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)).uppercase(Locale.US),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.1.sp
                )
                TextButton(onClick = onNextMonth, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("›", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(Modifier.fillMaxWidth()) {
                listOf("M", "T", "W", "T", "F", "S", "S").forEach { label ->
                    Text(label, color = TextSoft, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                }
            }

            repeat(weekCount) { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(7) { dayOfWeek ->
                        val cell = week * 7 + dayOfWeek
                        val day = cell - firstOffset + 1
                        if (day !in 1..days) {
                            Spacer(Modifier.weight(1f).height(38.dp))
                        } else {
                            val date = month.atDay(day)
                            val minutes = focusByDay[day] ?: 0
                            val intensity = (minutes / 120f).coerceIn(0f, 1f)
                            val selected = date == selectedDate
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
                                    .background(
                                        if (minutes > 0) Gold.copy(alpha = 0.15f + 0.68f * intensity)
                                        else Color(0xFF19232E)
                                    )
                                    .then(
                                        if (selected) Modifier.border(1.dp, GoldSoft, androidx.compose.foundation.shape.RoundedCornerShape(9.dp)) else Modifier
                                    )
                                    .clickable { onSelectDate(date) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(day.toString(), color = if (minutes > 0) Color.White else TextSoft, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                    if (minutes > 0) Text("${minutes}m", color = Color.White.copy(alpha = 0.85f), fontSize = 6.5.sp)
                                }
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("Less", color = TextSoft, fontSize = 7.sp)
                Spacer(Modifier.width(5.dp))
                listOf(0.16f, 0.30f, 0.48f, 0.66f, 0.83f).forEach { alpha ->
                    Box(Modifier.padding(horizontal = 1.dp).size(9.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(2.dp)).background(Gold.copy(alpha = alpha)))
                }
                Spacer(Modifier.width(5.dp))
                Text("More", color = TextSoft, fontSize = 7.sp)
            }
        }
    }
}

@Composable
private fun OnboardingScreen(onFinish: (OnboardingProfile, Set<String>) -> Unit) {
    var name by remember { mutableStateOf("") }
    var activeStart by remember { mutableStateOf("07:00") }
    var activeEnd by remember { mutableStateOf("23:00") }
    val selected = remember {
        mutableStateListOf<String>().also { list -> list.addAll(missionTemplates.map { it.id }) }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xC9081018), Color(0xF0081018), Color(0xFF080D14)))))
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = gamifyHorizontalPadding())
                .navigationBarsPadding(),
            contentPadding = PaddingValues(top = GamifySpacing.Xl, bottom = GamifySpacing.Xl),
            verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
        ) {
            item {
                Text("WELCOME TO GAMIFICATION", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.8.sp)
            }
            item {
                SettingsGroup(title = "PLAYER SETUP") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("PLAYER:", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(40) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("Name") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text("ACTIVE HOURS:", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                        OutlinedTextField(
                            value = activeStart,
                            onValueChange = { activeStart = it.take(5) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("Start") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                        Text("–", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = activeEnd,
                            onValueChange = { activeEnd = it.take(5) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("End") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                }
            }
            item {
                SettingsGroup(title = "STARTER MISSIONS") {
                    val rows = missionTemplates.chunked(3)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rows.forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowItems.forEach { template ->
                                    val isSelected = template.id in selected
                                    OnboardingMissionTile(
                                        title = template.title,
                                        selected = isSelected,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        if (isSelected) selected.remove(template.id) else selected.add(template.id)
                                    }
                                }
                                repeat(3 - rowItems.size) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        onFinish(
                            OnboardingProfile(
                                name = name.trim().ifBlank { "Player" },
                                activeStart = activeStart.ifBlank { "07:00" },
                                activeEnd = activeEnd.ifBlank { "23:00" }
                            ),
                            selected.toSet()
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(GamifyDimens.ButtonHeight),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                    shape = GamifyShapes.Field
                ) { Text("Enter My World", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun OnboardingMissionTile(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(58.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .background(
                if (selected) Brush.verticalGradient(listOf(Color(0x30F7C948), Color(0x1826333F)))
                else Brush.verticalGradient(listOf(Color(0xFF17212C), Color(0xFF121A23)))
            )
            .border(1.dp, if (selected) Gold.copy(alpha = 0.85f) else GamifyColors.BorderSoft, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        if (selected) {
            Text(
                "×",
                color = GoldSoft,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd)
            )
        }
        Text(
            text = title,
            color = if (selected) Color.White else TextSoft,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun SettingsScreen(
    settings: GameSettings,
    onSettingsChange: (GameSettings) -> Unit,
    onDataRestored: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var dataMessage by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) dataMessage = if (exportBackup(context, uri)) "خروجی کامل با موفقیت ذخیره شد" else "ذخیره خروجی ناموفق بود"
    }
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val restoreResult = importBackup(context, uri)
            dataMessage = when (restoreResult) {
                "Backup restored" -> "ورود کامل اطلاعات با موفقیت انجام شد"
                else -> restoreResult
            }
            if (restoreResult == "Backup restored") onDataRestored()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xE90A1119), Color(0xF50A1119), Color(0xFC080D14))))
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = gamifyHorizontalPadding()),
            contentPadding = PaddingValues(top = GamifySpacing.Lg, bottom = GamifySpacing.Xl),
            verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
        ) {
            item {
                Column {
                    Text("SETTINGS", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Tune focus, feedback and gameplay to your style.", color = TextSoft, fontSize = 12.sp)
                }
            }

            item {
                SettingsGroup(title = "FEEDBACK") {
                    SettingsToggleRow(
                        title = "Sound effects",
                        subtitle = "Mission complete and level-up sounds",
                        checked = settings.soundEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(soundEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Vibration",
                        subtitle = "Short haptics for results and rewards",
                        checked = settings.vibrationEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(vibrationEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Timer notifications",
                        subtitle = "Notify when a running mission reaches zero",
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "TREE STATS") {
                    SettingsToggleRow(
                        title = "نوتیفیکیشن آمار درختواره",
                        subtitle = "یادآوری روزانه برای ثبت آمار فردبه‌فرد",
                        checked = settings.treeStatsReminderEnabled,
                        onCheckedChange = { enabled ->
                            onSettingsChange(settings.copy(treeStatsReminderEnabled = enabled))
                        }
                    )
                    SettingsDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = settings.treeStatsReminderEnabled) {
                                TimePickerDialog(
                                    context,
                                    { _, hour, minute ->
                                        onSettingsChange(
                                            settings.copy(
                                                treeStatsReminderHour = hour,
                                                treeStatsReminderMinute = minute
                                            )
                                        )
                                    },
                                    settings.treeStatsReminderHour,
                                    settings.treeStatsReminderMinute,
                                    true
                                ).show()
                            }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f).padding(end = GamifySpacing.Md)) {
                            Text(
                                "ساعت یادآوری",
                                color = if (settings.treeStatsReminderEnabled) Color.White else TextSoft,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "برای تغییر ساعت لمس کنید",
                                color = TextSoft,
                                fontSize = 9.5.sp,
                                lineHeight = 12.sp
                            )
                        }
                        Surface(
                            color = if (settings.treeStatsReminderEnabled) Gold.copy(alpha = 0.14f) else Color(0x221FFFFFFF),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                1.dp,
                                if (settings.treeStatsReminderEnabled) Gold.copy(alpha = 0.48f) else GamifyColors.BorderSoft
                            )
                        ) {
                            Text(
                                String.format(
                                    Locale.US,
                                    "%02d:%02d",
                                    settings.treeStatsReminderHour,
                                    settings.treeStatsReminderMinute
                                ),
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                color = if (settings.treeStatsReminderEnabled) GoldSoft else TextSoft,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            item {
                SettingsGroup(title = "GAMEPLAY") {
                    Text("Combo ×1.5", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(3.dp))
                    Text("۵ مأموریت Done متوالی → ضریب ×1.5 روی XP و Coins؛ مأموریت پنجم هم با همین ضریب محاسبه می‌شود.", color = TextSoft, fontSize = 9.5.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Fail / Partial → ریست Combo  •  Defer → حفظ Combo  •  بعد از فعال‌شدن، هر Done پنجره ۳۰ دقیقه‌ای Combo را تازه می‌کند.", color = GoldSoft, fontSize = 8.8.sp, lineHeight = 12.sp)
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Reduced motion",
                        subtitle = "Disable pulse and carousel depth animations",
                        checked = settings.reducedMotion,
                        onCheckedChange = { onSettingsChange(settings.copy(reducedMotion = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "THEME") {
                    Text(
                        "World tint",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                        AppThemeMode.values().forEach { mode ->
                            ThemeChoice(
                                mode = mode,
                                selected = settings.themeMode == mode,
                                onClick = { onSettingsChange(settings.copy(themeMode = mode)) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item {
                SettingsGroup(title = "داده‌ها و بکاپ") {
                    Text("یک فایل برای تمام اطلاعات اپ و تصاویر تابلو رویاها.", color = TextSoft, fontSize = 10.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { exportLauncher.launch("gamification-full-backup.gamify.zip") },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("خروجی کامل", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { importLauncher.launch(arrayOf("application/zip", "application/json", "application/octet-stream", "text/plain")) },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("ورود کامل", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    dataMessage?.let {
                        Spacer(Modifier.height(9.dp))
                        val isError = it.contains("failed", true) || it.contains("newer", true) || it.contains("ناموفق", true) || it.contains("invalid", true)
                        Text(it, color = if (isError) Color(0xFFFF8A80) else Color(0xFF86EFAC), fontSize = 9.5.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("ورود کامل فقط بعد از اعتبارسنجی فایل انجام می‌شود و همه بخش‌های قابل بکاپ را یکجا برمی‌گرداند.", color = GamifyColors.TextMuted, fontSize = 8.5.sp)
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("پاک کردن همه داده‌های محلی", color = Color(0xFFFF8A80), fontSize = 10.sp)
                    }
                    Text("Backup schema v$CURRENT_SCHEMA_VERSION • تایمر در حال اجرا عمداً وارد بکاپ نمی‌شود", color = GamifyColors.TextMuted, fontSize = 8.5.sp)
                }
            }

            item {
                SettingsGroup(title = "SYSTEM HEALTH") {
                    val profile = loadOnboardingProfile(context)
                    Text("Release ${BuildConfig.VERSION_NAME} • Player: ${profile.name} • Active: ${profile.activeStart}–${profile.activeEnd}", color = TextSoft, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { dataMessage = runDataHealthCheck(context) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("Run data health check", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text("Repairs invalid mission values, deduplicates history/notifications and refreshes the widget.", color = GamifyColors.TextMuted, fontSize = 8.5.sp)
                }
            }

            item {
                SettingsGroup(title = "CONNECTED FEATURES") {
                    val firstMission = loadMissions(context).firstOrNull()
                    val league = personalLeague(context, loadHistory(context))
                    Text("Personal League: $league", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Android Auto Backup is enabled for device cloud restore. Real-time cross-device sync and online leaderboards require a backend account service.", color = TextSoft, fontSize = 9.5.sp)
                    Spacer(Modifier.height(9.dp))
                    Button(
                        onClick = {
                            dataMessage = if (firstMission != null && addMissionToCalendar(context, firstMission)) "Opened Calendar" else "No Calendar app found"
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("Add next mission to Calendar", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(7.dp))
                    Text("Home-screen widget is included: add “Gamification” from your launcher’s Widgets menu.", color = GamifyColors.TextMuted, fontSize = 9.sp)
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xB90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x2FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("COMBO ×1.5 RULES", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Done  →  +1 Combo", color = Color.White, fontSize = 11.sp)
                        Text("5 Done  →  ×1.5 XP & Coins (از همان Done پنجم)", color = GoldSoft, fontSize = 10.5.sp)
                        Text("Fail / Partial  →  Combo resets", color = TextSoft, fontSize = 11.sp)
                        Text("Defer  →  Combo preserved", color = TextSoft, fontSize = 11.sp)
                        Text("Boost: ×1.5 from Done #5 onward", color = GoldSoft, fontSize = 9.5.sp)
                    }
                }
            }
        }

        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                containerColor = GamifyColors.Surface,
                shape = GamifyShapes.Dialog,
                title = { Text("Reset all data?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text("Missions, history, progress, rewards and settings will return to defaults. Export a backup first if needed.", color = TextSoft, fontSize = 12.sp) },
                confirmButton = {
                    TextButton(onClick = {
                        resetGameData(context)
                        confirmReset = false
                        dataMessage = "Local data reset"
                        onDataRestored()
                    }) { Text("Reset", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun SettingsGroup(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = GamifyColors.Surface.copy(alpha = 0.90f)),
        shape = GamifyShapes.Card,
        border = BorderStroke(1.dp, GamifyColors.BorderSoft)
    ) {
        Column(Modifier.fillMaxWidth().padding(GamifySpacing.Lg)) {
            Text(title, color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(GamifySpacing.Sm))
            content()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = GamifySpacing.Md)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = TextSoft, fontSize = 9.5.sp, lineHeight = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = GamifySpacing.Sm)
            .height(1.dp)
            .background(GamifyColors.BorderSoft.copy(alpha = 0.65f))
    )
}

@Composable
private fun MissionTerminalTransition(
    mission: Mission,
    result: MissionResult,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    val duration = if (result == MissionResult.Fail) 900 else 650
    val progress = remember(mission.id, mission.title, result, reducedMotion) { Animatable(if (reducedMotion) 1f else 0f) }
    val density = LocalDensity.current
    val slidePx = with(density) { 110.dp.toPx() }
    LaunchedEffect(mission.id, mission.title, result, reducedMotion) {
        if (!reducedMotion) {
            progress.snapTo(0f)
            progress.animateTo(1f, animationSpec = tween(durationMillis = duration))
        }
    }
    val p = progress.value.coerceIn(0f, 1f)
    val failed = result == MissionResult.Fail
    val accent = if (failed) Color(0xFFFF7278) else Gold
    val glyph = if (failed) "×" else "↻"
    val status = if (failed) "انجام نشد" else "برگشت به صف"

    Box(modifier = modifier.fillMaxWidth().height(128.dp), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
                .graphicsLayer {
                    translationX = if (failed) slidePx * p else -slidePx * 0.35f * p
                    translationY = if (failed) 18f * p else 24f * p
                    rotationZ = if (failed) 1.5f * p else -1.0f * p
                    scaleX = 1f - (if (failed) 0.10f else 0.06f) * p
                    scaleY = 1f - (if (failed) 0.18f else 0.12f) * p
                    alpha = if (reducedMotion) 0f else (1f - p * 1.08f).coerceIn(0f, 1f)
                },
            colors = CardDefaults.cardColors(containerColor = if (failed) Color(0xE63A1C22) else Color(0xEB171B20)),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.72f)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(glyph, color = accent, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    mission.title,
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (failed) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(status, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MissionCompletionFlight(
    mission: Mission,
    xpGain: Int,
    coinGain: Int,
    reducedMotion: Boolean,
    durationMillis: Int,
    modifier: Modifier = Modifier
) {
    val progress = remember(mission.id, mission.title, reducedMotion) { Animatable(if (reducedMotion) 1f else 0f) }
    val density = LocalDensity.current
    val travelPx = with(density) { 520.dp.toPx() }
    val sidePx = with(density) { 86.dp.toPx() }
    LaunchedEffect(mission.id, mission.title, reducedMotion, durationMillis) {
        if (!reducedMotion) {
            progress.snapTo(0f)
            progress.animateTo(1f, animationSpec = tween(durationMillis = durationMillis))
        }
    }
    val p = progress.value.coerceIn(0f, 1f)
    Box(modifier = modifier.fillMaxWidth().height(128.dp), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
                .graphicsLayer {
                    scaleX = 1f - 0.16f * p
                    scaleY = 1f - 0.42f * p
                    alpha = if (reducedMotion) 0f else (1f - p * 1.25f).coerceIn(0f, 1f)
                },
            colors = CardDefaults.cardColors(containerColor = Color(0xEB0B121A)),
            border = BorderStroke(1.dp, Color(0xAA55D98A)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("✓", color = Color(0xFF55D98A), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(mission.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (xpGain > 0) {
            Surface(
                modifier = Modifier.graphicsLayer {
                    translationX = -sidePx * p
                    translationY = -travelPx * p
                    scaleX = 1f - 0.30f * p
                    scaleY = 1f - 0.30f * p
                    alpha = if (reducedMotion) 0f else (1f - (p - 0.82f).coerceAtLeast(0f) / 0.18f).coerceIn(0f, 1f)
                },
                shape = CircleShape,
                color = Color(0xFF55D98A),
                shadowElevation = 8.dp
            ) { Text("+$xpGain XP", color = Color(0xFF07130D), fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) }
        }
        if (coinGain > 0) {
            Surface(
                modifier = Modifier.graphicsLayer {
                    translationX = sidePx * p
                    translationY = -travelPx * p
                    scaleX = 1f - 0.30f * p
                    scaleY = 1f - 0.30f * p
                    alpha = if (reducedMotion) 0f else (1f - (p - 0.82f).coerceAtLeast(0f) / 0.18f).coerceIn(0f, 1f)
                },
                shape = CircleShape,
                color = Color(0xFFFFD66B),
                shadowElevation = 8.dp
            ) { Text("+$coinGain", color = Color(0xFF1A1303), fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) }
        }
    }
}

@Composable
private fun ThemeChoice(
    mode: AppThemeMode,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val label = when (mode) {
        AppThemeMode.Classic -> "Classic"
        AppThemeMode.Midnight -> "Midnight"
        AppThemeMode.Obsidian -> "Obsidian"
    }
    val swatch = when (mode) {
        AppThemeMode.Classic -> Color(0xFFB98A36)
        AppThemeMode.Midnight -> Color(0xFF274D78)
        AppThemeMode.Obsidian -> Color(0xFF181B20)
    }
    Surface(
        modifier = modifier.height(62.dp).clickable(onClick = onClick),
        color = if (selected) Color(0x2EF7C948) else Color(0x60131B25),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (selected) Gold else Color(0x353A4654))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(19.dp).clip(androidx.compose.foundation.shape.CircleShape).background(swatch))
            Spacer(Modifier.height(5.dp))
            Text(label, color = if (selected) GoldSoft else TextSoft, fontSize = 8.5.sp, maxLines = 1)
        }
    }
}

@Composable
private fun AchievementMasteryCelebration(
    category: AchievementCategory,
    reducedMotion: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pulse = if (reducedMotion) 1f else {
        val transition = rememberInfiniteTransition(label = "mastery-celebration")
        val value by transition.animateFloat(
            initialValue = 0.975f, targetValue = 1.025f,
            animationSpec = infiniteRepeatable(tween(720), repeatMode = RepeatMode.Reverse),
            label = "mastery-celebration-pulse"
        )
        value
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.width(342.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }.clickable { onDismiss() },
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFC101923)),
            border = BorderStroke(1.6.dp, Gold)
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("✦  MASTERED  ✦", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                Text(achievementCategoryLabel(category), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("تمام Tierهای این دسته کامل شد", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text("این افتخار فقط یک‌بار نمایش داده می‌شود • برای بستن لمس کن", color = TextSoft, fontSize = 8.5.sp)
            }
        }
    }
}

@Composable
private fun AchievementUnlockToast(
    achievement: Achievement,
    reducedMotion: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pulse = if (reducedMotion) 1f else {
        val transition = rememberInfiniteTransition(label = "achievement-unlock")
        val value by transition.animateFloat(
            initialValue = 0.985f, targetValue = 1.015f,
            animationSpec = infiniteRepeatable(tween(650), repeatMode = RepeatMode.Reverse),
            label = "achievement-unlock-pulse"
        )
        value
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.width(330.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }.clickable { onDismiss() },
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFA0A141D)),
            border = BorderStroke(1.2.dp, Gold.copy(alpha = 0.9f))
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Gold.copy(alpha = 0.14f)).border(1.dp, Gold.copy(alpha = 0.72f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(achievement.glyph, fontSize = 23.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ACHIEVEMENT UNLOCKED", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
                    Text(achievement.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("Tier ${achievement.tier} • +${achievement.xpReward} XP • +${achievement.coinReward} Coin آماده دریافت", color = TextSoft, fontSize = 9.5.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ProgressionNoticeOverlay(
    notice: ProgressionNotice,
    reducedMotion: Boolean,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pulse = if (reducedMotion) {
        1f
    } else {
        val transition = rememberInfiniteTransition(label = "progression-notice")
        val value by transition.animateFloat(
            initialValue = 0.992f,
            targetValue = 1.008f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 850),
                repeatMode = RepeatMode.Reverse
            ),
            label = "progression-notice-pulse"
        )
        value
    }
    val isLevel = notice.kind == ProgressionNoticeKind.Level
    val rankTier = currentRankTier(notice.newValue)
    val accent = if (isLevel) Gold else rankTier.secondary
    val rankBase = if (isLevel) Color(0xFF172331) else rankTier.primary
    val title = if (isLevel) "LEVEL UP" else "RANK UP"
    val celebration = remember(notice.kind, notice.newValue) { Animatable(if (reducedMotion) 1f else 0f) }
    LaunchedEffect(notice.kind, notice.newValue, reducedMotion) {
        if (!reducedMotion) celebration.animateTo(1f, animationSpec = tween(GamifyMotion.CelebrationMs))
    }
    val subtitle = if (isLevel) "سطح جدید شما" else "رنک جدید شما"
    val mainValue = if (isLevel) "لول ${notice.newValue}" else "رنک ${notice.newValue}"

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier
                .width(330.dp)
                .heightIn(min = 318.dp, max = 350.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse },
            colors = CardDefaults.cardColors(containerColor = Color(0xFA071019)),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
            border = BorderStroke(1.2.dp, accent.copy(alpha = 0.88f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                rankBase.copy(alpha = if (isLevel) 1f else 0.78f),
                                Color(0xFF0B141E),
                                Color(0xFF080C10)
                            )
                        )
                    )
            ) {
                Canvas(Modifier.matchParentSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.26f), Color.Transparent)
                        ),
                        radius = size.width * 0.54f,
                        center = Offset(size.width * 0.5f, size.height * 0.18f)
                    )
                    if (isLevel || notice.kind == ProgressionNoticeKind.Rank) {
                        val t = celebration.value
                        val center = Offset(size.width * 0.5f, size.height * 0.23f)
                        val rays = 14
                        repeat(rays) { i ->
                            val angle = (Math.PI * 2.0 * i / rays).toFloat()
                            val distance = size.minDimension * (0.12f + 0.34f * t)
                            val x = center.x + kotlin.math.cos(angle) * distance
                            val y = center.y + kotlin.math.sin(angle) * distance
                            val particleAlpha = ((1f - t) * 0.92f).coerceIn(0f, 1f)
                            drawCircle(
                                color = if (i % 3 == 0) Color.White.copy(alpha = particleAlpha) else accent.copy(alpha = particleAlpha),
                                radius = (2.2f + (i % 3)) * density,
                                center = Offset(x, y)
                            )
                        }
                        drawCircle(
                            color = accent.copy(alpha = ((1f - t) * 0.24f).coerceIn(0f, 0.24f)),
                            radius = size.minDimension * (0.16f + 0.42f * t),
                            center = center,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                        )
                    }
                    val line = accent.copy(alpha = 0.11f)
                    val gap = 32.dp.toPx()
                    var y = 0f
                    while (y < size.height) {
                        drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 0.7.dp.toPx())
                        y += gap
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(74.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color(0x291F1600))
                            .border(1.dp, accent.copy(alpha = 0.75f), androidx.compose.foundation.shape.CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(Modifier.size(46.dp)) {
                            if (isLevel) {
                                val crown = Path().apply {
                                    moveTo(size.width * 0.12f, size.height * 0.68f)
                                    lineTo(size.width * 0.22f, size.height * 0.28f)
                                    lineTo(size.width * 0.43f, size.height * 0.50f)
                                    lineTo(size.width * 0.50f, size.height * 0.18f)
                                    lineTo(size.width * 0.57f, size.height * 0.50f)
                                    lineTo(size.width * 0.78f, size.height * 0.28f)
                                    lineTo(size.width * 0.88f, size.height * 0.68f)
                                    close()
                                }
                                drawPath(crown, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), accent, Color(0xFFB97812))))
                                drawRoundRect(color = Color(0xFFFFE58B), topLeft = Offset(size.width * 0.16f, size.height * 0.68f), size = Size(size.width * 0.68f, size.height * 0.13f), cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx()))
                            } else {
                                val shield = Path().apply {
                                    moveTo(size.width * .50f, size.height * .08f)
                                    lineTo(size.width * .84f, size.height * .22f)
                                    lineTo(size.width * .78f, size.height * .62f)
                                    quadraticBezierTo(size.width * .68f, size.height * .84f, size.width * .50f, size.height * .94f)
                                    quadraticBezierTo(size.width * .32f, size.height * .84f, size.width * .22f, size.height * .62f)
                                    lineTo(size.width * .16f, size.height * .22f)
                                    close()
                                }
                                drawPath(shield, brush = Brush.verticalGradient(listOf(Color.White.copy(alpha=.92f), accent, rankBase)))
                                drawCircle(Color(0xFF081019).copy(alpha=.86f), radius=size.width*.16f, center=Offset(size.width*.5f,size.height*.47f))
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        title,
                        color = Color(0xFFFFE99B),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.4.sp
                    )
                    Text(subtitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(mainValue, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    if (!isLevel) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (notice.newValue - notice.fromValue > 1)
                                "${notice.fromValue}  →  ${notice.newValue}  •  +${notice.newValue - notice.fromValue} رنک"
                            else "${notice.fromValue}  →  ${notice.newValue}",
                            color = GamifyColors.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(7.dp))
                        Surface(color = Color(0xB30A1119), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, accent.copy(alpha = .46f))) {
                            Text(
                                if (notice.newValue >= ProgressionRules.MAX_RANK) "بالاترین رنک" else "رنک بعدی: ${notice.nextLevelXp} مأموریت رنک",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (isLevel) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (notice.newValue - notice.fromValue > 1)
                                "${notice.fromValue}  →  ${notice.newValue}  •  +${notice.newValue - notice.fromValue} سطح"
                            else "${notice.fromValue}  →  ${notice.newValue}",
                            color = GamifyColors.TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(7.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                color = Color(0xB30A1119),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.40f))
                            ) {
                                Text(
                                    "+${notice.rewardCoins} سکه",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = Color(0xB30A1119),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.40f))
                            ) {
                                Text(
                                    "هدف بعدی ${notice.nextLevelXp} XP",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Surface(
                        color = Color(0xB30A1119),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.48f))
                    ) {
                        Text(
                            "رنک: ${notice.rankLabel}",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
                            color = GoldSoft,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = onContinue,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFFD052),
                            contentColor = Color(0xFF201700)
                        ),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp)
                    ) {
                        Text("ادامه  ›", fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorldProgressDialog(
    player: PlayerState,
    onDismiss: () -> Unit
) {
    val current = currentWorldRegion(player.level)
    val next = worldRegions.firstOrNull { it.minLevel > player.level }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = {
            Column {
                Text("WORLD PROGRESSION", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                Text("${current.name} • Level ${player.level}", color = GoldSoft, fontSize = 10.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(420.dp)),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(worldRegions) { region ->
                    val unlocked = player.level >= region.minLevel
                    val active = region == current
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (active) Color(0xD2211C10) else Color(0xC916202B)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
                        border = BorderStroke(1.dp, if (active) Gold.copy(alpha = 0.75f) else Color(0x332F3A47))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(if (unlocked) Gold.copy(alpha = 0.18f) else Color(0x281A2430)),
                                contentAlignment = Alignment.Center
                            ) { Text(if (unlocked) "✦" else "🔒", color = if (unlocked) Gold else TextSoft, fontSize = 16.sp) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(region.name, color = if (unlocked) Color.White else TextSoft, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(region.subtitle, color = TextSoft, fontSize = 8.5.sp)
                            }
                            Text(if (active) "ACTIVE" else if (unlocked) "UNLOCKED" else "LV ${region.minLevel}", color = if (active) Gold else TextSoft, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (next != null) {
                    item {
                        val span = (next.minLevel - current.minLevel).coerceAtLeast(1)
                        val progress = ((player.level - current.minLevel).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                        Column(Modifier.fillMaxWidth().padding(top = 5.dp)) {
                            Text("NEXT WORLD • ${next.name} AT LEVEL ${next.minLevel}", color = GoldSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.fillMaxWidth().height(6.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFF27313C))) {
                                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Gold))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Gold) } }
    )
}

@Composable
private fun ShopDialog(
    player: PlayerState,
    rewards: List<PersonalReward>,
    redemptions: List<RewardRedemptionEntry>,
    onAdd: (PersonalReward) -> Unit,
    onUpdate: (Int, PersonalReward) -> Unit,
    onDelete: (Int) -> Unit,
    onRedeem: (Int, PersonalReward) -> RewardRedemptionStatus,
    onDismiss: () -> Unit
) {
    var message by remember { mutableStateOf<String?>(null) }
    var messageIsError by remember { mutableStateOf(false) }
    var editorIndex by remember { mutableStateOf<Int?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showChecked by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val ordered = rewards.mapIndexed { index, reward -> index to reward }
        .sortedWith(
            compareBy<Pair<Int, PersonalReward>> { it.second.completed && !it.second.reusable }
                .thenBy { if (it.second.position > 0) it.second.position else Int.MAX_VALUE }
                .thenBy { it.first }
        )
    val visible = if (showChecked) ordered else ordered.filterNot { it.second.completed && !it.second.reusable }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 84.dp, start = gamifyHorizontalPadding(), end = gamifyHorizontalPadding(), bottom = GamifySpacing.Lg),
                contentAlignment = Alignment.TopCenter
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth().fillMaxHeight(),
                    color = GamifyColors.Surface.copy(alpha = 0.96f),
                    shape = GamifyShapes.Dialog,
                    border = BorderStroke(1.dp, GamifyColors.BorderSoft)
                ) {
                    Column(Modifier.fillMaxSize().padding(GamifySpacing.Md)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    editorIndex = null
                                    showEditor = true
                                    message = null
                                },
                                modifier = Modifier.weight(1f).height(GamifyDimens.CompactButtonHeight),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                            ) { Text("+  افزودن پاداش", fontWeight = FontWeight.ExtraBold) }
                            TextButton(onClick = onDismiss, modifier = Modifier.height(GamifyDimens.CompactButtonHeight)) {
                                Text("بستن", color = TextSoft, fontSize = 11.sp)
                            }
                        }

                        message?.let { msg ->
                            Spacer(Modifier.height(6.dp))
                            Text(
                                msg,
                                color = if (messageIsError) Color(0xFFFFC7A8) else GoldSoft,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        if (showHistory) {
                            if (redemptions.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Text("هنوز پاداشی استفاده نشده", color = TextSoft, fontSize = 11.sp)
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.weight(1f).fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    items(redemptions.take(100), key = { it.transactionId }) { entry ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xD218222D)),
                                            shape = GamifyShapes.Field,
                                            border = BorderStroke(1.dp, GamifyColors.BorderSoft)
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp),
                                                horizontalAlignment = Alignment.End
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        "−${formatNumber(entry.price)} سکه",
                                                        color = Color(0xFFFFC98B),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        entry.rewardTitle,
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        textAlign = TextAlign.End,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f).padding(start = 8.dp)
                                                    )
                                                }
                                                Spacer(Modifier.height(3.dp))
                                                Text(
                                                    "${formatRewardRedemptionTime(entry.timestamp)}  •  ${if (entry.reusable) "نامحدود" else "یک‌باره"}  •  مانده ${formatNumber(entry.balanceAfter)}",
                                                    color = TextSoft,
                                                    fontSize = 9.sp,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { showHistory = false; message = null }) {
                                    Text("بازگشت به پاداش‌ها", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(visible, key = { it.second.id }) { (index, reward) ->
                                    val completedOneTime = reward.completed && !reward.reusable
                                    val affordable = player.coins >= reward.price
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (completedOneTime) Color(0xB315241E) else Color(0xD218222D)
                                        ),
                                        shape = GamifyShapes.Field,
                                        border = BorderStroke(1.dp, if (completedOneTime) GamifyColors.Success.copy(alpha = 0.55f) else GamifyColors.BorderSoft)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    if (!completedOneTime) {
                                                        val status = onRedeem(index, reward)
                                                        messageIsError = status in setOf(
                                                            RewardRedemptionStatus.InsufficientCoins,
                                                            RewardRedemptionStatus.AlreadyCompleted,
                                                            RewardRedemptionStatus.InvalidReward,
                                                            RewardRedemptionStatus.StorageFailure
                                                        )
                                                        message = when (status) {
                                                            RewardRedemptionStatus.Success -> if (reward.reusable) "${reward.title} ثبت شد" else "${reward.title} ✓"
                                                            RewardRedemptionStatus.InsufficientCoins -> "برای این پاداش سکه کافی نیست"
                                                            RewardRedemptionStatus.AlreadyCompleted -> "این پاداش قبلاً استفاده شده"
                                                            RewardRedemptionStatus.Duplicate -> "در حال ثبت پاداش…"
                                                            RewardRedemptionStatus.InvalidReward -> "پاداش پیدا نشد"
                                                            RewardRedemptionStatus.StorageFailure -> "ذخیره پاداش انجام نشد"
                                                        }
                                                    }
                                                },
                                                enabled = !completedOneTime,
                                                modifier = Modifier.size(48.dp),
                                                contentPadding = PaddingValues(0.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = when {
                                                        completedOneTime -> Color(0xFF2F8D61)
                                                        affordable -> Gold
                                                        else -> Gold.copy(alpha = 0.38f)
                                                    },
                                                    contentColor = when {
                                                        completedOneTime -> Color.White
                                                        affordable -> Color(0xFF211800)
                                                        else -> Color.White.copy(alpha = 0.82f)
                                                    },
                                                    disabledContainerColor = Color(0xFF2F8D61),
                                                    disabledContentColor = Color.White
                                                ),
                                                shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp)
                                            ) { Text("✓", fontSize = 25.sp, fontWeight = FontWeight.Black) }

                                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                                Text(
                                                    reward.title,
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth(),
                                                    textDecoration = if (completedOneTime) TextDecoration.LineThrough else TextDecoration.None
                                                )
                                                Spacer(Modifier.height(2.dp))
                                                Text(
                                                    "${formatNumber(reward.price)} سکه  •  ${if (reward.reusable) "نامحدود" else "یک‌باره"}  •  جایگاه ${reward.position.coerceAtLeast(1)}",
                                                    color = if (affordable || completedOneTime) Color(0xFFE7C96F) else Color(0xFFD7A68E),
                                                    fontSize = 9.2.sp,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                                if (reward.reusable && reward.redeemCount > 0) {
                                                    Text(
                                                        "${reward.redeemCount} بار استفاده شده",
                                                        color = TextSoft,
                                                        fontSize = 8.5.sp,
                                                        textAlign = TextAlign.End,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                }
                                            }
                                            Text(
                                                "✎",
                                                color = Color(0xFFC9D2DE),
                                                fontSize = 13.sp,
                                                modifier = Modifier.clickable {
                                                    editorIndex = index
                                                    showEditor = true
                                                    message = null
                                                }.padding(3.dp)
                                            )
                                            Text(
                                                "×",
                                                color = Color(0xFFFF8D8D),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    onDelete(index)
                                                    messageIsError = false
                                                    message = "پاداش حذف شد"
                                                }.padding(3.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { showHistory = true; message = null }) {
                                    Text("تاریخچه استفاده", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("نمایش تیک‌خورده‌ها", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = showChecked, onCheckedChange = { showChecked = it })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        val existing = editorIndex?.let { rewards.getOrNull(it) }
        RewardEditorDialog(
            initial = existing,
            rewardCount = rewards.size,
            onDismiss = { showEditor = false },
            onSave = { reward ->
                val index = editorIndex
                if (index == null) onAdd(reward) else onUpdate(index, reward)
                showEditor = false
                message = null
            }
        )
    }
}

@Composable
private fun RewardEditorDialog(
    initial: PersonalReward?,
    rewardCount: Int,
    onDismiss: () -> Unit,
    onSave: (PersonalReward) -> Unit
) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var priceText by remember(initial?.id) { mutableStateOf(initial?.price?.toString() ?: "100") }
    var reusable by remember(initial?.id) { mutableStateOf(initial?.reusable ?: false) }
    val maxPosition = (rewardCount + if (initial == null) 1 else 0).coerceAtLeast(1)
    var position by remember(initial?.id, maxPosition) {
        mutableIntStateOf((initial?.position ?: maxPosition).coerceIn(1, maxPosition))
    }
    var positionExpanded by remember { mutableStateOf(false) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = GamifyColors.Surface,
            shape = GamifyShapes.Dialog,
            title = { Text(if (initial == null) "افزودن پاداش" else "ویرایش پاداش", color = Color.White, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("نام پاداش") },
                        singleLine = true,
                        colors = readableOutlinedFieldColors(),
                        shape = GamifyShapes.Field,
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight)
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter(Char::isDigit).take(7) },
                        label = { Text("قیمت به سکه") },
                        singleLine = true,
                        colors = readableOutlinedFieldColors(),
                        shape = GamifyShapes.Field,
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(GamifySpacing.InlineGap)) {
                        SmallSelectChip("یک‌باره", !reusable, Modifier.weight(1f)) { reusable = false }
                        SmallSelectChip("نامحدود", reusable, Modifier.weight(1f)) { reusable = true }
                    }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(GamifyDimens.FieldMinHeight)
                                .clickable { positionExpanded = true },
                            color = GamifyColors.SurfaceInput,
                            shape = GamifyShapes.Field,
                            border = BorderStroke(1.dp, GamifyColors.Border)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("موقعیت: $position از $maxPosition", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("▾", color = GoldSoft, fontSize = 15.sp)
                            }
                        }
                        DropdownMenu(expanded = positionExpanded, onDismissRequest = { positionExpanded = false }) {
                            (1..maxPosition).forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("$option از $maxPosition", color = if (option == position) Gold else Color.White) },
                                    onClick = {
                                        position = option
                                        positionExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val price = priceText.toIntOrNull()?.coerceAtLeast(1) ?: 1
                        val id = initial?.id ?: "personal_${System.currentTimeMillis()}"
                        onSave(
                            PersonalReward(
                                id = id,
                                title = title.trim().ifBlank { "پاداش من" },
                                price = price,
                                reusable = reusable,
                                completed = if (reusable) false else (initial?.completed ?: false),
                                redeemCount = initial?.redeemCount ?: 0,
                                position = position
                            )
                        )
                    }
                ) { Text("ذخیره", color = Gold, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف", color = TextSoft) } }
        )
    }
}

@Composable
private fun MissionTowerScreen(
    player: PlayerState,
    hudRewardCue: HudRewardCue?,
    missions: List<Mission>,
    history: List<MissionHistoryEntry>,
    activeTimer: ActiveTimerState?,
    focusMissionIndex: Int?,
    focusRequest: Int,
    onStart: (Mission) -> Unit,
    onCreateMission: (Int, Mission) -> Unit,
    onEditMission: (Int, Mission) -> Unit,
    onDeleteMission: (Int) -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current.applicationContext
    val ordered = orderedMissionsForCurrentDay(context, missions, history, activeTimer)
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    val startPadding = 108.dp
    val nodeSpacing = 188.dp
    var showAddMission by remember { mutableStateOf(false) }
    var editingMissionIndex by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(focusRequest, ordered.map { it.second.id.ifBlank { it.second.title } }) {
        val sourceIndex = focusMissionIndex ?: return@LaunchedEffect
        if (sourceIndex !in missions.indices) return@LaunchedEffect
        val target = missions[sourceIndex]
        val displayIndex = ordered.indexOfFirst { (_, candidate) ->
            (target.id.isNotBlank() && candidate.id == target.id) ||
                (target.id.isBlank() && candidate.title == target.title)
        }
        if (displayIndex >= 0) {
            val targetScroll = with(density) {
                (displayIndex * nodeSpacing.toPx() - 32.dp.toPx()).roundToInt().coerceAtLeast(0)
            }
            scrollState.animateScrollTo(targetScroll)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        InternalGameBackdrop()

        Column(
            Modifier
                .fillMaxSize()
                .padding(top = GamifySpacing.ScreenTop, bottom = GamifySpacing.ScreenBottom)
        ) {
            TopGameHud(
                player = player,
                rewardCue = hudRewardCue,
                modifier = Modifier.padding(horizontal = gamifyHorizontalPadding())
            )
            Spacer(Modifier.height(GamifySpacing.Md))

            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = gamifyHorizontalPadding())
                    .height(44.dp)
            ) {
                Text(
                    "مسیر پیشرفت",
                    color = GoldSoft,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.Center),
                    textAlign = TextAlign.Center
                )
                Surface(
                    modifier = Modifier
                        .size(42.dp)
                        .align(Alignment.CenterEnd)
                        .clickable { showAddMission = true },
                    shape = CircleShape,
                    color = Gold.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Gold.copy(alpha = 0.55f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("+", color = GoldSoft, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))

            if (ordered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("هنوز مأموریتی ساخته نشده", color = TextSoft, fontSize = 12.sp)
                }
            } else {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    val routeHeight = 410.dp
                    val contentWidth = maxOf(maxWidth, startPadding * 2 + nodeSpacing * (ordered.size - 1) + 164.dp)
                    val nodeLayouts = remember(ordered, maxWidth, density) {
                        val baseY = with(density) { 164.dp.toPx() }
                        val amplitude = with(density) { 66.dp.toPx() }
                        val startX = with(density) { startPadding.toPx() }
                        val spacing = with(density) { nodeSpacing.toPx() }
                        ordered.indices.map { index ->
                            val wave = sin(index * 0.85f).toFloat()
                            ProgressNodeLayout(
                                xPx = (startX + index * spacing).roundToInt(),
                                yPx = (baseY + wave * amplitude).roundToInt()
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(scrollState)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(contentWidth)
                                .fillMaxHeight()
                        ) {
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(routeHeight)
                                    .align(Alignment.TopStart)
                            ) {
                                if (nodeLayouts.isNotEmpty()) {
                                    val routePath = Path().apply {
                                        moveTo(nodeLayouts.first().xPx.toFloat(), nodeLayouts.first().yPx.toFloat())
                                        for (i in 0 until nodeLayouts.lastIndex) {
                                            val startNode = nodeLayouts[i]
                                            val endNode = nodeLayouts[i + 1]
                                            val controlOffset = (endNode.xPx - startNode.xPx) * 0.5f
                                            cubicTo(
                                                startNode.xPx + controlOffset,
                                                startNode.yPx.toFloat(),
                                                endNode.xPx - controlOffset,
                                                endNode.yPx.toFloat(),
                                                endNode.xPx.toFloat(),
                                                endNode.yPx.toFloat()
                                            )
                                        }
                                    }
                                    drawPath(
                                        path = routePath,
                                        color = Gold.copy(alpha = 0.18f),
                                        style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                    drawPath(
                                        path = routePath,
                                        brush = Brush.horizontalGradient(
                                            listOf(
                                                Gold.copy(alpha = 0.96f),
                                                Color(0xFFFFE6A0),
                                                Gold.copy(alpha = 0.88f)
                                            )
                                        ),
                                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                    nodeLayouts.forEach { node ->
                                        drawCircle(
                                            color = Color(0xFFFFF1BD),
                                            radius = 4.dp.toPx(),
                                            center = Offset(node.xPx.toFloat(), node.yPx.toFloat())
                                        )
                                    }
                                }
                            }

                            ordered.forEachIndexed { displayIndex, (sourceIndex, mission) ->
                                val layout = nodeLayouts.getOrNull(displayIndex) ?: return@forEachIndexed
                                val dayState = missionDayStateForCurrentDay(context, mission, history)
                                val runningThisMission = activeTimer != null && remainingSeconds(context, activeTimer) > 0 && (
                                    (mission.id.isNotBlank() && activeTimer.mission.id == mission.id) ||
                                        (mission.id.isBlank() && activeTimer.mission.title == mission.title)
                                    )
                                val canStart = dayState == MissionDayState.Active || dayState == MissionDayState.Later
                                val accent = when (dayState) {
                                    MissionDayState.Active -> Gold
                                    MissionDayState.Later -> Gold.copy(alpha = 0.62f)
                                    MissionDayState.Done -> Color(0xFF55D98A)
                                    MissionDayState.Failed -> Color(0xFFE06666)
                                }
                                val icon = when {
                                    runningThisMission -> "▶"
                                    dayState == MissionDayState.Done -> "✓"
                                    dayState == MissionDayState.Failed -> "×"
                                    else -> "●"
                                }
                                val nodeSize = when {
                                    runningThisMission -> 70.dp
                                    displayIndex == 0 -> 64.dp
                                    dayState == MissionDayState.Active -> 58.dp
                                    else -> 52.dp
                                }
                                val nodeSizePx = with(density) { nodeSize.roundToPx() }

                                Box(
                                    modifier = Modifier
                                        .offset {
                                            IntOffset(
                                                x = layout.xPx - nodeSizePx / 2,
                                                y = layout.yPx - nodeSizePx / 2
                                            )
                                        }
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box {
                                            Surface(
                                                modifier = Modifier
                                                    .size(nodeSize)
                                                    .clickable(enabled = canStart) { onStart(mission) },
                                                shape = CircleShape,
                                                color = Color(0xFF132236).copy(alpha = if (canStart) 0.96f else 0.88f),
                                                border = BorderStroke(
                                                    if (runningThisMission || displayIndex == 0) 2.2.dp else 1.2.dp,
                                                    accent
                                                ),
                                                shadowElevation = if (runningThisMission || displayIndex == 0) 10.dp else 3.dp
                                            ) {
                                                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(if (runningThisMission || displayIndex == 0) 42.dp else 34.dp)
                                                            .clip(CircleShape)
                                                            .background(accent.copy(alpha = 0.18f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            icon,
                                                            color = accent,
                                                            fontSize = if (runningThisMission || displayIndex == 0) 20.sp else 16.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }
                                            }
                                            Surface(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .offset(x = 6.dp, y = (-6).dp)
                                                    .size(24.dp)
                                                    .clickable(enabled = !runningThisMission) { editingMissionIndex = sourceIndex },
                                                shape = CircleShape,
                                                color = Color(0xCC101A25),
                                                border = BorderStroke(1.dp, Gold.copy(alpha = 0.30f))
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        "⋮",
                                                        color = if (runningThisMission) TextSoft.copy(alpha = 0.35f) else GoldSoft,
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        Text(
                                            mission.title,
                                            color = if (dayState == MissionDayState.Done) Color(0xFFA3F0BF) else Color.White,
                                            fontSize = if (runningThisMission || displayIndex == 0) 15.sp else 13.sp,
                                            lineHeight = 18.sp,
                                            fontWeight = if (runningThisMission || displayIndex == 0) FontWeight.ExtraBold else FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = TextAlign.Center,
                                            textDecoration = when (dayState) {
                                                MissionDayState.Done, MissionDayState.Failed -> TextDecoration.LineThrough
                                                else -> null
                                            },
                                            modifier = Modifier.width(122.dp)
                                        )
                                        Spacer(Modifier.height(5.dp))
                                        Text(
                                            when {
                                                runningThisMission -> "در حال اجرا"
                                                dayState == MissionDayState.Done -> "انجام شد"
                                                dayState == MissionDayState.Failed -> "انجام نشد"
                                                else -> "${mission.durationMinutes} دقیقه"
                                            },
                                            color = accent.copy(alpha = 0.92f),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Medium,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddMission) {
            AddMissionDialog(
                initialMission = defaultMission(),
                missionCount = missions.size,
                onDismiss = { showAddMission = false },
                onCreate = { position, mission ->
                    onCreateMission(position, mission)
                    showAddMission = false
                }
            )
        }
        editingMissionIndex?.let { sourceIndex ->
            missions.getOrNull(sourceIndex)?.let { mission ->
                EditMissionDialog(
                    mission = mission,
                    currentIndex = sourceIndex,
                    missionCount = missions.size,
                    onDismiss = { editingMissionIndex = null },
                    onSave = { position, updated ->
                        onEditMission(position, updated)
                        editingMissionIndex = null
                    },
                    onDelete = {
                        onDeleteMission(sourceIndex)
                        editingMissionIndex = null
                    }
                )
            }
        }
    }
}

private data class ProgressNodeLayout(
    val xPx: Int,
    val yPx: Int
)

@Composable
private fun GameBottomNavigation(selected: Int, onSelect: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x440B1119),
                        Color(0xA80A1018),
                        Color(0xE8080D14)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0x72E5C87A), Color.Transparent)
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(size.width, 1.dp.toPx())
                )
            }
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(BottomNavType.Home, "خانه", 0),
                Triple(BottomNavType.Stats, "آمار", 1),
                Triple(BottomNavType.Settings, "تنظیمات", 2),
                Triple(BottomNavType.Profile, "پروفایل", 3)
            )
            items.forEach { (type, title, index) ->
                BottomNavItem(
                    type = type,
                    title = title,
                    selected = selected == index,
                    onClick = { onSelect(index) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    type: BottomNavType,
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconColor = if (selected) Gold else Color(0xFFB3BBC7)
    val textColor = if (selected) GoldSoft else Color(0xFFA6AFBC)

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(width = 43.dp, height = 28.dp)
                .drawBehind {
                    if (selected) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color(0x46F6C84C), Color(0x14F6C84C), Color.Transparent),
                                center = center,
                                radius = size.width * 0.52f
                            ),
                            radius = size.width * 0.52f,
                            center = center
                        )
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, Gold.copy(alpha = 0.85f), Color.Transparent)
                            ),
                            topLeft = Offset(size.width * 0.16f, 0f),
                            size = Size(size.width * 0.68f, 1.5.dp.toPx()),
                            cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx())
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            BottomNavIcon(type = type, color = iconColor)
        }
        Spacer(Modifier.height(1.dp))
        Text(
            text = title,
            color = textColor,
            fontSize = 9.5.sp,
            lineHeight = 9.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun BottomNavIcon(type: BottomNavType, color: Color) {
    Canvas(modifier = Modifier.size(GamifyIcons.Navigation)) {
        val w = size.width
        val h = size.height
        val stroke = 1.5.dp.toPx()
        when (type) {
            BottomNavType.Home -> {
                // Compact gamepad icon.
                val body = Path().apply {
                    moveTo(w * 0.22f, h * 0.42f)
                    cubicTo(w * 0.28f, h * 0.24f, w * 0.42f, h * 0.23f, w * 0.50f, h * 0.31f)
                    cubicTo(w * 0.58f, h * 0.23f, w * 0.72f, h * 0.24f, w * 0.78f, h * 0.42f)
                    lineTo(w * 0.88f, h * 0.70f)
                    cubicTo(w * 0.91f, h * 0.80f, w * 0.82f, h * 0.88f, w * 0.73f, h * 0.81f)
                    lineTo(w * 0.60f, h * 0.70f)
                    lineTo(w * 0.40f, h * 0.70f)
                    lineTo(w * 0.27f, h * 0.81f)
                    cubicTo(w * 0.18f, h * 0.88f, w * 0.09f, h * 0.80f, w * 0.12f, h * 0.70f)
                    close()
                }
                drawPath(body, color = color, style = Stroke(width = stroke))
                drawLine(color, Offset(w * 0.31f, h * 0.48f), Offset(w * 0.31f, h * 0.64f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(w * 0.23f, h * 0.56f), Offset(w * 0.39f, h * 0.56f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.67f, h * 0.51f))
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.75f, h * 0.60f))
            }
            BottomNavType.Stats -> {
                drawRoundRect(color = color, topLeft = Offset(w * 0.16f, h * 0.56f), size = Size(w * 0.14f, h * 0.28f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.43f, h * 0.38f), size = Size(w * 0.14f, h * 0.46f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.70f, h * 0.20f), size = Size(w * 0.14f, h * 0.64f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
            }
            BottomNavType.Profile -> {
                drawCircle(color = color, radius = w * 0.16f, center = Offset(w * 0.50f, h * 0.32f), style = Stroke(width = stroke))
                val shoulders = Path().apply {
                    moveTo(w * 0.20f, h * 0.82f)
                    cubicTo(w * 0.24f, h * 0.60f, w * 0.38f, h * 0.54f, w * 0.50f, h * 0.54f)
                    cubicTo(w * 0.62f, h * 0.54f, w * 0.76f, h * 0.60f, w * 0.80f, h * 0.82f)
                }
                drawPath(shoulders, color = color, style = Stroke(width = stroke, cap = StrokeCap.Round))
            }
            BottomNavType.Settings -> {
                drawCircle(color = color, radius = w * 0.23f, center = center, style = Stroke(width = stroke))
                drawCircle(color = color, radius = w * 0.07f, center = center)
                val cx = center.x
                val cy = center.y
                val r1 = w * 0.30f
                val r2 = w * 0.42f
                listOf(0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f).forEach { a ->
                    val rad = Math.toRadians(a.toDouble())
                    val p1 = Offset(cx + cos(rad).toFloat() * r1, cy + sin(rad).toFloat() * r1)
                    val p2 = Offset(cx + cos(rad).toFloat() * r2, cy + sin(rad).toFloat() * r2)
                    drawLine(color, p1, p2, strokeWidth = stroke, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun GameHome(
    player: PlayerState,
    hudRewardCue: HudRewardCue?,
    missions: List<Mission>,
    settings: GameSettings,
    onOpenDreamboard: () -> Unit,
    onOpenTree: () -> Unit,
    onOpenTimeSheet: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenWorldMap: () -> Unit,
    onOpenMissions: () -> Unit,
    history: List<MissionHistoryEntry>,
    modifier: Modifier = Modifier
 ) {
    val homeContext = LocalContext.current.applicationContext
    var homeActiveTimer by remember { mutableStateOf(recoverActiveTimer(homeContext)) }
    var homeRemaining by remember { mutableIntStateOf(homeActiveTimer?.let { remainingSeconds(homeContext, it) } ?: 0) }

    LaunchedEffect(Unit) {
        while (true) {
            val stored = loadActiveTimer(homeContext)
            if (stored == null) {
                homeActiveTimer = null
                homeRemaining = 0
            } else {
                val liveRemaining = remainingSeconds(homeContext, stored)
                if (stored.isRunning && liveRemaining <= 0) {
                    // Make foreground expiry deterministic even when system alarm
                    // delivery is late. This also persists the finished state so
                    // every screen observes the same 00:00 result.
                    TimerFinishReceiver.finishTimer(homeContext, stored.sessionId, notify = true)
                    val ended = loadActiveTimer(homeContext)
                    homeActiveTimer = ended
                    homeRemaining = ended?.let { remainingSeconds(homeContext, it) } ?: 0
                } else {
                    homeActiveTimer = stored.copy(remainingSeconds = liveRemaining)
                    homeRemaining = liveRemaining
                }
            }
            delay(250L)
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = "World Background",
            modifier = Modifier.fillMaxSize().offset(y = 60.dp),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.TopCenter
        )
        // v310: no dark/blur/tint cover over the Home artwork.


        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            TopGameHud(player, hudRewardCue)
            Spacer(Modifier.height(6.dp))
            WorldStage(
                player = player,
                missions = missions,
                settings = settings,
                onOpenDreamboard = onOpenDreamboard,
                onOpenTree = onOpenTree,
                onOpenTimeSheet = onOpenTimeSheet,
                onOpenShop = onOpenShop,
                onOpenWorldMap = onOpenWorldMap,
                onOpenMissions = onOpenMissions,
                history = history,
                activeTimer = homeActiveTimer,
                activeRemaining = homeRemaining,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun WorldStage(
    player: PlayerState,
    missions: List<Mission>,
    settings: GameSettings,
    onOpenDreamboard: () -> Unit,
    onOpenTree: () -> Unit,
    onOpenTimeSheet: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenWorldMap: () -> Unit,
    onOpenMissions: () -> Unit,
    history: List<MissionHistoryEntry>,
    activeTimer: ActiveTimerState?,
    activeRemaining: Int,
    modifier: Modifier = Modifier
) {
    val worldContext = LocalContext.current.applicationContext
    val missionStatesToday = missions.map { missionDayStateForCurrentDay(worldContext, it, history) }
    val missionNodeState = when {
        activeTimer != null && activeRemaining > 0 -> WorldNodeState.Active
        missionStatesToday.isNotEmpty() && missionStatesToday.all { it == MissionDayState.Done } -> WorldNodeState.Completed
        missionStatesToday.any { it == MissionDayState.Active || it == MissionDayState.Later || it == MissionDayState.Failed } -> WorldNodeState.Pending
        else -> WorldNodeState.Normal
    }
    // Stage 64: the world map now summarizes the other daily work areas too.
    // Tree is pending until every current member has explicitly saved today's stats.
    val treeSnapshot = remember { treeHomeSnapshot(worldContext) }
    val treeNodeState = when {
        treeSnapshot.peopleCount == 0 -> WorldNodeState.Normal
        treeSnapshot.todayCaptured -> WorldNodeState.Completed
        else -> WorldNodeState.Pending
    }
    val timeSheetNodeState = timeSheetWorldState(worldContext)
    // Dreamboard is not a daily checklist. Empty means it needs setup; once the user
    // has at least one dream it reads as established rather than demanding daily work.
    val worldDreams = loadDreamItems(worldContext)
    val dreamNodeState = if (worldDreams.isEmpty()) WorldNodeState.Pending else WorldNodeState.Completed

    // Stage 141: live cross-system metrics on the Home world landmarks.
    val todayMissionDone = missionStatesToday.count { it == MissionDayState.Done }
    val missionLiveDetail = when {
        activeTimer != null && activeRemaining > 0 -> "ACTIVE"
        missions.isEmpty() -> "NO MISSIONS"
        else -> "$todayMissionDone/${missions.size} DONE"
    }
    val networkLiveDetail = when {
        treeSnapshot.peopleCount == 0 -> "NO TEAM"
        treeSnapshot.todayCaptured -> "${treeSnapshot.peopleCount}/${treeSnapshot.peopleCount} SAVED"
        else -> "0/${treeSnapshot.peopleCount} SAVED"
    }
    val achievedDreams = worldDreams.count { it.progressSnapshot(history).achieved }
    val dreamLiveDetail = if (worldDreams.isEmpty()) "ADD DREAM" else "$achievedDreams/${worldDreams.size} ACHIEVED"
    val timeSheetLiveDetail = when (timeSheetNodeState) {
        WorldNodeState.Completed -> "TODAY DONE"
        WorldNodeState.Pending -> "PLAN ACTIVE"
        WorldNodeState.Active -> "IN PROGRESS"
        WorldNodeState.Normal -> "NO PLAN"
    }

    Box(modifier = modifier.fillMaxSize()) {
        // v305: The Home artwork itself is the navigation map. All Persian labels and
        // landmark icons are baked into world_home.png; Compose adds only transparent
        // hit areas so the artwork stays clean and visually identical to the reference.
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // v308: world_home is rendered with FillWidth, so hit areas must use the
            // rendered image height (1536/865), not the screen height. This keeps taps
            // locked to the baked artwork on different phone aspect ratios.
            val artworkTop = 60.dp
            val artworkHeight = maxWidth * (1536f / 865f)
            // v309: lift the touch target roughly one fingertip above the artwork label
            // and make every target more forgiving without changing its destination.
            val touchLift = 72.dp

            fun Modifier.worldHotspot(
                centerX: Float,
                centerY: Float,
                widthFraction: Float,
                heightFraction: Float,
                onClick: () -> Unit
            ): Modifier = this
                .offset(
                    x = maxWidth * (centerX - widthFraction / 2f),
                    y = artworkTop + artworkHeight * (centerY - heightFraction / 2f) - touchLift
                )
                .size(maxWidth * widthFraction, artworkHeight * heightFraction)
                .clickable(
                    interactionSource = MutableInteractionSource(),
                    indication = null,
                    onClick = onClick
                )

            // Exact centers of the six black baked-in labels in world_home.png.
            // Bottom -> top: Mission path, Dream castle, Time travel, Forest,
            // Shopping center, World Cup. Compose draws no label/icon over the art.
            Box(Modifier.worldHotspot(0.50f, 0.820f, 0.56f, 0.135f, onOpenMissions))
            Box(Modifier.worldHotspot(0.80f, 0.300f, 0.48f, 0.135f, onOpenDreamboard))
            Box(Modifier.worldHotspot(0.28f, 0.487f, 0.48f, 0.135f, onOpenTimeSheet))
            Box(Modifier.worldHotspot(0.80f, 0.544f, 0.48f, 0.135f, onOpenTree))
            Box(Modifier.worldHotspot(0.21f, 0.291f, 0.48f, 0.135f, onOpenShop))
            Box(Modifier.worldHotspot(0.50f, 0.164f, 0.48f, 0.135f, onOpenWorldMap))
        }

        // v298: Mission cards were removed from Home.
        // The Mission landmark above is now the single entry point to Mission Tower.
    }


}


@Composable
private fun AddMissionDialog(
    initialMission: Mission,
    missionCount: Int,
    onDismiss: () -> Unit,
    onCreate: (Int, Mission) -> Unit
) {
    MissionEditorDialog(
        titleText = "Create Mission Card",
        initialMission = initialMission,
        initialPosition = missionCount + 1,
        maxPosition = missionCount + 1,
        confirmText = "Create",
        showDelete = false,
        onDismiss = onDismiss,
        onConfirm = { position, mission -> onCreate(position - 1, mission) },
        onDelete = {}
    )
}

@Composable
private fun EditMissionDialog(
    mission: Mission,
    currentIndex: Int,
    missionCount: Int,
    onDismiss: () -> Unit,
    onSave: (Int, Mission) -> Unit,
    onDelete: () -> Unit
) {
    MissionEditorDialog(
        titleText = "Edit Mission",
        initialMission = mission,
        initialPosition = currentIndex + 1,
        maxPosition = missionCount.coerceAtLeast(1),
        confirmText = "Save",
        showDelete = true,
        onDismiss = onDismiss,
        onConfirm = { position, updated -> onSave(position - 1, updated) },
        onDelete = onDelete
    )
}

@Composable
private fun MissionEditorDialog(
    titleText: String,
    initialMission: Mission,
    initialPosition: Int,
    maxPosition: Int,
    confirmText: String,
    showDelete: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int, Mission) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(initialMission) { mutableStateOf(initialMission.title) }
    var duration by remember(initialMission) { mutableStateOf(initialMission.durationMinutes.toString()) }
    var importance by remember(initialMission) { mutableStateOf(initialMission.importance) }
    var position by remember(initialMission, initialPosition) { mutableIntStateOf(initialPosition) }
    var positionExpanded by remember { mutableStateOf(false) }
    var rankMission by remember(initialMission) { mutableStateOf(initialMission.isRankMission) }
    var repeat by remember(initialMission) { mutableStateOf(if (initialMission.repeat == MissionRepeat.None) MissionRepeat.None else MissionRepeat.Daily) }
    var reminderHour by remember(initialMission) { mutableStateOf(initialMission.reminderHour.takeIf { it >= 0 }?.toString() ?: "") }
    var subtasks by remember(initialMission) { mutableStateOf(initialMission.subtasks) }
    var newSubtask by remember(initialMission) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xF10B1620),
        shape = RoundedCornerShape(30.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MissionEditorHeaderIcon()
                Text(titleText, color = GamifyColors.TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
        },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
            ) {
                MissionDialogArtBackground(Modifier.matchParentSize())
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(490.dp)),
                    verticalArrangement = Arrangement.spacedBy(GamifySpacing.Sm)
                ) {
                    item {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                            label = { Text("عنوان مأموریت") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = duration,
                            onValueChange = { duration = it.filter(Char::isDigit).take(4) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                            label = { Text("مدت مأموریت (دقیقه)") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                    item {
                        Text("اهمیت مأموریت", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SmallSelectChip("کم", importance == MissionImportance.Low, modifier = Modifier.weight(1f)) { importance = MissionImportance.Low }
                            SmallSelectChip("متوسط", importance == MissionImportance.Medium, modifier = Modifier.weight(1f)) { importance = MissionImportance.Medium }
                            SmallSelectChip("زیاد", importance == MissionImportance.High, modifier = Modifier.weight(1f)) { importance = MissionImportance.High }
                        }
                        Spacer(Modifier.height(6.dp))
                        val previewXp = MissionDefinitionRules.xpFor(importance)
                        val previewCoins = MissionDefinitionRules.coinsFor(importance)
                        Text("پاداش: +$previewXp XP  •  +$previewCoins Coins", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x26141F2A), RoundedCornerShape(18.dp))
                                .border(1.dp, Color(0x2EF7C948), RoundedCornerShape(18.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("مأموریت رنک", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Switch(checked = rankMission, onCheckedChange = { rankMission = it })
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("نوع تکرار", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                SmallSelectChip("یک‌بار", repeat == MissionRepeat.None, modifier = Modifier.width(86.dp)) {
                                    repeat = MissionRepeat.None
                                    reminderHour = ""
                                }
                                SmallSelectChip("روزانه", repeat == MissionRepeat.Daily, modifier = Modifier.width(86.dp)) { repeat = MissionRepeat.Daily }
                            }
                        }
                    }
                    if (repeat == MissionRepeat.Daily) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("ساعت یادآوری", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                CompactHourField(
                                    value = reminderHour,
                                    onValueChange = { reminderHour = it.filter(Char::isDigit).take(2) }
                                )
                            }
                        }
                    }
                    item {
                        Text("تودوهای راهنما", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            subtasks.forEachIndexed { index, subtask ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedTextField(
                                        value = subtask,
                                        onValueChange = { value ->
                                            subtasks = subtasks.toMutableList().also { it[index] = value.take(120) }
                                        },
                                        modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                                        placeholder = { Text("تودو") },
                                        singleLine = true,
                                        colors = gamifyTextFieldColors(),
                                        shape = GamifyShapes.Field
                                    )
                                    TextButton(
                                        onClick = { subtasks = subtasks.toMutableList().also { it.removeAt(index) } }
                                    ) {
                                        Text("×", color = Color(0xFFFF7A7A), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = newSubtask,
                                    onValueChange = { newSubtask = it.take(120) },
                                    modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                                    placeholder = { Text("افزودن تودو") },
                                    singleLine = true,
                                    colors = gamifyTextFieldColors(),
                                    shape = GamifyShapes.Field
                                )
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x26F7C948))
                                        .border(1.dp, Color(0x88F7C948), CircleShape)
                                        .clickable {
                                            val clean = newSubtask.trim()
                                            if (clean.isNotEmpty()) {
                                                subtasks = subtasks + clean
                                                newSubtask = ""
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("+", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    item {
                        Text("Card position", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier.fillMaxWidth().height(GamifyDimens.FieldMinHeight).clickable { positionExpanded = true },
                                color = GamifyColors.SurfaceInput,
                                shape = GamifyShapes.Field,
                                border = BorderStroke(1.dp, GamifyColors.Border)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("$position of $maxPosition", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("▾", color = GoldSoft, fontSize = 15.sp)
                                }
                            }
                            DropdownMenu(
                                expanded = positionExpanded,
                                onDismissRequest = { positionExpanded = false }
                            ) {
                                (1..maxPosition).forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text("$option of $maxPosition", color = if (option == position) Gold else Color.White) },
                                        onClick = {
                                            position = option
                                            positionExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val hour = reminderHour.toIntOrNull()?.takeIf { it in 0..23 } ?: -1
                    onConfirm(
                        position,
                        MissionDefinitionRules.withCanonicalRewards(
                            Mission(
                                title = title.trim().ifEmpty { "مأموریت جدید" },
                                durationMinutes = duration.toIntOrNull() ?: MissionDefinitionRules.DEFAULT_DURATION_MINUTES,
                                xpReward = MissionDefinitionRules.xpFor(importance),
                                coinReward = MissionDefinitionRules.coinsFor(importance),
                                isRankMission = rankMission,
                                repeat = repeat,
                                reminderHour = if (repeat == MissionRepeat.Daily) hour else -1,
                                reminderMinute = if (repeat == MissionRepeat.Daily && hour >= 0) 0 else -1,
                                subtasks = subtasks.map { it.trim() }.filter { it.isNotEmpty() },
                                id = initialMission.id,
                                importance = importance
                            )
                        )
                    )
                }
            ) { Text(confirmText, color = Gold, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showDelete) {
                    TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFFF7A7A), fontWeight = FontWeight.Bold) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel", color = TextSoft) }
            }
        }
    )
}

@Composable
private fun MissionDialogArtBackground(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cell = size.width / 7f
        var row = 0
        var y = 0f
        while (y < size.height + cell) {
            var col = 0
            var x = 0f
            while (x < size.width + cell) {
                val color = if ((row + col) % 2 == 0) Color(0x06F7C948) else Color(0x051E4D79)
                drawRect(color = color, topLeft = Offset(x, y), size = Size(cell, cell))
                x += cell
                col++
            }
            y += cell
            row++
        }
        drawCircle(Color(0x12F7C948), radius = size.width * 0.20f, center = Offset(size.width * 0.12f, size.height * 0.18f))
        drawCircle(Color(0x0C2D6AA0), radius = size.width * 0.30f, center = Offset(size.width * 0.90f, size.height * 0.72f))
        drawRoundRect(
            color = Color(0x082B5C8E),
            topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
            size = Size(size.width * 0.18f, size.width * 0.18f),
            cornerRadius = CornerRadius(18f, 18f),
            style = Stroke(width = 2f)
        )
    }
}

@Composable
private fun MissionEditorHeaderIcon() {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0x28F7C948), Color(0x10152130))))
            .border(1.dp, Color(0x70F7C948), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            drawRoundRect(
                color = GoldSoft,
                topLeft = Offset(size.width * 0.18f, size.height * 0.18f),
                size = Size(size.width * 0.64f, size.height * 0.64f),
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 1.8f)
            )
            drawLine(GoldSoft, Offset(size.width * 0.32f, size.height * 0.40f), Offset(size.width * 0.68f, size.height * 0.40f), strokeWidth = 1.8f, cap = StrokeCap.Round)
            drawLine(GoldSoft, Offset(size.width * 0.32f, size.height * 0.58f), Offset(size.width * 0.58f, size.height * 0.58f), strokeWidth = 1.8f, cap = StrokeCap.Round)
            drawCircle(GoldSoft, radius = size.minDimension * 0.08f, center = Offset(size.width * 0.72f, size.height * 0.24f))
        }
    }
}

@Composable
private fun SmallSelectChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(38.dp).clickable(onClick = onClick),
        color = if (selected) Gold.copy(alpha = 0.16f) else GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.dp, if (selected) Gold else GamifyColors.BorderSoft)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, color = if (selected) GoldSoft else GamifyColors.TextSecondary, fontSize = 9.5.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun CompactHourField(value: String, onValueChange: (String) -> Unit) {
    Surface(
        modifier = Modifier.width(122.dp).height(GamifyDimens.CompactFieldHeight),
        color = GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.dp, GamifyColors.Border)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(
                color = GamifyColors.TextPrimary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            ),
            cursorBrush = SolidColor(Gold),
            modifier = Modifier.fillMaxSize(),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (value.isBlank()) Text("Hour", color = GamifyColors.TextMuted, fontSize = 12.sp)
                    innerTextField()
                }
            }
        )
    }
}

@Composable
private fun CompactSubtaskField(
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(GamifyDimens.FieldMinHeight),
        color = GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.5.dp, Gold)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onDone() }),
            textStyle = androidx.compose.ui.text.TextStyle(
                color = GamifyColors.TextPrimary,
                fontSize = 12.sp,
                textAlign = TextAlign.End
            ),
            cursorBrush = SolidColor(Gold),
            modifier = Modifier.fillMaxSize(),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    if (value.isBlank()) {
                        Text(
                            "Add subtask",
                            color = GamifyColors.TextMuted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    innerTextField()
                }
            }
        )
    }
}
@Composable
internal fun InternalHomeButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier.size(38.dp),
        shape = CircleShape,
        color = Color(0xCC172534),
        border = BorderStroke(1.dp, Color(0x556E8BA6))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text("⌂", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun TopGameHud(
    player: PlayerState,
    rewardCue: HudRewardCue? = null,
    modifier: Modifier = Modifier
) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    // Stage 80: HUD reads the same canonical progression snapshot as Profile.
    val progression = progressionSummary(player)
    val progress = progression.levelProgress

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(21.dp))
                .background(Brush.verticalGradient(listOf(Color(0xBC101722), Color(0xA7080D14))))
                .drawBehind {
                    val stroke = 1.2.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xAAEED68A), Color(0xAAAF7A1E), Color(0xAAF1D57D), Color(0xAA996716))
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(Color(0x12FFF4C8), Color.Transparent, Color(0x0AFFF4C8))),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 3.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1.68f), verticalAlignment = Alignment.CenterVertically) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        XpBar(progress, player.level, nearLevelUp = progress >= 0.85f)
                        Spacer(Modifier.height(3.dp))
                        val xpCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Xp || it.step == ProgressionVisualStep.Level }
                        Text(
                            xpCue?.label ?: "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP  •  ${formatNumber(progression.xpRemaining)} تا Lv ${player.level + 1}",
                            color = if (xpCue != null) Gold else Color(0xFFE8EBEF),
                            fontSize = 7.7.sp,
                            fontWeight = if (xpCue != null) FontWeight.ExtraBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.16f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text("Rank ${player.rank}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp)
                        val rankCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Rank }
                        Text(
                            rankCue?.label ?: if (progression.isMaxRank) {
                                "${rankTier.title} • MAX"
                            } else {
                                "${rankTier.title} • ${progression.rankRemaining} تا Rank ${player.rank + 1}"
                            },
                            color = if (rankCue != null) Gold else rankTier.secondary,
                            fontSize = 6.0.sp,
                            fontWeight = if (rankCue != null) FontWeight.ExtraBold else FontWeight.Normal,
                            lineHeight = 6.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        RankHudProgressBar(
                            progress = progression.rankProgressFraction,
                            accent = rankTier.secondary,
                            isMax = progression.isMaxRank,
                            nearRankUp = !progression.isMaxRank && progression.rankProgressFraction >= 0.80f
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.00f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        val coinCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Coins }
                        Text(formatNumber(player.coins), color = if (coinCue != null) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text(coinCue?.label ?: "Today", color = if (coinCue != null) Gold else GoldSoft, fontSize = 7.sp, fontWeight = if (coinCue != null) FontWeight.ExtraBold else FontWeight.Normal, lineHeight = 7.sp, maxLines = 1)
                    }
                }
                HudDivider()
                ComboHudSegment(
                    combo = player.combo,
                    rewardCue = rewardCue,
                    modifier = Modifier.weight(0.82f)
                )
            }
        }
    }
}


@Composable
private fun ComboHudSegment(
    combo: Int,
    rewardCue: HudRewardCue?,
    modifier: Modifier = Modifier
) {
    var previousCombo by remember { mutableIntStateOf(combo) }
    val activation = remember { Animatable(0f) }
    val active = combo >= ProgressionRules.COMBO_ACTIVATION_COUNT
    val comboTarget = ProgressionRules.COMBO_ACTIVATION_COUNT
    val chainProgress = combo.coerceIn(0, comboTarget)
    val nearActivation = !active && chainProgress >= (comboTarget - 2)

    LaunchedEffect(combo) {
        val justActivated = previousCombo < ProgressionRules.COMBO_ACTIVATION_COUNT &&
            combo >= ProgressionRules.COMBO_ACTIVATION_COUNT
        previousCombo = combo
        if (justActivated) {
            activation.snapTo(0f)
            activation.animateTo(1f, tween(260))
            activation.animateTo(0.42f, tween(180))
            activation.animateTo(1f, tween(220))
            activation.animateTo(0f, tween(620))
        }
    }

    val burst = activation.value
    Box(
        modifier = modifier
            .graphicsLayer {
                val bump = 1f + (0.08f * burst)
                scaleX = bump
                scaleY = bump
            }
            .drawBehind {
                if (active || burst > 0.01f) {
                    val strength = if (burst > 0.01f) 0.34f + 0.34f * burst else 0.16f
                    drawCircle(
                        color = Color(0xFFFFB52A).copy(alpha = strength),
                        radius = size.minDimension * (0.62f + 0.18f * burst),
                        center = center
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            FlameBadge(active = active || burst > 0.01f, activation = burst)
            Spacer(Modifier.width(4.dp))
            Column(verticalArrangement = Arrangement.Center) {
                val comboCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Combo }
                Text(
                    combo.toString(),
                    color = if (comboCue != null || active) Gold else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 12.sp
                )
                Text(
                    comboCue?.label ?: when {
                        active -> "×1.5 ACTIVE"
                        nearActivation -> "$chainProgress/$comboTarget • ×1.5"
                        else -> "$chainProgress/$comboTarget Combo"
                    },
                    color = if (comboCue != null || active || nearActivation) Gold else GoldSoft,
                    fontSize = if (active || nearActivation) 6.sp else 6.5.sp,
                    fontWeight = if (comboCue != null || active || nearActivation) FontWeight.ExtraBold else FontWeight.Normal,
                    lineHeight = 7.sp,
                    maxLines = 1
                )
                Spacer(Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
                    repeat(comboTarget) { index ->
                        Box(
                            Modifier
                                .size(width = 5.dp, height = 2.dp)
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(2.dp))
                                .background(if (index < chainProgress) Gold else Color(0x45FFFFFF))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    // Stage 72: the level number itself reacts at the exact rollover frame.
    // This makes the threshold crossing readable even when one reward skips
    // through more than one level.
    val levelPulse = remember { Animatable(1f) }
    LaunchedEffect(level) {
        if (level > 1) {
            levelPulse.snapTo(1.16f)
            levelPulse.animateTo(1f, animationSpec = tween(260))
        }
    }
    Box(
        modifier = Modifier
            .size(41.dp)
            .graphicsLayer { scaleX = levelPulse.value; scaleY = levelPulse.value },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f
            drawCircle(brush = Brush.sweepGradient(tier.ringColors), radius = radius, style = Stroke(width = stroke))
            drawCircle(color = Color(0xFF10141B), radius = size.minDimension * 0.36f)
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )
            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                drawCircle(
                    color = GoldSoft,
                    radius = dotR,
                    center = Offset(cx + cos(rad).toFloat() * ringR, cy + sin(rad).toFloat() * ringR)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float, level: Int, nearLevelUp: Boolean = false) {
    // Stage 72: every level boundary gets a short gold flash. The XP state
    // itself is still supplied by ProgressionAnimation, so the bar visibly
    // fills to 100%, resets, then continues with overflow XP in the next level.
    val boundaryFlash = remember { Animatable(0f) }
    LaunchedEffect(level) {
        if (level > 1) {
            boundaryFlash.snapTo(1f)
            boundaryFlash.animateTo(0f, animationSpec = tween(320))
        }
    }
    val nearTransition = rememberInfiniteTransition(label = "nearLevelUp")
    val nearPulse by nearTransition.animateFloat(
        initialValue = 0.18f,
        targetValue = 0.78f,
        animationSpec = infiniteRepeatable(animation = tween(920), repeatMode = RepeatMode.Reverse),
        label = "nearLevelUpPulse"
    )
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .drawBehind {
                if (nearLevelUp) {
                    drawRoundRect(
                        color = Gold.copy(alpha = 0.12f + nearPulse * 0.18f),
                        topLeft = Offset(-2.dp.toPx(), -2.dp.toPx()),
                        size = Size(size.width + 4.dp.toPx(), size.height + 4.dp.toPx()),
                        cornerRadius = CornerRadius(50.dp.toPx(), 50.dp.toPx())
                    )
                }
            }
            .clip(shape)
            .background(Color(0xFF242B34))
            .border(
                width = (1f + boundaryFlash.value * 1.2f + if (nearLevelUp) nearPulse * 0.45f else 0f).dp,
                color = if (nearLevelUp) Gold.copy(alpha = 0.45f + nearPulse * 0.35f) else Color(0x805E4A20).copy(alpha = 0.50f + boundaryFlash.value * 0.50f),
                shape = shape
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
        if (boundaryFlash.value > 0.01f) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(Color(0xFFFFE58B).copy(alpha = 0.34f * boundaryFlash.value))
            )
        }
    }
}

private fun DrawScope.starPath(center: Offset, outerRadius: Float, innerRadius: Float, points: Int = 5): Path {
    val path = Path()
    val angle = Math.PI / points
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val theta = i * angle - Math.PI / 2
        val x = center.x + cos(theta).toFloat() * r
        val y = center.y + sin(theta).toFloat() * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
private fun RankHudProgressBar(progress: Float, accent: Color, isMax: Boolean, nearRankUp: Boolean = false) {
    val nearTransition = rememberInfiniteTransition(label = "nearRankUp")
    val nearPulse by nearTransition.animateFloat(
        initialValue = 0.20f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(animation = tween(1040), repeatMode = RepeatMode.Reverse),
        label = "nearRankUpPulse"
    )
    val rankShape = androidx.compose.foundation.shape.RoundedCornerShape(99.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (nearRankUp) 4.dp else 3.dp)
            .drawBehind {
                if (nearRankUp) {
                    drawRoundRect(
                        color = accent.copy(alpha = 0.16f + nearPulse * 0.24f),
                        topLeft = Offset(-1.dp.toPx(), -1.dp.toPx()),
                        size = Size(size.width + 2.dp.toPx(), size.height + 2.dp.toPx()),
                        cornerRadius = CornerRadius(99.dp.toPx(), 99.dp.toPx())
                    )
                }
            }
            .clip(rankShape)
            .background(Color(0x442A3440))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(if (isMax) 1f else progress.coerceIn(0f, 1f))
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(99.dp))
                .background(accent)
        )
    }
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(GamifyIcons.Hero), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                lineTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.80f, h * 0.66f)
                quadraticBezierTo(w * 0.66f, h * 0.87f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.87f, w * 0.20f, h * 0.66f)
                lineTo(w * 0.14f, h * 0.18f)
                close()
            }
            drawPath(shield, brush = Brush.verticalGradient(listOf(tier.secondary.copy(alpha = 0.18f), tier.primary)))
            drawPath(shield, color = tier.secondary, style = Stroke(width = 1.6f))
            val inner = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.77f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.61f)
                quadraticBezierTo(w * 0.61f, h * 0.77f, w * 0.50f, h * 0.83f)
                quadraticBezierTo(w * 0.39f, h * 0.77f, w * 0.28f, h * 0.61f)
                lineTo(w * 0.23f, h * 0.24f)
                close()
            }
            drawPath(inner, color = Color(0x14FFFFFF))
            val star = starPath(Offset(w * 0.50f, h * 0.44f), outerRadius = w * 0.17f, innerRadius = w * 0.07f)
            drawPath(star, color = GoldSoft)
        }
    }
}

@Composable
private fun CoinBadge() {
    Box(Modifier.size(GamifyIcons.Feature), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFF0B5), Color(0xFFF5C84F), Color(0xFFC88715))),
                radius = size.minDimension / 2f,
                center = center
            )
            drawCircle(color = Color(0x30FFFFFF), radius = size.minDimension * 0.34f, center = Offset(center.x, center.y - 1.dp.toPx()))
            drawCircle(color = Color(0xB9784B0A), radius = size.minDimension / 2f - 0.6.dp.toPx(), center = center, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(color = Color(0xFFFCE9A7), radius = size.minDimension / 2f - 1.4.dp.toPx(), center = center, style = Stroke(width = 0.8.dp.toPx()))
            val star = starPath(center, outerRadius = size.minDimension * 0.18f, innerRadius = size.minDimension * 0.08f)
            drawPath(star, color = Color(0xFF7A4E00))
        }
    }
}

@Composable
private fun FlameBadge(active: Boolean = false, activation: Float = 0f) {
    Box(
        modifier = Modifier
            .size(GamifyIcons.Standard)
            .graphicsLayer {
                val pulse = 1f + activation * 0.16f
                scaleX = pulse
                scaleY = pulse
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            if (active) {
                drawCircle(
                    color = Color(0xFFFFC247).copy(alpha = 0.20f + activation * 0.32f),
                    radius = size.minDimension * (0.52f + activation * 0.14f)
                )
            }
            drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))))
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(inner, brush = Brush.verticalGradient(listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))))
        }
    }
}

@Composable
private fun HudDivider() {
    Box(Modifier.width(1.dp).height(31.dp).background(Divider))
}

@Composable
private fun Reward(text: String, color: Color, fontSize: TextUnit = 12.5.sp) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = fontSize)
}
