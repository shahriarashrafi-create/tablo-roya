package com.shahriar.gamify

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class TimerFinishReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val expectedSessionId = intent?.getLongExtra(EXTRA_TIMER_SESSION_ID, 0L) ?: 0L
        finishTimer(context, expectedSessionId, notify = true)
    }

    companion object {
        internal fun finishTimer(context: Context, expectedSessionId: Long = 0L, notify: Boolean) {
            val state = loadActiveTimer(context) ?: run {
                // No persisted timer means no mission session should still own a
                // foreground notification/music process. This is safe because there
                // is no newer persisted session to interrupt.
                cancelTimerAlarm(context)
                MissionMusicController.stop()
                MissionSessionService.stop(context.applicationContext)
                return
            }
            // A stale alarm for an older session must never stop a newer mission.
            if (expectedSessionId > 0L && state.sessionId != expectedSessionId) return
            if (!state.isRunning && state.remainingSeconds <= 0) {
                // A UI/system recovery path may reach the finished state before the
                // scheduled receiver fires. Cancel any still-pending alarm as part of
                // the same idempotent cleanup so nothing can re-fire later.
                cancelTimerAlarm(context)
                MissionMusicController.stop()
                MissionSessionService.stop(context.applicationContext)
                if (notify) postFinishedNotification(context, state)
                return
            }

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putInt(KEY_TIMER_REMAINING, 0)
                .putLong(KEY_TIMER_END_AT, 0L)
                .putLong(KEY_TIMER_END_ELAPSED, 0L)
                .putInt(KEY_TIMER_BOOT_COUNT, -1)
                .putBoolean(KEY_TIMER_RUNNING, false)
                .apply()
            cancelTimerAlarm(context)
            MissionMusicController.stop()
            MissionSessionService.stop(context.applicationContext)

            if (notify) postFinishedNotification(context, state.copy(remainingSeconds = 0, endAtMillis = 0L, isRunning = false))
        }

        private fun postFinishedNotification(context: Context, state: ActiveTimerState) {
            val settings = loadSettings(context)
            if (!notificationsAllowed(context, settings)) return
            ensureNotificationChannels(context, settings)

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_OPEN_MISSION_ID, state.mission.id)
            }
            val contentIntent = PendingIntent.getActivity(
                context,
                (state.sessionId xor (state.sessionId ushr 32)).toInt(),
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val doneIntent = timerResultPendingIntent(context, state.sessionId, MissionResult.Done)
            val laterIntent = timerResultPendingIntent(context, state.sessionId, MissionResult.Defer)
            val failedIntent = timerResultPendingIntent(context, state.sessionId, MissionResult.Fail)
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(context, TIMER_CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION") Notification.Builder(context)
            }
            builder
                .setSmallIcon(R.drawable.ic_timer)
                .setContentTitle("زمان مأموریت تمام شد")
                .setContentText("${state.mission.title} • نتیجه را ثبت کن")
                .setContentIntent(contentIntent)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(
                    Notification.Action.Builder(R.drawable.ic_done_action, "انجام شد", doneIntent).build()
                )
                .addAction(
                    Notification.Action.Builder(R.drawable.ic_later_action, "بعداً", laterIntent).build()
                )
                .addAction(
                    Notification.Action.Builder(R.drawable.ic_failed_action, "انجام نشد", failedIntent).build()
                )

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(TIMER_FINISHED_NOTIFICATION_ID, builder.build())
        }
    }
}
