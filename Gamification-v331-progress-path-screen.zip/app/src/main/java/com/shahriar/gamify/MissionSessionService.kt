package com.shahriar.gamify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * v302 persistent mission owner.
 * Keeps the mission process/music alive while the UI is on Home, another screen,
 * in background, or the device is locked. AlarmManager remains the authoritative
 * timer finish path, so elapsed time never depends on this service ticking.
 */
class MissionSessionService : Service() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val timer = recoverActiveTimer(applicationContext)
        if (timer == null || !timer.isRunning || remainingSeconds(applicationContext, timer) <= 0) {
            removeForegroundNotification()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification(timer))
        MissionMusicController.ensureForTimer(applicationContext, loadSettings(applicationContext), timer)
        return START_STICKY
    }

    override fun onDestroy() {
        // A stopped/finished mission must never leave the persistent "active mission"
        // notification behind. Music is still owned by the authoritative timer/result
        // cleanup paths so a transient service recreation cannot silence a live session.
        removeForegroundNotification()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun removeForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.cancel(NOTIFICATION_ID)
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Active mission", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the active mission timer and focus music running"
                    setSound(null, null)
                }
            )
        }
    }

    private fun notification(timer: ActiveTimerState): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(EXTRA_OPEN_MISSION_ID, timer.mission.id)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, 302, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("مأموریت در حال اجرا")
            .setContentText(timer.mission.title)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "mission_session_v302"
        private const val NOTIFICATION_ID = 7302

        fun start(context: Context) {
            val intent = Intent(context, MissionSessionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MissionSessionService::class.java))
            // stopService normally removes a foreground notification, but explicitly
            // cancel it as well so process/service timing can never leave a stale card.
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(NOTIFICATION_ID)
        }
    }
}
