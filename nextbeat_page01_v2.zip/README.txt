NextBeat — Page 01 — v2

این ZIP مخصوص Workflow فعلی شماست:
- پروژه Android/Gradle مستقیم در ریشه ZIP است.
- settings.gradle.kts در ریشه قرار دارد تا مرحله Find Android project آن را پیدا کند.
- Java 17
- compileSdk 35
- خروجی Debug APK با assembleDebug
- هیچ فایل Workflow داخل ZIP قرار نگرفته است.

نکته:
اگر GitHub Actions قبل از مرحله Build debug APK و در خود مرحله
Set up Android SDK
متوقف شود، آن خطا مربوط به اکشن setup-android است و قبل از اجرای پروژه رخ می‌دهد.
