@echo off
setlocal
set GRADLE_VERSION=8.9
set GRADLE_HOME_BASE=%USERPROFILE%\.gradle\journey-wrapper
set INSTALL_DIR=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%INSTALL_DIR%\bin\gradle.bat
set ZIP_FILE=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%-bin.zip
set DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_HOME_BASE%" mkdir "%GRADLE_HOME_BASE%"
  if not exist "%ZIP_FILE%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%ZIP_FILE%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_FILE%' '%GRADLE_HOME_BASE%'"
)

call "%GRADLE_BIN%" %*
endlocal
