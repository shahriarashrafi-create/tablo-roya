Journey v54

Changes in this version:
- Replaced the previous header with a new compact blue HUD-style header similar to the approved mockup.
- Added the business anime avatar as the header profile image.
- Replaced the launcher icon with the same avatar image.
- Kept the current home background/touch calibration from v53.
- Settings backup actions remain available (Export / Import).

Version v58: updated home background with final high-quality six-panel artwork.

## v59
- Replaced the Home background with the supplied final 1:2 artwork at original quality.
- Recalibrated all six Home touch zones to the visible wide cards.
- Preserved the requested +1dp downward touch offset.
- Ensured Header and Bottom Bar are layered above Home touch zones.
