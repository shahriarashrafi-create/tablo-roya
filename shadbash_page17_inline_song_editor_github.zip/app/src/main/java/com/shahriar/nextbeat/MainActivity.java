package com.shahriar.nextbeat;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 1001;

    private WebView webView;
    private long lastBackPressed = 0L;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean pendingAudioChooser = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(6, 17, 44));
        getWindow().setNavigationBarColor(Color.rgb(6, 17, 44));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setBackgroundColor(Color.rgb(6, 17, 44));
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;
                pendingAudioChooser = false;

                String[] accepts = fileChooserParams.getAcceptTypes();
                if (accepts != null) {
                    for (String accept : accepts) {
                        if (accept != null && accept.toLowerCase().contains("audio")) {
                            pendingAudioChooser = true;
                            break;
                        }
                    }
                }

                Intent intent = fileChooserParams.createIntent();

                try {
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    pendingAudioChooser = false;
                    Toast.makeText(MainActivity.this, "باز کردن انتخاب فایل ممکن نشد", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != REQ_FILE_CHOOSER) return;
        if (filePathCallback == null) return;

        Uri[] results = null;
        Uri selectedUri = null;

        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedUri = data.getData();
            results = new Uri[]{selectedUri};
        }

        if (selectedUri != null && pendingAudioChooser) {
            importAudioToAppStorage(selectedUri);
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        pendingAudioChooser = false;
    }

    private void importAudioToAppStorage(Uri sourceUri) {
        try {
            String originalName = getDisplayName(sourceUri);
            if (originalName == null || originalName.trim().isEmpty()) {
                originalName = "audio_" + System.currentTimeMillis() + ".mp3";
            }

            String safeName = originalName.replaceAll("[^a-zA-Z0-9._-]", "_");
            File songsDir = new File(getFilesDir(), "songs");
            if (!songsDir.exists() && !songsDir.mkdirs()) {
                throw new Exception("Could not create songs directory");
            }

            File destination = new File(
                    songsDir,
                    System.currentTimeMillis() + "_" + safeName
            );

            try (
                    InputStream in = getContentResolver().openInputStream(sourceUri);
                    FileOutputStream out = new FileOutputStream(destination)
            ) {
                if (in == null) throw new Exception("Input stream is null");

                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            }

            String localUrl = Uri.fromFile(destination).toString();
            String js = "window.onNativeAudioImported && window.onNativeAudioImported("
                    + JSONObject.quote(originalName) + ","
                    + JSONObject.quote(localUrl) + ");";

            webView.post(() -> webView.evaluateJavascript(js, null));

        } catch (Exception e) {
            Toast.makeText(this, "ذخیره فایل آهنگ انجام نشد", Toast.LENGTH_SHORT).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = null;
        Cursor cursor = null;

        try {
            cursor = getContentResolver().query(
                    uri,
                    new String[]{OpenableColumns.DISPLAY_NAME},
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    result = cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }

        return result;
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript("window.appBack ? window.appBack() : false;", value -> {
            String v = value == null ? "false" : value.replace("\"", "");
            if ("true".equalsIgnoreCase(v)) {
                return;
            }

            long now = SystemClock.elapsedRealtime();
            if (now - lastBackPressed < 1800) {
                MainActivity.super.onBackPressed();
            } else {
                lastBackPressed = now;
                Toast.makeText(
                        MainActivity.this,
                        "برای خروج دوباره بازگشت را بزنید",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void noop() {}

        @JavascriptInterface
        public void deleteLocalFile(String localUrl) {
            try {
                Uri uri = Uri.parse(localUrl);
                String path = uri.getPath();
                if (path == null) return;

                File file = new File(path);
                File songsDir = new File(getFilesDir(), "songs");

                String fileCanonical = file.getCanonicalPath();
                String dirCanonical = songsDir.getCanonicalPath();

                if (fileCanonical.startsWith(dirCanonical + File.separator) && file.exists()) {
                    file.delete();
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void exportTextFile(String fileName, String text) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(
                                MediaStore.Downloads.RELATIVE_PATH,
                                Environment.DIRECTORY_DOWNLOADS + "/Shadbash"
                        );

                        Uri uri = getContentResolver().insert(
                                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                                values
                        );

                        if (uri == null) throw new Exception("uri null");

                        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                            if (os == null) throw new Exception("stream null");
                            os.write(text.getBytes(StandardCharsets.UTF_8));
                        }
                    } else {
                        File dir = new File(
                                getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                                "Shadbash"
                        );

                        if (!dir.exists()) dir.mkdirs();

                        File file = new File(dir, fileName);
                        try (FileOutputStream fos = new FileOutputStream(file)) {
                            fos.write(text.getBytes(StandardCharsets.UTF_8));
                        }
                    }

                    Toast.makeText(MainActivity.this, "فایل Export ذخیره شد", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ذخیره فایل انجام نشد", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
