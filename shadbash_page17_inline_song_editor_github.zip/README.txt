shadbash - Inline Song Editor

Changes:
- Song test moved inside each song's Edit section.
- Removed the separate Test page.
- During test you can move freely inside the selected test range:
  - drag the seek bar
  - -5 seconds
  - +5 seconds
  - jump to start
  - play/pause
  - stop
- Two test modes:
  - Question: Start -> Stop
  - Continuation: Start -> Final
- Song list is now one compact line per song:
  - ✓ ready / × needs fix
  - song name
  - start second
  - edit icon
- Removed long descriptions and extra metadata from song rows.
- File selection is now an icon instead of a text selector.
- Song name and singer name are on the same row as the file icon.
- Delete moved inside Edit.
- Existing three-time flow, backup/import, error states, back-to-reset confirmation, scoring and final results remain.
