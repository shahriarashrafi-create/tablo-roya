package com.shahriar.gamify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Applies one of the three timer-finish notification actions without opening
 * the Activity. The persisted timer session ID is mandatory, and the same
 * finalizeActiveMissionSession() path used by Compose remains the only writer
 * of mission rewards/history, so repeated taps cannot grant rewards twice.
 */
class MissionResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val source = intent ?: return
        val result = when (source.action) {
            ACTION_TIMER_RESULT_DONE -> MissionResult.Done
            ACTION_TIMER_RESULT_LATER -> MissionResult.Defer
            ACTION_TIMER_RESULT_FAILED -> MissionResult.Fail
            else -> return
        }
        val expectedSessionId = source.getLongExtra(EXTRA_TIMER_RESULT_SESSION_ID, 0L)
        if (expectedSessionId <= 0L) return

        val timer = loadActiveTimer(context) ?: run {
            cancelTimerFinishedNotification(context)
            return
        }
        if (timer.sessionId != expectedSessionId) {
            // A stale notification must never resolve a newer timer session.
            cancelTimerFinishedNotification(context)
            return
        }
        if (timer.isRunning || timer.remainingSeconds > 0) return

        val focusSeconds = (timer.mission.durationMinutes.coerceAtLeast(1) * 60)
        val committed = finalizeActiveMissionSession(context, result, focusSeconds) ?: return

        cancelTimerFinishedNotification(context)
        markExternalMissionResultApplied(context, committed.sessionId)
    }
}
