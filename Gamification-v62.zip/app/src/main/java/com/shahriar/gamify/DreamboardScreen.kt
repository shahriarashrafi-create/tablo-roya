package com.shahriar.gamify

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.max

@Composable
internal fun DreamboardDialog(
    dreams: List<DreamItem>,
    onAdd: (DreamItem) -> Unit,
    onUpdate: (DreamItem) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var editorId by remember { mutableStateOf<String?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var fullscreenId by remember { mutableStateOf<String?>(null) }
    val ordered = DreamboardEngine.normalize(dreams)
    val pagerState = rememberPagerState(pageCount = { ordered.size + 1 })
    val activeDream = ordered.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF071019)),
            contentAlignment = Alignment.Center
        ) {
            DreamboardBackdrop(activeDream)

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 34.dp),
                pageSpacing = 14.dp,
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                val distance = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                    .coerceIn(0f, 1f)
                val pageScale = 1f - (0.075f * distance)
                val pageAlpha = 1f - (0.30f * distance)

                if (page < ordered.size) {
                    val dream = ordered[page]
                    DreamboardCard(
                        dream = dream,
                        onTap = { fullscreenId = dream.id },
                        onLongPress = { editorId = dream.id; showEditor = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                            .graphicsLayer {
                                scaleX = pageScale
                                scaleY = pageScale
                                alpha = pageAlpha
                            }
                    )
                } else {
                    AddDreamCard(
                        onClick = { editorId = null; showEditor = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                            .graphicsLayer {
                                scaleX = pageScale
                                scaleY = pageScale
                                alpha = pageAlpha
                            }
                    )
                }
            }

            if (activeDream != null) {
                DreamPageIndicator(
                    current = pagerState.currentPage + 1,
                    total = ordered.size,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 18.dp)
                )
            }
        }
    }

    fullscreenId?.let { id ->
        DreamFullscreenDialog(
            dreams = ordered,
            initialId = id,
            onDismiss = { fullscreenId = null }
        )
    }

    if (showEditor) {
        val existing = editorId?.let { id -> dreams.firstOrNull { it.id == id } }
        DreamEditorDialog(
            initial = existing,
            totalCount = dreams.size,
            onDismiss = { showEditor = false },
            onDelete = existing?.let { dream ->
                {
                    onDelete(dream.id)
                    showEditor = false
                }
            },
            onSave = { item ->
                if (existing == null) onAdd(item) else onUpdate(item)
                showEditor = false
            }
        )
    }
}

@Composable
private fun DreamboardCard(
    dream: DreamItem,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }
    Card(
        modifier = modifier.pointerInput(dream.id) {
            detectTapGestures(
                onTap = { onTap() },
                onLongPress = { onLongPress() }
            )
        },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111A24)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x665F6D7C))
    ) {
        Box(Modifier.fillMaxSize()) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = dream.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF223244), Color(0xFF0F1721)))
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("DREAM", color = Color(0x55FFFFFF), fontSize = 32.sp, fontWeight = FontWeight.Black)
                }
            }

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(92.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD8000000))))
            )

            DreamMetadataOverlay(
                dream = dream,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun DreamboardBackdrop(dream: DreamItem?) {
    val context = LocalContext.current
    val backdrop = remember(dream?.imageUri) {
        dream?.imageUri?.takeIf { it.isNotBlank() }?.let { loadDreamBackdropBitmap(context, it) }
    }

    if (backdrop != null) {
        Image(
            bitmap = backdrop,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.10f
                    scaleY = 1.10f
                    alpha = 0.74f
                },
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF142235), Color(0xFF071019), Color(0xFF04080D))
                    )
                )
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xAA02060A),
                        Color(0x72040A10),
                        Color(0xC9070C12)
                    )
                )
            )
    )
}

@Composable
private fun DreamPageIndicator(
    current: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    if (total <= 0) return
    Surface(
        modifier = modifier,
        color = Color(0xC20A1118),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, Color(0x55FFFFFF))
    ) {
        Text(
            "$current/$total",
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun DreamMetadataOverlay(
    dream: DreamItem,
    modifier: Modifier = Modifier,
    roomy: Boolean = false
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    horizontal = if (roomy) 20.dp else 16.dp,
                    vertical = if (roomy) 22.dp else 18.dp
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                dream.price.filter(Char::isDigit).let { if (it.isBlank()) "" else "$it \$" },
                color = GoldSoft,
                fontSize = if (roomy) 14.sp else 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Start,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                dream.year.trim().let { if (it.isBlank()) "" else "سال $it" },
                color = Color.White,
                fontSize = if (roomy) 13.sp else 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(0.72f),
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text(
                dream.title,
                color = Color.White,
                fontSize = if (roomy) 16.sp else 14.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1.45f),
                textAlign = TextAlign.End,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DreamFullscreenDialog(
    dreams: List<DreamItem>,
    initialId: String,
    onDismiss: () -> Unit
) {
    if (dreams.isEmpty()) return
    val initialIndex = dreams.indexOfFirst { it.id == initialId }.let { if (it < 0) 0 else it }
    val pagerState = rememberPagerState(
        initialPage = initialIndex,
        pageCount = { dreams.size }
    )
    val activeDream = dreams.getOrNull(pagerState.currentPage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            DreamboardBackdrop(activeDream)

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp),
                pageSpacing = 8.dp,
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                val dream = dreams[page]
                val context = LocalContext.current
                val bitmap = remember(dream.imageUri) { loadDreamBitmap(context, dream.imageUri) }

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .padding(
                            top = 14.dp,
                            bottom = 14.dp,
                            start = 4.dp,
                            end = 4.dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f),
                        color = Color(0xFF0B1118),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0x44FFFFFF))
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = dream.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color(0xFF223244), Color(0xFF0F1721))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "DREAM",
                                        color = Color(0x55FFFFFF),
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Box(
                                Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .height(116.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color(0xE8000000))
                                        )
                                    )
                            )
                            DreamMetadataOverlay(
                                dream = dream,
                                modifier = Modifier.align(Alignment.BottomCenter),
                                roomy = true
                            )
                        }
                    }
                }
            }

            DreamPageIndicator(
                current = pagerState.currentPage + 1,
                total = dreams.size,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp)
            )
        }
    }
}

@Composable
private fun AddDreamCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = Color(0xFF101923),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color(0x667E8C9E))
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF172432), Color(0xFF09111A)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("+", color = Gold, fontSize = 54.sp, fontWeight = FontWeight.Light)
                Text("Add Dream", color = Color(0xFFD9E1EA), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun DreamCropDialog(
    sourceUri: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val context = LocalContext.current
    val source = remember(sourceUri) { loadDreamSourceBitmap(context, sourceUri) }
    var scale by remember(sourceUri) { mutableStateOf(1f) }
    var offset by remember(sourceUri) { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            color = GamifyColors.Surface,
            shape = GamifyShapes.Dialog
        ) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Crop", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 16f)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .onSizeChanged { viewport = it }
                        .pointerInput(sourceUri, viewport) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 4f)
                                if (source != null && viewport.width > 0 && viewport.height > 0) {
                                    val baseScale = max(
                                        viewport.width.toFloat() / source.width.toFloat(),
                                        viewport.height.toFloat() / source.height.toFloat()
                                    )
                                    val scaledW = source.width * baseScale * newScale
                                    val scaledH = source.height * baseScale * newScale
                                    val maxX = ((scaledW - viewport.width) / 2f).coerceAtLeast(0f)
                                    val maxY = ((scaledH - viewport.height) / 2f).coerceAtLeast(0f)
                                    offset = Offset(
                                        (offset.x + pan.x).coerceIn(-maxX, maxX),
                                        (offset.y + pan.y).coerceIn(-maxY, maxY)
                                    )
                                } else {
                                    offset += pan
                                }
                                scale = newScale
                            }
                        }
                ) {
                    if (source != null) {
                        Image(
                            bitmap = source.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    scaleX = scale
                                    scaleY = scale
                                    translationX = offset.x
                                    translationY = offset.y
                                },
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Unable to load image", color = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Drag to move • Pinch to zoom", color = TextSoft, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel", color = TextSoft)
                    }
                    Button(
                        onClick = {
                            val bitmap = source ?: return@Button
                            saveDreamCrop(context, bitmap, viewport, scale, offset)?.let(onSave)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                    ) { Text("Save", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun DreamEditorDialog(
    initial: DreamItem?,
    totalCount: Int,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (DreamItem) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var year by remember(initial?.id) { mutableStateOf(initial?.year.orEmpty()) }
    var price by remember(initial?.id) { mutableStateOf(initial?.price?.filter(Char::isDigit).orEmpty()) }
    var imageUri by remember(initial?.id) { mutableStateOf(initial?.imageUri.orEmpty()) }
    val maxPosition = if (initial == null) totalCount else (totalCount - 1).coerceAtLeast(0)
    val positionCount = if (initial == null) totalCount + 1 else totalCount.coerceAtLeast(1)
    var position by remember(initial?.id, totalCount) {
        mutableIntStateOf((initial?.position ?: totalCount).coerceIn(0, maxPosition))
    }
    var positionMenu by remember { mutableStateOf(false) }
    var pendingCropUri by remember { mutableStateOf<String?>(null) }
    val originalImageUri = initial?.imageUri.orEmpty()

    fun discardUnsavedCrop() {
        if (imageUri.isNotBlank() && imageUri != originalImageUri) {
            deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
        }
    }

    fun dismissEditor() {
        discardUnsavedCrop()
        onDismiss()
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pendingCropUri = uri.toString()
        }
    }
    val preview = remember(imageUri) { loadDreamBitmap(context, imageUri) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(onDismissRequest = { dismissEditor() }) {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                color = GamifyColors.Surface,
                shape = GamifyShapes.Dialog,
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight()).padding(GamifySpacing.Md),
                    verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(contentAlignment = Alignment.BottomCenter) {
                                Surface(
                                    modifier = Modifier
                                        .width(118.dp)
                                        .aspectRatio(9f / 16f)
                                        .clickable { imagePicker.launch(arrayOf("image/*")) },
                                    color = Color(0xFF16202B),
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                                    border = BorderStroke(1.dp, Color(0x667E8C9E))
                                ) {
                                    if (preview != null) {
                                        Image(
                                            bitmap = preview,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("+", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Light)
                                        }
                                    }
                                }
                                Surface(
                                    modifier = Modifier.padding(bottom = 8.dp).clickable { imagePicker.launch(arrayOf("image/*")) },
                                    color = Color(0xD90A1118),
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, Color(0x55E6C969))
                                ) {
                                    Text("تغییر عکس", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                                }
                            }
                        }
                    }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("عنوان", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it.take(80) },
                                placeholder = { Text("عنوان رویا") },
                                singleLine = true,
                                colors = readableOutlinedFieldColors(),
                                modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                                shape = GamifyShapes.Field
                            )
                        }
                    }

                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("سال", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = year,
                                    onValueChange = { year = it.filter(Char::isDigit).take(4) },
                                    placeholder = { Text("۱۴۰۷") },
                                    singleLine = true,
                                    colors = readableOutlinedFieldColors(),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                                    shape = GamifyShapes.Field
                                )
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("قیمت", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = price,
                                    onValueChange = { price = it.filter(Char::isDigit).take(15) },
                                    placeholder = { Text("25000") },
                                    singleLine = true,
                                    trailingIcon = { Text("\$", color = GoldSoft, fontWeight = FontWeight.Bold) },
                                    colors = readableOutlinedFieldColors(),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                                    shape = GamifyShapes.Field
                                )
                            }
                        }
                    }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("ترتیب نمایش", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Box {
                                Surface(
                                    modifier = Modifier.fillMaxWidth().height(GamifyDimens.FieldMinHeight).clickable { positionMenu = true },
                                    color = GamifyColors.SurfaceInput,
                                    shape = GamifyShapes.Field,
                                    border = BorderStroke(1.dp, GamifyColors.Border)
                                ) {
                                    Row(
                                        Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("انتخاب جایگاه", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                                        Text(
                                            "${position + 1} از $positionCount",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                DropdownMenu(expanded = positionMenu, onDismissRequest = { positionMenu = false }) {
                                    for (i in 0..maxPosition) {
                                        DropdownMenuItem(
                                            text = { Text("جایگاه ${i + 1}") },
                                            onClick = { position = i; positionMenu = false }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onSave(
                                        DreamItem(
                                            id = initial?.id ?: DreamboardEngine.newId(),
                                            title = title.trim(),
                                            year = year.trim(),
                                            price = price.filter(Char::isDigit),
                                            imageUri = imageUri,
                                            position = position
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1.4f).height(GamifyDimens.ButtonHeight),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                shape = GamifyShapes.Field
                            ) { Text("ذخیره", fontWeight = FontWeight.ExtraBold) }
                            TextButton(onClick = { dismissEditor() }, modifier = Modifier.weight(1f).height(GamifyDimens.ButtonHeight)) {
                                Text("انصراف", color = TextSoft)
                            }
                            onDelete?.let { deleteAction ->
                                TextButton(
                                    onClick = {
                                        discardUnsavedCrop()
                                        deleteAction()
                                    },
                                    modifier = Modifier.height(GamifyDimens.ButtonHeight)
                                ) {
                                    Text("حذف", color = Color(0xFFFF8D8D), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingCropUri?.let { uri ->
        DreamCropDialog(
            sourceUri = uri,
            onDismiss = { pendingCropUri = null },
            onSave = { croppedUri ->
                if (imageUri.isNotBlank() && imageUri != originalImageUri && imageUri != croppedUri) {
                    deleteOwnedDreamImageIfUnused(context, imageUri, listOfNotNull(initial))
                }
                imageUri = croppedUri
                pendingCropUri = null
            }
        )
    }
}

