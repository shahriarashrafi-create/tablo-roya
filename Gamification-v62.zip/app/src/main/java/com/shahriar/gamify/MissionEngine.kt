package com.shahriar.gamify

import java.time.LocalDate
import java.util.UUID

/**
 * Canonical mission state/order rules.
 *
 * The persisted mission-list order is the base order selected by the user.
 * Daily status never mutates that base order. Instead, this engine derives the
 * visible order for the current day: Active -> Done -> Failed, while a Later
 * action keeps a mission Active and moves it behind the other active missions
 * for that day only.
 */
internal enum class MissionDayState { Active, Later, Done, Failed }

internal fun newMissionId(): String = UUID.randomUUID().toString()

internal fun legacyMissionId(index: Int, title: String, durationMinutes: Int): String {
    val fingerprint = "$index|${title.trim()}|$durationMinutes".hashCode().toUInt().toString(16)
    return "legacy_${index}_$fingerprint"
}

internal fun normalizeMissionIdentities(missions: List<Mission>): List<Mission> {
    val used = mutableSetOf<String>()
    return missions.mapIndexed { index, mission ->
        var candidate = mission.id.trim()
        if (candidate.isBlank() || candidate in used) {
            candidate = if (mission.id.isBlank()) {
                legacyMissionId(index, mission.title, mission.durationMinutes)
            } else {
                newMissionId()
            }
        }
        used += candidate
        mission.copy(id = candidate)
    }
}

internal fun prepareMissionForInsert(mission: Mission, existing: List<Mission>): Mission {
    val used = existing.mapNotNull { item -> item.id.trim().takeIf { it.isNotBlank() } }.toSet()
    val candidate = mission.id.trim()
    return mission.copy(id = if (candidate.isBlank() || candidate in used) newMissionId() else candidate)
}

internal fun preserveMissionIdentity(original: Mission, edited: Mission): Mission =
    edited.copy(id = original.id.ifBlank { newMissionId() })

internal fun MissionHistoryEntry.matchesMission(mission: Mission): Boolean =
    if (mission.id.isNotBlank() && missionId.isNotBlank()) missionId == mission.id else missionTitle == mission.title

internal fun missionDayState(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): MissionDayState {
    val matching = history.asSequence().filter { it.matchesMission(mission) }
    val relevant = if (mission.repeat == MissionRepeat.Daily) {
        matching.filter { it.localDate() == date }.toList()
    } else {
        matching.toList()
    }

    val terminal = relevant
        .asSequence()
        .filter { it.result != MissionResult.Defer }
        .maxByOrNull { it.timestamp }

    if (terminal != null) {
        return if (terminal.result == MissionResult.Done) MissionDayState.Done else MissionDayState.Failed
    }

    val deferredToday = history.asSequence()
        .filter { it.matchesMission(mission) && it.result == MissionResult.Defer && it.localDate() == date }
        .maxByOrNull { it.timestamp }

    return if (deferredToday != null) MissionDayState.Later else MissionDayState.Active
}

internal enum class MissionCardState { Active, Done, Failed }

internal fun missionCardState(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): MissionCardState = when (missionDayState(mission, history, date)) {
    MissionDayState.Active, MissionDayState.Later -> MissionCardState.Active
    MissionDayState.Done -> MissionCardState.Done
    MissionDayState.Failed -> MissionCardState.Failed
}

internal fun isMissionDoneToday(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): Boolean = missionDayState(mission, history, date) == MissionDayState.Done

internal fun deferredTodayTimestamp(
    mission: Mission,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): Long? = history.asSequence()
    .filter { it.matchesMission(mission) && it.result == MissionResult.Defer && it.localDate() == date }
    .maxOfOrNull { it.timestamp }

internal fun orderedMissionsForDisplay(
    missions: List<Mission>,
    history: List<MissionHistoryEntry>,
    date: LocalDate = LocalDate.now()
): List<Pair<Int, Mission>> = missions.mapIndexed { index, mission -> index to mission }
    .sortedWith(Comparator { a, b ->
        val dayA = missionDayState(a.second, history, date)
        val dayB = missionDayState(b.second, history, date)

        fun group(state: MissionDayState): Int = when (state) {
            MissionDayState.Active, MissionDayState.Later -> 0
            MissionDayState.Done -> 1
            MissionDayState.Failed -> 2
        }

        val groupDiff = group(dayA) - group(dayB)
        if (groupDiff != 0) return@Comparator groupDiff

        if (group(dayA) == 0) {
            // Normal active missions stay in base order. Later missions are
            // appended to the active queue in the order they were deferred.
            if (dayA == MissionDayState.Active && dayB == MissionDayState.Later) return@Comparator -1
            if (dayA == MissionDayState.Later && dayB == MissionDayState.Active) return@Comparator 1
            if (dayA == MissionDayState.Later && dayB == MissionDayState.Later) {
                val aTime = deferredTodayTimestamp(a.second, history, date) ?: Long.MIN_VALUE
                val bTime = deferredTodayTimestamp(b.second, history, date) ?: Long.MIN_VALUE
                val deferCompare = aTime.compareTo(bTime)
                if (deferCompare != 0) return@Comparator deferCompare
            }
        }

        // The persisted list order is the canonical base position.
        a.first.compareTo(b.first)
    })
