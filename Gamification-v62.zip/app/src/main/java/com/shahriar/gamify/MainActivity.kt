package com.shahriar.gamify

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.CalendarContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.Channel
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max

private val motivationalQuotes = listOf(
    "Small steps build great futures.",
    "Discipline creates freedom.",
    "Keep moving forward.",
    "Win the next moment.",
    "Progress over perfection.",
    "Build the life you want.",
    "Focus. Execute. Grow.",
    "Your future starts today.",
    "One mission at a time.",
    "Consistency beats intensity.",
    "Become stronger every day.",
    "Do the hard thing first.",
    "Make today count.",
    "Your habits shape your destiny.",
    "Keep the promise to yourself.",
    "Action creates confidence.",
    "Great things take repetition.",
    "Earn your next level.",
    "Stay focused on the mission.",
    "Become who you said you would.",
    "Momentum changes everything.",
    "Show up and do the work.",
    "Every effort adds up.",
    "Your discipline is your power.",
    "Start before you feel ready.",
    "Keep building your future.",
    "One focused hour can change a day.",
    "Progress is always earned.",
    "Make your future proud.",
    "Train your mind to finish.",
    "Growth begins with action.",
    "Your next level needs you.",
    "Build momentum, not excuses.",
    "Today is another chance to grow.",
    "Focus turns goals into reality.",
    "Keep going when it gets hard.",
    "Success is built in small moments.",
    "Make discipline your advantage.",
    "Your actions define your path.",
    "Push beyond your comfort zone.",
    "Finish what you started.",
    "Create a life worth leveling up.",
    "Stay consistent. Stay dangerous.",
    "The mission is simple: improve.",
    "Build yourself every single day.",
    "Your future rewards consistency.",
    "Focus now. Celebrate later.",
    "Every mission makes you stronger.",
    "Become better than yesterday.",
    "Keep climbing. Your peak is ahead."
)

class MainActivity : ComponentActivity() {
    private var resumeGeneration by mutableIntStateOf(0)
    private var requestedOpenMissionId by mutableStateOf<String?>(null)
    private var openMissionGeneration by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        consumeOpenMissionIntent(intent)
        setContent {
            App(
                resumeGeneration = resumeGeneration,
                requestedOpenMissionId = requestedOpenMissionId,
                openMissionGeneration = openMissionGeneration
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeOpenMissionIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        resumeGeneration += 1
    }

    private fun consumeOpenMissionIntent(source: Intent?) {
        val missionId = source?.getStringExtra(EXTRA_OPEN_MISSION_ID)?.trim().orEmpty()
        if (missionId.isBlank()) return
        requestedOpenMissionId = missionId
        openMissionGeneration += 1
        source?.removeExtra(EXTRA_OPEN_MISSION_ID)
    }
}

private enum class WorldButtonType { Dreamboard, Map, Missions, Shop }
private enum class BottomNavType { Home, Stats, Settings, Profile }
private enum class ProgressionNoticeKind { Level, Rank }

private data class ProgressionNotice(
    val kind: ProgressionNoticeKind,
    val title: String,
    val detail: String
)

private fun levelProgressionNotice(event: LevelUpEvent): ProgressionNotice = ProgressionNotice(
    kind = ProgressionNoticeKind.Level,
    title = "LEVEL UP  ${event.fromLevel} → ${event.toLevel}",
    detail = "+${event.rewardCoins} bonus Coins  •  +${event.toLevel - event.fromLevel} Chest"
)

private fun rankProgressionNotice(event: RankUpEvent): ProgressionNotice = ProgressionNotice(
    kind = ProgressionNoticeKind.Rank,
    title = "RANK UP  ${event.fromRank} → ${event.toRank}",
    detail = "+${event.chestsEarned} Reward Chest"
)

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", Color(0xFF6D3C1D), Color(0xFFF2C56F)),
    RankTier(6, 10, "Explorer", Color(0xFF7D1E1A), Color(0xFFF5CC62)),
    RankTier(11, 15, "Seeker", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "%,d", value)
private val rewardHistoryDateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
private fun formatRewardRedemptionTime(timestamp: Long): String =
    Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).format(rewardHistoryDateFormatter)

@Composable
fun App(
    resumeGeneration: Int = 0,
    requestedOpenMissionId: String? = null,
    openMissionGeneration: Int = 0
) {
    val context = LocalContext.current.applicationContext
    remember { migrateState(context); performDailyResetIfNeeded(context); Unit }
    val restoredTimer = remember { recoverActiveTimer(context) }
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf(if (restoredTimer != null) AppScreen.Mission else AppScreen.Home) }
    var player by remember { mutableStateOf(loadPlayer(context)) }
    var settings by remember { mutableStateOf(loadSettings(context)) }
    var quoteIndex by remember { mutableIntStateOf(motivationalQuotes.indices.random()) }
    var activeMission by remember { mutableStateOf(restoredTimer?.mission) }
    var completionAnimation by remember { mutableStateOf<MissionCompletionAnimation?>(null) }
    var hudRewardCue by remember { mutableStateOf<HudRewardCue?>(null) }
    var progressionNotice by remember { mutableStateOf<ProgressionNotice?>(null) }
    val progressionNoticeChannel = remember { Channel<ProgressionNotice>(Channel.UNLIMITED) }
    var showShop by remember { mutableStateOf(false) }
    var showInventory by remember { mutableStateOf(false) }
    var showWorldMap by remember { mutableStateOf(false) }
    var showMissions by remember { mutableStateOf(false) }
    var showDreamboard by remember { mutableStateOf(false) }
    var requestedMissionIndex by remember { mutableStateOf<Int?>(null) }
    var requestedMissionNonce by remember { mutableIntStateOf(0) }
    var dailyLoginEvent by remember { mutableStateOf<DailyLoginEvent?>(null) }
    var profileLoadout by remember { mutableStateOf(loadProfileLoadout(context)) }
    val ownedRewards = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_OWNED_REWARDS)) } }
    val personalRewards = remember { mutableStateListOf<PersonalReward>().also { it.addAll(loadPersonalRewards(context)) } }
    val rewardRedemptions = remember { mutableStateListOf<RewardRedemptionEntry>().also { it.addAll(loadRewardRedemptions(context)) } }
    val dreamItems = remember { mutableStateListOf<DreamItem>().also { it.addAll(loadDreamItems(context)) } }
    val claimedChallenges = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_CHALLENGE_CLAIMS)) } }
    val claimedAchievements = remember { mutableStateListOf<String>().also { it.addAll(loadStringSet(context, KEY_ACHIEVEMENT_CLAIMS)) } }
    val quote = motivationalQuotes[quoteIndex]
    val missions = remember {
        mutableStateListOf<Mission>().also { it.addAll(loadMissions(context)) }
    }
    val history = remember {
        mutableStateListOf<MissionHistoryEntry>().also { it.addAll(loadHistory(context)) }
    }
    var observedExternalResultRevision by remember {
        mutableStateOf(externalMissionResultRevision(context))
    }
    var externalResultSignal by remember { mutableStateOf(observedExternalResultRevision) }

    DisposableEffect(context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_EXTERNAL_MISSION_RESULT_REVISION) {
                externalResultSignal = externalMissionResultRevision(context)
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    val notifications = remember {
        mutableStateListOf<GameNotification>().also { it.addAll(loadNotifications(context)) }
    }
    var onboardingComplete by remember { mutableStateOf(isOnboardingComplete(context)) }

    if (!onboardingComplete) {
        GamifyTheme {
            OnboardingScreen(
                onFinish = { profile, templateIds ->
                    saveOnboardingProfile(context, profile)
                    val additions = missionTemplates.filter { it.id in templateIds }.map { it.mission }
                    missions.clear()
                    val initialMissions = if (additions.isNotEmpty()) additions else listOf(defaultMission())
                    missions.addAll(normalizeMissionIdentities(initialMissions))
                    saveMissions(context, missions)
                    onboardingComplete = true
                }
            )
        }
        return
    }

    LaunchedEffect(resumeGeneration, externalResultSignal) {
        val revision = externalMissionResultRevision(context)
        if (revision != observedExternalResultRevision) {
            observedExternalResultRevision = revision
            performDailyResetIfNeeded(context)
            player = loadPlayer(context)
            history.clear(); history.addAll(loadHistory(context))
            val recovered = recoverActiveTimer(context)
            activeMission = recovered?.mission
            if (recovered == null && screen == AppScreen.Mission) {
                screen = AppScreen.Home
            }
            completionAnimation = null
            hudRewardCue = null
        }
    }

    LaunchedEffect(openMissionGeneration, requestedOpenMissionId) {
        val missionId = requestedOpenMissionId?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        val recovered = recoverActiveTimer(context)
        if (recovered != null && recovered.mission.id == missionId) {
            activeMission = recovered.mission
            screen = AppScreen.Mission
            tab = 0
            showShop = false
            showInventory = false
            showWorldMap = false
            showMissions = false
            showDreamboard = false
        } else {
            val baseIndex = missions.indexOfFirst { it.id == missionId }
            if (baseIndex >= 0) {
                requestedMissionIndex = baseIndex
                requestedMissionNonce += 1
                tab = 0
                screen = AppScreen.Home
                showShop = false
                showInventory = false
                showWorldMap = false
                showMissions = false
                showDreamboard = false
            }
        }
    }

    fun pushNotification(id: String, glyph: String, title: String, body: String) {
        if (notifications.none { it.id == id }) {
            notifications.add(0, GameNotification(id, glyph, title, body, System.currentTimeMillis(), false))
            while (notifications.size > 100) notifications.removeAt(notifications.lastIndex)
            saveNotifications(context, notifications)
        }
    }

    fun enqueueProgressionNotices(levelUp: LevelUpEvent?, rankUp: RankUpEvent?) {
        levelUp?.let { progressionNoticeChannel.trySend(levelProgressionNotice(it)) }
        rankUp?.let { progressionNoticeChannel.trySend(rankProgressionNotice(it)) }
    }

    LaunchedEffect(progressionNoticeChannel) {
        for (notice in progressionNoticeChannel) {
            progressionNotice = notice
            delay(if (settings.reducedMotion) 1100L else 1900L)
            progressionNotice = null
            delay(if (settings.reducedMotion) 80L else 180L)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted && settings.notificationsEnabled) {
            settings = settings.copy(notificationsEnabled = false)
            saveSettings(context, settings)
            synchronizeScheduledAlarms(context, settings)
        } else if (granted) {
            synchronizeScheduledAlarms(context, settings)
        }
    }

    LaunchedEffect(settings.notificationsEnabled) {
        if (settings.notificationsEnabled &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            synchronizeScheduledAlarms(context, settings)
        }
    }

    LaunchedEffect(Unit) {
        applyDailyLogin(context, player)?.let { event ->
            player = event.player
            dailyLoginEvent = event
            pushNotification(
                id = "login:${LocalDate.now()}",
                glyph = "🔥",
                title = "Daily streak ${event.streak}",
                body = "+${event.coinReward} Coins${event.milestone?.let { " • $it" } ?: ""}"
            )
        }
        val today = LocalDate.now()
        missions.forEachIndexed { index, mission ->
            val due = isMissionScheduledToday(mission, today) &&
                missionCardState(mission, history, today) == MissionCardState.Active
            if (due && mission.repeat != MissionRepeat.None) {
                pushNotification(
                    id = "due:$today:$index:${mission.title}",
                    glyph = "◷",
                    title = "Mission due today",
                    body = "${mission.title}${recurrenceTimeText(mission).takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}"
                )
            }
        }
        buildChallenges(history).filter { it.progress >= it.goal && it.claimKey !in claimedChallenges }.forEach { challenge ->
            pushNotification("challenge:${challenge.claimKey}", "✦", "Challenge complete", "${challenge.title} • reward ready")
        }
        synchronizeScheduledAlarms(context, settings)
    }

    fun completeMission(result: MissionResult, focusSeconds: Int) {
        val committed = finalizeActiveMissionSession(context, result, focusSeconds)
        if (committed == null) {
            player = loadPlayer(context)
            history.clear(); history.addAll(loadHistory(context))
            activeMission = null
            hudRewardCue = null
            screen = AppScreen.Home
            return
        }

        history.clear(); history.addAll(committed.history)
        activeMission = null
        screen = AppScreen.Home

        if (committed.duplicate) {
            player = loadPlayer(context)
            completionAnimation = null
            hudRewardCue = null
            return
        }

        val outcome = committed.outcome
        val beforePlayer = committed.beforePlayer
        val mission = committed.mission
        val nextLevelEvent = levelUpEventFor(beforePlayer, outcome)
        val nextRankEvent = rankUpEventFor(beforePlayer, outcome)

        playResultFeedback(
            context = context,
            settings = settings,
            result = result,
            levelUp = outcome.levelsGained > 0
        )

        if (outcome.ranksGained > 0) {
            pushNotification(
                "rank:${outcome.player.rank}:${System.currentTimeMillis()}",
                "♜",
                "Rank Up!",
                "You reached Rank ${outcome.player.rank} and earned ${outcome.ranksGained} chest${if (outcome.ranksGained > 1) "s" else ""}."
            )
        }
        if (outcome.levelsGained > 0) {
            pushNotification(
                "level:${outcome.player.level}:${System.currentTimeMillis()}",
                "★",
                "Level Up!",
                "Level ${outcome.player.level} • +${outcome.levelRewardCoins} Coins • +${outcome.levelsGained} chest${if (outcome.levelsGained > 1) "s" else ""}"
            )
        }
        buildChallenges(history).filter { it.progress >= it.goal && it.claimKey !in claimedChallenges }.forEach { challenge ->
            pushNotification("challenge:${challenge.claimKey}", "✦", "Challenge complete", "${challenge.title} • reward ready")
        }

        if (result == MissionResult.Done) {
            // The committed PlayerState is already persisted. The UI intentionally
            // starts at the pre-result snapshot and reveals each reward on the HUD
            // in a fixed XP -> Coin -> Combo -> Level -> Rank sequence.
            player = beforePlayer
            hudRewardCue = null
            completionAnimation = MissionCompletionAnimation(
                mission = mission,
                fromPlayer = beforePlayer,
                toPlayer = outcome.player,
                xpGain = outcome.xpGain,
                coinGain = outcome.missionCoinGain + outcome.levelRewardCoins,
                levelUp = nextLevelEvent,
                rankUp = nextRankEvent
            )
        } else {
            player = outcome.player
            completionAnimation = null
            hudRewardCue = null
            enqueueProgressionNotices(nextLevelEvent, nextRankEvent)
        }
    }

    LaunchedEffect(completionAnimation) {
        val animation = completionAnimation ?: return@LaunchedEffect
        if (settings.reducedMotion) {
            player = animation.toPlayer
            hudRewardCue = null
            delay(160L)
        } else {
            var visualPlayer = animation.fromPlayer

            suspend fun animateStep(
                step: ProgressionVisualStep,
                cue: String,
                durationMillis: Long
            ) {
                hudRewardCue = HudRewardCue(step, cue)
                val frameDelay = 32L
                val frames = (durationMillis / frameDelay).toInt().coerceAtLeast(1)
                for (frame in 1..frames) {
                    val fraction = frame.toFloat() / frames.toFloat()
                    player = interpolateProgressionStep(
                        base = visualPlayer,
                        from = animation.fromPlayer,
                        to = animation.toPlayer,
                        step = step,
                        fraction = fraction
                    )
                    delay(frameDelay)
                }
                visualPlayer = player
            }

            if (animation.xpGain > 0 || animation.fromPlayer.level != animation.toPlayer.level) {
                animateStep(
                    ProgressionVisualStep.Xp,
                    if (animation.xpGain > 0) "+${formatNumber(animation.xpGain)} XP" else "XP",
                    1500L
                )
            }
            if (animation.coinGain != 0) {
                animateStep(
                    ProgressionVisualStep.Coins,
                    "${if (animation.coinGain > 0) "+" else ""}${formatNumber(animation.coinGain)} Coins",
                    850L
                )
            }
            if (animation.fromPlayer.combo != animation.toPlayer.combo) {
                val delta = animation.toPlayer.combo - animation.fromPlayer.combo
                animateStep(
                    ProgressionVisualStep.Combo,
                    "Combo ${if (delta > 0) "+" else ""}$delta",
                    600L
                )
            }
            if (animation.fromPlayer.level != animation.toPlayer.level) {
                hudRewardCue = HudRewardCue(
                    ProgressionVisualStep.Level,
                    "Level ${animation.fromPlayer.level} → ${animation.toPlayer.level}"
                )
                delay(650L)
            }
            if (
                animation.fromPlayer.rank != animation.toPlayer.rank ||
                animation.fromPlayer.rankProgress != animation.toPlayer.rankProgress
            ) {
                val rankCue = if (animation.fromPlayer.rank != animation.toPlayer.rank) {
                    "Rank ${animation.fromPlayer.rank} → ${animation.toPlayer.rank}"
                } else if (animation.toPlayer.rank >= ProgressionRules.MAX_RANK) {
                    "Rank MAX"
                } else {
                    "Rank ${animation.toPlayer.rankProgress}/${rankRequirement(animation.toPlayer.rank)}"
                }
                animateStep(ProgressionVisualStep.Rank, rankCue, 850L)
            }
        }

        player = animation.toPlayer
        hudRewardCue = null
        delay(180L)
        completionAnimation = null
        enqueueProgressionNotices(animation.levelUp, animation.rankUp)
    }

    GamifyTheme {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    if (screen == AppScreen.Home) {
                        GameBottomNavigation(
                            selected = tab,
                            onSelect = { i ->
                                tab = i
                                if (i == 0) {
                                    var next = motivationalQuotes.indices.random()
                                    if (motivationalQuotes.size > 1) {
                                        while (next == quoteIndex) next = motivationalQuotes.indices.random()
                                    }
                                    quoteIndex = next
                                }
                            }
                        )
                    }
                }
            ) { pad ->
                when (screen) {
                    AppScreen.Mission -> {
                        val mission = activeMission ?: recoverActiveTimer(context)?.mission ?: missions.firstOrNull() ?: defaultMission()
                        MissionExecutionScreen(
                            mission = mission,
                            player = player,
                            settings = settings,
                            onAbandon = { focusSeconds ->
                                completeMission(MissionResult.Defer, focusSeconds)
                            },
                            onResult = { result, focusSeconds ->
                                completeMission(result, focusSeconds)
                            },
                            modifier = Modifier.padding(top = pad.calculateTopPadding())
                        )
                    }
                    AppScreen.Home -> {
                        when (tab) {
                            0 -> {
                                GameHome(
                                    player = player,
                                    hudRewardCue = hudRewardCue,
                                    quote = quote,
                                    missions = missions,
                                    settings = settings,
                                    onStartMission = { mission ->
                                        val needsNotificationPermission = settings.notificationsEnabled &&
                                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                        if (needsNotificationPermission) {
                                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                        beginActiveTimer(context, mission, settings)
                                        activeMission = mission
                                        screen = AppScreen.Mission
                                    },
                                    onAddMission = { position, mission ->
                                        val index = position.coerceIn(0, missions.size)
                                        val prepared = prepareMissionForInsert(mission, missions)
                                        missions.add(index, prepared)
                                        saveMissions(context, missions)
                                    },
                                    onUpdateMission = { index, newPosition, mission ->
                                        if (index in missions.indices) {
                                            val original = missions[index]
                                            missions[index] = preserveMissionIdentity(original, mission)
                                            val moved = missions.removeAt(index)
                                            val target = newPosition.coerceIn(0, missions.size)
                                            missions.add(target, moved)
                                            saveMissions(context, missions)
                                        }
                                    },
                                    onDeleteMission = { index ->
                                        if (index in missions.indices) {
                                            missions.removeAt(index)
                                            saveMissions(context, missions)
                                        }
                                    },
                                    onOpenDreamboard = { showDreamboard = true },
                                    onOpenShop = { showShop = true },
                                    onOpenWorldMap = { showWorldMap = true },
                                    onOpenMissions = { showMissions = true },
                                    unreadNotificationCount = notifications.count { !it.read },
                                    focusMissionIndex = requestedMissionIndex,
                                    focusRequest = requestedMissionNonce,
                                    history = history,
                                    claimedChallenges = claimedChallenges.toSet(),
                                    modifier = Modifier.padding(top = pad.calculateTopPadding())
                                )
                            }
                            1 -> {
                                StatsScreen(
                                    player = player,
                                    history = history,
                                    settings = settings,
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                            2 -> {
                                SettingsScreen(
                                    settings = settings,
                                    onSettingsChange = { updated ->
                                        settings = updated
                                        saveSettings(context, updated)
                                        if (updated.notificationsEnabled) {
                                            val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                            if (needsPermission) {
                                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            } else {
                                                synchronizeScheduledAlarms(context, updated)
                                            }
                                        } else {
                                            synchronizeScheduledAlarms(context, updated)
                                        }
                                    },
                                    onDataRestored = {
                                        player = loadPlayer(context)
                                        settings = loadSettings(context)
                                        missions.clear(); missions.addAll(loadMissions(context))
                                        history.clear(); history.addAll(loadHistory(context))
                                        ownedRewards.clear(); ownedRewards.addAll(loadStringSet(context, KEY_OWNED_REWARDS))
                                        personalRewards.clear(); personalRewards.addAll(loadPersonalRewards(context))
                                        rewardRedemptions.clear(); rewardRedemptions.addAll(loadRewardRedemptions(context))
                                        profileLoadout = loadProfileLoadout(context)
                                        claimedChallenges.clear(); claimedChallenges.addAll(loadStringSet(context, KEY_CHALLENGE_CLAIMS))
                                        claimedAchievements.clear(); claimedAchievements.addAll(loadStringSet(context, KEY_ACHIEVEMENT_CLAIMS))
                                        notifications.clear(); notifications.addAll(loadNotifications(context))
                                        onboardingComplete = isOnboardingComplete(context)
                                        activeMission = null
                                        completionAnimation = null
                                        hudRewardCue = null
                                        progressionNotice = null
                                        while (progressionNoticeChannel.tryReceive().isSuccess) { }
                                        tab = 0
                                        screen = AppScreen.Home
                                        synchronizeScheduledAlarms(context, settings)
                                    },
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                            else -> {
                                ProfileProgressScreen(
                                    player = player,
                                    history = history,
                                    settings = settings,
                                    ownedRewards = ownedRewards.toSet(),
                                    loadout = profileLoadout,
                                    onOpenInventory = { showInventory = true },
                                    claimedAchievements = claimedAchievements.toSet(),
                                    onClaimAchievement = { achievement ->
                                        if (achievement.id !in claimedAchievements && achievement.progress >= achievement.goal) {
                                            claimedAchievements.add(achievement.id)
                                            saveStringSet(context, KEY_ACHIEVEMENT_CLAIMS, claimedAchievements.toSet())
                                            val (updated, event) = applyBonusReward(player, achievement.xpReward, achievement.coinReward)
                                            player = updated
                                            savePlayer(context, player)
                                            enqueueProgressionNotices(event, null)
                                        }
                                    },
                                    modifier = Modifier.padding(
                                        top = pad.calculateTopPadding(),
                                        bottom = pad.calculateBottomPadding()
                                    )
                                )
                            }
                        }
                    }
                }
            }

            completionAnimation?.let { animation ->
                MissionCompletionFlight(
                    mission = animation.mission,
                    reducedMotion = settings.reducedMotion,
                    durationMillis = missionCompletionAnimationDurationMillis(animation),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(start = 20.dp, end = 20.dp, bottom = 150.dp)
                )
            }

            progressionNotice?.let { notice ->
                ProgressionNoticeOverlay(
                    notice = notice,
                    reducedMotion = settings.reducedMotion,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 88.dp)
                )
            }
            if (showShop) {
                ShopDialog(
                    player = player,
                    rewards = personalRewards,
                    redemptions = rewardRedemptions,
                    onAdd = { reward ->
                        val updated = RewardEngine.upsertAtPosition(personalRewards, reward)
                        personalRewards.clear()
                        personalRewards.addAll(updated)
                        savePersonalRewards(context, updated)
                    },
                    onUpdate = { _, reward ->
                        val updated = RewardEngine.upsertAtPosition(personalRewards, reward)
                        personalRewards.clear()
                        personalRewards.addAll(updated)
                        savePersonalRewards(context, updated)
                    },
                    onDelete = { index ->
                        personalRewards.getOrNull(index)?.let { removed ->
                            val updated = RewardEngine.removeAndNormalize(personalRewards, removed.id)
                            personalRewards.clear()
                            personalRewards.addAll(updated)
                            savePersonalRewards(context, updated)
                        }
                    },
                    onRedeem = { _, reward ->
                        val commit = redeemPersonalReward(context, reward.id)
                        if (commit.status == RewardRedemptionStatus.Success) {
                            player = commit.player
                            personalRewards.clear()
                            personalRewards.addAll(commit.rewards)
                            commit.entry?.let { entry ->
                                rewardRedemptions.removeAll { it.transactionId == entry.transactionId }
                                rewardRedemptions.add(0, entry)
                                while (rewardRedemptions.size > 500) rewardRedemptions.removeAt(rewardRedemptions.lastIndex)
                            }
                        }
                        commit.status
                    },
                    onDismiss = { showShop = false }
                )
            }
            if (showInventory) {
                InventoryDialog(
                    owned = ownedRewards.toSet(),
                    loadout = profileLoadout,
                    onEquip = { updated ->
                        profileLoadout = updated
                        saveProfileLoadout(context, updated)
                    },
                    onDismiss = { showInventory = false }
                )
            }
            if (showMissions) {
                MissionsDialog(
                    missions = missions,
                    history = history,
                    onSelect = { index ->
                        requestedMissionIndex = index
                        requestedMissionNonce += 1
                        tab = 0
                        screen = AppScreen.Home
                        showMissions = false
                    },
                    onDismiss = { showMissions = false }
                )
            }
            if (showDreamboard) {
                DreamboardDialog(
                    dreams = dreamItems,
                    onAdd = { dream ->
                        val updated = DreamboardEngine.insert(dreamItems, dream)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                    },
                    onUpdate = { dream ->
                        val previous = dreamItems.firstOrNull { it.id == dream.id }
                        val updated = DreamboardEngine.update(dreamItems, dream)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                        previous?.imageUri
                            ?.takeIf { it.isNotBlank() && it != dream.imageUri }
                            ?.let { deleteOwnedDreamImageIfUnused(context, it, updated) }
                    },
                    onDelete = { dreamId ->
                        val previous = dreamItems.firstOrNull { it.id == dreamId }
                        val updated = DreamboardEngine.remove(dreamItems, dreamId)
                        dreamItems.clear()
                        dreamItems.addAll(updated)
                        saveDreamItems(context, updated)
                        previous?.imageUri
                            ?.takeIf { it.isNotBlank() }
                            ?.let { deleteOwnedDreamImageIfUnused(context, it, updated) }
                    },
                    onDismiss = { showDreamboard = false }
                )
            }
            dailyLoginEvent?.let { event ->
                DailyLoginDialog(event = event, onDismiss = { dailyLoginEvent = null })
            }
            if (showWorldMap) {
                WorldProgressDialog(player = player, onDismiss = { showWorldMap = false })
            }
        }
    }
}

@Composable
private fun MissionExecutionScreen(
    mission: Mission,
    player: PlayerState,
    settings: GameSettings,
    onAbandon: (Int) -> Unit,
    onResult: (MissionResult, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current.applicationContext
    var timerState by remember(mission) {
        mutableStateOf(
            recoverActiveTimer(context)?.takeIf { state ->
                val sameId = state.mission.id.isNotBlank() && state.mission.id == mission.id
                sameId || (state.mission.id.isBlank() && state.mission.title == mission.title)
            } ?: beginActiveTimer(context, mission, settings)
        )
    }
    var remaining by remember(mission) { mutableIntStateOf(remainingSeconds(context, timerState)) }
    var choosingResult by remember(mission) { mutableStateOf(remaining <= 0) }
    var resultSubmitted by remember(timerState.sessionId) { mutableStateOf(false) }
    var showAbandonDialog by remember { mutableStateOf(false) }
    val executionSubtasks = remember(timerState.sessionId) {
        mutableStateListOf<String>().also { it.addAll(timerState.mission.subtasks) }
    }
    val checkedSubtasks = remember(timerState.sessionId) {
        mutableStateListOf<Boolean>().also { list ->
            executionSubtasks.indices.forEach { index ->
                list.add(timerState.checkedSubtasks.getOrElse(index) { false })
            }
        }
    }
    var newExecutionSubtask by remember(timerState.sessionId) { mutableStateOf("") }

    fun persistSubtaskState() {
        val updated = timerState.copy(
            mission = timerState.mission.copy(subtasks = executionSubtasks.toList()),
            checkedSubtasks = checkedSubtasks.toList()
        )
        timerState = updated
        saveActiveTimer(context, updated)
        saveMissionSubtaskChecks(context, updated.mission, updated.checkedSubtasks)
    }

    fun persistTimer(state: ActiveTimerState) {
        timerState = state
        remaining = remainingSeconds(context, state)
        saveActiveTimer(context, state)
        if (state.isRunning) scheduleTimerAlarm(context, state, settings) else cancelTimerAlarm(context)
    }

    BackHandler { showAbandonDialog = true }

    LaunchedEffect(timerState.isRunning, timerState.endAtMillis, choosingResult) {
        if (choosingResult || !timerState.isRunning) {
            remaining = remainingSeconds(context, timerState)
            return@LaunchedEffect
        }
        while (timerState.isRunning && !choosingResult) {
            val nowRemaining = remainingSeconds(context, timerState)
            remaining = nowRemaining
            if (nowRemaining <= 0) {
                // Use the same receiver path as AlarmManager so timer expiry also
                // posts the actionable notification while the app is foreground.
                TimerFinishReceiver.finishTimer(context, timerState.sessionId, notify = true)
                val ended = loadActiveTimer(context) ?: timerState.copy(
                    remainingSeconds = 0,
                    endAtMillis = 0L,
                    isRunning = false,
                    endAtElapsedRealtime = 0L,
                    bootCount = -1
                )
                timerState = ended
                remaining = 0
                choosingResult = true
                break
            }
            delay(250L)
        }
    }

    val totalSeconds = (mission.durationMinutes * 60).coerceAtLeast(1)
    val focusedSeconds = (totalSeconds - remaining).coerceIn(0, totalSeconds)
    val minutes = remaining / 60
    val seconds = remaining % 60
    val timerText = String.format(Locale.US, "%02d:%02d", minutes, seconds)
    val progress = remaining.toFloat() / totalSeconds.toFloat()
    val nextCombo = player.combo + 1
    val boost = if (settings.comboBoostEnabled) comboMultiplier(nextCombo) else 1.0f
    val previewXp = (mission.xpReward * boost).toInt()
    val previewCoins = (mission.coinReward * boost).toInt()
    val completedSubtasks = checkedSubtasks.count { it }
    val allSubtasksDone = executionSubtasks.isNotEmpty() && completedSubtasks == executionSubtasks.size
    val compactExecution = gamifyCompactScreen()
    val executionHorizontalPadding = if (compactExecution) GamifySpacing.Md else 22.dp
    val executionVerticalPadding = if (compactExecution) GamifySpacing.Md else 18.dp
    val timerDiameter = if (compactExecution) 190.dp else 230.dp

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xD80A1018), Color(0xE80A1018), Color(0xF40A1018))))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = executionHorizontalPadding, vertical = executionVerticalPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "‹ Back",
                    color = GoldSoft,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { showAbandonDialog = true }.padding(8.dp)
                )
                Text("MISSION", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.width(52.dp))
            }

            Spacer(Modifier.height(if (compactExecution) 14.dp else 28.dp))
            Text(
                mission.title,
                color = Color.White,
                fontSize = if (compactExecution) 22.sp else 26.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(9.dp))
            Text(
                if (boost > 1f) "+$previewXp XP   •   +$previewCoins Coins   •   Combo x${String.format(Locale.US, "%.2g", boost)}"
                else "+${mission.xpReward} XP   •   +${mission.coinReward} Coins",
                color = GoldSoft,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(if (compactExecution) 10.dp else 16.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xB8151D27),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x445F6D7C))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SUBTASKS", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                        Text(
                            if (allSubtasksDone) "$completedSubtasks/${executionSubtasks.size} • READY" else "$completedSubtasks/${executionSubtasks.size}",
                            color = if (allSubtasksDone) Color(0xFF86EFAC) else TextSoft,
                            fontSize = 9.sp,
                            fontWeight = if (allSubtasksDone) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    if (executionSubtasks.isNotEmpty()) {
                        Spacer(Modifier.height(5.dp))
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = if (compactExecution) 90.dp else 112.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            itemsIndexed(executionSubtasks) { index, subtask ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Text(
                                        "×",
                                        color = Color(0xFFFF8C8C),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable {
                                            executionSubtasks.removeAt(index)
                                            checkedSubtasks.removeAt(index)
                                            persistSubtaskState()
                                        }.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                    Text(
                                        subtask,
                                        color = if (checkedSubtasks[index]) Color(0xFF91A09B) else Color.White,
                                        fontSize = 11.sp,
                                        textDecoration = if (checkedSubtasks[index]) TextDecoration.LineThrough else TextDecoration.None,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Surface(
                                        modifier = Modifier.size(22.dp).clickable {
                                            checkedSubtasks[index] = !checkedSubtasks[index]
                                            persistSubtaskState()
                                        },
                                        color = if (checkedSubtasks[index]) Color(0xFF2F8D61) else Color(0xFF202B37),
                                        shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, if (checkedSubtasks[index]) Color(0xFF86EFAC) else Color(0xFF5C6876))
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            if (checkedSubtasks[index]) Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CompactSubtaskField(
                            value = newExecutionSubtask,
                            onValueChange = { newExecutionSubtask = it.take(120) },
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            modifier = Modifier.size(42.dp).clickable {
                                val clean = newExecutionSubtask.trim()
                                if (clean.isNotEmpty()) {
                                    executionSubtasks.add(clean)
                                    checkedSubtasks.add(false)
                                    newExecutionSubtask = ""
                                    persistSubtaskState()
                                }
                            },
                            color = Color(0x33F7C948),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Gold.copy(alpha = 0.65f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("+", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(if (compactExecution) 10.dp else 18.dp))
            Box(
                modifier = Modifier
                    .size(timerDiameter)
                    .clickable(enabled = !choosingResult) {
                        if (timerState.isRunning) {
                            val nowRemaining = remainingSeconds(context, timerState)
                            persistTimer(
                                timerState.copy(
                                    remainingSeconds = nowRemaining,
                                    endAtMillis = 0L,
                                    isRunning = false,
                                    endAtElapsedRealtime = 0L,
                                    bootCount = -1
                                )
                            )
                        } else {
                            val safeRemaining = remaining.coerceAtLeast(1)
                            persistTimer(
                                withRunningTimerDeadline(context, timerState, safeRemaining)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 10.dp.toPx()
                    drawCircle(color = Color(0x55000000), radius = size.minDimension * 0.45f)
                    drawCircle(
                        color = Color(0xFF28313D),
                        radius = size.minDimension * 0.45f,
                        style = Stroke(width = stroke)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(GoldSoft, Gold, Color(0xFFE7A91C), GoldSoft)),
                        startAngle = -90f,
                        sweepAngle = 360f * progress,
                        useCenter = false,
                        topLeft = Offset(size.width * 0.05f, size.height * 0.05f),
                        size = Size(size.width * 0.90f, size.height * 0.90f),
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(timerText, color = GamifyColors.TextPrimary, fontSize = if (compactExecution) 38.sp else 44.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        when {
                            choosingResult -> "COMPLETE"
                            timerState.isRunning -> "FOCUS"
                            else -> "PAUSED"
                        },
                        color = GoldSoft,
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                    if (!choosingResult) {
                        Spacer(Modifier.height(5.dp))
                        Text("${formatFocusTime(focusedSeconds)} focused", color = TextSoft, fontSize = 9.sp)
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .size(if (compactExecution) 52.dp else 58.dp)
                        .clickable(enabled = !resultSubmitted) {
                            resultSubmitted = true
                            onResult(MissionResult.Fail, focusedSeconds)
                        },
                    color = Color(0xB0151B24),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x88E36E73))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("×", color = Color(0xFFFF7278), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Surface(
                    modifier = Modifier
                        .size(if (compactExecution) 52.dp else 58.dp)
                        .clickable(enabled = !resultSubmitted) {
                            resultSubmitted = true
                            onResult(MissionResult.Defer, focusedSeconds)
                        },
                    color = Color(0xB0151B24),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x66F1D487))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("◷", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Button(
                    onClick = {
                        if (!resultSubmitted) {
                            resultSubmitted = true
                            onResult(MissionResult.Done, focusedSeconds)
                        }
                    },
                    enabled = !resultSubmitted,
                    modifier = Modifier.weight(1f).height(if (compactExecution) 52.dp else 58.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("انجام شد", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }

    if (showAbandonDialog) {
        AlertDialog(
            onDismissRequest = { showAbandonDialog = false },
            containerColor = GamifyColors.Surface,
            shape = GamifyShapes.Dialog,
            title = { Text("Leave mission?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Leaving marks this mission as Later, keeps your Combo unchanged, and stops the timer.",
                    color = TextSoft,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                TextButton(
                    enabled = !resultSubmitted,
                    onClick = {
                        resultSubmitted = true
                        onAbandon(focusedSeconds)
                    }
                ) {
                    Text("Leave", color = Color(0xFFE67B7B), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAbandonDialog = false }) {
                    Text("Keep focusing", color = GoldSoft)
                }
            }
        )
    }
}

@Composable
private fun ResultButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

private fun formatFocusTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val secs = safe % 60
    return when {
        hours > 0 -> String.format(Locale.US, "%dh %02dm", hours, minutes)
        minutes > 0 -> String.format(Locale.US, "%dm %02ds", minutes, secs)
        else -> String.format(Locale.US, "%ds", secs)
    }
}

private fun historyResultColor(result: MissionResult): Color = when (result) {
    MissionResult.Done -> Gold
    MissionResult.Partial -> Blue
    MissionResult.Fail -> Color(0xFFE67B7B)
    MissionResult.Defer -> Color(0xFFAAB3C0)
}

@Composable
private fun StatsScreen(
    player: PlayerState,
    history: List<MissionHistoryEntry>,
    settings: GameSettings,
    modifier: Modifier = Modifier
) {
    val zoneId = ZoneId.systemDefault()
    val today = LocalDate.now(zoneId)
    val todayEntries = history.filter { it.localDate(zoneId) == today }
    val todayXp = todayEntries.sumOf { it.xpEarned }
    val todayFocus = todayEntries.sumOf { it.focusSeconds }
    val todayDone = todayEntries.count { it.result == MissionResult.Done }
    val recordedXp = history.sumOf { it.xpEarned }
    val recordedCoins = history.sumOf { it.coinsEarned }
    val totalFocus = history.sumOf { it.focusSeconds }
    val totalDone = history.count { it.result == MissionResult.Done }
    val lastSevenDays = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val focusByDay = lastSevenDays.map { day ->
        history.asSequence()
            .filter { it.localDate(zoneId) == day }
            .sumOf { it.focusSeconds } / 60
    }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xE40A1119), Color(0xF00A1119), Color(0xFA080D14))
                    )
                )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text(
                        "STATS",
                        color = Gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.2.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Your progress, built from completed missions.",
                        color = TextSoft,
                        fontSize = 12.sp
                    )
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("TODAY XP", "+${formatNumber(todayXp)}", "XP", Modifier.weight(1f))
                    StatMetricCard("FOCUS", formatFocusTime(todayFocus), "today", Modifier.weight(1f))
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("DONE", todayDone.toString(), "today", Modifier.weight(1f))
                    StatMetricCard("BEST COMBO", player.bestCombo.toString(), "record", Modifier.weight(1f))
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, Color(0x3FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("7 DAY FOCUS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Minutes focused each day", color = TextSoft, fontSize = 10.sp)
                            }
                            Text("${focusByDay.sum()} min", color = GoldSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(14.dp))
                        SevenDayFocusChart(days = lastSevenDays, minutes = focusByDay)
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, Color(0x302D3948))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ALL TIME", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        StatLine("Recorded XP", formatNumber(recordedXp))
                        StatLine("Recorded Coins", formatNumber(recordedCoins))
                        StatLine("Focus Time", formatFocusTime(totalFocus))
                        StatLine("Missions Done", totalDone.toString())
                        StatLine("Current Level", player.level.toString())
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("MISSION HISTORY", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("${history.size} records", color = TextSoft, fontSize = 10.sp)
                }
            }

            if (history.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xA90D141E)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("No mission history yet", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("Finish a mission and your activity will appear here.", color = TextSoft, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(history, key = { if (it.sessionId > 0L) "session-${it.sessionId}" else "${it.timestamp}-${it.missionTitle}" }) { entry ->
                    MissionHistoryRow(entry)
                }
            }
        }
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    suffix: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(92.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD30D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 13.dp, vertical = 11.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Column {
                Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(suffix, color = GoldSoft, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextSoft, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SevenDayFocusChart(days: List<LocalDate>, minutes: List<Int>) {
    val maxMinutes = (minutes.maxOrNull() ?: 0).coerceAtLeast(1)
    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(112.dp)) {
            val count = minutes.size.coerceAtLeast(1)
            val gap = 8.dp.toPx()
            val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(2.dp.toPx())
            val baseline = size.height - 4.dp.toPx()
            drawLine(
                color = Color(0x444B5664),
                start = Offset(0f, baseline),
                end = Offset(size.width, baseline),
                strokeWidth = 1.dp.toPx()
            )
            minutes.forEachIndexed { index, value ->
                val fraction = value.toFloat() / maxMinutes.toFloat()
                val barHeight = if (value == 0) 4.dp.toPx() else (size.height * 0.86f * fraction).coerceAtLeast(8.dp.toPx())
                val left = index * (barWidth + gap)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(GoldSoft, Gold, Color(0xFFC58D20))),
                    topLeft = Offset(left, baseline - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            days.forEach { day ->
                Text(
                    text = day.dayOfWeek.name.take(1),
                    color = if (day == LocalDate.now()) GoldSoft else TextSoft,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MissionHistoryRow(entry: MissionHistoryEntry) {
    val dateText = remember(entry.timestamp) {
        val formatter = DateTimeFormatter.ofPattern("MMM d • HH:mm", Locale.US)
        Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.systemDefault()).format(formatter)
    }
    val resultColor = historyResultColor(entry.result)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xBF0D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color(0x292D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(entry.missionTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(dateText, color = TextSoft, fontSize = 9.sp)
                }
                Spacer(Modifier.width(10.dp))
                Surface(
                    color = resultColor.copy(alpha = 0.16f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, resultColor.copy(alpha = 0.45f))
                ) {
                    Text(
                        entry.result.name.uppercase(Locale.US),
                        color = resultColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⏱ ${formatFocusTime(entry.focusSeconds)}", color = TextSoft, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("+${entry.xpEarned} XP", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("+${entry.coinsEarned} Coins", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (entry.levelRewardCoins > 0) {
                Text(
                    "Includes +${entry.levelRewardCoins} level-up bonus coins",
                    color = Gold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ProfileProgressScreen(
    player: PlayerState,
    history: List<MissionHistoryEntry>,
    settings: GameSettings,
    ownedRewards: Set<String>,
    loadout: ProfileLoadout,
    onOpenInventory: () -> Unit,
    claimedAchievements: Set<String>,
    onClaimAchievement: (Achievement) -> Unit,
    modifier: Modifier = Modifier
) {
    val zoneId = ZoneId.systemDefault()
    val achievements = buildAchievements(player, history)
    val completedAchievements = achievements.count { it.progress >= it.goal }
    val totalFocusSeconds = history.sumOf { it.focusSeconds }
    val totalDone = history.count { it.result == MissionResult.Done }
    val recordedXp = history.sumOf { it.xpEarned }
    val rankTier = currentRankTier(player.rank)
    val levelProgress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)
    val rankProgress = if (player.rank >= 100) 1f else (player.rankProgress.toFloat() / rankRequirement(player.rank).toFloat()).coerceIn(0f, 1f)
    var month by remember { mutableStateOf(YearMonth.now(zoneId)) }
    var selectedDate by remember { mutableStateOf(LocalDate.now(zoneId)) }

    val selectedEntries = history.filter { it.localDate(zoneId) == selectedDate }
    val selectedDone = selectedEntries.count { it.result == MissionResult.Done }
    val selectedFocus = selectedEntries.sumOf { it.focusSeconds }
    val selectedXp = selectedEntries.sumOf { it.xpEarned }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xDF09111A), Color(0xF20A1119), Color(0xFC080D14)))
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text("PROFILE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Your long-term progression and milestones.", color = TextSoft, fontSize = 12.sp)
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD40D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, if (loadout.frame == "elite_frame") Gold.copy(alpha = 0.95f) else Color(0x48E5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(Brush.radialGradient(listOf(Gold.copy(alpha = 0.30f), Color(0xFF172230))))
                                    .border(1.dp, Gold.copy(alpha = 0.65f), androidx.compose.foundation.shape.CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(avatarGlyph(loadout.avatar), color = GoldSoft, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("LEVEL ${player.level}  •  ${loadout.title}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Rank ${player.rank} • ${rankTier.title}", color = rankTier.secondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text("$completedAchievements/${achievements.size} achievements unlocked", color = TextSoft, fontSize = 9.5.sp)
                            }
                            Text(if (loadout.badge == "midnight_crest") "✦" else "♛", color = Gold, fontSize = 25.sp)
                        }

                        ProfileProgressRow("LEVEL XP", "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP", levelProgress, Gold)
                        ProfileProgressRow(
                            "RANK PROGRESS",
                            if (player.rank >= 100) "MAX RANK" else "${player.rankProgress} / ${rankRequirement(player.rank)} missions",
                            rankProgress,
                            rankTier.secondary
                        )
                        Button(
                            onClick = onOpenInventory,
                            modifier = Modifier.fillMaxWidth().height(40.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF182431), contentColor = GoldSoft),
                            border = BorderStroke(1.dp, Color(0x55E5C87A))
                        ) { Text("Inventory & Customize", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileMetric("DONE", totalDone.toString(), "missions", Modifier.weight(1f))
                    ProfileMetric("FOCUS", formatFocusTime(totalFocusSeconds), "total", Modifier.weight(1f))
                    ProfileMetric("BEST", player.bestCombo.toString(), "combo", Modifier.weight(1f))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileMetric("RECORDED XP", formatNumber(recordedXp), "history", Modifier.weight(1f))
                    ProfileMetric("COINS", formatNumber(player.coins), "wallet", Modifier.weight(1f))
                    ProfileMetric("BADGES", (completedAchievements + ownedRewards.size).toString(), "unlocked", Modifier.weight(1f))
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ACHIEVEMENTS", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Milestones with permanent rewards", color = TextSoft, fontSize = 9.sp)
                    }
                    Text("$completedAchievements/${achievements.size}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                }
            }

            items(achievements) { achievement ->
                AchievementCard(
                    achievement = achievement,
                    claimed = achievement.id in claimedAchievements,
                    onClaim = { onClaimAchievement(achievement) }
                )
            }

            item {
                Spacer(Modifier.height(2.dp))
                Text("ACTIVITY CALENDAR", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("Tap a day to inspect its activity", color = TextSoft, fontSize = 9.sp)
            }

            item {
                ActivityCalendarCard(
                    month = month,
                    selectedDate = selectedDate,
                    history = history,
                    onPreviousMonth = {
                        month = month.minusMonths(1)
                        selectedDate = month.atDay(1)
                    },
                    onNextMonth = {
                        month = month.plusMonths(1)
                        selectedDate = month.atDay(1)
                    },
                    onSelectDate = { selectedDate = it }
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xC90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x332D3948))
                ) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(
                            selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.US)).uppercase(Locale.US),
                            color = GoldSoft,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$selectedDone done", color = Color.White, fontSize = 11.sp)
                            Text(formatFocusTime(selectedFocus), color = TextSoft, fontSize = 11.sp)
                            Text("+$selectedXp XP", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (selectedEntries.isEmpty()) {
                            Text("No missions recorded on this day.", color = TextSoft, fontSize = 9.5.sp)
                        } else {
                            selectedEntries.take(3).forEach { entry ->
                                Text("• ${entry.missionTitle}  —  ${entry.result.name}", color = TextSoft, fontSize = 9.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileProgressRow(label: String, value: String, progress: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Box(
            Modifier.fillMaxWidth().height(6.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color(0xFF26313D))
        ) {
            Box(
                Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().background(color)
            )
        }
    }
}

@Composable
private fun ProfileMetric(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(78.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xC70D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
        border = BorderStroke(1.dp, Color(0x302D3948))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(9.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = TextSoft, fontSize = 7.2.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp, textAlign = TextAlign.Center)
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(subtitle, color = GoldSoft, fontSize = 7.5.sp)
        }
    }
}

@Composable
private fun AchievementCard(
    achievement: Achievement,
    claimed: Boolean,
    onClaim: () -> Unit
) {
    val complete = achievement.progress >= achievement.goal
    val progress = (achievement.progress.toFloat() / achievement.goal.toFloat()).coerceIn(0f, 1f)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (complete) Color(0xD61B1A10) else Color(0xC90D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, if (complete) Gold.copy(alpha = 0.55f) else Color(0x302D3948))
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (complete) Gold.copy(alpha = 0.18f) else Color(0xFF202A35)),
                contentAlignment = Alignment.Center
            ) {
                Text(achievement.glyph, color = if (complete) Gold else TextSoft, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(achievement.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${achievement.progress.coerceAtMost(achievement.goal)}/${achievement.goal}", color = if (complete) Gold else TextSoft, fontSize = 9.sp)
                }
                Text(achievement.subtitle, color = TextSoft, fontSize = 8.7.sp)
                Box(
                    Modifier.fillMaxWidth().height(4.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color(0xFF27313C))
                ) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(if (complete) Gold else Color(0xFF718096)))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("+${achievement.xpReward} XP • +${achievement.coinReward} Coins", color = GoldSoft, fontSize = 8.5.sp)
                    TextButton(onClick = onClaim, enabled = complete && !claimed, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text(if (claimed) "Claimed" else if (complete) "Claim" else "Locked", color = if (complete && !claimed) Gold else TextSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActivityCalendarCard(
    month: YearMonth,
    selectedDate: LocalDate,
    history: List<MissionHistoryEntry>,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDate: (LocalDate) -> Unit
) {
    val zoneId = ZoneId.systemDefault()
    val firstOffset = month.atDay(1).dayOfWeek.value - 1
    val days = month.lengthOfMonth()
    val weekCount = (firstOffset + days + 6) / 7
    val focusByDay = (1..days).associateWith { day ->
        val date = month.atDay(day)
        history.asSequence().filter { it.localDate(zoneId) == date }.sumOf { it.focusSeconds } / 60
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xD00D141E)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, Color(0x352D3948))
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPreviousMonth, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("‹", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)).uppercase(Locale.US),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.1.sp
                )
                TextButton(onClick = onNextMonth, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("›", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(Modifier.fillMaxWidth()) {
                listOf("M", "T", "W", "T", "F", "S", "S").forEach { label ->
                    Text(label, color = TextSoft, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                }
            }

            repeat(weekCount) { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(7) { dayOfWeek ->
                        val cell = week * 7 + dayOfWeek
                        val day = cell - firstOffset + 1
                        if (day !in 1..days) {
                            Spacer(Modifier.weight(1f).height(38.dp))
                        } else {
                            val date = month.atDay(day)
                            val minutes = focusByDay[day] ?: 0
                            val intensity = (minutes / 120f).coerceIn(0f, 1f)
                            val selected = date == selectedDate
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
                                    .background(
                                        if (minutes > 0) Gold.copy(alpha = 0.15f + 0.68f * intensity)
                                        else Color(0xFF19232E)
                                    )
                                    .then(
                                        if (selected) Modifier.border(1.dp, GoldSoft, androidx.compose.foundation.shape.RoundedCornerShape(9.dp)) else Modifier
                                    )
                                    .clickable { onSelectDate(date) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(day.toString(), color = if (minutes > 0) Color.White else TextSoft, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                    if (minutes > 0) Text("${minutes}m", color = Color.White.copy(alpha = 0.85f), fontSize = 6.5.sp)
                                }
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("Less", color = TextSoft, fontSize = 7.sp)
                Spacer(Modifier.width(5.dp))
                listOf(0.16f, 0.30f, 0.48f, 0.66f, 0.83f).forEach { alpha ->
                    Box(Modifier.padding(horizontal = 1.dp).size(9.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(2.dp)).background(Gold.copy(alpha = alpha)))
                }
                Spacer(Modifier.width(5.dp))
                Text("More", color = TextSoft, fontSize = 7.sp)
            }
        }
    }
}

@Composable
private fun OnboardingScreen(onFinish: (OnboardingProfile, Set<String>) -> Unit) {
    var name by remember { mutableStateOf("") }
    var activeStart by remember { mutableStateOf("07:00") }
    var activeEnd by remember { mutableStateOf("23:00") }
    val selected = remember {
        mutableStateListOf<String>().also { list -> list.addAll(missionTemplates.map { it.id }) }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xC9081018), Color(0xF0081018), Color(0xFF080D14)))))
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = gamifyHorizontalPadding()),
            contentPadding = PaddingValues(top = GamifySpacing.Xl, bottom = GamifySpacing.Xl),
            verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
        ) {
            item {
                Text("WELCOME TO GAMIFICATION", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.8.sp)
            }
            item {
                SettingsGroup(title = "PLAYER SETUP") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("PLAYER:", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(40) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("Name") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text("ACTIVE HOURS:", color = GoldSoft, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold)
                        OutlinedTextField(
                            value = activeStart,
                            onValueChange = { activeStart = it.take(5) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("Start") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                        Text("–", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = activeEnd,
                            onValueChange = { activeEnd = it.take(5) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            placeholder = { Text("End") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                }
            }
            item {
                SettingsGroup(title = "STARTER MISSIONS") {
                    missionTemplates.forEach { template ->
                        val isSelected = template.id in selected
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                                .clickable { if (isSelected) selected.remove(template.id) else selected.add(template.id) }
                                .background(if (isSelected) Color(0x303CCB7A) else Color(0x1919232D))
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isSelected) "✓" else "○", color = if (isSelected) Color(0xFF86EFAC) else TextSoft, fontSize = 16.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(template.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(template.subtitle, color = if (isSelected) Color(0xFFA7DDB9) else TextSoft, fontSize = 8.8.sp)
                            }
                            Text("DAILY", color = if (isSelected) GoldSoft else Color(0xFF66717E), fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        onFinish(
                            OnboardingProfile(
                                name = name.trim().ifBlank { "Player" },
                                activeStart = activeStart.ifBlank { "07:00" },
                                activeEnd = activeEnd.ifBlank { "23:00" }
                            ),
                            selected.toSet()
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(GamifyDimens.ButtonHeight),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                    shape = GamifyShapes.Field
                ) { Text("Enter My World", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: GameSettings,
    onSettingsChange: (GameSettings) -> Unit,
    onDataRestored: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var dataMessage by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) dataMessage = if (exportBackup(context, uri)) "Backup exported" else "Export failed"
    }
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            dataMessage = importBackup(context, uri)
            if (dataMessage == "Backup restored") onDataRestored()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xE90A1119), Color(0xF50A1119), Color(0xFC080D14))))
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = gamifyHorizontalPadding()),
            contentPadding = PaddingValues(top = GamifySpacing.Lg, bottom = GamifySpacing.Xl),
            verticalArrangement = Arrangement.spacedBy(GamifySpacing.Md)
        ) {
            item {
                Column {
                    Text("SETTINGS", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Tune focus, feedback and gameplay to your style.", color = TextSoft, fontSize = 12.sp)
                }
            }

            item {
                SettingsGroup(title = "FEEDBACK") {
                    SettingsToggleRow(
                        title = "Sound effects",
                        subtitle = "Mission complete and level-up sounds",
                        checked = settings.soundEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(soundEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Vibration",
                        subtitle = "Short haptics for results and rewards",
                        checked = settings.vibrationEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(vibrationEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Timer notifications",
                        subtitle = "Notify when a running mission reaches zero",
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "GAMEPLAY") {
                    SettingsToggleRow(
                        title = "Combo reward boost",
                        subtitle = "Longer combos increase XP and Coin rewards",
                        checked = settings.comboBoostEnabled,
                        onCheckedChange = { onSettingsChange(settings.copy(comboBoostEnabled = it)) }
                    )
                    SettingsDivider()
                    SettingsToggleRow(
                        title = "Reduced motion",
                        subtitle = "Disable pulse and carousel depth animations",
                        checked = settings.reducedMotion,
                        onCheckedChange = { onSettingsChange(settings.copy(reducedMotion = it)) }
                    )
                }
            }

            item {
                SettingsGroup(title = "THEME") {
                    Text(
                        "World tint",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.values().forEach { mode ->
                            ThemeChoice(
                                mode = mode,
                                selected = settings.themeMode == mode,
                                onClick = { onSettingsChange(settings.copy(themeMode = mode)) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item {
                SettingsGroup(title = "DATA & BACKUP") {
                    Text("Portable backup of app data plus Dreamboard photos.", color = TextSoft, fontSize = 10.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { exportLauncher.launch("gamification-backup.gamify.zip") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                        ) { Text("Export", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = { importLauncher.launch(arrayOf("application/zip", "application/json", "application/octet-stream", "text/plain")) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                        ) { Text("Restore", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                    dataMessage?.let {
                        Spacer(Modifier.height(7.dp))
                        Text(it, color = if (it.contains("failed", true) || it.contains("newer", true)) Color(0xFFFF8A80) else Color(0xFF86EFAC), fontSize = 9.5.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Reset all local data", color = Color(0xFFFF8A80), fontSize = 10.sp)
                    }
                    Text("Backup schema v$CURRENT_SCHEMA_VERSION • running timer is intentionally excluded", color = GamifyColors.TextMuted, fontSize = 8.5.sp)
                }
            }

            item {
                SettingsGroup(title = "SYSTEM HEALTH") {
                    val profile = loadOnboardingProfile(context)
                    Text("Release 0.60 • Player: ${profile.name} • Active: ${profile.activeStart}–${profile.activeEnd}", color = TextSoft, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { dataMessage = runDataHealthCheck(context) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("Run data health check", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text("Repairs invalid mission values, deduplicates history/notifications and refreshes the widget.", color = GamifyColors.TextMuted, fontSize = 8.5.sp)
                }
            }

            item {
                SettingsGroup(title = "CONNECTED FEATURES") {
                    val firstMission = loadMissions(context).firstOrNull()
                    val league = personalLeague(loadHistory(context))
                    Text("Personal League: $league", color = GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Android Auto Backup is enabled for device cloud restore. Real-time cross-device sync and online leaderboards require a backend account service.", color = TextSoft, fontSize = 9.5.sp)
                    Spacer(Modifier.height(9.dp))
                    Button(
                        onClick = {
                            dataMessage = if (firstMission != null && addMissionToCalendar(context, firstMission)) "Opened Calendar" else "No Calendar app found"
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233040), contentColor = GoldSoft)
                    ) { Text("Add next mission to Calendar", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(7.dp))
                    Text("Home-screen widget is included: add “Gamification” from your launcher’s Widgets menu.", color = GamifyColors.TextMuted, fontSize = 9.sp)
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xB90D141E)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0x2FE5C87A))
                ) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("COMBO RULES", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Done  →  +1 Combo", color = Color.White, fontSize = 11.sp)
                        Text("Partial  →  −1 Combo", color = TextSoft, fontSize = 11.sp)
                        Text("Fail / Defer  →  Combo resets", color = TextSoft, fontSize = 11.sp)
                        Text("Boosts: x1.10 at 3 • x1.25 at 5 • x1.50 at 10 • x2 at 20", color = GoldSoft, fontSize = 9.5.sp)
                    }
                }
            }
        }

        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                containerColor = GamifyColors.Surface,
                shape = GamifyShapes.Dialog,
                title = { Text("Reset all data?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text("Missions, history, progress, rewards and settings will return to defaults. Export a backup first if needed.", color = TextSoft, fontSize = 12.sp) },
                confirmButton = {
                    TextButton(onClick = {
                        resetGameData(context)
                        confirmReset = false
                        dataMessage = "Local data reset"
                        onDataRestored()
                    }) { Text("Reset", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun SettingsGroup(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = GamifyColors.Surface.copy(alpha = 0.90f)),
        shape = GamifyShapes.Card,
        border = BorderStroke(1.dp, GamifyColors.BorderSoft)
    ) {
        Column(Modifier.fillMaxWidth().padding(GamifySpacing.Lg)) {
            Text(title, color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(GamifySpacing.Sm))
            content()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = GamifySpacing.Md)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = TextSoft, fontSize = 9.5.sp, lineHeight = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = GamifySpacing.Sm)
            .height(1.dp)
            .background(GamifyColors.BorderSoft.copy(alpha = 0.65f))
    )
}

@Composable
private fun MissionCompletionFlight(
    mission: Mission,
    reducedMotion: Boolean,
    durationMillis: Int,
    modifier: Modifier = Modifier
) {
    val progress = remember(mission.id, mission.title, reducedMotion) { Animatable(if (reducedMotion) 1f else 0f) }
    val travelPx = with(LocalDensity.current) { 540.dp.toPx() }
    LaunchedEffect(mission.id, mission.title, reducedMotion, durationMillis) {
        if (!reducedMotion) {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = durationMillis)
            )
        }
    }
    val p = progress.value
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(112.dp)
            .graphicsLayer {
                translationY = -travelPx * p
                scaleX = 1f - 0.42f * p
                scaleY = 1f - 0.42f * p
                alpha = if (reducedMotion) 0f else (1f - p).coerceIn(0f, 1f)
            },
        colors = CardDefaults.cardColors(containerColor = Color(0xEB0B121A)),
        border = BorderStroke(1.dp, Color(0xAA55D98A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("✓", color = Color(0xFF55D98A), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                mission.title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ThemeChoice(
    mode: AppThemeMode,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val label = when (mode) {
        AppThemeMode.Classic -> "Classic"
        AppThemeMode.Midnight -> "Midnight"
        AppThemeMode.Obsidian -> "Obsidian"
    }
    val swatch = when (mode) {
        AppThemeMode.Classic -> Color(0xFFB98A36)
        AppThemeMode.Midnight -> Color(0xFF274D78)
        AppThemeMode.Obsidian -> Color(0xFF181B20)
    }
    Surface(
        modifier = modifier.height(62.dp).clickable(onClick = onClick),
        color = if (selected) Color(0x2EF7C948) else Color(0x60131B25),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (selected) Gold else Color(0x353A4654))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(19.dp).clip(androidx.compose.foundation.shape.CircleShape).background(swatch))
            Spacer(Modifier.height(5.dp))
            Text(label, color = if (selected) GoldSoft else TextSoft, fontSize = 8.5.sp, maxLines = 1)
        }
    }
}

@Composable
private fun ProgressionNoticeOverlay(
    notice: ProgressionNotice,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    val pulse = if (reducedMotion) {
        1f
    } else {
        val transition = rememberInfiniteTransition(label = "progression-notice")
        val value by transition.animateFloat(
            initialValue = 0.985f,
            targetValue = 1.015f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 700),
                repeatMode = RepeatMode.Reverse
            ),
            label = "progression-notice-pulse"
        )
        value
    }
    val accent = when (notice.kind) {
        ProgressionNoticeKind.Level -> Gold
        ProgressionNoticeKind.Rank -> currentRankTier(1).secondary
    }
    Card(
        modifier = modifier
            .width(292.dp)
            .graphicsLayer { scaleX = pulse; scaleY = pulse },
        colors = CardDefaults.cardColors(containerColor = Color(0xF20B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.78f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (notice.kind == ProgressionNoticeKind.Level) "★" else "♜",
                    color = accent,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    notice.title,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    notice.detail,
                    color = GoldSoft,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun WorldProgressDialog(
    player: PlayerState,
    onDismiss: () -> Unit
) {
    val current = currentWorldRegion(player.level)
    val next = worldRegions.firstOrNull { it.minLevel > player.level }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = {
            Column {
                Text("WORLD PROGRESSION", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                Text("${current.name} • Level ${player.level}", color = GoldSoft, fontSize = 10.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(420.dp)),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(worldRegions) { region ->
                    val unlocked = player.level >= region.minLevel
                    val active = region == current
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (active) Color(0xD2211C10) else Color(0xC916202B)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(17.dp),
                        border = BorderStroke(1.dp, if (active) Gold.copy(alpha = 0.75f) else Color(0x332F3A47))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(if (unlocked) Gold.copy(alpha = 0.18f) else Color(0x281A2430)),
                                contentAlignment = Alignment.Center
                            ) { Text(if (unlocked) "✦" else "🔒", color = if (unlocked) Gold else TextSoft, fontSize = 16.sp) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(region.name, color = if (unlocked) Color.White else TextSoft, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(region.subtitle, color = TextSoft, fontSize = 8.5.sp)
                            }
                            Text(if (active) "ACTIVE" else if (unlocked) "UNLOCKED" else "LV ${region.minLevel}", color = if (active) Gold else TextSoft, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (next != null) {
                    item {
                        val span = (next.minLevel - current.minLevel).coerceAtLeast(1)
                        val progress = ((player.level - current.minLevel).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                        Column(Modifier.fillMaxWidth().padding(top = 5.dp)) {
                            Text("NEXT WORLD • ${next.name} AT LEVEL ${next.minLevel}", color = GoldSoft, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.fillMaxWidth().height(6.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFF27313C))) {
                                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Gold))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Gold) } }
    )
}

@Composable
private fun InventoryDialog(
    owned: Set<String>,
    loadout: ProfileLoadout,
    onEquip: (ProfileLoadout) -> Unit,
    onDismiss: () -> Unit
) {
    val avatars = listOf(
        "crown" to "Crown",
        "knight_avatar" to "Knight",
        "flame_avatar" to "Flame",
        "star_avatar" to "Star"
    )
    val titles = listOf("Pathfinder", "Focused", "Legend")
    val frames = listOf("default" to "Classic", "elite_frame" to "Elite")
    val badges = listOf("none" to "None", "midnight_crest" to "Midnight Crest")

    fun unlocked(id: String): Boolean = when (id) {
        "crown", "default", "none", "Pathfinder", "Focused" -> true
        "Legend" -> "legend_title" in owned
        "star_avatar" -> true
        else -> id in owned
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = {
            Column {
                Text("INVENTORY", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                Text("Equip your avatar, title, frame and badge", color = TextSoft, fontSize = 9.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(440.dp)),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("AVATAR", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        avatars.forEach { (id, label) ->
                            val ok = unlocked(id)
                            Surface(
                                modifier = Modifier.weight(1f).height(58.dp).clickable(enabled = ok) { onEquip(loadout.copy(avatar = id)) },
                                color = if (loadout.avatar == id) Color(0x33F7C948) else Color(0xFF18232E),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(13.dp),
                                border = BorderStroke(1.dp, if (loadout.avatar == id) Gold else Color(0x332F3A47))
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(if (ok) avatarGlyph(id) else "🔒", color = if (ok) GoldSoft else TextSoft, fontSize = 19.sp)
                                    Text(label, color = if (ok) Color.White else TextSoft, fontSize = 7.5.sp)
                                }
                            }
                        }
                    }
                }
                item {
                    Text("TITLE", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        titles.forEach { title ->
                            SmallSelectChip(if (unlocked(title)) title else "🔒 $title", loadout.title == title, Modifier.weight(1f)) {
                                if (unlocked(title)) onEquip(loadout.copy(title = title))
                            }
                        }
                    }
                }
                item {
                    Text("FRAME", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        frames.forEach { (id, label) ->
                            SmallSelectChip(if (unlocked(id)) label else "🔒 $label", loadout.frame == id, Modifier.weight(1f)) {
                                if (unlocked(id)) onEquip(loadout.copy(frame = id))
                            }
                        }
                    }
                }
                item {
                    Text("BADGE", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        badges.forEach { (id, label) ->
                            SmallSelectChip(if (unlocked(id)) label else "🔒 $label", loadout.badge == id, Modifier.weight(1f)) {
                                if (unlocked(id)) onEquip(loadout.copy(badge = id))
                            }
                        }
                    }
                }
                item {
                    val inventory = shopRewards.filter { it.id in owned }
                    Text("OWNED REWARDS  ${inventory.size}", color = GoldSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (inventory.isEmpty()) {
                        Text("Your purchased and chest rewards will appear here.", color = TextSoft, fontSize = 9.sp)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            inventory.forEach { reward ->
                                Row(
                                    Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).background(Color(0xFF17212C)).padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("✦", color = Gold, fontSize = 15.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text(reward.title, color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        Text(reward.subtitle, color = TextSoft, fontSize = 8.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Gold) } }
    )
}

@Composable
private fun ShopDialog(
    player: PlayerState,
    rewards: List<PersonalReward>,
    redemptions: List<RewardRedemptionEntry>,
    onAdd: (PersonalReward) -> Unit,
    onUpdate: (Int, PersonalReward) -> Unit,
    onDelete: (Int) -> Unit,
    onRedeem: (Int, PersonalReward) -> RewardRedemptionStatus,
    onDismiss: () -> Unit
) {
    var message by remember { mutableStateOf<String?>(null) }
    var messageIsError by remember { mutableStateOf(false) }
    var editorIndex by remember { mutableStateOf<Int?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showChecked by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val ordered = rewards.mapIndexed { index, reward -> index to reward }
        .sortedWith(
            compareBy<Pair<Int, PersonalReward>> { it.second.completed && !it.second.reusable }
                .thenBy { if (it.second.position > 0) it.second.position else Int.MAX_VALUE }
                .thenBy { it.first }
        )
    val visible = if (showChecked) ordered else ordered.filterNot { it.second.completed && !it.second.reusable }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 84.dp, start = gamifyHorizontalPadding(), end = gamifyHorizontalPadding(), bottom = GamifySpacing.Lg),
                contentAlignment = Alignment.TopCenter
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth().fillMaxHeight(),
                    color = GamifyColors.Surface.copy(alpha = 0.96f),
                    shape = GamifyShapes.Dialog,
                    border = BorderStroke(1.dp, GamifyColors.BorderSoft)
                ) {
                    Column(Modifier.fillMaxSize().padding(GamifySpacing.Md)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    editorIndex = null
                                    showEditor = true
                                    message = null
                                },
                                modifier = Modifier.weight(1f).height(GamifyDimens.CompactButtonHeight),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800)),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                            ) { Text("+  افزودن پاداش", fontWeight = FontWeight.ExtraBold) }
                            TextButton(onClick = onDismiss, modifier = Modifier.height(GamifyDimens.CompactButtonHeight)) {
                                Text("بستن", color = TextSoft, fontSize = 11.sp)
                            }
                        }

                        message?.let { msg ->
                            Spacer(Modifier.height(6.dp))
                            Text(
                                msg,
                                color = if (messageIsError) Color(0xFFFFC7A8) else GoldSoft,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        if (showHistory) {
                            if (redemptions.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Text("هنوز پاداشی استفاده نشده", color = TextSoft, fontSize = 11.sp)
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.weight(1f).fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    items(redemptions.take(100), key = { it.transactionId }) { entry ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xD218222D)),
                                            shape = GamifyShapes.Field,
                                            border = BorderStroke(1.dp, GamifyColors.BorderSoft)
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp),
                                                horizontalAlignment = Alignment.End
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        "−${formatNumber(entry.price)} سکه",
                                                        color = Color(0xFFFFC98B),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        entry.rewardTitle,
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        textAlign = TextAlign.End,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f).padding(start = 8.dp)
                                                    )
                                                }
                                                Spacer(Modifier.height(3.dp))
                                                Text(
                                                    "${formatRewardRedemptionTime(entry.timestamp)}  •  ${if (entry.reusable) "نامحدود" else "یک‌باره"}  •  مانده ${formatNumber(entry.balanceAfter)}",
                                                    color = TextSoft,
                                                    fontSize = 9.sp,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { showHistory = false; message = null }) {
                                    Text("بازگشت به پاداش‌ها", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(visible, key = { it.second.id }) { (index, reward) ->
                                    val completedOneTime = reward.completed && !reward.reusable
                                    val affordable = player.coins >= reward.price
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (completedOneTime) Color(0xB315241E) else Color(0xD218222D)
                                        ),
                                        shape = GamifyShapes.Field,
                                        border = BorderStroke(1.dp, if (completedOneTime) GamifyColors.Success.copy(alpha = 0.55f) else GamifyColors.BorderSoft)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    if (!completedOneTime) {
                                                        val status = onRedeem(index, reward)
                                                        messageIsError = status in setOf(
                                                            RewardRedemptionStatus.InsufficientCoins,
                                                            RewardRedemptionStatus.AlreadyCompleted,
                                                            RewardRedemptionStatus.InvalidReward,
                                                            RewardRedemptionStatus.StorageFailure
                                                        )
                                                        message = when (status) {
                                                            RewardRedemptionStatus.Success -> if (reward.reusable) "${reward.title} ثبت شد" else "${reward.title} ✓"
                                                            RewardRedemptionStatus.InsufficientCoins -> "برای این پاداش سکه کافی نیست"
                                                            RewardRedemptionStatus.AlreadyCompleted -> "این پاداش قبلاً استفاده شده"
                                                            RewardRedemptionStatus.Duplicate -> "در حال ثبت پاداش…"
                                                            RewardRedemptionStatus.InvalidReward -> "پاداش پیدا نشد"
                                                            RewardRedemptionStatus.StorageFailure -> "ذخیره پاداش انجام نشد"
                                                        }
                                                    }
                                                },
                                                enabled = !completedOneTime,
                                                modifier = Modifier.size(48.dp),
                                                contentPadding = PaddingValues(0.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = when {
                                                        completedOneTime -> Color(0xFF2F8D61)
                                                        affordable -> Gold
                                                        else -> Gold.copy(alpha = 0.38f)
                                                    },
                                                    contentColor = when {
                                                        completedOneTime -> Color.White
                                                        affordable -> Color(0xFF211800)
                                                        else -> Color.White.copy(alpha = 0.82f)
                                                    },
                                                    disabledContainerColor = Color(0xFF2F8D61),
                                                    disabledContentColor = Color.White
                                                ),
                                                shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp)
                                            ) { Text("✓", fontSize = 25.sp, fontWeight = FontWeight.Black) }

                                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                                Text(
                                                    reward.title,
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth(),
                                                    textDecoration = if (completedOneTime) TextDecoration.LineThrough else TextDecoration.None
                                                )
                                                Spacer(Modifier.height(2.dp))
                                                Text(
                                                    "${formatNumber(reward.price)} سکه  •  ${if (reward.reusable) "نامحدود" else "یک‌باره"}  •  جایگاه ${reward.position.coerceAtLeast(1)}",
                                                    color = if (affordable || completedOneTime) Color(0xFFE7C96F) else Color(0xFFD7A68E),
                                                    fontSize = 9.2.sp,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                                if (reward.reusable && reward.redeemCount > 0) {
                                                    Text(
                                                        "${reward.redeemCount} بار استفاده شده",
                                                        color = TextSoft,
                                                        fontSize = 8.5.sp,
                                                        textAlign = TextAlign.End,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                }
                                            }
                                            Text(
                                                "✎",
                                                color = Color(0xFFC9D2DE),
                                                fontSize = 13.sp,
                                                modifier = Modifier.clickable {
                                                    editorIndex = index
                                                    showEditor = true
                                                    message = null
                                                }.padding(3.dp)
                                            )
                                            Text(
                                                "×",
                                                color = Color(0xFFFF8D8D),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    onDelete(index)
                                                    messageIsError = false
                                                    message = "پاداش حذف شد"
                                                }.padding(3.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { showHistory = true; message = null }) {
                                    Text("تاریخچه استفاده", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("نمایش تیک‌خورده‌ها", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = showChecked, onCheckedChange = { showChecked = it })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        val existing = editorIndex?.let { rewards.getOrNull(it) }
        RewardEditorDialog(
            initial = existing,
            rewardCount = rewards.size,
            onDismiss = { showEditor = false },
            onSave = { reward ->
                val index = editorIndex
                if (index == null) onAdd(reward) else onUpdate(index, reward)
                showEditor = false
                message = null
            }
        )
    }
}

@Composable
private fun RewardEditorDialog(
    initial: PersonalReward?,
    rewardCount: Int,
    onDismiss: () -> Unit,
    onSave: (PersonalReward) -> Unit
) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var priceText by remember(initial?.id) { mutableStateOf(initial?.price?.toString() ?: "100") }
    var reusable by remember(initial?.id) { mutableStateOf(initial?.reusable ?: false) }
    val maxPosition = (rewardCount + if (initial == null) 1 else 0).coerceAtLeast(1)
    var position by remember(initial?.id, maxPosition) {
        mutableIntStateOf((initial?.position ?: maxPosition).coerceIn(1, maxPosition))
    }
    var positionExpanded by remember { mutableStateOf(false) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = GamifyColors.Surface,
            shape = GamifyShapes.Dialog,
            title = { Text(if (initial == null) "افزودن پاداش" else "ویرایش پاداش", color = Color.White, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("نام پاداش") },
                        singleLine = true,
                        colors = readableOutlinedFieldColors(),
                        shape = GamifyShapes.Field,
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight)
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter(Char::isDigit).take(7) },
                        label = { Text("قیمت به سکه") },
                        singleLine = true,
                        colors = readableOutlinedFieldColors(),
                        shape = GamifyShapes.Field,
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallSelectChip("یک‌باره", !reusable, Modifier.weight(1f)) { reusable = false }
                        SmallSelectChip("نامحدود", reusable, Modifier.weight(1f)) { reusable = true }
                    }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(GamifyDimens.FieldMinHeight)
                                .clickable { positionExpanded = true },
                            color = GamifyColors.SurfaceInput,
                            shape = GamifyShapes.Field,
                            border = BorderStroke(1.dp, GamifyColors.Border)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("موقعیت: $position از $maxPosition", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("▾", color = GoldSoft, fontSize = 15.sp)
                            }
                        }
                        DropdownMenu(expanded = positionExpanded, onDismissRequest = { positionExpanded = false }) {
                            (1..maxPosition).forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("$option از $maxPosition", color = if (option == position) Gold else Color.White) },
                                    onClick = {
                                        position = option
                                        positionExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val price = priceText.toIntOrNull()?.coerceAtLeast(1) ?: 1
                        val id = initial?.id ?: "personal_${System.currentTimeMillis()}"
                        onSave(
                            PersonalReward(
                                id = id,
                                title = title.trim().ifBlank { "پاداش من" },
                                price = price,
                                reusable = reusable,
                                completed = if (reusable) false else (initial?.completed ?: false),
                                redeemCount = initial?.redeemCount ?: 0,
                                position = position
                            )
                        )
                    }
                ) { Text("ذخیره", color = Gold, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف", color = TextSoft) } }
        )
    }
}

@Composable
private fun MissionsDialog(
    missions: List<Mission>,
    history: List<MissionHistoryEntry>,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val ordered = orderedMissionsForDisplay(missions, history)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = {
            Column {
                Text("MISSIONS", color = Color.White, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                Text("All mission cards in one place", color = TextSoft, fontSize = 9.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(470.dp)),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(ordered) { (index, mission) ->
                    val state = missionCardState(mission, history)
                    val accent = when (state) {
                        MissionCardState.Active -> Gold
                        MissionCardState.Done -> Color(0xFF55D98A)
                        MissionCardState.Failed -> Color(0xFFE06666)
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { if (state == MissionCardState.Active) onSelect(index) },
                        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(25.dp).clip(androidx.compose.foundation.shape.CircleShape).background(accent.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    when (state) { MissionCardState.Active -> "▶"; MissionCardState.Done -> "✓"; MissionCardState.Failed -> "×" },
                                    color = accent,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    mission.title,
                                    color = if (state == MissionCardState.Active) Color.White else Color(0xFFC7CDD4),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textDecoration = if (state == MissionCardState.Active) null else TextDecoration.LineThrough
                                )
                                Text("+${mission.xpReward} XP  •  +${mission.coinReward} Coins  •  ${mission.durationMinutes} min", color = TextSoft, fontSize = 8.sp)
                            }
                            Text(
                                when (state) { MissionCardState.Active -> "OPEN"; MissionCardState.Done -> "DONE"; MissionCardState.Failed -> "MISSED" },
                                color = accent,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Gold) } }
    )
}

@Composable
private fun GameBottomNavigation(selected: Int, onSelect: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x520B1119),
                        Color(0xB20A1018),
                        Color(0xE2080D14)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0x55E5C87A), Color.Transparent)
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(size.width, 1.dp.toPx())
                )
            }
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(BottomNavType.Home, "خانه", 0),
                Triple(BottomNavType.Stats, "آمار", 1),
                Triple(BottomNavType.Settings, "تنظیمات", 2),
                Triple(BottomNavType.Profile, "پروفایل", 3)
            )
            items.forEach { (type, title, index) ->
                BottomNavItem(
                    type = type,
                    title = title,
                    selected = selected == index,
                    onClick = { onSelect(index) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    type: BottomNavType,
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconColor = if (selected) Gold else Color(0xFFB3BBC7)
    val textColor = if (selected) GoldSoft else Color(0xFFA6AFBC)

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(width = 46.dp, height = 30.dp)
                .drawBehind {
                    if (selected) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color(0x38F6C84C), Color(0x12F6C84C), Color.Transparent),
                                center = center,
                                radius = size.width * 0.52f
                            ),
                            radius = size.width * 0.52f,
                            center = center
                        )
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, Gold.copy(alpha = 0.85f), Color.Transparent)
                            ),
                            topLeft = Offset(size.width * 0.16f, 0f),
                            size = Size(size.width * 0.68f, 1.5.dp.toPx()),
                            cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            BottomNavIcon(type = type, color = iconColor)
        }
        Spacer(Modifier.height(1.dp))
        Text(
            text = title,
            color = textColor,
            fontSize = 9.5.sp,
            lineHeight = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun BottomNavIcon(type: BottomNavType, color: Color) {
    Canvas(modifier = Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.5.dp.toPx()
        when (type) {
            BottomNavType.Home -> {
                // Compact gamepad icon.
                val body = Path().apply {
                    moveTo(w * 0.22f, h * 0.42f)
                    cubicTo(w * 0.28f, h * 0.24f, w * 0.42f, h * 0.23f, w * 0.50f, h * 0.31f)
                    cubicTo(w * 0.58f, h * 0.23f, w * 0.72f, h * 0.24f, w * 0.78f, h * 0.42f)
                    lineTo(w * 0.88f, h * 0.70f)
                    cubicTo(w * 0.91f, h * 0.80f, w * 0.82f, h * 0.88f, w * 0.73f, h * 0.81f)
                    lineTo(w * 0.60f, h * 0.70f)
                    lineTo(w * 0.40f, h * 0.70f)
                    lineTo(w * 0.27f, h * 0.81f)
                    cubicTo(w * 0.18f, h * 0.88f, w * 0.09f, h * 0.80f, w * 0.12f, h * 0.70f)
                    close()
                }
                drawPath(body, color = color, style = Stroke(width = stroke))
                drawLine(color, Offset(w * 0.31f, h * 0.48f), Offset(w * 0.31f, h * 0.64f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(w * 0.23f, h * 0.56f), Offset(w * 0.39f, h * 0.56f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.67f, h * 0.51f))
                drawCircle(color, radius = 1.4.dp.toPx(), center = Offset(w * 0.75f, h * 0.60f))
            }
            BottomNavType.Stats -> {
                drawRoundRect(color = color, topLeft = Offset(w * 0.16f, h * 0.56f), size = Size(w * 0.14f, h * 0.28f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.43f, h * 0.38f), size = Size(w * 0.14f, h * 0.46f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
                drawRoundRect(color = color, topLeft = Offset(w * 0.70f, h * 0.20f), size = Size(w * 0.14f, h * 0.64f), cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()))
            }
            BottomNavType.Profile -> {
                drawCircle(color = color, radius = w * 0.16f, center = Offset(w * 0.50f, h * 0.32f), style = Stroke(width = stroke))
                val shoulders = Path().apply {
                    moveTo(w * 0.20f, h * 0.82f)
                    cubicTo(w * 0.24f, h * 0.60f, w * 0.38f, h * 0.54f, w * 0.50f, h * 0.54f)
                    cubicTo(w * 0.62f, h * 0.54f, w * 0.76f, h * 0.60f, w * 0.80f, h * 0.82f)
                }
                drawPath(shoulders, color = color, style = Stroke(width = stroke, cap = StrokeCap.Round))
            }
            BottomNavType.Settings -> {
                drawCircle(color = color, radius = w * 0.23f, center = center, style = Stroke(width = stroke))
                drawCircle(color = color, radius = w * 0.07f, center = center)
                val cx = center.x
                val cy = center.y
                val r1 = w * 0.30f
                val r2 = w * 0.42f
                listOf(0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f).forEach { a ->
                    val rad = Math.toRadians(a.toDouble())
                    val p1 = Offset(cx + cos(rad).toFloat() * r1, cy + sin(rad).toFloat() * r1)
                    val p2 = Offset(cx + cos(rad).toFloat() * r2, cy + sin(rad).toFloat() * r2)
                    drawLine(color, p1, p2, strokeWidth = stroke, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun GameHome(
    player: PlayerState,
    hudRewardCue: HudRewardCue?,
    quote: String,
    missions: List<Mission>,
    settings: GameSettings,
    onStartMission: (Mission) -> Unit,
    onAddMission: (Int, Mission) -> Unit,
    onUpdateMission: (Int, Int, Mission) -> Unit,
    onDeleteMission: (Int) -> Unit,
    onOpenDreamboard: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenWorldMap: () -> Unit,
    onOpenMissions: () -> Unit,
    unreadNotificationCount: Int,
    focusMissionIndex: Int?,
    focusRequest: Int,
    history: List<MissionHistoryEntry>,
    claimedChallenges: Set<String>,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize().background(Bg)) {
        Image(
            painter = painterResource(id = R.drawable.world_home),
            contentDescription = "World Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(themeOverlay(settings.themeMode)))
        Box(Modifier.fillMaxSize().background(currentWorldRegion(player.level).tint))

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x6A081118),
                        Color(0x140A1118),
                        Color(0x120B1118),
                        Color(0x46091018),
                        Color(0xD8091018)
                    ),
                    startY = 0f,
                    endY = size.height
                )
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0x4C050B12),
                        Color(0x14050B12),
                        Color(0x00050B12),
                        Color(0x14050B12),
                        Color(0x4C050B12)
                    )
                )
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x18FFFFFF), Color(0x08FFFFFF), Color.Transparent)
                ),
                topLeft = Offset(0f, 0f),
                size = Size(size.width, size.height * 0.14f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            TopGameHud(player, hudRewardCue)
            Spacer(Modifier.height(8.dp))
            WorldStage(
                player = player,
                quote = quote,
                missions = missions,
                settings = settings,
                onStartMission = onStartMission,
                onAddMission = onAddMission,
                onUpdateMission = onUpdateMission,
                onDeleteMission = onDeleteMission,
                onOpenDreamboard = onOpenDreamboard,
                onOpenShop = onOpenShop,
                onOpenWorldMap = onOpenWorldMap,
                onOpenMissions = onOpenMissions,
                unreadNotificationCount = unreadNotificationCount,
                focusMissionIndex = focusMissionIndex,
                focusRequest = focusRequest,
                history = history,
                claimedChallenges = claimedChallenges,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun WorldStage(
    player: PlayerState,
    quote: String,
    missions: List<Mission>,
    settings: GameSettings,
    onStartMission: (Mission) -> Unit,
    onAddMission: (Int, Mission) -> Unit,
    onUpdateMission: (Int, Int, Mission) -> Unit,
    onDeleteMission: (Int) -> Unit,
    onOpenDreamboard: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenWorldMap: () -> Unit,
    onOpenMissions: () -> Unit,
    unreadNotificationCount: Int,
    focusMissionIndex: Int?,
    focusRequest: Int,
    history: List<MissionHistoryEntry>,
    claimedChallenges: Set<String>,
    modifier: Modifier = Modifier
) {
    var showAddMission by remember { mutableStateOf(false) }
    var showTemplatePicker by remember { mutableStateOf(false) }
    var addDraft by remember { mutableStateOf(defaultMission().copy(title = "")) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var pendingScrollPage by remember { mutableStateOf<Int?>(null) }
    val displayMissions = orderedMissionsForDisplay(missions, history)
    val pagerState = rememberPagerState(pageCount = { displayMissions.size + 1 })
    val challenges = buildChallenges(history)
    val completedChallengeCount = challenges.count { it.progress >= it.goal }
    val unclaimedChallengeCount = challenges.count { it.progress >= it.goal && it.claimKey !in claimedChallenges }

    LaunchedEffect(missions.size, pendingScrollPage) {
        val maxPage = displayMissions.size
        if (pagerState.currentPage > maxPage) pagerState.scrollToPage(maxPage)
        pendingScrollPage?.let { target ->
            pagerState.animateScrollToPage(target.coerceIn(0, maxPage))
            pendingScrollPage = null
        }
    }

    LaunchedEffect(focusMissionIndex, focusRequest, displayMissions.size) {
        val originalIndex = focusMissionIndex ?: return@LaunchedEffect
        val displayIndex = displayMissions.indexOfFirst { it.first == originalIndex }
        if (displayIndex >= 0 && pagerState.currentPage != displayIndex) {
            pagerState.animateScrollToPage(displayIndex)
        }
    }

    LaunchedEffect(history.size) {
        if (history.isNotEmpty() && displayMissions.isNotEmpty() && !settings.reducedMotion) {
            delay(140L)
            val firstActive = displayMissions.indexOfFirst { missionCardState(it.second, history) == MissionCardState.Active }
            if (firstActive >= 0 && pagerState.currentPage != firstActive) {
                pagerState.animateScrollToPage(firstActive)
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(
                type = WorldButtonType.Dreamboard,
                label = "Dreamboard",
                badge = false,
                onClick = onOpenDreamboard
            )
            SideWorldButton(type = WorldButtonType.Map, label = "Map", onClick = onOpenWorldMap)
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 0.dp, top = 2.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            SideWorldButton(type = WorldButtonType.Missions, label = "Missions", badge = false, onClick = onOpenMissions)
            SideWorldButton(type = WorldButtonType.Shop, label = "Shop", onClick = onOpenShop)
        }

        HeadlineBlock(
            quote = quote,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp, start = 76.dp, end = 76.dp)
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 164.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) { page ->
            val pageOffset = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                .coerceIn(0f, 1f)
            val scale = if (settings.reducedMotion) 1f else 1f - (pageOffset * 0.035f)
            val pageAlpha = if (settings.reducedMotion) 1f else 1f - (pageOffset * 0.16f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        alpha = pageAlpha
                    }
            ) {
                if (page < displayMissions.size) {
                    val (originalIndex, mission) = displayMissions[page]
                    MissionCard(
                        mission = mission,
                        onStart = { onStartMission(mission) },
                        onManage = { editingIndex = originalIndex },
                        history = history,
                        reducedMotion = settings.reducedMotion,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                } else {
                    AddMissionCard(
                        onClick = { showTemplatePicker = true },
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            }
        }

            Spacer(Modifier.height(5.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(displayMissions.size + 1) { index ->
                    PageDot(active = pagerState.currentPage == index)
                }
            }
        }
    }

    if (showTemplatePicker) {
        MissionTemplatePickerDialog(
            onChoose = { templateMission ->
                addDraft = templateMission
                showTemplatePicker = false
                showAddMission = true
            },
            onDismiss = { showTemplatePicker = false }
        )
    }

    if (showAddMission) {
        AddMissionDialog(
            initialMission = addDraft,
            missionCount = missions.size,
            onDismiss = { showAddMission = false },
            onCreate = { position, mission ->
                onAddMission(position, mission)
                pendingScrollPage = position
                showAddMission = false
            }
        )
    }

    editingIndex?.let { index ->
        if (index in missions.indices) {
            EditMissionDialog(
                mission = missions[index],
                currentIndex = index,
                missionCount = missions.size,
                onDismiss = { editingIndex = null },
                onSave = { newPosition, mission ->
                    onUpdateMission(index, newPosition, mission)
                    pendingScrollPage = newPosition
                    editingIndex = null
                },
                onDelete = {
                    onDeleteMission(index)
                    editingIndex = null
                }
            )
        } else {
            editingIndex = null
        }
    }
}

@Composable
private fun AddMissionCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(142.dp)
            .clickable(onClick = onClick)
            .border(1.dp, Color(0x66D8B55E), androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xC90B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0x22F7C948))
                    .border(1.dp, Color(0x99F7C948), androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Light)
            }
            Spacer(Modifier.height(5.dp))
            Text("Add New Mission", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text("Create a card and choose its position", color = TextSoft, fontSize = 9.sp)
        }
    }
}

@Composable
private fun AddMissionDialog(
    initialMission: Mission,
    missionCount: Int,
    onDismiss: () -> Unit,
    onCreate: (Int, Mission) -> Unit
) {
    MissionEditorDialog(
        titleText = "Create Mission Card",
        initialMission = initialMission,
        initialPosition = missionCount + 1,
        maxPosition = missionCount + 1,
        confirmText = "Create",
        showDelete = false,
        onDismiss = onDismiss,
        onConfirm = { position, mission -> onCreate(position - 1, mission) },
        onDelete = {}
    )
}

@Composable
private fun EditMissionDialog(
    mission: Mission,
    currentIndex: Int,
    missionCount: Int,
    onDismiss: () -> Unit,
    onSave: (Int, Mission) -> Unit,
    onDelete: () -> Unit
) {
    MissionEditorDialog(
        titleText = "Edit Mission",
        initialMission = mission,
        initialPosition = currentIndex + 1,
        maxPosition = missionCount.coerceAtLeast(1),
        confirmText = "Save",
        showDelete = true,
        onDismiss = onDismiss,
        onConfirm = { position, updated -> onSave(position - 1, updated) },
        onDelete = onDelete
    )
}

@Composable
private fun MissionEditorDialog(
    titleText: String,
    initialMission: Mission,
    initialPosition: Int,
    maxPosition: Int,
    confirmText: String,
    showDelete: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int, Mission) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(initialMission) { mutableStateOf(initialMission.title) }
    var duration by remember(initialMission) { mutableStateOf(initialMission.durationMinutes.toString()) }
    var xp by remember(initialMission) { mutableStateOf(initialMission.xpReward.toString()) }
    var coins by remember(initialMission) { mutableStateOf(initialMission.coinReward.toString()) }
    var position by remember(initialMission, initialPosition) { mutableIntStateOf(initialPosition) }
    var positionExpanded by remember { mutableStateOf(false) }
    var rankMission by remember(initialMission) { mutableStateOf(initialMission.isRankMission) }
    var repeat by remember(initialMission) { mutableStateOf(if (initialMission.repeat == MissionRepeat.None) MissionRepeat.None else MissionRepeat.Daily) }
    var reminderHour by remember(initialMission) { mutableStateOf(initialMission.reminderHour.takeIf { it >= 0 }?.toString() ?: "") }
    var subtasks by remember(initialMission) { mutableStateOf(initialMission.subtasks) }
    var newSubtask by remember(initialMission) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = { Text(titleText, color = GamifyColors.TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(470.dp)),
                verticalArrangement = Arrangement.spacedBy(GamifySpacing.Sm)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = GamifyDimens.FieldMinHeight),
                        label = { Text("Mission title") },
                        singleLine = true,
                        colors = gamifyTextFieldColors(),
                        shape = GamifyShapes.Field
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = duration,
                            onValueChange = { duration = it.filter(Char::isDigit).take(3) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            label = { Text("Min") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                        OutlinedTextField(
                            value = xp,
                            onValueChange = { xp = it.filter(Char::isDigit).take(4) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            label = { Text("XP") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                        OutlinedTextField(
                            value = coins,
                            onValueChange = { coins = it.filter(Char::isDigit).take(4) },
                            modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                            label = { Text("Coins") },
                            singleLine = true,
                            colors = gamifyTextFieldColors(),
                            shape = GamifyShapes.Field
                        )
                    }
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Rank Mission", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Switch(checked = rankMission, onCheckedChange = { rankMission = it })
                    }
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Repeat schedule:", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SmallSelectChip("None", repeat == MissionRepeat.None, modifier = Modifier.width(86.dp)) {
                                repeat = MissionRepeat.None
                                reminderHour = ""
                            }
                            SmallSelectChip("Daily", repeat == MissionRepeat.Daily, modifier = Modifier.width(86.dp)) { repeat = MissionRepeat.Daily }
                        }
                    }
                }
                if (repeat == MissionRepeat.Daily) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Reminder time:", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            CompactHourField(
                                value = reminderHour,
                                onValueChange = { reminderHour = it.filter(Char::isDigit).take(2) }
                            )
                        }
                    }
                }
                item {
                    Text("Subtasks", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        subtasks.forEachIndexed { index, subtask ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = subtask,
                                    onValueChange = { value ->
                                        subtasks = subtasks.toMutableList().also { it[index] = value.take(120) }
                                    },
                                    modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                                    placeholder = { Text("Subtask") },
                                    singleLine = true,
                                    colors = gamifyTextFieldColors(),
                                    shape = GamifyShapes.Field
                                )
                                TextButton(
                                    onClick = { subtasks = subtasks.toMutableList().also { it.removeAt(index) } }
                                ) {
                                    Text("×", color = Color(0xFFFF7A7A), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = newSubtask,
                                onValueChange = { newSubtask = it.take(120) },
                                modifier = Modifier.weight(1f).heightIn(min = GamifyDimens.FieldMinHeight),
                                placeholder = { Text("Add subtask") },
                                singleLine = true,
                                colors = gamifyTextFieldColors()
                            )
                            TextButton(
                                onClick = {
                                    val clean = newSubtask.trim()
                                    if (clean.isNotEmpty()) {
                                        subtasks = subtasks + clean
                                        newSubtask = ""
                                    }
                                }
                            ) {
                                Text("+", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                item {
                    Text("Card position", color = GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth().height(GamifyDimens.FieldMinHeight).clickable { positionExpanded = true },
                            color = GamifyColors.SurfaceInput,
                            shape = GamifyShapes.Field,
                            border = BorderStroke(1.dp, GamifyColors.Border)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("$position of $maxPosition", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("▾", color = GoldSoft, fontSize = 15.sp)
                            }
                        }
                        DropdownMenu(
                            expanded = positionExpanded,
                            onDismissRequest = { positionExpanded = false }
                        ) {
                            (1..maxPosition).forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("$option of $maxPosition", color = if (option == position) Gold else Color.White) },
                                    onClick = {
                                        position = option
                                        positionExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val hour = reminderHour.toIntOrNull()?.takeIf { it in 0..23 } ?: -1
                    onConfirm(
                        position,
                        Mission(
                            title = title.trim().ifEmpty { "New Mission" },
                            durationMinutes = duration.toIntOrNull()?.coerceAtLeast(1) ?: 45,
                            xpReward = xp.toIntOrNull()?.coerceAtLeast(0) ?: 50,
                            coinReward = coins.toIntOrNull()?.coerceAtLeast(0) ?: 20,
                            isRankMission = rankMission,
                            repeat = repeat,
                            reminderHour = if (repeat == MissionRepeat.Daily) hour else -1,
                            reminderMinute = if (repeat == MissionRepeat.Daily && hour >= 0) 0 else -1,
                            subtasks = subtasks.map { it.trim() }.filter { it.isNotEmpty() },
                            id = initialMission.id
                        )
                    )
                }
            ) { Text(confirmText, color = Gold, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showDelete) {
                    TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFFF7A7A), fontWeight = FontWeight.Bold) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel", color = TextSoft) }
            }
        }
    )
}

@Composable
private fun SmallSelectChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(38.dp).clickable(onClick = onClick),
        color = if (selected) Gold.copy(alpha = 0.16f) else GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.dp, if (selected) Gold else GamifyColors.BorderSoft)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, color = if (selected) GoldSoft else GamifyColors.TextSecondary, fontSize = 9.5.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun CompactHourField(value: String, onValueChange: (String) -> Unit) {
    Surface(
        modifier = Modifier.width(122.dp).height(GamifyDimens.CompactFieldHeight),
        color = GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.dp, GamifyColors.Border)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(
                color = GamifyColors.TextPrimary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            ),
            cursorBrush = SolidColor(Gold),
            modifier = Modifier.fillMaxSize(),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (value.isBlank()) Text("Hour", color = GamifyColors.TextMuted, fontSize = 12.sp)
                    innerTextField()
                }
            }
        )
    }
}

@Composable
private fun CompactSubtaskField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(GamifyDimens.FieldMinHeight),
        color = GamifyColors.SurfaceInput,
        shape = GamifyShapes.Chip,
        border = BorderStroke(1.5.dp, Gold)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(
                color = GamifyColors.TextPrimary,
                fontSize = 12.sp,
                textAlign = TextAlign.End
            ),
            cursorBrush = SolidColor(Gold),
            modifier = Modifier.fillMaxSize(),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    if (value.isBlank()) {
                        Text(
                            "Add subtask",
                            color = GamifyColors.TextMuted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    innerTextField()
                }
            }
        )
    }
}

@Composable
private fun MissionTemplatePickerDialog(
    onChoose: (Mission) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = {
            Column {
                Text("MISSION TEMPLATES", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                Text("Start fast, then customize every detail", color = TextSoft, fontSize = 9.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = gamifyDialogMaxHeight(430.dp)),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { onChoose(defaultMission().copy(title = "")) },
                        color = Color(0xFF18232E),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp),
                        border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("+", color = Gold, fontSize = 24.sp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Blank Mission", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("Build a mission from scratch", color = TextSoft, fontSize = 8.5.sp)
                            }
                        }
                    }
                }
                items(missionTemplates) { template ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { onChoose(template.mission) },
                        color = Color(0xFF16212B),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp),
                        border = BorderStroke(1.dp, Gold.copy(alpha = 0.30f))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(template.title, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                Text(template.subtitle, color = TextSoft, fontSize = 8.sp)
                                Text(
                                    "${template.mission.durationMinutes} min • ${template.mission.xpReward} XP • ${template.mission.coinReward} Coins",
                                    color = GoldSoft,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text("→", color = GoldSoft, fontSize = 16.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextSoft) } }
    )
}

@Composable
private fun DailyLoginDialog(event: DailyLoginEvent, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamifyColors.Surface,
        shape = GamifyShapes.Dialog,
        title = { Text("DAILY STREAK", color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🔥", fontSize = 42.sp)
                Text("${event.streak} DAYS", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(5.dp))
                Text("+${event.coinReward} Coins", color = GoldSoft, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                event.milestone?.let {
                    Spacer(Modifier.height(7.dp))
                    Surface(color = Color(0x22F7C948), shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
                        Text(it, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Come back tomorrow to keep the streak alive.", color = TextSoft, fontSize = 9.sp, textAlign = TextAlign.Center)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Claimed", color = Gold, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
private fun HeadlineBlock(quote: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = quote.uppercase(Locale.US),
            color = Color(0xFFF8EFD8),
            textAlign = TextAlign.Center,
            fontSize = 9.6.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 12.sp,
            letterSpacing = 1.1.sp,
            style = androidx.compose.ui.text.TextStyle(
                shadow = Shadow(
                    color = Color(0xFF10151D),
                    offset = Offset(0f, 1.6f),
                    blurRadius = 6f
                )
            ),
            modifier = Modifier.drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(listOf(Color.Transparent, Color(0x12000000), Color.Transparent)),
                    topLeft = Offset(-10.dp.toPx(), -2.dp.toPx()),
                    size = Size(size.width + 20.dp.toPx(), size.height + 4.dp.toPx())
                )
            }
        )
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0x00E9C969), Color(0xA5E8C96D), Color(0xCCEFD98A))
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .padding(horizontal = 7.dp)
                    .size(11.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val diamond = Path().apply {
                        moveTo(size.width * 0.5f, 0f)
                        lineTo(size.width, size.height * 0.5f)
                        lineTo(size.width * 0.5f, size.height)
                        lineTo(0f, size.height * 0.5f)
                        close()
                    }
                    drawPath(diamond, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0B0), Color(0xFFE3BE53))))
                    drawPath(diamond, color = Color(0xFFF9E9B3), style = Stroke(width = 1.dp.toPx()))
                    drawCircle(brush = Brush.radialGradient(listOf(Color(0x70FFF2BF), Color.Transparent)), radius = size.minDimension * 0.55f)
                }
            }
            Box(
                modifier = Modifier
                    .width(34.dp)
                    .height(1.2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xCCEFD98A), Color(0xA5E8C96D), Color(0x00E9C969))
                        )
                    )
            )
        }
    }
}

@Composable
private fun PageDot(active: Boolean) {
    Box(
        modifier = Modifier
            .width(if (active) 20.dp else 7.dp)
            .height(7.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
            .background(if (active) Gold else Color(0xFF5A606D))
    )
}

@Composable
private fun SideWorldButton(
    type: WorldButtonType,
    label: String,
    badge: Boolean = false,
    onClick: () -> Unit = {}
) {
    Box {
        val buttonWidth = 48.dp
        val labelSize = if (type == WorldButtonType.Dreamboard) 6.2.sp else 8.sp
        Column(
            modifier = Modifier
                .width(buttonWidth)
                .height(49.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .background(Color(0x94090E14))
                .border(0.8.dp, Color(0x34E5C87A), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .clickable(onClick = onClick)
                .padding(vertical = 5.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            WorldButtonIcon(type)
            Text(
                label,
                color = Color.White,
                fontSize = labelSize,
                textAlign = TextAlign.Center,
                lineHeight = 7.sp,
                maxLines = 1,
                overflow = TextOverflow.Clip
            )
        }
        if (badge) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-1).dp, y = (-1).dp)
                    .size(6.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Color(0xFFEE4B4B))
            )
        }
    }
}

@Composable
private fun WorldButtonIcon(type: WorldButtonType) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 1.3.dp.toPx()
        when (type) {
            WorldButtonType.Dreamboard -> {
                // Dream car icon: a compact premium coupe silhouette.
                val body = Path().apply {
                    moveTo(w * 0.14f, h * 0.60f)
                    lineTo(w * 0.22f, h * 0.45f)
                    lineTo(w * 0.36f, h * 0.32f)
                    lineTo(w * 0.64f, h * 0.32f)
                    lineTo(w * 0.77f, h * 0.46f)
                    lineTo(w * 0.86f, h * 0.51f)
                    lineTo(w * 0.86f, h * 0.66f)
                    lineTo(w * 0.14f, h * 0.66f)
                    close()
                }
                drawPath(body, color = Color(0xFFE8C06A), style = Stroke(width = stroke, cap = StrokeCap.Round))
                drawLine(Color(0xFFE8C06A), Offset(w * 0.35f, h * 0.34f), Offset(w * 0.30f, h * 0.50f), strokeWidth = stroke)
                drawLine(Color(0xFFE8C06A), Offset(w * 0.65f, h * 0.34f), Offset(w * 0.71f, h * 0.50f), strokeWidth = stroke)
                drawCircle(Color(0xFFE8C06A), radius = w * 0.10f, center = Offset(w * 0.30f, h * 0.69f), style = Stroke(width = stroke))
                drawCircle(Color(0xFFE8C06A), radius = w * 0.10f, center = Offset(w * 0.70f, h * 0.69f), style = Stroke(width = stroke))
                drawLine(Color(0xFFE8C06A), Offset(w * 0.18f, h * 0.56f), Offset(w * 0.82f, h * 0.56f), strokeWidth = stroke, cap = StrokeCap.Round)
            }
            WorldButtonType.Map -> {
                val path = Path().apply {
                    moveTo(w * 0.18f, h * 0.68f)
                    lineTo(w * 0.18f, h * 0.26f)
                    lineTo(w * 0.40f, h * 0.18f)
                    lineTo(w * 0.56f, h * 0.30f)
                    lineTo(w * 0.78f, h * 0.22f)
                    lineTo(w * 0.78f, h * 0.64f)
                    lineTo(w * 0.56f, h * 0.72f)
                    lineTo(w * 0.40f, h * 0.60f)
                    close()
                }
                drawPath(path, color = Color(0xFFE8C06A))
                drawLine(Color(0xFF815A17), Offset(w * 0.40f, h * 0.19f), Offset(w * 0.40f, h * 0.60f), strokeWidth = stroke)
                drawLine(Color(0xFF815A17), Offset(w * 0.56f, h * 0.30f), Offset(w * 0.56f, h * 0.71f), strokeWidth = stroke)
                drawCircle(Color(0xFFB53A31), radius = w * 0.09f, center = Offset(w * 0.54f, h * 0.42f))
            }
            WorldButtonType.Missions -> {
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.20f, h * 0.18f),
                    size = Size(w * 0.60f, h * 0.64f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                    style = Stroke(width = stroke)
                )
                listOf(0.34f, 0.50f, 0.66f).forEach { y ->
                    drawCircle(Color(0xFFE8C06A), radius = 1.5.dp.toPx(), center = Offset(w * 0.30f, h * y))
                    drawLine(Color(0xFFE8C06A), Offset(w * 0.40f, h * y), Offset(w * 0.70f, h * y), strokeWidth = stroke, cap = StrokeCap.Round)
                }
            }
            WorldButtonType.Shop -> {
                drawRoundRect(
                    color = Color(0xFFB86A2F),
                    topLeft = Offset(w * 0.18f, h * 0.34f),
                    size = Size(w * 0.64f, h * 0.34f),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
                drawRoundRect(
                    color = Color(0xFFE8C06A),
                    topLeft = Offset(w * 0.14f, h * 0.22f),
                    size = Size(w * 0.72f, h * 0.20f),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
                drawLine(Color(0xFF7B3E11), Offset(w * 0.50f, h * 0.22f), Offset(w * 0.50f, h * 0.68f), strokeWidth = stroke)
                drawRoundRect(
                    color = Color(0xFFF7D883),
                    topLeft = Offset(w * 0.44f, h * 0.42f),
                    size = Size(w * 0.12f, h * 0.12f),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun MissionCard(
    mission: Mission,
    onStart: () -> Unit,
    onManage: () -> Unit,
    history: List<MissionHistoryEntry>,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current.applicationContext
    val state = missionCardState(mission, history)
    val subtaskChecks = loadMissionSubtaskChecks(context, mission)
    val subtaskDone = subtaskChecks.count { it }
    val subtaskTotal = mission.subtasks.size
    val accentColor = when (state) {
        MissionCardState.Active -> Gold
        MissionCardState.Done -> Color(0xFF55D98A)
        MissionCardState.Failed -> Color(0xFFE06666)
    }
    val terminal = state != MissionCardState.Active
    val startScale = if (reducedMotion || terminal) {
        1f
    } else {
        val transition = rememberInfiniteTransition(label = "start-button-pulse")
        val pulse by transition.animateFloat(
            initialValue = 0.996f,
            targetValue = 1.012f,
            animationSpec = infiniteRepeatable(animation = tween(durationMillis = 900), repeatMode = RepeatMode.Reverse),
            label = "start-button-scale"
        )
        pulse
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(142.dp)
            .clickable(onClick = onManage)
            .border(1.dp, accentColor.copy(alpha = 0.68f), androidx.compose.foundation.shape.RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xD80B121A)),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(accentColor.copy(alpha = 0.16f), Color(0xDE0D1420), Color(0xD30A1017))
                    )
                )
                .padding(horizontal = 14.dp, vertical = if (terminal) 14.dp else 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (terminal) 8.dp else 6.dp, Alignment.CenterVertically)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (mission.isRankMission) {
                    Text("★", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    mission.title,
                    color = if (terminal) accentColor else Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (terminal) TextDecoration.LineThrough else TextDecoration.None
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Reward("★ +${mission.xpReward} XP", if (terminal) accentColor else Gold, fontSize = 9.sp)
                Spacer(Modifier.width(10.dp))
                Reward("◉ +${mission.coinReward}", if (terminal) accentColor else Color.White, fontSize = 9.sp)
                Spacer(Modifier.width(10.dp))
                Reward("⏱ ${mission.durationMinutes} min", if (terminal) accentColor.copy(alpha = 0.9f) else TextSoft, fontSize = 9.sp)
                if (subtaskTotal > 0) {
                    Spacer(Modifier.width(10.dp))
                    Reward("✓ $subtaskDone/$subtaskTotal", if (subtaskDone == subtaskTotal) Color(0xFF86EFAC) else TextSoft, fontSize = 9.sp)
                }
            }

            if (!terminal) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .drawBehind {
                            drawRoundRect(
                                color = accentColor.copy(alpha = if (reducedMotion) 0.10f else 0.18f),
                                cornerRadius = CornerRadius(19.dp.toPx(), 19.dp.toPx())
                            )
                        }
                        .padding(1.5.dp)
                ) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = startScale; scaleY = startScale },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color(0xFF211800))
                    ) {
                        Text("▶  Start Mission", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TopGameHud(player: PlayerState, rewardCue: HudRewardCue? = null) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(21.dp))
                .background(Brush.verticalGradient(listOf(Color(0xBC101722), Color(0xA7080D14))))
                .drawBehind {
                    val stroke = 1.2.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xAAEED68A), Color(0xAAAF7A1E), Color(0xAAF1D57D), Color(0xAA996716))
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(Color(0x12FFF4C8), Color.Transparent, Color(0x0AFFF4C8))),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 3.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1.68f), verticalAlignment = Alignment.CenterVertically) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        XpBar(progress)
                        Spacer(Modifier.height(3.dp))
                        val xpCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Xp || it.step == ProgressionVisualStep.Level }
                        Text(
                            xpCue?.label ?: "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP",
                            color = if (xpCue != null) Gold else Color(0xFFE8EBEF),
                            fontSize = 8.5.sp,
                            fontWeight = if (xpCue != null) FontWeight.ExtraBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.16f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text("Rank ${player.rank}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 11.sp)
                        val rankCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Rank }
                        Text(
                            rankCue?.label ?: if (player.rank >= 100) "${rankTier.title} • MAX" else "${rankTier.title} • ${player.rankProgress}/${rankRequirement(player.rank)}",
                            color = if (rankCue != null) Gold else rankTier.secondary,
                            fontSize = 6.5.sp,
                            fontWeight = if (rankCue != null) FontWeight.ExtraBold else FontWeight.Normal,
                            lineHeight = 7.sp,
                            maxLines = 1
                        )
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(1.00f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        val coinCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Coins }
                        Text(formatNumber(player.coins), color = if (coinCue != null) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text(coinCue?.label ?: "Today", color = if (coinCue != null) Gold else GoldSoft, fontSize = 7.sp, fontWeight = if (coinCue != null) FontWeight.ExtraBold else FontWeight.Normal, lineHeight = 7.sp, maxLines = 1)
                    }
                }
                HudDivider()
                Row(
                    modifier = Modifier.weight(0.82f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    FlameBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        val comboCue = rewardCue?.takeIf { it.step == ProgressionVisualStep.Combo }
                        Text(player.combo.toString(), color = if (comboCue != null) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 12.sp)
                        Text(comboCue?.label ?: "Combo", color = if (comboCue != null) Gold else GoldSoft, fontSize = 7.sp, fontWeight = if (comboCue != null) FontWeight.ExtraBold else FontWeight.Normal, lineHeight = 7.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(41.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f
            drawCircle(brush = Brush.sweepGradient(tier.ringColors), radius = radius, style = Stroke(width = stroke))
            drawCircle(color = Color(0xFF10141B), radius = size.minDimension * 0.36f)
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )
            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                drawCircle(
                    color = GoldSoft,
                    radius = dotR,
                    center = Offset(cx + cos(rad).toFloat() * ringR, cy + sin(rad).toFloat() * ringR)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
            .background(Color(0xFF242B34))
            .border(1.dp, Color(0x805E4A20), androidx.compose.foundation.shape.RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

private fun DrawScope.starPath(center: Offset, outerRadius: Float, innerRadius: Float, points: Int = 5): Path {
    val path = Path()
    val angle = Math.PI / points
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val theta = i * angle - Math.PI / 2
        val x = center.x + cos(theta).toFloat() * r
        val y = center.y + sin(theta).toFloat() * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                lineTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.80f, h * 0.66f)
                quadraticBezierTo(w * 0.66f, h * 0.87f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.87f, w * 0.20f, h * 0.66f)
                lineTo(w * 0.14f, h * 0.18f)
                close()
            }
            drawPath(shield, brush = Brush.verticalGradient(listOf(tier.secondary.copy(alpha = 0.18f), tier.primary)))
            drawPath(shield, color = tier.secondary, style = Stroke(width = 1.6f))
            val inner = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.77f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.61f)
                quadraticBezierTo(w * 0.61f, h * 0.77f, w * 0.50f, h * 0.83f)
                quadraticBezierTo(w * 0.39f, h * 0.77f, w * 0.28f, h * 0.61f)
                lineTo(w * 0.23f, h * 0.24f)
                close()
            }
            drawPath(inner, color = Color(0x14FFFFFF))
            val star = starPath(Offset(w * 0.50f, h * 0.44f), outerRadius = w * 0.17f, innerRadius = w * 0.07f)
            drawPath(star, color = GoldSoft)
        }
    }
}

@Composable
private fun CoinBadge() {
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFF0B5), Color(0xFFF5C84F), Color(0xFFC88715))),
                radius = size.minDimension / 2f,
                center = center
            )
            drawCircle(color = Color(0x30FFFFFF), radius = size.minDimension * 0.34f, center = Offset(center.x, center.y - 1.dp.toPx()))
            drawCircle(color = Color(0xB9784B0A), radius = size.minDimension / 2f - 0.6.dp.toPx(), center = center, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(color = Color(0xFFFCE9A7), radius = size.minDimension / 2f - 1.4.dp.toPx(), center = center, style = Stroke(width = 0.8.dp.toPx()))
            val star = starPath(center, outerRadius = size.minDimension * 0.18f, innerRadius = size.minDimension * 0.08f)
            drawPath(star, color = Color(0xFF7A4E00))
        }
    }
}

@Composable
private fun FlameBadge() {
    Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))))
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(inner, brush = Brush.verticalGradient(listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))))
        }
    }
}

@Composable
private fun HudDivider() {
    Box(Modifier.width(1.dp).height(31.dp).background(Divider))
}

@Composable
private fun Reward(text: String, color: Color, fontSize: TextUnit = 12.5.sp) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = fontSize)
}
