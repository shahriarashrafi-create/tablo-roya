package com.shahriar.gamify

import kotlin.math.max

/**
 * Single source of truth for XP, Level, Rank and Combo progression.
 *
 * Storage owns persistence only; UI reads PlayerState only. All progression
 * mutations must enter through this file so mission rewards and bonus rewards
 * cannot drift into separate formulas over time.
 */
internal object ProgressionRules {
    const val MIN_LEVEL_XP = 500
    const val LEVEL_XP_STEP = 500
    const val LEVEL_UP_COIN_REWARD = 100
    const val MAX_RANK = 100

    fun nextLevelThreshold(currentThreshold: Int): Int =
        currentThreshold.coerceAtLeast(MIN_LEVEL_XP) + LEVEL_XP_STEP
}

/** Combo reward multiplier used only for a successfully completed mission. */
internal fun comboMultiplier(combo: Int): Float = when {
    combo >= 20 -> 2.0f
    combo >= 10 -> 1.5f
    combo >= 5 -> 1.25f
    combo >= 3 -> 1.10f
    else -> 1.0f
}

/** Number of completed Rank Missions required to advance from [rank]. */
internal fun rankRequirement(rank: Int): Int =
    if (rank >= 10) 10 else rank.coerceAtLeast(1)

/**
 * Sanitizes persisted/imported progression without inventing rewards.
 * nextLevelXp remains the player's canonical threshold so existing saves keep
 * their current progress curve; every future level then follows one +500 rule.
 */
internal fun normalizePlayerProgression(player: PlayerState): PlayerState {
    val safeLevel = player.level.coerceAtLeast(1)
    val safeThreshold = player.nextLevelXp.coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
    val safeRank = player.rank.coerceIn(1, ProgressionRules.MAX_RANK)
    val safeCombo = player.combo.coerceAtLeast(0)
    return player.copy(
        level = safeLevel,
        currentXp = player.currentXp.coerceIn(0, safeThreshold - 1),
        nextLevelXp = safeThreshold,
        rank = safeRank,
        rankProgress = if (safeRank >= ProgressionRules.MAX_RANK) {
            0
        } else {
            player.rankProgress.coerceIn(0, rankRequirement(safeRank) - 1)
        },
        coins = player.coins.coerceAtLeast(0),
        combo = safeCombo,
        bestCombo = max(safeCombo, player.bestCombo.coerceAtLeast(0)),
        chests = player.chests.coerceAtLeast(0),
        loginStreak = player.loginStreak.coerceAtLeast(0),
        bestLoginStreak = max(player.loginStreak.coerceAtLeast(0), player.bestLoginStreak.coerceAtLeast(0))
    )
}

private data class LevelAdvance(
    val level: Int,
    val currentXp: Int,
    val nextLevelXp: Int,
    val levelsGained: Int,
    val levelRewardCoins: Int
)

/** The only XP -> Level conversion path in the app. */
private fun advanceXp(player: PlayerState, xpGain: Int): LevelAdvance {
    var level = player.level
    var xp = player.currentXp + xpGain.coerceAtLeast(0)
    var threshold = player.nextLevelXp.coerceAtLeast(ProgressionRules.MIN_LEVEL_XP)
    var levelsGained = 0

    while (xp >= threshold) {
        xp -= threshold
        level += 1
        levelsGained += 1
        threshold = ProgressionRules.nextLevelThreshold(threshold)
    }

    return LevelAdvance(
        level = level,
        currentXp = xp,
        nextLevelXp = threshold,
        levelsGained = levelsGained,
        levelRewardCoins = levelsGained * ProgressionRules.LEVEL_UP_COIN_REWARD
    )
}

private fun comboAfterResult(player: PlayerState, result: MissionResult): Int = when (result) {
    MissionResult.Done -> player.combo + 1
    MissionResult.Partial -> (player.combo - 1).coerceAtLeast(0)
    MissionResult.Fail -> 0
    MissionResult.Defer -> player.combo
}

/**
 * Canonical mission progression transition.
 *
 * - Done: advances Combo and can earn XP/Coin (Combo boost may apply).
 * - Later/Defer: changes no progression value.
 * - Failed: resets Combo and awards nothing.
 * - Rank only advances on Done for a Rank Mission.
 */
internal fun applyMissionResult(
    player: PlayerState,
    mission: Mission,
    result: MissionResult,
    settings: GameSettings
): MissionOutcome {
    val before = normalizePlayerProgression(player)
    val comboAfter = comboAfterResult(before, result)
    val rewardMultiplier = if (settings.comboBoostEnabled && result == MissionResult.Done) {
        comboMultiplier(comboAfter)
    } else {
        1.0f
    }

    val baseXp = when (result) {
        MissionResult.Done -> mission.xpReward
        MissionResult.Partial -> mission.xpReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }.coerceAtLeast(0)

    val baseCoins = when (result) {
        MissionResult.Done -> mission.coinReward
        MissionResult.Partial -> mission.coinReward / 2
        MissionResult.Fail, MissionResult.Defer -> 0
    }.coerceAtLeast(0)

    val xpGain = (baseXp * rewardMultiplier).toInt().coerceAtLeast(0)
    val missionCoinGain = (baseCoins * rewardMultiplier).toInt().coerceAtLeast(0)
    val levelAdvance = advanceXp(before, xpGain)

    var rank = before.rank
    var rankProgress = before.rankProgress
    var ranksGained = 0
    if (mission.isRankMission && result == MissionResult.Done && rank < ProgressionRules.MAX_RANK) {
        rankProgress += 1
        while (rank < ProgressionRules.MAX_RANK && rankProgress >= rankRequirement(rank)) {
            rankProgress -= rankRequirement(rank)
            rank += 1
            ranksGained += 1
        }
        if (rank >= ProgressionRules.MAX_RANK) rankProgress = 0
    }

    val chestsEarned = levelAdvance.levelsGained + ranksGained
    val updated = before.copy(
        level = levelAdvance.level,
        currentXp = levelAdvance.currentXp,
        nextLevelXp = levelAdvance.nextLevelXp,
        rank = rank,
        rankProgress = rankProgress,
        coins = before.coins + missionCoinGain + levelAdvance.levelRewardCoins,
        combo = comboAfter,
        bestCombo = max(before.bestCombo, comboAfter),
        chests = before.chests + chestsEarned
    )

    return MissionOutcome(
        player = updated,
        xpGain = xpGain,
        missionCoinGain = missionCoinGain,
        levelsGained = levelAdvance.levelsGained,
        levelRewardCoins = levelAdvance.levelRewardCoins,
        comboBefore = before.combo,
        comboAfter = comboAfter,
        rewardMultiplier = rewardMultiplier,
        ranksGained = ranksGained,
        chestsEarned = chestsEarned
    )
}

/**
 * Canonical non-mission XP/Coin reward path (for example an Achievement).
 * It can level the player, but never changes Rank or Combo.
 */
internal fun applyBonusReward(
    player: PlayerState,
    xpGain: Int,
    coinGain: Int
): Pair<PlayerState, LevelUpEvent?> {
    val before = normalizePlayerProgression(player)
    val advance = advanceXp(before, xpGain)
    val updated = before.copy(
        level = advance.level,
        currentXp = advance.currentXp,
        nextLevelXp = advance.nextLevelXp,
        coins = before.coins + coinGain.coerceAtLeast(0) + advance.levelRewardCoins,
        chests = before.chests + advance.levelsGained
    )
    val event = if (advance.levelsGained > 0) {
        LevelUpEvent(before.level, advance.level, advance.levelRewardCoins)
    } else {
        null
    }
    return updated to event
}

/** UI event projection; progression itself has already been committed. */
internal fun levelUpEventFor(before: PlayerState, outcome: MissionOutcome): LevelUpEvent? =
    if (outcome.levelsGained > 0) {
        LevelUpEvent(before.level, outcome.player.level, outcome.levelRewardCoins)
    } else {
        null
    }

/** UI event projection; session de-duplication guarantees this is surfaced once. */
internal fun rankUpEventFor(before: PlayerState, outcome: MissionOutcome): RankUpEvent? =
    if (outcome.ranksGained > 0) {
        RankUpEvent(before.rank, outcome.player.rank, outcome.ranksGained)
    } else {
        null
    }
