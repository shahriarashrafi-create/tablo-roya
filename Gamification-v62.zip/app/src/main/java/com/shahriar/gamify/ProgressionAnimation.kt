package com.shahriar.gamify

import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Visual-only progression sequencing for the HUD.
 *
 * ProgressionEngine owns the real persisted values. This file only builds
 * intermediate PlayerState snapshots so committed XP/Coin/Combo/Rank rewards
 * can be revealed slowly and in a deterministic order without mutating rules.
 */
internal enum class ProgressionVisualStep { Xp, Coins, Combo, Level, Rank }

internal data class HudRewardCue(
    val step: ProgressionVisualStep,
    val label: String
)

private data class XpVisualState(
    val level: Int,
    val currentXp: Int,
    val nextLevelXp: Int
)

private data class RankVisualState(
    val rank: Int,
    val progress: Int
)

private fun lerpInt(from: Int, to: Int, fraction: Float): Int {
    val f = fraction.coerceIn(0f, 1f)
    return from + ((to - from) * f).roundToInt()
}

/**
 * Walks the same +500 XP threshold curve as ProgressionEngine, so the HUD bar
 * can fill, roll over and continue even when one reward crosses multiple levels.
 */
private fun interpolateXpState(from: PlayerState, to: PlayerState, fraction: Float): XpVisualState {
    val f = fraction.coerceIn(0f, 1f)
    if (f >= 1f) return XpVisualState(to.level, to.currentXp, to.nextLevelXp)
    if (to.level <= from.level) {
        return XpVisualState(
            level = from.level,
            currentXp = lerpInt(from.currentXp, to.currentXp, f).coerceAtLeast(0),
            nextLevelXp = from.nextLevelXp
        )
    }

    var totalDistance = (from.nextLevelXp - from.currentXp).coerceAtLeast(0)
    var threshold = from.nextLevelXp
    var level = from.level
    while (level + 1 < to.level) {
        level += 1
        threshold = ProgressionRules.nextLevelThreshold(threshold)
        totalDistance += threshold
    }
    totalDistance += to.currentXp.coerceAtLeast(0)

    var travelled = (totalDistance * f).roundToInt().coerceAtLeast(0)
    level = from.level
    threshold = from.nextLevelXp
    var currentXp = from.currentXp.coerceAtLeast(0)

    while (level < to.level) {
        val untilNext = (threshold - currentXp).coerceAtLeast(0)
        if (travelled < untilNext) {
            currentXp += travelled
            travelled = 0
            break
        }
        travelled -= untilNext
        level += 1
        threshold = ProgressionRules.nextLevelThreshold(threshold)
        currentXp = 0
    }

    if (level == to.level && travelled > 0) {
        currentXp = (currentXp + travelled).coerceAtMost(to.currentXp.coerceAtLeast(0))
    }

    return XpVisualState(level, currentXp, threshold)
}

private fun interpolateRankState(from: PlayerState, to: PlayerState, fraction: Float): RankVisualState {
    val f = fraction.coerceIn(0f, 1f)
    if (f >= 1f) return RankVisualState(to.rank, to.rankProgress)
    if (to.rank <= from.rank) {
        return RankVisualState(from.rank, lerpInt(from.rankProgress, to.rankProgress, f).coerceAtLeast(0))
    }

    var totalDistance = (rankRequirement(from.rank) - from.rankProgress).coerceAtLeast(0)
    var rank = from.rank
    while (rank + 1 < to.rank) {
        rank += 1
        totalDistance += rankRequirement(rank)
    }
    totalDistance += to.rankProgress.coerceAtLeast(0)

    var travelled = (totalDistance * f).roundToInt().coerceAtLeast(0)
    rank = from.rank
    var progress = from.rankProgress.coerceAtLeast(0)

    while (rank < to.rank) {
        val requirement = rankRequirement(rank)
        val untilNext = (requirement - progress).coerceAtLeast(0)
        if (travelled < untilNext) {
            progress += travelled
            travelled = 0
            break
        }
        travelled -= untilNext
        rank += 1
        progress = 0
    }
    if (rank == to.rank && travelled > 0) {
        progress = (progress + travelled).coerceAtMost(to.rankProgress.coerceAtLeast(0))
    }
    return RankVisualState(rank, progress)
}

internal fun interpolateProgressionStep(
    base: PlayerState,
    from: PlayerState,
    to: PlayerState,
    step: ProgressionVisualStep,
    fraction: Float
): PlayerState = when (step) {
    ProgressionVisualStep.Xp -> {
        val xp = interpolateXpState(from, to, fraction)
        base.copy(level = xp.level, currentXp = xp.currentXp, nextLevelXp = xp.nextLevelXp)
    }
    ProgressionVisualStep.Coins -> base.copy(coins = lerpInt(from.coins, to.coins, fraction).coerceAtLeast(0))
    ProgressionVisualStep.Combo -> base.copy(
        combo = lerpInt(from.combo, to.combo, fraction).coerceAtLeast(0),
        bestCombo = max(base.bestCombo, lerpInt(from.bestCombo, to.bestCombo, fraction).coerceAtLeast(0))
    )
    ProgressionVisualStep.Level -> base
    ProgressionVisualStep.Rank -> {
        val rank = interpolateRankState(from, to, fraction)
        base.copy(rank = rank.rank, rankProgress = rank.progress)
    }
}

internal fun missionCompletionAnimationDurationMillis(animation: MissionCompletionAnimation): Int {
    var duration = 250
    if (animation.xpGain > 0 || animation.fromPlayer.level != animation.toPlayer.level) duration += 1500
    if (animation.coinGain != 0) duration += 850
    if (animation.fromPlayer.combo != animation.toPlayer.combo) duration += 600
    if (animation.fromPlayer.level != animation.toPlayer.level) duration += 650
    if (
        animation.fromPlayer.rank != animation.toPlayer.rank ||
        animation.fromPlayer.rankProgress != animation.toPlayer.rankProgress
    ) duration += 850
    return duration.coerceAtLeast(1800)
}
