package com.shahriar.gamify

import java.util.UUID

/**
 * Pure ordering/normalization rules for Dreamboard.
 *
 * The UI never mutates list positions directly. Every insert/update/delete goes
 * through this engine so persisted order and carousel order stay identical.
 */
internal object DreamboardEngine {
    fun newId(): String = "dream_${UUID.randomUUID()}"

    fun normalize(items: List<DreamItem>): List<DreamItem> {
        val usedIds = mutableSetOf<String>()
        return items
            .sortedBy { it.position }
            .mapIndexed { index, item ->
                val baseId = item.id.trim().ifBlank { "dream_$index" }
                var stableId = baseId
                var suffix = 1
                while (!usedIds.add(stableId)) {
                    stableId = "${baseId}_$suffix"
                    suffix++
                }
                item.copy(
                    id = stableId,
                    title = item.title.trim().take(80),
                    year = item.year.filter(Char::isDigit).take(4),
                    price = item.price.filter(Char::isDigit).take(15),
                    imageUri = item.imageUri.trim(),
                    position = index
                )
            }
    }

    fun insert(items: List<DreamItem>, item: DreamItem): List<DreamItem> {
        val normalized = normalize(items).filterNot { it.id == item.id }.toMutableList()
        val target = item.position.coerceIn(0, normalized.size)
        normalized.add(target, item.copy(position = target))
        return normalize(normalized)
    }

    fun update(items: List<DreamItem>, item: DreamItem): List<DreamItem> {
        val normalized = normalize(items)
        if (normalized.none { it.id == item.id }) return normalized
        val without = normalized.filterNot { it.id == item.id }.toMutableList()
        val target = item.position.coerceIn(0, without.size)
        without.add(target, item.copy(position = target))
        return normalize(without)
    }

    fun remove(items: List<DreamItem>, id: String): List<DreamItem> =
        normalize(items.filterNot { it.id == id })
}
