# Gamification v50 Progress — Step 1B

## Cleanup and hardening
- Removed retired Mission fields for Deadline and Notes from the active data model and persistence layer.
- Removed the retired onboarding Main Goal field from the active model/storage path while keeping old backups migratable.
- Removed unreachable legacy Challenges and Inbox dialog UI paths without changing currently reachable screens.
- Bumped persistence schema to 11 and automatically removes retired preference keys during migration.
- Hardened backup import by validating and staging the full backup before replacing current data.
- Retired fields are no longer exported in new backups, but older backups remain accepted through migration.

## Repeatable build verification
- Added project-local `gradlew` / `gradlew.bat` launchers pinned to Gradle 8.9.
- Added `gradle/wrapper/gradle-wrapper.properties`.
- Added `scripts/verify-project.sh` for structural checks plus debug APK compilation.
- Added `.github/workflows/android-build.yml` to compile every push/PR and upload the debug APK.
- Version bumped to 0.50 / versionCode 50.

## Next approved step
- Step 2A: define and apply the shared UI/RTL design system primitives.

## v51 — Step 2A: UI / RTL design-system foundation
- Added a centralized `DesignSystem.kt` for app-wide colors, spacing, dimensions, shapes, and Material 3 dark theme tokens.
- Replaced the duplicated text-field palettes with one high-contrast app-wide input palette.
- Switched onboarding and the main app shell to `GamifyTheme` so Material dialogs/controls inherit the same dark/gold visual language.
- Standardized core input minimum heights and field corner radii in Onboarding, Mission Editor, Reward Editor, and Dream Properties.
- Standardized compact Hour/Subtask surfaces to shared design tokens, preventing future clipping regressions.
- Kept gameplay/storage behavior unchanged in this stage; full screen-by-screen RTL/small-screen audit remains Step 2B.

## v52 — Step 2B: full UI / RTL / compact-screen audit
- Applied the shared v51 design tokens to the remaining active dialogs and surfaces instead of screen-specific colors/radii.
- Added responsive horizontal padding and dialog-height helpers for narrow/short Android screens.
- Made Mission Execution adapt its timer, title, spacing, subtask list height and result buttons on compact displays to prevent vertical clipping.
- Standardized Onboarding, Settings, Shop, Mission Editor, Reward Editor, Dream Properties, Mission list/templates, World Progress, Inventory and reset/abandon dialogs.
- Kept Persian Shop and Dream editing surfaces explicitly RTL while preserving LTR for English/numeric HUD areas.
- Increased None/Daily selectors for better readability and kept shared high-contrast input colors for Hour/Subtask and all OutlinedTextFields.
- Updated the System Health release label and app version to 0.52 / versionCode 52.
- Gameplay and persistence behavior are intentionally unchanged in Step 2B.

## Next approved step
- Step 3A: consolidate Mission state transitions (Active / Done / Failed / Later), base position, Daily reset and Subtask state into one Mission Engine.


## v53 — Step 3A: Mission Engine core
- Added a centralized `MissionEngine.kt` for Active / Later / Done / Failed state derivation and mission display ordering.
- Added stable mission IDs and persisted them in missions, timer state, and history so renaming a mission no longer breaks its status/history association.
- Migrated schema to 12; old history entries are linked to migrated missions where possible without deleting history.
- Defined the persisted mission-list order as the canonical base position. Status sorting is derived at runtime: active first, then done, then failed.
- `Later` keeps a mission active, gives no terminal card state, and appends it to the end of the active queue for the current day only. Repeated Later actions move it to the latest active-queue position.
- Subtask progress now keys by stable mission ID; schema migration copies legacy title-based progress forward and keeps fallback support. Daily subtasks naturally reset on the next mission day while one-time mission progress persists.
- Home carousel and Missions list now use the same Mission Engine ordering rules instead of separate sort implementations.
- Mission editing preserves identity; new/template missions receive unique IDs before insertion.
- Version bumped to 0.53 / versionCode 53.

## v54 — Step 3B: session recovery and exact result commits
- Added timer recovery based on the persisted end timestamp, so a running mission resumes accurately after backgrounding or process death and an expired timer reopens at 00:00 ready for a result.
- Added a durable session ID to mission history. Home, Missions and History now resolve the same committed session/result source of truth.
- Added one atomic mission-result commit path: player XP/coins/combo/rank, history, completed-session guard, and timer cleanup are committed together before the UI animates.
- Added duplicate-result protection for rapid taps/re-entry so a single timer session cannot grant rewards twice.
- Result buttons lock immediately after the first selection, while the storage layer still independently rejects duplicate commits.
- Done/Failed/Later state changes are reflected from the committed history list instead of separate UI-only state.
- Later continues to preserve Combo and reward values, and the abandon copy now matches that behavior.
- Daily due-state checks now use the same Mission Engine card state used by Home/Missions.
- History row keys prefer stable session IDs, preventing collisions after fast sequential actions.
- Persistence schema bumped to 13 and app version bumped to 0.54 / versionCode 54.

## v55 — Step 4A: atomic Coin spend + One-time / Termless reward core
- Added `RewardEngine.kt` as the single pure rules layer for personal reward redemption.
- One-time rewards become completed after a successful redemption and cannot charge coins again.
- Termless/reusable rewards stay active after redemption and increment their redemption count without being permanently completed.
- Added `redeemPersonalReward()` as the single Shop spend path. Coin deduction, reward state, and the redemption ledger are committed together in one storage transaction.
- Added a short duplicate-submit guard for rapid repeated taps, including reusable rewards, so one physical action cannot double-charge the wallet.
- Added a durable reward redemption ledger with transaction ID, timestamp, reward identity/title, price, reward mode, and before/after coin balances. The ledger is included in normal backups.
- Reward loading/saving now normalizes invalid prices and guarantees reusable rewards cannot remain in a completed state after old data/edit migrations.
- Shop UI now delegates redemption to the atomic engine rather than directly mutating player coins and reward state.
- Persistence schema bumped to 14 and app version bumped to 0.55 / versionCode 55.

## Next approved step
- Step 4B: finish the Shop UI, ordering, completed/redeemed history presentation, insufficient-coin feedback, and reward-position behavior.

## v56 — Step 4B: Shop ordering, completed view, history and feedback
- Added persistent reward `position` so every personal reward has a stable user-controlled order.
- Added reward placement helpers in `RewardEngine`: insert/update at a chosen position, normalize positions after edits, and compact positions after deletion.
- Existing v55 rewards migrate automatically to sequential positions without losing completion/redeem state.
- One-time completed rewards sort after active rewards and remain hidden by default; the existing bottom switch reveals them on demand.
- Termless rewards never enter the completed bucket and remain available at their configured position after every successful use.
- Reward Editor now includes a compact RTL position selector (`موقعیت: X از Y`) for new and existing rewards.
- Shop cards remain fully RTL, keep a large icon-only check action, and use smaller icon-only Edit/Delete controls.
- Insufficient coin actions remain tappable and now return subtle in-Shop feedback instead of being silently disabled.
- Added a visible redemption-history view showing reward title, spend amount, timestamp, mode, and post-redemption balance from the durable ledger created in v55.
- The app keeps the redemption-history state live after each successful atomic redemption and reloads it after backup restore.
- Persistence schema bumped to 15 and app version bumped to 0.56 / versionCode 56.

## Next approved step
- Step 5A: Dreamboard carousel core, 9:16 image flow, Properties fields, persistent ordering and crop/pan/zoom foundation.

## v57 — Step 5A: Dreamboard core, 9:16 carousel, Properties and image crop
- Moved the Dreamboard UI out of `MainActivity.kt` into `DreamboardScreen.kt`, reducing the main activity/orchestration file by roughly 500 lines.
- Added `DreamboardEngine.kt` as the single pure ordering/normalization layer for dream insertion, editing, movement, deletion, stable IDs and sequential positions.
- Dreamboard remains a horizontal snapping carousel of portrait 9:16 cards; the active card is larger/clearer while neighboring cards are reduced in scale/opacity.
- The carousel itself stays visually clean: no Dreamboard title, top add button, close button, achieved marker, or three-dot menu. The last card is the Add Dream card.
- Long-pressing a dream opens its Properties editor. Properties contains only Image, Title, Year, Price and Position plus Save/Cancel/Delete actions.
- Card overlay layout remains Title on the right, `سال <year>` in the center, and the numeric dollar price with `$` beside/after it on the left.
- Position edits are ID-based rather than source-index-based, preventing edits/deletes from targeting the wrong card after reordering.
- Gallery image selection opens a 9:16 crop surface with one-finger pan and pinch zoom; the saved crop is copied into app-owned storage so the card no longer depends on continued gallery access.
- Replacing/canceling/deleting dreams now cleans unused app-owned crop files, and migration/health-check pruning removes old orphan crop images without touching external URIs.
- Dream data loading/saving now normalizes title/year/price/order consistently and repairs duplicate/blank legacy IDs.
- Persistence schema bumped to 16 and app version bumped to 0.57 / versionCode 57.

## v58 — Step 5B: fullscreen Dreamboard, active-photo backdrop and portable photos
- Tapping a Dreamboard image opens a full-screen, image-first viewer with horizontal swipe navigation across all dreams; the main long-press Properties behavior stays unchanged.
- Both the main Dreamboard and fullscreen viewer derive a soft, darkened background from the active image using a cross-version downsample/upsample blur that works back to minSdk 26.
- Added a compact `current/total` indicator (for example `4/12`) instead of dot rows, keeping the Dreamboard surface visually minimal.
- Fullscreen keeps the same 9:16 image presentation and bottom metadata overlay: price left, `سال <year>` center, title right.
- Manual Export now creates a portable `.gamify.zip` bundle containing app data plus the actual Dreamboard photo bytes; Restore remaps every bundled image to a new app-private file path.
- Legacy JSON backups are still accepted. ZIP imports validate paths/count/size before applying data and ignore unsafe archive paths.
- App-private Dreamboard files are now included in Android Auto Backup and device-to-device transfer rules.
- Dream loading repairs stale file URIs by matching the restored app-private filename where possible.
- Persistence schema bumped to 17 and app version bumped to 0.58 / versionCode 58.

## Next approved step
- Step 6A: centralize XP / Level / Rank / Combo progression rules in one Progression Engine.

## v59 — Step 6A: centralized Progression Engine
- Added `ProgressionEngine.kt` as the single rules source for XP, Level, Rank and Combo transitions.
- Mission results no longer calculate progression inside `GameStorage`; storage now only loads/commits the result returned by the engine.
- Bonus/Achievement XP uses the same internal XP-to-Level path as mission rewards, preventing different level formulas from drifting apart.
- Centralized Combo rules: Done +1, Later unchanged, Failed resets to 0, Partial -1; Combo reward multipliers are defined in the engine only.
- Centralized Rank rules: only a successfully completed Rank Mission can add Rank progress; Rank requirements and max Rank live in the engine only.
- Centralized Level advancement: all XP sources share one threshold transition and one level-up Coin reward rule.
- Added progression normalization for persisted/imported player state so invalid XP/rank/combo values cannot leak into HUD, Stats or Profile.
- Level/Rank UI event projection now comes from the engine after the persisted transition, while the existing session de-duplication remains the guard against duplicate rewards/events.
- `loadPlayer` and `savePlayer` both pass through the same normalization layer, making PlayerState the shared source read by Home/HUD/Stats/Profile.
- Persistence schema bumped to 18 and app version bumped to 0.59 / versionCode 59.
- Pure Progression Engine smoke tests passed for level-up, Rank Mission advancement, Combo boost, Later, Failed, and bonus rewards.

## Next approved step
- Step 6B: slow/queued HUD progression animations and Level/Rank reward presentation without changing the progression rules.

## v60 — Step 6B: queued HUD reward animation and compact Level/Rank notices
- Added `ProgressionAnimation.kt` as a visual-only layer; persisted progression rules remain exclusively in `ProgressionEngine.kt`.
- Done missions now reveal rewards on the Home HUD in a fixed slow sequence: XP → Coins → Combo → Level → Rank.
- XP animation follows the same threshold curve as the engine, so the XP bar can visibly fill, roll into a new Level, and continue from zero without inventing intermediate saved state.
- Coin totals count toward the committed balance after XP, then Combo updates, followed by Level and Rank emphasis.
- Rank progress animates from the pre-mission value to the committed value; Rank-up and max-rank cases use the same final persisted state.
- The green completed-mission card flight now lasts for the full queued reward sequence, moving/fading toward the HUD more slowly than before.
- Removed the old generic “MISSION COMPLETE” reward overlay and stopped showing Level/Rank as blocking full-screen result screens.
- Level Up and Rank Up are now compact, non-blocking top notices delivered through one queue, so simultaneous Level + Rank events are shown one after another instead of overlapping.
- HUD sublabels temporarily show the active reward cue (`+XP`, `+Coins`, Combo delta, Level transition, Rank transition) while the visible values increment.
- Reduced Motion still skips the long counting/flight sequence and jumps to the already committed final state, while keeping a short milestone notice.
- App version bumped to 0.60 / versionCode 60. Persistence schema remains 18 because Step 6B changes presentation only.

## Next approved step
- Step 8A when progression work is complete: timer/reminder reliability, notification scheduling, and device-restart recovery. Profile/Stats remains intentionally parked.

## v61 — Step 8A: reliable timer, daily reminders and restart recovery
- Added `AlarmScheduler.kt` as the single scheduling layer for timer-finish alarms and per-mission Daily reminders.
- Running timers now persist both wall-clock and monotonic (`elapsedRealtime`) deadlines plus Android boot count. Manual clock changes on the same boot no longer incorrectly stretch or finish a running timer; reboot recovery safely falls back to the persisted wall-clock deadline.
- Timer alarms use exact idle alarms when Android grants exact-alarm access, with an idle-capable fallback when that access is unavailable.
- Daily reminders are one-shot alarms recalculated in the current system timezone after every fire, edit, delete, result, timezone/time change, app update and device restart. This avoids repeating-alarm DST drift.
- A Daily mission that is already Done/Failed for the current day is scheduled for its next eligible day rather than notifying later that same day.
- Added `MissionReminderReceiver` for reminder delivery and `SystemEventReceiver` for BOOT_COMPLETED, TIME_SET, TIMEZONE_CHANGED, MY_PACKAGE_REPLACED and exact-alarm-permission changes.
- If the phone was powered off when a running timer expired, reboot recovery preserves the finished mission session and surfaces the timer-finished notification instead of losing it.
- Notification channels for timer completion and mission reminders are created centrally, and Android 13+ notification permission is requested when notifications are enabled.
- Editing/deleting missions or changing History immediately invalidates/reschedules stale reminder PendingIntents; removed mission alarms are cancelled through a persisted scheduled-ID set.
- Persistence schema bumped to 19 and app version bumped to 0.61 / versionCode 61.

## v62 — Step 8B: actionable timer-finish notification results
- Timer-finished notifications now expose three direct actions: Done, Later and Failed, each with its own compact action icon.
- Actions are handled by `MissionResultReceiver` without opening the Activity, so they work while the app process/UI is closed or the phone is locked (subject to the device notification/lock-screen policy).
- Every action carries the immutable timer `sessionId`, verifies that the persisted session is the same finished timer, and commits through `finalizeActiveMissionSession()` — the same atomic/idempotent path used by the in-app result controls.
- Done therefore awards XP/Coin/Combo/Rank exactly once; Later awards nothing and keeps Combo unchanged; Failed awards nothing and resets Combo according to `ProgressionEngine`. Rapid repeated taps cannot duplicate rewards or History.
- The timer-finished notification is cancelled after any result is committed, when the result is completed inside the app, when a new timer starts, or when active timer state is explicitly cleared.
- Tapping the notification body now reliably routes an existing finished timer back to its Mission result screen. Tapping a normal mission reminder routes Home to that mission card.
- A lightweight persisted revision marker lets an already-running Activity refresh Player/History/timer state after a notification action was applied in the background, avoiding stale HUD or Mission UI. The marker is ephemeral and excluded from manual backups.
- App version bumped to 0.62 / versionCode 62. Persistence schema remains 19 because no durable domain schema changed.

## Next approved step
- Step 9A: define the complete versioned backup bundle and safe migration/import staging, including portable Dreamboard photos and all current domain state.
