shadbash - Clean Manager / Metadata Backup / Music Replay State

Changes:
- Removed extra helper/explanatory text from Song Manager.
- During «بریم ادامه‌شو بشنویم», the 10-second numeric timer disappears.
- Removed «داریم ادامه آهنگ رو گوش می‌دیم...» and replay time text.
- Added a dedicated animated music-playing visual (spinning record + equalizer) during answer replay.
- After replay reaches the final time, the music visual disappears and the answer + Correct/Wrong controls appear.
- Export now backs up app data and song metadata but NEVER audio files.
- Backup includes team count, team names, round selection, custom round count, song title/artist, start/stop/final times, answer and file name metadata.
- Audio local paths are excluded from exported JSON.
- Import is selected from the device using the file picker.
- Imported songs intentionally have no audio path; the user must select each audio file again from the device.
- Existing song tester, persistent local audio storage, random no-repeat gameplay, scoring, results and final winner remain.
- No song-swap feature is included.
