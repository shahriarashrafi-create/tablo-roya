# Gamification v44 Progress

- Deferred (Later) missions stay active/yellow, keep Start Mission, preserve XP/Coin/Combo, and move to the end of today's active yellow queue.
- Done no longer shows the old Mission Complete reward banner.
- Added a completion-flight animation: the completed mission card rises toward the HUD and fades away.
- XP, coins, combo, level bar, rank progress and related HUD values count into their final values progressively after Done.
- Level Up and Rank Up overlays wait until the HUD reward-count animation finishes.
- Failed missions remain red/terminal and move behind active and completed cards according to existing state sorting.
- Version bumped to 0.44.
