# Gamification v36 Progress

- Added first-run onboarding with player name, main goal, active hours, and selectable starter mission templates.
- Existing users upgrading from previous schemas skip onboarding automatically; Reset All Data returns to onboarding.
- Added runtime data-health repair: mission value sanitizing, history/notification de-duplication, player/settings repair, and widget refresh.
- Backup schema upgraded to v6 and onboarding data is included automatically in JSON Backup/Restore.
- Added release hardening configuration for the Android release build, ProGuard baseline, splash theme, launcher icon, and cloud/device-transfer backup rules.
- Added native Android home-screen widget showing player name, Level, Rank, Coins, and Combo; it refreshes when player state changes.
- Added Calendar integration using the system Calendar event composer for the next mission (no calendar permission required).
- Added Personal League status based on weekly completed missions.
- Enabled Android Auto Backup/device transfer as the cloud-restore foundation; true real-time account sync and online leaderboards still require a backend service.
- App version bumped to 0.36 (versionCode 36).


## v37 build fix
- Fixed Android 12+ resource linking failure caused by invalid `android:postSplashScreenTheme` attribute in `values-v31/styles.xml`.
- Kept native Android splash screen background and animated icon attributes.
- Bumped app version to 0.37 / versionCode 37.
