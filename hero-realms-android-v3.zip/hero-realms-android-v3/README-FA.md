# Hero Realms Android v1.2

نسخه حرفه‌ای‌تر بازی برای Android و GitHub Actions.

## تغییرات این نسخه
- هیروی سه‌بعدی واقعی و اسکین‌شده (GLB) به‌جای کاراکتر ساخته‌شده با شکل‌های ساده.
- انیمیشن اسکلتی روی هیرو و ترکیب انیمیشن حرکت با ضربه.
- جوی‌استیک آنالوگ سمت چپ: هر جهتی که انگشت را ببری، هیرو همان جهت حرکت می‌کند.
- دویدن خودکار وقتی جوی‌استیک را تا نزدیکی لبه ببری.
- سیستم حمله ۳ ضربه‌ای (Combo) با زمان‌بندی Hit Frame، Knockback، Slash FX و Camera Impact.
- دکمه Dash و چرخاندن دوربین با کشیدن سمت راست صفحه.
- مدل، Three.js و GLTFLoader در زمان Build داخل APK قرار می‌گیرند؛ بعد از نصب بازی برای اجرای اصلی به اینترنت نیاز ندارد.
- fallback گرافیکی باقی مانده تا اگر یک دستگاه خاص نتوانست مدل GLB را لود کند، بازی بسته نشود.

## برای ساخت APK
همین ZIP را به همان GitHub workflow قبلی بده. پروژه Android داخل ریشه ZIP است و `./gradlew assembleDebug` یا `assembleRelease` قابل اجراست.

نسخه: `1.2.0` — versionCode `3`

## اعتبار مدل سه‌بعدی
Hero base model: **Cesium Man**, from Khronos glTF Sample Assets / Cesium. Model files are distributed under CC BY 4.0 with the attribution/trademark notes listed by the upstream asset repository.

Upstream asset path:
`KhronosGroup/glTF-Sample-Assets/Models/CesiumMan`
