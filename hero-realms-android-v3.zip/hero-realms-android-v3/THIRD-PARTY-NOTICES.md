# Third-party notices

## Cesium Man
Source: KhronosGroup/glTF-Sample-Assets, `Models/CesiumMan`.
Credit: Cesium.
License: CC BY 4.0 with the trademark limitations/notices documented in the upstream model directory.

## three.js / GLTFLoader
Source: mrdoob/three.js.
License: MIT.

The Gradle build downloads pinned Three.js r146 runtime files and the Cesium Man GLB, then bundles them into the APK.
