plugins {
    id("com.android.application")
}

android {
    namespace = "com.shahriar.nextbeat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shahriar.shadbash"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "0.9.0-shadbash-boghz-46-92"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
