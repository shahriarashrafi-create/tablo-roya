shadbash - Boghze Taraneh 46s to 1:32

Changes:
- Song segment is now physically trimmed from 00:46 to 01:32 for reliable 46-second playback.
- After Play is pressed, singer/title replace the pre-play team/instruction area:
  Reza Sadeghi / Boghze Taraneh.
- Added playing state, progress bar, elapsed/total time, equalizer animation, and play/pause behavior.
- After the clip ends, the 20-second guessing page opens.
- Correct answer is hidden first.
- Host must press «نمایش جواب درست» to reveal:
  «تو بودی تمام هستی و مستی و راستی و تمام قصه من»
- Correct/Wrong buttons appear only after the answer is revealed.
- Separate song-card page remains removed.
- Existing step-by-step Back behavior remains.
