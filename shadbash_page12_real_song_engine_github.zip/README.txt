shadbash - Real Song Engine

Changes:
- No song-swap feature was added.
- Audio selected in «مدیریت آهنگ‌ها» is copied into app-private persistent storage.
- Saved audio remains available after closing and reopening the app.
- Each song plays from its configured start second to end second.
- At the end second, playback stops and the 20-second guessing page opens.
- The saved correct answer is shown only after the host presses «نمایش جواب درست».
- A new game shuffles the song library.
- Each team/round receives a different song with no repetition.
- Start Game is blocked when there are not enough playable songs for all turns.
- Play Again creates a new random order.
- Deleting a song also deletes its local audio file.
- Existing scoreboards, round results, final winner page, and Settings Export/Import remain.
