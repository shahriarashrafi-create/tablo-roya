# آپلود نسخه ۱۵ روی GitHub

1. ZIP را Extract کن.
2. همه فایل‌ها را در ریشه Repository قرار بده.
3. Push کن یا Workflow «Build Android APK» را از Actions اجرا کن.
4. بعد از Build موفق، Artifact با نام `shahriar-million-path-v15-apk` را دانلود کن.
