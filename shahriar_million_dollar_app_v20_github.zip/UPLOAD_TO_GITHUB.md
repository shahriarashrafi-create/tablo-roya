# آپلود نسخه ۲۰ روی GitHub

1. ZIP را Extract کن.
2. محتویات را در ریشه Repository قرار بده.
3. Push کن یا Workflow `Build Android APK` را در Actions اجرا کن.
4. بعد از Build، Artifact با نام `shahriar-million-path-v20-apk` را دانلود کن.
