# Gamification v50 Progress — Step 1B

## Cleanup and hardening
- Removed retired Mission fields for Deadline and Notes from the active data model and persistence layer.
- Removed the retired onboarding Main Goal field from the active model/storage path while keeping old backups migratable.
- Removed unreachable legacy Challenges and Inbox dialog UI paths without changing currently reachable screens.
- Bumped persistence schema to 11 and automatically removes retired preference keys during migration.
- Hardened backup import by validating and staging the full backup before replacing current data.
- Retired fields are no longer exported in new backups, but older backups remain accepted through migration.

## Repeatable build verification
- Added project-local `gradlew` / `gradlew.bat` launchers pinned to Gradle 8.9.
- Added `gradle/wrapper/gradle-wrapper.properties`.
- Added `scripts/verify-project.sh` for structural checks plus debug APK compilation.
- Added `.github/workflows/android-build.yml` to compile every push/PR and upload the debug APK.
- Version bumped to 0.50 / versionCode 50.

## Next approved step
- Step 2A: define and apply the shared UI/RTL design system primitives.

## v51 — Step 2A: UI / RTL design-system foundation
- Added a centralized `DesignSystem.kt` for app-wide colors, spacing, dimensions, shapes, and Material 3 dark theme tokens.
- Replaced the duplicated text-field palettes with one high-contrast app-wide input palette.
- Switched onboarding and the main app shell to `GamifyTheme` so Material dialogs/controls inherit the same dark/gold visual language.
- Standardized core input minimum heights and field corner radii in Onboarding, Mission Editor, Reward Editor, and Dream Properties.
- Standardized compact Hour/Subtask surfaces to shared design tokens, preventing future clipping regressions.
- Kept gameplay/storage behavior unchanged in this stage; full screen-by-screen RTL/small-screen audit remains Step 2B.

## v52 — Step 2B: full UI / RTL / compact-screen audit
- Applied the shared v51 design tokens to the remaining active dialogs and surfaces instead of screen-specific colors/radii.
- Added responsive horizontal padding and dialog-height helpers for narrow/short Android screens.
- Made Mission Execution adapt its timer, title, spacing, subtask list height and result buttons on compact displays to prevent vertical clipping.
- Standardized Onboarding, Settings, Shop, Mission Editor, Reward Editor, Dream Properties, Mission list/templates, World Progress, Inventory and reset/abandon dialogs.
- Kept Persian Shop and Dream editing surfaces explicitly RTL while preserving LTR for English/numeric HUD areas.
- Increased None/Daily selectors for better readability and kept shared high-contrast input colors for Hour/Subtask and all OutlinedTextFields.
- Updated the System Health release label and app version to 0.52 / versionCode 52.
- Gameplay and persistence behavior are intentionally unchanged in Step 2B.

## Next approved step
- Step 3A: consolidate Mission state transitions (Active / Done / Failed / Later), base position, Daily reset and Subtask state into one Mission Engine.


## v53 — Step 3A: Mission Engine core
- Added a centralized `MissionEngine.kt` for Active / Later / Done / Failed state derivation and mission display ordering.
- Added stable mission IDs and persisted them in missions, timer state, and history so renaming a mission no longer breaks its status/history association.
- Migrated schema to 12; old history entries are linked to migrated missions where possible without deleting history.
- Defined the persisted mission-list order as the canonical base position. Status sorting is derived at runtime: active first, then done, then failed.
- `Later` keeps a mission active, gives no terminal card state, and appends it to the end of the active queue for the current day only. Repeated Later actions move it to the latest active-queue position.
- Subtask progress now keys by stable mission ID; schema migration copies legacy title-based progress forward and keeps fallback support. Daily subtasks naturally reset on the next mission day while one-time mission progress persists.
- Home carousel and Missions list now use the same Mission Engine ordering rules instead of separate sort implementations.
- Mission editing preserves identity; new/template missions receive unique IDs before insertion.
- Version bumped to 0.53 / versionCode 53.

## v54 — Step 3B: session recovery and exact result commits
- Added timer recovery based on the persisted end timestamp, so a running mission resumes accurately after backgrounding or process death and an expired timer reopens at 00:00 ready for a result.
- Added a durable session ID to mission history. Home, Missions and History now resolve the same committed session/result source of truth.
- Added one atomic mission-result commit path: player XP/coins/combo/rank, history, completed-session guard, and timer cleanup are committed together before the UI animates.
- Added duplicate-result protection for rapid taps/re-entry so a single timer session cannot grant rewards twice.
- Result buttons lock immediately after the first selection, while the storage layer still independently rejects duplicate commits.
- Done/Failed/Later state changes are reflected from the committed history list instead of separate UI-only state.
- Later continues to preserve Combo and reward values, and the abandon copy now matches that behavior.
- Daily due-state checks now use the same Mission Engine card state used by Home/Missions.
- History row keys prefer stable session IDs, preventing collisions after fast sequential actions.
- Persistence schema bumped to 13 and app version bumped to 0.54 / versionCode 54.

## v55 — Step 4A: atomic Coin spend + One-time / Termless reward core
- Added `RewardEngine.kt` as the single pure rules layer for personal reward redemption.
- One-time rewards become completed after a successful redemption and cannot charge coins again.
- Termless/reusable rewards stay active after redemption and increment their redemption count without being permanently completed.
- Added `redeemPersonalReward()` as the single Shop spend path. Coin deduction, reward state, and the redemption ledger are committed together in one storage transaction.
- Added a short duplicate-submit guard for rapid repeated taps, including reusable rewards, so one physical action cannot double-charge the wallet.
- Added a durable reward redemption ledger with transaction ID, timestamp, reward identity/title, price, reward mode, and before/after coin balances. The ledger is included in normal backups.
- Reward loading/saving now normalizes invalid prices and guarantees reusable rewards cannot remain in a completed state after old data/edit migrations.
- Shop UI now delegates redemption to the atomic engine rather than directly mutating player coins and reward state.
- Persistence schema bumped to 14 and app version bumped to 0.55 / versionCode 55.

## Next approved step
- Step 4B: finish the Shop UI, ordering, completed/redeemed history presentation, insufficient-coin feedback, and reward-position behavior.

## v56 — Step 4B: Shop ordering, completed view, history and feedback
- Added persistent reward `position` so every personal reward has a stable user-controlled order.
- Added reward placement helpers in `RewardEngine`: insert/update at a chosen position, normalize positions after edits, and compact positions after deletion.
- Existing v55 rewards migrate automatically to sequential positions without losing completion/redeem state.
- One-time completed rewards sort after active rewards and remain hidden by default; the existing bottom switch reveals them on demand.
- Termless rewards never enter the completed bucket and remain available at their configured position after every successful use.
- Reward Editor now includes a compact RTL position selector (`موقعیت: X از Y`) for new and existing rewards.
- Shop cards remain fully RTL, keep a large icon-only check action, and use smaller icon-only Edit/Delete controls.
- Insufficient coin actions remain tappable and now return subtle in-Shop feedback instead of being silently disabled.
- Added a visible redemption-history view showing reward title, spend amount, timestamp, mode, and post-redemption balance from the durable ledger created in v55.
- The app keeps the redemption-history state live after each successful atomic redemption and reloads it after backup restore.
- Persistence schema bumped to 15 and app version bumped to 0.56 / versionCode 56.

## Next approved step
- Step 5A: Dreamboard carousel core, 9:16 image flow, Properties fields, persistent ordering and crop/pan/zoom foundation.

## v57 — Step 5A: Dreamboard core, 9:16 carousel, Properties and image crop
- Moved the Dreamboard UI out of `MainActivity.kt` into `DreamboardScreen.kt`, reducing the main activity/orchestration file by roughly 500 lines.
- Added `DreamboardEngine.kt` as the single pure ordering/normalization layer for dream insertion, editing, movement, deletion, stable IDs and sequential positions.
- Dreamboard remains a horizontal snapping carousel of portrait 9:16 cards; the active card is larger/clearer while neighboring cards are reduced in scale/opacity.
- The carousel itself stays visually clean: no Dreamboard title, top add button, close button, achieved marker, or three-dot menu. The last card is the Add Dream card.
- Long-pressing a dream opens its Properties editor. Properties contains only Image, Title, Year, Price and Position plus Save/Cancel/Delete actions.
- Card overlay layout remains Title on the right, `سال <year>` in the center, and the numeric dollar price with `$` beside/after it on the left.
- Position edits are ID-based rather than source-index-based, preventing edits/deletes from targeting the wrong card after reordering.
- Gallery image selection opens a 9:16 crop surface with one-finger pan and pinch zoom; the saved crop is copied into app-owned storage so the card no longer depends on continued gallery access.
- Replacing/canceling/deleting dreams now cleans unused app-owned crop files, and migration/health-check pruning removes old orphan crop images without touching external URIs.
- Dream data loading/saving now normalizes title/year/price/order consistently and repairs duplicate/blank legacy IDs.
- Persistence schema bumped to 16 and app version bumped to 0.57 / versionCode 57.

## v58 — Step 5B: fullscreen Dreamboard, active-photo backdrop and portable photos
- Tapping a Dreamboard image opens a full-screen, image-first viewer with horizontal swipe navigation across all dreams; the main long-press Properties behavior stays unchanged.
- Both the main Dreamboard and fullscreen viewer derive a soft, darkened background from the active image using a cross-version downsample/upsample blur that works back to minSdk 26.
- Added a compact `current/total` indicator (for example `4/12`) instead of dot rows, keeping the Dreamboard surface visually minimal.
- Fullscreen keeps the same 9:16 image presentation and bottom metadata overlay: price left, `سال <year>` center, title right.
- Manual Export now creates a portable `.gamify.zip` bundle containing app data plus the actual Dreamboard photo bytes; Restore remaps every bundled image to a new app-private file path.
- Legacy JSON backups are still accepted. ZIP imports validate paths/count/size before applying data and ignore unsafe archive paths.
- App-private Dreamboard files are now included in Android Auto Backup and device-to-device transfer rules.
- Dream loading repairs stale file URIs by matching the restored app-private filename where possible.
- Persistence schema bumped to 17 and app version bumped to 0.58 / versionCode 58.

## Next approved step
- Step 6A: centralize XP / Level / Rank / Combo progression rules in one Progression Engine.

## v59 — Step 6A: centralized Progression Engine
- Added `ProgressionEngine.kt` as the single rules source for XP, Level, Rank and Combo transitions.
- Mission results no longer calculate progression inside `GameStorage`; storage now only loads/commits the result returned by the engine.
- Bonus/Achievement XP uses the same internal XP-to-Level path as mission rewards, preventing different level formulas from drifting apart.
- Centralized Combo rules: Done +1, Later unchanged, Failed resets to 0, Partial -1; Combo reward multipliers are defined in the engine only.
- Centralized Rank rules: only a successfully completed Rank Mission can add Rank progress; Rank requirements and max Rank live in the engine only.
- Centralized Level advancement: all XP sources share one threshold transition and one level-up Coin reward rule.
- Added progression normalization for persisted/imported player state so invalid XP/rank/combo values cannot leak into HUD, Stats or Profile.
- Level/Rank UI event projection now comes from the engine after the persisted transition, while the existing session de-duplication remains the guard against duplicate rewards/events.
- `loadPlayer` and `savePlayer` both pass through the same normalization layer, making PlayerState the shared source read by Home/HUD/Stats/Profile.
- Persistence schema bumped to 18 and app version bumped to 0.59 / versionCode 59.
- Pure Progression Engine smoke tests passed for level-up, Rank Mission advancement, Combo boost, Later, Failed, and bonus rewards.

## Next approved step
- Step 6B: slow/queued HUD progression animations and Level/Rank reward presentation without changing the progression rules.

## v60 — Step 6B: queued HUD reward animation and compact Level/Rank notices
- Added `ProgressionAnimation.kt` as a visual-only layer; persisted progression rules remain exclusively in `ProgressionEngine.kt`.
- Done missions now reveal rewards on the Home HUD in a fixed slow sequence: XP → Coins → Combo → Level → Rank.
- XP animation follows the same threshold curve as the engine, so the XP bar can visibly fill, roll into a new Level, and continue from zero without inventing intermediate saved state.
- Coin totals count toward the committed balance after XP, then Combo updates, followed by Level and Rank emphasis.
- Rank progress animates from the pre-mission value to the committed value; Rank-up and max-rank cases use the same final persisted state.
- The green completed-mission card flight now lasts for the full queued reward sequence, moving/fading toward the HUD more slowly than before.
- Removed the old generic “MISSION COMPLETE” reward overlay and stopped showing Level/Rank as blocking full-screen result screens.
- Level Up and Rank Up are now compact, non-blocking top notices delivered through one queue, so simultaneous Level + Rank events are shown one after another instead of overlapping.
- HUD sublabels temporarily show the active reward cue (`+XP`, `+Coins`, Combo delta, Level transition, Rank transition) while the visible values increment.
- Reduced Motion still skips the long counting/flight sequence and jumps to the already committed final state, while keeping a short milestone notice.
- App version bumped to 0.60 / versionCode 60. Persistence schema remains 18 because Step 6B changes presentation only.

## Next approved step
- Step 8A when progression work is complete: timer/reminder reliability, notification scheduling, and device-restart recovery. Profile/Stats remains intentionally parked.

## v61 — Step 8A: reliable timer, daily reminders and restart recovery
- Added `AlarmScheduler.kt` as the single scheduling layer for timer-finish alarms and per-mission Daily reminders.
- Running timers now persist both wall-clock and monotonic (`elapsedRealtime`) deadlines plus Android boot count. Manual clock changes on the same boot no longer incorrectly stretch or finish a running timer; reboot recovery safely falls back to the persisted wall-clock deadline.
- Timer alarms use exact idle alarms when Android grants exact-alarm access, with an idle-capable fallback when that access is unavailable.
- Daily reminders are one-shot alarms recalculated in the current system timezone after every fire, edit, delete, result, timezone/time change, app update and device restart. This avoids repeating-alarm DST drift.
- A Daily mission that is already Done/Failed for the current day is scheduled for its next eligible day rather than notifying later that same day.
- Added `MissionReminderReceiver` for reminder delivery and `SystemEventReceiver` for BOOT_COMPLETED, TIME_SET, TIMEZONE_CHANGED, MY_PACKAGE_REPLACED and exact-alarm-permission changes.
- If the phone was powered off when a running timer expired, reboot recovery preserves the finished mission session and surfaces the timer-finished notification instead of losing it.
- Notification channels for timer completion and mission reminders are created centrally, and Android 13+ notification permission is requested when notifications are enabled.
- Editing/deleting missions or changing History immediately invalidates/reschedules stale reminder PendingIntents; removed mission alarms are cancelled through a persisted scheduled-ID set.
- Persistence schema bumped to 19 and app version bumped to 0.61 / versionCode 61.

## v62 — Step 8B: actionable timer-finish notification results
- Timer-finished notifications now expose three direct actions: Done, Later and Failed, each with its own compact action icon.
- Actions are handled by `MissionResultReceiver` without opening the Activity, so they work while the app process/UI is closed or the phone is locked (subject to the device notification/lock-screen policy).
- Every action carries the immutable timer `sessionId`, verifies that the persisted session is the same finished timer, and commits through `finalizeActiveMissionSession()` — the same atomic/idempotent path used by the in-app result controls.
- Done therefore awards XP/Coin/Combo/Rank exactly once; Later awards nothing and keeps Combo unchanged; Failed awards nothing and resets Combo according to `ProgressionEngine`. Rapid repeated taps cannot duplicate rewards or History.
- The timer-finished notification is cancelled after any result is committed, when the result is completed inside the app, when a new timer starts, or when active timer state is explicitly cleared.
- Tapping the notification body now reliably routes an existing finished timer back to its Mission result screen. Tapping a normal mission reminder routes Home to that mission card.
- A lightweight persisted revision marker lets an already-running Activity refresh Player/History/timer state after a notification action was applied in the background, avoiding stale HUD or Mission UI. The marker is ephemeral and excluded from manual backups.
- App version bumped to 0.62 / versionCode 62. Persistence schema remains 19 because no durable domain schema changed.

## Next approved step
- Step 9A: define the complete versioned backup bundle and safe migration/import staging, including portable Dreamboard photos and all current domain state.

## v0.82 — TimeSheet daily performance
- Added per-occurrence status tracking: planned, done, missed.
- Added quick status controls to the TimeSheet event editor with instant persistence.
- Added weekly override records so recurring weekly templates can have independent completion status in each week without mutating the template.
- TimeSheet stats now reflect scheduled, done, missed, and free hours with Persian digits.
- Event cells now show compact status marks and status-specific colors.
- Fixed recurring occurrence rendering to avoid duplicate template/override blocks.
- Version bumped to 0.82 / versionCode 82.

## v0.83 — TimeSheet gestures + reminders
- Added persisted pinch-to-zoom for the weekly TimeSheet board (65%–150%).
- Added one-finger horizontal/vertical panning via native scroll containers.
- Added per-plan "5 minutes before" reminders with weekly recurring scheduling.
- TimeSheet reminders are restored after reboot/time/timezone/app-update schedule synchronization.
- Reminder icon is shown on TimeSheet entries that have reminders enabled.


## v0.84 — TimeSheet final integration
- Finalized the native TimeSheet visual language in the app's navy/gold game style with a quieter large-board background.
- Compacted the TimeSheet header and removed the redundant subtitle while keeping an explicit close control and Android Back support.
- Added a compact status legend, stronger current-day highlighting, clearer event cells, and final week-navigation polish.
- Kept 7-day Saturday–Friday scheduling, 07:00–24:00 hours, ±10-week navigation, recurring weekly plans, overlap protection, per-occurrence performance states, persisted zoom/pan, and optional 5-minute reminders.
- TimeSheet state remains inside the app backup because it is stored as a normal persisted preference; restore/reset now immediately resynchronizes native TimeSheet reminder alarms.
- Version bumped to 0.84 / versionCode 84.


## v85 – TimeSheet interaction and readability fixes
- Merged contiguous hour selections into one continuous block so 14–18 appears as a single rectangle with the title centered.
- Increased contrast between empty cells and planned/done/missed entries for faster at-a-glance reading.
- Improved zoom and pan gestures, enabled broader zoom range (40%–180%), and persisted the new zoom limits.
- Fixed reversed previous/next arrows in week navigation.
- Preserved status on save and applied done/missed state correctly to one-time and recurring occurrences.
- Enabled weekly recurring checkbox by default for newly created events.


## v86 – Build fix + persistent mission execution
- Added the missing ScrollState.scrollBy import used by TimeSheet pan gestures, fixing the GitHub Kotlin compile error.
- Mission Back now returns to Home without completing, deferring, or stopping the active timer.
- Home mission cards show the live remaining time for the running mission and switch the button to «ادامه ماموریت».
- App launch now opens Home even when a mission timer is active; the mission can be resumed from its card.
- Re-entering the same running mission resumes the existing timer instead of starting a new session.
- Mission timer ring stays at a fixed 230dp diameter while typing so keyboard resize no longer shrinks the circle.
- Version bumped to 0.86 / versionCode 86.

## Stage 18 — Large tree performance
NetworkTreeScreen now culls off-screen nodes during Canvas rendering and reduces detail at distant zoom levels. The complete logical layout remains intact for search and navigation.

## v162 — Stage 20
Unified the Network Tree, person card, prospect list, todos/history/coaching and person-management surfaces under centralized NetworkUi visual tokens in DesignSystem.kt.

## Stage 21 / v163
- Unified animated navigation for the new network tree.
- Person cards use soft fade + scale + horizontal motion.
- Deeper person sub-pages slide in and reverse on Back.
- Previous destination remains mounted during exit animation to avoid snapping.

## v173 / Stage 31
- Completed canonical Defer/Later mission flow: no rewards, Combo preserved, active session released, direct return to Mission Tower, deferred card re-queued after untouched active cards, and full-duration timer on restart.


## Stage 36 — Combo x1.5
Five consecutive Done missions arm Combo. Rewards from the following Done mission onward are multiplied by x1.5 while the 30-minute combo window remains active. Failed/Partial break the streak; Defer preserves it.

## Stage 44 — Mission carousel focus stability
The mission carousel now follows the same mission across Start/result-driven reordering instead of jumping to the first active card. Done, Failed and Defer request focus using the mission's stable source index; Restore and notification flows retain their existing explicit focus behavior.


## Stage 72 / v214 — Level-up XP rollover animation
- XP bar now emphasizes each threshold crossing with a gold flash while preserving overflow XP into the next level.
- Level badge pulses at the exact rollover frame, including multi-level gains.
- Schema version 77.

## Stage 78 / v220 — Compact Progress Profile
- Consolidated Level, Rank, XP, Coins, Combo, current Daily Streak, best Daily Streak and personal records in the existing Progress Profile destination.
- Added the shared game HUD at the top of the profile while preserving achievements and the activity calendar.
- Daily streak visibility follows the configured mission-day boundary and does not show a stale streak after a missed work day.
- Schema version 83.


## Stage 79 / v221 — Personal Best Records
- Added a dedicated BEST RECORDS block to Progress Profile.
- Tracks best day, highest XP in one work day, most successful missions in one work day, longest single focus session, and highest total daily focus.
- Records are derived from canonical mission history and respect the configured mission-day boundary, so backup/import and restored history remain authoritative.
- Schema version 84.


## Stage 80 / v222 — Progression consolidation
- Added a canonical ProgressionSummary used by HUD and Progress Profile for Level, XP distance, Rank progress and Combo state.
- Daily Stats now respects the configured mission-day boundary, matching Missions, Daily Streak and Personal Bests instead of switching at midnight.
- Existing reward, level, rank, combo, streak and record formulas remain unchanged.
- Schema version 85.


## Stage 83 / v225 — Achievement category filters
- Added compact category filters for Mission, Focus, Combo, Rank, Level and Streak plus an All view.
- Each filter exposes completed/total category progress and selected categories show a compact progress bar.
- Existing READY/CLAIMED ordering and reward claim behavior remain unchanged inside each filter.
- Schema version 88.

- Stage 84 / v226: Added persistent one-time Achievement Unlock Celebration with queued in-app toast, reward preview, upgrade-safe seeding, and Reduced Motion support.


## Stage 86 / v228 — Achievement Category Mastery
- Added an overall Achievement Mastery summary with completion percentage.
- A category is marked Mastered only after all of its tiered achievements are complete.
- Mastery is presentation-only and does not alter XP/Coin reward formulas or claim persistence.
- Schema version 91.

## Stage 87 / v229 — Achievement Mastery Celebration
- Added a persistent one-time Mastery celebration for completing every tier in an Achievement category.
- Upgrade-safe seeding prevents old mastered categories from generating a notification flood.
- Mastery notices are queued behind Level/Rank and individual Achievement unlock feedback.
- Reduced Motion is supported; Mastery remains prestige-only with no extra XP/Coin economy change.
- Schema version 92.

## Stage 88 — Achievement Showcase (v230)
Progress Profile now supports a persistent three-slot Achievement Showcase. Only unlocked achievements may be featured; selections survive restart and full backup/import. This is cosmetic/profile identity only and does not alter XP/Coin economics.

## Stage 89 — Achievement Medal Frames (v231)
Showcase medals now communicate progression visually: Tier 1 uses a steel frame, Tier 2 bronze, Tier 3 gold, and Tier 4 a prestige violet frame. If the medal belongs to a fully mastered category, the showcase upgrades it to a brighter Mastery frame with a small spark marker. Unlocked achievement-list icons also inherit tier styling while locked icons remain muted. This is presentation-only and does not change rewards, claims, unlock thresholds, or mastery economy. Schema 94.


## Stage 90 — Achievement system consolidation (v232)
- Added one canonical AchievementCollectionSummary for completed/total, claimable rewards, category progress, overall progress and mastered categories.
- Progress Profile filters, collection mastery, showcase medal mastery and claim counters now share the same derived projection instead of recomputing parallel state.
- Existing unlock thresholds, tier rewards, one-time celebrations, claim persistence, showcase selections and medal frames are unchanged.
- Schema version 95.

## Stage 91 — Daily / Weekly Challenges foundation (v233)
Challenges now use `currentMissionDay(context)` and `MissionHistoryEntry.missionDay(context)`, so progress follows the configured work-day boundary. The pool now contains three daily and three weekly objectives covering completed missions, focus, XP, and active days. A compact live tracker exposes Daily/Weekly completion and ready rewards on the World/Mission stage. Schema 96.


## Stage 92 — Challenge screen
Full-page Daily/Weekly Challenges UI with progress, reward, persisted Claim, and World entry point. Schema 97.


## Stage 93 — Challenge Claim Animation
Challenge claims now trigger the shared HUD reward sequence (XP, then Coins) while the claimed-key state changes the card live to CLAIMED. Reward persistence still uses the canonical progression engine. Schema 98.

## Stage 94 — Challenge completion celebration
Daily/Weekly challenges now emit a one-time in-app `CHALLENGE COMPLETE` / `Reward Ready` toast when they first cross their goal. Seen completion keys are persisted, old completions are seeded silently on upgrade, and the toast waits for Level/Rank/Achievement/Mastery notices before appearing. Claim remains a separate manual reward action. Schema 99.

## Stage 95 — Daily Challenge Bonus Chest
Completing all three Daily Challenges unlocks one date-scoped bonus chest. Opening it awards +250 XP and +125 Coins through the canonical progression engine. The chest can only be opened once per configured mission day, is backed up with the rest of persistent preferences, and reuses the Challenge XP/Coin HUD reward sequence. Existing individual challenge rewards remain unchanged.

## Stage 96 — Weekly Challenge Bonus Chest (v238)
Completing all three Weekly Challenges unlocks a larger week-scoped bonus chest. Opening it awards +750 XP and +375 Coins through the canonical progression engine. The claim is persisted independently per Saturday-based challenge week, survives full backup/import, and reuses the Challenge HUD reward sequence. Individual weekly challenge rewards remain unchanged. Schema 101.

## Stage 97 — Bonus Chest Opening Celebration
Daily and Weekly challenge bonus chests now have a dedicated opening beat before their canonical reward claim. The overlay shows the exact XP/Coin payout, uses distinct Daily/Weekly visual language, blocks duplicate opens, respects Reduced Motion, then hands off to the existing XP -> Coin HUD reward sequence. No reward values or claim-key rules changed.

## Stage 98 — Challenge Streak
- Added a separate Challenge Streak based on days where all three Daily Challenges are completed.
- Current streak survives an in-progress current day and uses the configured mission-day boundary.
- Tracks best streak and 3/7/14/30-day milestones.
- Challenge screen shows current/best streak and next-milestone distance.

## Stage 99 — Challenge Streak Milestone Rewards
Challenge Streak milestones at 3/7/14/30 days now grant one-time XP/Coin rewards through the canonical progression engine. A dedicated celebration is queued with the existing progression notification system. Existing historical milestones are seeded silently on upgrade to avoid duplicate payouts.

## Stage 100 — Challenge system consolidation (v242)
- Added canonical `ChallengeCollectionSummary` for Daily/Weekly challenge progress, ready claims, Daily/Weekly bonus chest state and Challenge Streak.
- ChallengeScreen now consumes the shared projection instead of maintaining parallel derivations.
- Weekly challenge aggregation is now consistently Saturday-based across challenge progress and the Weekly Bonus Chest, matching the app's week model.
- Existing challenge rewards, chest payouts, streak milestone rewards and claim persistence remain unchanged.
- Schema version 105.


## Stage 101 — Statistics & Analytics
Stats is now an analytics dashboard with 30-day productivity KPIs and a 7-day mission/XP trend while preserving focus history and all-time totals. All day grouping uses the configured mission-day boundary. Schema 106.


## Stage 102 — Weekly Comparison
- Statistics now compares this Saturday-based work week against the previous week.
- Metrics: completed missions, focus time, XP.
- Growth/decline percentage is shown beside current and previous values.
- Mission-day boundary remains consistent with the configured work-day start.

## Stage 103 — Monthly Comparison (v245)
- Statistics now compares the current Jalali month-to-date with the complete previous Jalali month.
- Tracks successful Missions, Focus, XP, and Active Days.
- Uses the same mission-day boundary as the rest of the app.
- Shared the existing Jalali conversion helpers with analytics instead of introducing a second calendar implementation.
- Schema: 108.


## Stage 104 — Personal Performance Records
Statistics now includes best day/week, highest daily XP, most completed missions in one day, and highest daily Focus. Records use canonical mission-day boundaries, Saturday-based weeks, and Jalali labels. Schema 109.


## Stage 105 — Productivity Heatmap
Added a compact 12-week productivity heatmap to Analytics. Each work day is represented by a cell whose intensity is derived from successful missions plus focus minutes, using the configured mission-day boundary. Today is outlined and an active-day total plus intensity legend are shown. Schema 110.

## Stage 106 — Interactive Productivity Heatmap
- Heatmap cells are tappable and expose an inline detail panel for the selected work-day.
- Day details show Jalali date, successful missions, Focus, XP, and Success Rate.
- Selected-day highlight is distinct from the current-day border.
- Analytics remain based on the configured mission-day boundary and are read-only.
- Schema 111 / release v248.

## Stage 107 — Performance Trends
Statistics now includes 7-day and 30-day trend comparisons for successful missions, focus time, and XP. Trend direction is descriptive only and does not alter progression or rewards. All windows use the canonical configured mission-day boundary.


## Stage 108 — Best Time Analysis
- Added analytics for the strongest mission-completion hour and strongest focus hour.
- Added Morning / Afternoon / Evening / Night daypart comparison and highlights the best daypart.
- Uses actual local mission result timestamps; focus is attributed to the hour/daypart where the session result was recorded.
- Analytics only: progression and reward formulas are unchanged.
- Backup schema: 113.


## Stage 109 — Mission Performance Analysis
- Added per-mission analytics grouped by mission id (title fallback for legacy history).
- Shows most completed, most focus, most XP, and best success-rate mission.
- Success-rate leader requires at least two resolved outcomes to avoid one-off 100% noise.
- Added compact Top Missions ranking using Done, Focus, and XP as deterministic ordering.
- Analytics only; progression and reward formulas are unchanged.
- Backup schema: 114.

## Stage 110 — Statistics & Analytics consolidation (v252)
- Added a canonical `AnalyticsDashboardSummary` projection for headline daily/30-day KPIs.
- Stats now builds one mission-day index and reuses it across dashboard, comparisons, records, heatmap, trends, best-time and mission-performance analysis.
- Existing Saturday-based weekly logic, Jalali monthly logic, configured mission-day boundary, and read-only analytics semantics are preserved.
- No reward or progression formulas changed.
- Backup schema: 115.


## Stage 111 — TimeSheet Integration foundation
- TimeSheet now reads real Mission history for the displayed Saturday-based week.
- Added a compact Mission × TimeSheet panel with successful mission count, actual focus, plan coverage, and same-title block matching.
- This is analytics-only: it does not auto-complete TimeSheet blocks or alter Mission rewards.
- Schema 116.

## Stage 114 — TimeSheet as Mission entry point
- Unfinished linked TimeSheet blocks can launch their Mission directly.
- Existing active session is continued without timer reset when it is the same Mission.
- Single-active-mission conflict protection remains canonical when a different Mission is running.
- Terminal linked blocks (Done/Failed) stay editable and do not restart.
- Schema 118 / release v256.

## Stage 115 — TimeSheet result + actual focus sync
- Linked blocks now use the latest terminal MissionHistoryEntry for the same work-day.
- DONE/FAILED visual state and actual focus duration are rendered together on the block.
- Unlinked TimeSheet blocks keep their previous manual status behavior.
- Schema 119.


## Stage 116 — TimeSheet planned vs actual focus
- Linked TimeSheet blocks now compare their scheduled duration with the actual focus committed by the same terminal Mission run.
- Blocks show `actual / planned min` plus completion percentage (for example `42 / 60 min • 70%`).
- Percentages can exceed 100% so extra focus remains visible instead of being silently capped.
- Done/Failed status continues to come from the same MissionHistoryEntry used for actual focus, preserving result/focus consistency.
- Schema 120 / release v258.


## Stage 117 — TimeSheet visual Plan vs Actual progress
- Linked TimeSheet blocks now include a compact progress bar for actual focus versus planned duration.
- The visual bar caps at 100% for stable layout, while the numeric percentage remains uncapped so over-delivery is still explicit.
- Bar accent follows the linked Mission state and updates from the same canonical MissionHistoryEntry used by status/focus text.
- Schema 121 / release v259.


## Stage 118 — TimeSheet daily Plan vs Actual summary
- Added a compact daily roll-up directly to each sticky TimeSheet day header.
- Each day now shows actual mission focus versus planned TimeSheet minutes plus a completion percentage.
- Added a tiny daily progress bar for glanceable plan coverage; over-delivery remains visible numerically above 100%.
- Actual focus respects the configured mission-day boundary via `missionDay(context)`.
- Backup schema advanced to 122.


## Stage 119 — TimeSheet weekly performance card
- Consolidated the TimeSheet/Mission weekly summary into a Weekly Performance card.
- Shows planned time, actual Mission focus, weekly coverage, successful planned days, and best day of the week.
- A successful day means actual Mission focus reached or exceeded that day’s planned TimeSheet duration.
- Best day is selected by plan coverage, then actual focus as a tie-breaker.
- Saturday-based week and configured Mission work-day boundary remain canonical.
- Backup schema advanced to 123 / release v261.

## Stage 120 — TimeSheet × Mission consolidation
- Centralized block, daily and weekly Plan vs Actual calculations behind one canonical `TsPlanActual` projection.
- Planned minutes, committed Mission focus, uncapped coverage percentage and capped visual progress now share the same formulas everywhere.
- Daily and weekly roll-ups continue to respect the configured Mission work-day boundary and Saturday-based TimeSheet week.
- Removed duplicated coverage math to prevent drift between block progress, day headers and Weekly Performance.
- Backup schema advanced to 124 / release v262.

## Stage 121 — Dreamboard × Gamification integration foundation
- Dreams can now link directly to a real Mission by stable mission ID.
- Dreamboard shows a compact GOAL LINK progress summary for the active dream.
- Progress uses real mission history: successful completions and XP earned.
- Existing dreams remain compatible and default to no linked mission.
- Backup/storage schema bumped to 125 and persists the dream-to-mission link.

## Stage 122 — Dream mission completion targets
- Each Dream can now define a real completion target for its linked Mission (for example, 30 successful completions).
- GOAL LINK shows Done / Target and uncapped numeric progress percentage from real Mission history.
- Added a compact visual progress bar capped at 100% while preserving over-target percentage numerically.
- Target is persisted with the Dream and older dreams remain compatible with target 0 (no target).
- Backup/storage schema advanced to 126 / release v264.


## Stage 123 — Dream Goal Completed state + celebration
- Dreams with a linked Mission target now enter GOAL COMPLETED state when successful completions reach 100% of target.
- Added a dedicated Dream completion celebration overlay that is shown once per completed goal configuration.
- Celebration acknowledgement is persisted so reopening the Dreamboard does not replay the same completion repeatedly.
- Changing the linked Mission or completion target rearms completion celebration for the new goal configuration.
- Backup/storage schema advanced to 127 / release v265.


## Stage 124 — Dream goal reward claim
- Completed Dream goals now expose a one-time reward claim: +250 XP and +100 Coins.
- Rewards use the canonical bonus progression path, so XP rollover/level-up rewards remain consistent.
- `goalRewardClaimed` is persisted per Dream and included in backup data; editing the linked mission/target resets claim ownership for the new goal definition.
- Schema version: 128.


## Stage 126 — Achieved Dreams Collection / Trophy Shelf
- Added a dedicated Trophy Shelf for permanently achieved and claimed Dream goals.
- Dreamboard now exposes collection progress: achieved count, total dreams, and overall completion percentage.
- Trophy Shelf summarizes the canonical Dream reward value already claimed across achieved goals.
- Each achieved Dream appears as a trophy entry with year and linked Mission context when available.
- Achievement state remains derived from the existing one-time reward claim, avoiding duplicate persistent state.
- Backup/storage schema advanced to 130 / release v268.

## Stage 127 — Dream achievement date + trophy details
- Dream reward claims now persist the exact achievement timestamp once, at the canonical one-time claim event.
- Trophy Shelf entries show the achievement date in Jalali format together with year and linked Mission context.
- Legacy claimed Dreams remain compatible; when no historical timestamp exists they explicitly show that the date was not recorded rather than inventing one.
- Editing the same goal preserves its achievement timestamp; changing the linked Mission/target resets it with the new claim lifecycle.
- Backup/storage schema advanced to 131 / release v269.

## Stage 128 — Dream Milestones
- Added Dreamboard milestone medals at 1, 3, 5, and 10 claimed Dreams.
- Trophy Shelf shows locked/unlocked medal states and progress toward the next milestone.
- Milestone progress is derived from canonical claimed Dream achievements.
- Backup/storage schema advanced to 132 / release v270.

## Stage 129 — Dream Milestone Unlock Celebration
- Unlocking the 1, 3, 5, or 10 Dream milestone now triggers a dedicated medal celebration overlay.
- The highest celebrated milestone is persisted so the same milestone does not replay on every Dreamboard visit.
- Celebration state is backup-eligible and restores with the rest of app preferences.
- Trophy Shelf milestone progress remains derived from canonical claimed Dream achievements.
- Backup/storage schema advanced to 133 / release v271.

## Stage 130 — Dreamboard × Gamification consolidation
- Centralized Dream mission progress into a canonical `DreamProgressSnapshot` projection.
- Dream completion count, XP, target, percentage, bounded progress bar, completion and achieved state now derive from one rule set.
- Centralized Dream milestone thresholds (1/3/5/10) so collection and celebration logic share the same progression ladder.
- Preserved reward, achievement date, Trophy Shelf, milestone celebration and backup behavior.
- Backup schema: 134.

## Stage 131 — Network Tree × Gamification foundation
- Added a derived daily Network Pulse to bridge real network activity into the gamification surface without duplicating persistent state.
- Pulse counts prospect actions, completed person todos, and confirmed daily person saves using the configured mission-day boundary.
- Added a compact NETWORK PULSE card beneath the shared game HUD with activity points derived from canonical NetworkData records.
- Current activity-point weights are presentation-only (action 10, completed todo 15, confirmed person 20); no XP/coin rewards are granted yet.
- Backup/storage schema advanced to 135 / release v273.


## Stage 132 — Network Activity XP Ledger
- Converts current mission-day network actions (10 XP), completed person todos (15 XP), and confirmed daily stats (20 XP) into real player XP.
- Uses stable record-based ledger keys so each activity rewards exactly once across recomposition, navigation, edits and backup/restore.
- Player progression and ledger are persisted together in one SharedPreferences editor transaction.
- Network Pulse reports XP synchronized during the current tree session.
- Backup schema: 136.


## Stage 133 — Per-person Network Activity Score
- Network activity is now attributed to the owning tree person.
- Prospect actions resolve through prospect owner; completed todos and confirmed daily stats use person IDs directly.
- Active tree nodes show a compact daily `PTS` badge using the same 10/15/20 scoring weights as Network Pulse.
- Scores respect the configured mission-day boundary and are derived from source records (no duplicate score state).
- Backup schema: 137.


## Stage 134 — Branch Network Activity Score
- Aggregates each person's canonical daily Activity Score upward through the actual parent/child tree.
- Every leader now has a branch score containing their own activity plus all descendants, including nodes hidden by collapse.
- Active leader nodes show personal score and branch total together (`PTS • BR`) without introducing duplicate persistent counters.
- Cycle protection keeps malformed legacy parent links from causing recursive failure.
- Backup/storage schema advanced to 138 / release v276.


## Stage 135 — Network Branch Ranking
- Added a live top-3 Branch Ranking card to Network Tree.
- Ranking uses the canonical recursive branch activity score (leader + all descendants).
- Only real leaders with direct children participate; collapsed descendants still count.
- Stable tie-breaker by leader name keeps ranking deterministic.
- Schema version: 139.


## Stage 136 — Network Daily Goal
- Added a live DAILY NETWORK GOAL card to Network Tree.
- Daily target is 300 activity points using the same canonical 10/15/20 scoring model as Network Pulse.
- Shows current points / goal, uncapped percentage, a capped visual progress bar, and remaining points.
- Goal completion is derived from today's real network records and respects the configured mission-day boundary; no duplicate goal state is stored.
- Backup/storage schema advanced to 140 / release v278.

## Stage 137 / 150 — Network Daily Goal Reward Claim
- Completing the 300-point Network Daily Goal unlocks a one-time daily claim.
- Reward: +150 XP and +75 Coins through the canonical progression engine.
- Claim idempotency is keyed by the configured mission-day boundary and is included in full backup/export.
- Recomposition, reopening Network, or repeated taps cannot grant the same day's reward twice.
- Schema: 141.

## Stage 138 — Network Streak
- Added a Network Streak derived from successful Daily Network Goal claims.
- Streak respects the configured mission-day boundary and counts consecutive completed days.
- Before today's goal is claimed, an intact streak from yesterday remains visible; claiming today extends it immediately.
- Network Pulse now surfaces the live streak without introducing duplicate reward state.
- Backup compatibility is automatic because the streak derives from the existing daily-goal claim ledger.
- Schema: 142.

## Stage 139 — Network Streak Milestones
- Added 3 / 7 / 14 / 30 day Network Streak milestone medals.
- Added one-time milestone claims with XP + Coins rewards.
- Milestone claim state is persisted in SharedPreferences and included in full backup/export.
- Rewards use the canonical player progression pipeline and cannot be claimed twice.
- Backup schema: 143.


## Stage 140 — Network Tree × Gamification consolidation
- Consolidated Network Pulse, per-person activity, recursive branch totals and Branch Ranking into one canonical `NetworkGamificationSnapshot`.
- Mission-day boundary and 10/15/20 activity weights are now evaluated once per NetworkData snapshot, preventing drift between network surfaces.
- Preserved XP ledger idempotency, Daily Network Goal reward claims, Network Streak and 3/7/14/30 milestone rewards.
- No reward formulas changed; this stage is a stability/consolidation pass before the final roadmap phase.
- Backup/storage schema advanced to 144 / release v282.


## Stage 141 — Final Integration: Live World Map
- Home landmarks now surface live Mission, Network, TimeSheet and Dreamboard metrics.
- Mission shows active/today completion context; Network shows today saved members; TimeSheet shows today plan state; Dreamboard shows achieved/total goals.
- Existing node states, navigation, rewards and daily completion remain unchanged.
- Backup schema: 145.

## Stage 142 — Unified Today Dashboard
- Added one compact TODAY dashboard to Home / World Map across Missions, TimeSheet, Network and Dreamboard.
- Shows today's mission completion, real focus duration, mission XP earned, TimeSheet plan coverage, Network activity points and achieved Dream count.
- TimeSheet and Network expose read-only canonical projections so Home does not duplicate their persistence/scoring rules.
- Existing world node states, rewards, navigation and daily completion lifecycle remain unchanged.
- Backup/storage schema advanced to 146 / release v284.


## Stage 143 — Interactive Unified Today Dashboard
- Made the four core TODAY metrics directly navigable.
- MISSIONS opens Missions, PLAN opens TimeSheet, NETWORK opens Tree, and DREAMS opens Dreamboard.
- Kept the dashboard read-only metrics and existing world-map navigation semantics intact.
- Backup schema bumped to 147.


## Stage 144 — Smart Next Action
- Added a live Smart Next Action card to Home beneath the unified Today dashboard.
- Deterministic priority: resume active mission → unfinished missions → incomplete TimeSheet plan → Network daily goal → Dreamboard setup/progress.
- The card is fully tappable and routes directly to the relevant core screen.
- Uses existing live system summaries; no parallel reward/progress state was introduced.
- Backup schema: 148.


## Stage 145 — End-of-Day Summary
- Added a compact Home end-of-day rollup sourced from canonical Today data.
- Summarizes missions, focus, XP, TimeSheet coverage, Network activity, and overall daily completion.
- Read-only integration: no duplicate rewards or parallel state.
- Backup schema: 149.


## Stage 146 — Unified Daily Score
- Added one deterministic 0–100 Daily Score to the End-of-Day summary.
- Score uses four capped 25-point pillars: Missions completion, Focus against today's mission duration target, TimeSheet plan coverage, and Network progress toward the 300-point daily goal.
- Added a compact per-pillar breakdown so the score remains explainable rather than opaque.
- The score is read-only and computed from canonical Today data; no new reward or duplicate persistence path was introduced.
- Backup schema: 150.

## Stage 147 — Daily Score History & Personal Best
- Persisted one canonical 0–100 Daily Score per mission-day, keyed by the configured day boundary.
- Added rolling score history (up to 366 days) with same-day replacement rather than duplicate entries.
- End-of-Day now shows the personal best score and the latest seven daily scores.
- Daily score history is stored in the main preferences store and therefore participates in full backup/export/import.
- Backup schema: 151.

## Stage 148 — Daily Score Trend
- Added Today / Yesterday / 7-Day Average comparison to the End-of-Day score card.
- Added an immediate directional delta indicator against the previous recorded day.
- Preserved the existing 7-day score strip and Personal Best for quick context.
- Uses the canonical Daily Score History only; no duplicate history or reward state was introduced.
- Backup schema: 152.


## Stage 149 — Full App Consistency & Stability Pass
- Audited the final integrated state paths for Missions, TimeSheet, Dreamboard, Network, progression, timer/session handling and Home summaries.
- Hardened full-backup coverage checks so core mission/history, Dreamboard, Network, TimeSheet, Tree, Network reward ledgers and Daily Score history cannot be silently omitted when present.
- Kept running timer/session state intentionally ephemeral so restoring a backup cannot resurrect a stale active countdown.
- Preserved the canonical navigation/result flows and existing reward idempotency; no scoring formulas were changed in this pass.
- Backup/storage schema advanced to 153 / release v291.


## Stage 150 — Final Release / Production Polish
- Completed the 150-stage roadmap and froze the integrated Mission, TimeSheet, Dreamboard, Network, progression and Home architecture for the final release candidate.
- Advanced Android app version metadata to versionCode 153 / versionName 1.53 and backup/storage schema to 154.
- Preserved reward idempotency, mission-day boundaries, timer/session safety and full backup coverage established in the stability pass.
- Added final release documentation and verification checklist; no gameplay scoring formulas were changed in this release freeze.
- Release: v292.

## v293 — Build / Packaging Fix
- Repacked the v292 final application as a clean Android-project archive.
- Removed historical root RELEASE marker clutter; no app feature behavior changed.
- Archive root now directly exposes `app/`, `gradle/`, `gradlew`, and `settings.gradle.kts`.
- ZIP extraction/integrity was verified before delivery.

## v294 — Kotlin Compile Fix
- Restored the proper ColumnScope receiver for Prospect and Coaching full-page content so `Modifier.weight(...)` resolves in Compose.
- Made the Home-facing `NetworkGamificationPulse` visibility consistent with `networkTodayPulse`.
- Removed ambiguous nested `it` inference from the Network history date label.
- No data/schema/reward behavior changes.
