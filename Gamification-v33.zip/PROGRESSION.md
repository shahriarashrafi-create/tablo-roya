# Gamification v33 Progress

- Added full local JSON backup export through Android's document picker.
- Added backup restore/import for missions, player progression, mission history, settings, rewards, challenge claims, and achievement claims.
- Backups are schema-versioned and validated before restore; active/running timer state is intentionally excluded to avoid stale alarms after recovery.
- Added Data & Backup controls in Settings, including Export, Restore, status feedback, and a confirmation-protected Reset All Local Data action.
- Added startup data migration/repair with schema version 3, normalization of player values, history de-duplication, and mission/history re-save through current parsers.
- Added timer session IDs and a last-completed-session guard so one mission session cannot grant XP/Coins/Rank rewards twice.
- Added a polished post-mission reward burst showing XP, Coins, and Combo with a lightweight coin-rise effect; Reduced Motion disables the movement.
- Refined mission carousel page indicators to a premium active gold pill with smaller inactive dots.
- Restore/reset now refreshes all in-memory state safely and returns the user to Home.
- Bumped app version to 0.33 / versionCode 33.
