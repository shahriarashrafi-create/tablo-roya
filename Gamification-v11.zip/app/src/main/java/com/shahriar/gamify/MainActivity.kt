package com.shahriar.gamify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF0D1420)
private val BgTop = Color(0xFF1B2938)
private val Gold = Color(0xFFFFC83D)
private val GoldSoft = Color(0xFFFFEAA7)
private val TextSoft = Color(0xFFC7CFDA)
private val Divider = Color(0xFF2B323C)
private val Blue = Color(0xFF5CA3FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val coins: Int = 1320,
    val combo: Int = 2
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val emblem: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val title: String,
    val emblem: String,
    val ringColors: List<Color>
)

private val rankTiers = listOf(
    RankTier(1, 5, "Novice", "✦", Color(0xFF7A5536), Color(0xFFE8B86D)),
    RankTier(6, 10, "Explorer", "★", Color(0xFF7B1D18), Color(0xFFFFC83D)),
    RankTier(11, 15, "Seeker", "◆", Color(0xFF475569), Color(0xFFD7E0EA)),
    RankTier(16, 20, "Vanguard", "⬟", Color(0xFF14532D), Color(0xFF86EFAC)),
    RankTier(21, 25, "Warrior", "⚔", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "Commander", "♛", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "Champion", "✹", Color(0xFF9A3412), Color(0xFFFDBA74)),
    RankTier(36, 40, "Master", "✪", Color(0xFF581C87), Color(0xFFD8B4FE)),
    RankTier(41, 45, "Guardian", "🛡", Color(0xFF155E75), Color(0xFF99F6E4)),
    RankTier(46, 50, "Conqueror", "☀", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "Strategist", "⌘", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "Myth Hunter", "✷", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "General", "⚜", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "Ruler", "♚", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "Legend", "✴", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "Immortal", "∞", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "Meteor", "☄", Color(0xFF9A3412), Color(0xFFFCA5A5)),
    RankTier(86, 90, "Cosmic", "✺", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "Eternal", "✵", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "Arcane", "☬", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)


private val levelTiers = listOf(
    LevelTier(1, 10, "Initiate", "◉", listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF2BF))),
    LevelTier(11, 20, "Apprentice", "✦", listOf(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFFFFFFFF))),
    LevelTier(21, 30, "Seeker", "✧", listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, "Pathfinder", "✶", listOf(Color(0xFF6B4E18), Color(0xFFF4C95B), Color(0xFFFFE8A1))),
    LevelTier(41, 50, "Builder", "◆", listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, "Steadfast", "⬟", listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, "Pioneer", "✪", listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, "Hero", "✹", listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, "Noble", "✴", listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, "Legend", "☼", listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

private fun formatNumber(value: Int): String = String.format(Locale.US, "% ,d", value).replace(" ", "")

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val player = remember { PlayerState() }

    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101823)) {
                    listOf("خانه","کارها","آمار","تنظیمات").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("🎮","☑","▥","⚙")[i], fontSize = 19.sp) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Color(0xFF2A2412),
                                unselectedIconColor = Color(0xFF8A93A2),
                                unselectedTextColor = Color(0xFF8A93A2)
                            )
                        )
                    }
                }
            }
        ) { pad ->
            if (tab == 0) {
                GameHome(player, Modifier.padding(pad))
            } else {
                Box(
                    Modifier
                        .padding(pad)
                        .fillMaxSize()
                        .background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        listOf("","کارها","آمار","تنظیمات")[tab],
                        color = Color.White,
                        fontSize = 24.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GameHome(player: PlayerState, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(BgTop, Color(0xFF132131), Bg)
                )
            )
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TopGameHud(player)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color(0x66D8B55E), RoundedCornerShape(24.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.world_home),
                contentDescription = "Game world",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x66D8B55E), RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111A24)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚔  مأموریت بعدی", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Surface(color = Color(0xFF162844), shape = RoundedCornerShape(50)) {
                        Text("کلاسیک", color = Blue, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp))
                    }
                }
                Text("۲۵ دقیقه تمرکز", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("روی مهم‌ترین کار فعلی تمرکز کن؛ بدون حواس‌پرتی.", color = TextSoft, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Reward("+50 XP", Gold)
                    Reward("+20 سکه", Color.White)
                    Reward("◷ 25 دقیقه", TextSoft)
                }
                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("▶   شروع مأموریت", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun TopGameHud(player: PlayerState) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(RoundedCornerShape(21.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF10161E), Color(0xFF080D14))
                    )
                )
                .drawBehind {
                    val stroke = 1.25.dp.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xAAEED68A),
                                Color(0xAAAF7A1E),
                                Color(0xAAF1D57D),
                                Color(0xAA996716)
                            )
                        ),
                        topLeft = Offset(stroke / 2f, stroke / 2f),
                        size = Size(size.width - stroke, size.height - stroke),
                        cornerRadius = CornerRadius(21.dp.toPx(), 21.dp.toPx()),
                        style = Stroke(width = stroke)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0x18FFF4C8), Color.Transparent, Color(0x10FFF4C8))
                        ),
                        topLeft = Offset(12.dp.toPx(), 2.dp.toPx()),
                        size = Size(size.width - 24.dp.toPx(), 4.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )
                }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1.73f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LevelBadge(player.level, levelTier)
                    Spacer(Modifier.width(7.dp))
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        XpBar(progress)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${formatNumber(player.currentXp)} / ${formatNumber(player.nextLevelXp)} XP",
                            color = Color(0xFFE8EBEF),
                            fontSize = 8.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }

                HudDivider()

                Row(
                    modifier = Modifier.weight(1.18f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RankBadge(rankTier)
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(
                            "Rank ${player.rank}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 11.sp
                        )
                        Text(
                            rankTier.title,
                            color = rankTier.secondary,
                            fontSize = 7.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 6.sp
                        )
                    }
                }

                HudDivider()

                Row(
                    modifier = Modifier.weight(1.06f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CoinBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(
                            formatNumber(player.coins),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            lineHeight = 12.sp
                        )
                        Text(
                            "Coins",
                            color = GoldSoft,
                            fontSize = 7.sp,
                            maxLines = 1,
                            lineHeight = 6.sp
                        )
                    }
                }

                HudDivider()

                Row(
                    modifier = Modifier.weight(0.82f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    FlameBadge()
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.Center) {
                        Text(
                            "x${player.combo}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            lineHeight = 12.sp
                        )
                        Text(
                            "Combo",
                            color = GoldSoft,
                            fontSize = 7.sp,
                            maxLines = 1,
                            lineHeight = 6.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(41.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.2.dp.toPx()
            val radius = (size.minDimension - stroke) / 2f
            val inset = stroke / 2f

            drawCircle(
                brush = Brush.sweepGradient(tier.ringColors),
                radius = radius,
                style = Stroke(width = stroke)
            )
            drawCircle(
                color = Color(0xFF10141B),
                radius = size.minDimension * 0.36f
            )
            drawArc(
                color = Color(0x70FFFFFF),
                startAngle = 214f,
                sweepAngle = 32f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round)
            )

            val dotR = 1.2.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = radius + 0.2.dp.toPx()
            val angles = listOf(35f, 145f, 270f)
            for (angle in angles) {
                val rad = Math.toRadians(angle.toDouble())
                val x = cx + kotlin.math.cos(rad).toFloat() * ringR
                val y = cy + kotlin.math.sin(rad).toFloat() * ringR
                drawCircle(color = GoldSoft, radius = dotR, center = Offset(x, y))
            }
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Lv", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold, lineHeight = 6.sp)
            Text(level.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.90f)
            .height(8.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF242B34))
            .border(1.dp, Color(0x805E4A20), RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFFFFE79C), Color(0xFFFFC83D), Color(0xFFE8A41C))
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.5.dp)
                .align(Alignment.TopStart)
                .clip(RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val path = Path().apply {
                moveTo(w * 0.50f, h * 0.06f)
                lineTo(w * 0.86f, h * 0.20f)
                lineTo(w * 0.80f, h * 0.67f)
                quadraticBezierTo(w * 0.66f, h * 0.88f, w * 0.50f, h * 0.96f)
                quadraticBezierTo(w * 0.34f, h * 0.88f, w * 0.20f, h * 0.67f)
                lineTo(w * 0.14f, h * 0.20f)
                close()
            }
            drawPath(path, tier.primary)
            drawPath(path, tier.secondary, style = Stroke(width = 1.6f))
        }
        Text("★", color = tier.secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, lineHeight = 11.sp)
    }
}

@Composable
private fun CoinBadge() {
    Box(
        Modifier
            .size(23.dp)
            .background(
                Brush.radialGradient(listOf(Color(0xFFFFEB9F), Color(0xFFFFC83D), Color(0xFFC88715))),
                CircleShape
            )
            .border(1.2.dp, Color(0xFFF8E8AC), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text("★", color = Color(0xFF6D4B00), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FlameBadge() {
    Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * 0.50f, h * 0.04f)
                cubicTo(w * 0.80f, h * 0.18f, w * 0.95f, h * 0.45f, w * 0.78f, h * 0.74f)
                cubicTo(w * 0.68f, h * 0.93f, w * 0.37f, h * 0.98f, w * 0.22f, h * 0.78f)
                cubicTo(w * 0.03f, h * 0.52f, w * 0.14f, h * 0.24f, w * 0.34f, h * 0.10f)
                cubicTo(w * 0.38f, h * 0.26f, w * 0.52f, h * 0.32f, w * 0.50f, h * 0.04f)
                close()
            }
            drawPath(
                outer,
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFFFF0A6), Color(0xFFFFB02E), Color(0xFFFF6A00))
                )
            )
            val inner = Path().apply {
                moveTo(w * 0.52f, h * 0.26f)
                cubicTo(w * 0.69f, h * 0.36f, w * 0.72f, h * 0.56f, w * 0.60f, h * 0.73f)
                cubicTo(w * 0.52f, h * 0.84f, w * 0.37f, h * 0.85f, w * 0.31f, h * 0.72f)
                cubicTo(w * 0.24f, h * 0.57f, w * 0.30f, h * 0.42f, w * 0.40f, h * 0.31f)
                cubicTo(w * 0.43f, h * 0.43f, w * 0.55f, h * 0.47f, w * 0.52f, h * 0.26f)
                close()
            }
            drawPath(
                inner,
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFFFF8D6), Color(0xFFFFD76A), Color(0xFFFFA41C))
                )
            )
        }
    }
}

@Composable
private fun HudDivider() {
    Box(
        Modifier
            .width(1.dp)
            .height(31.dp)
            .background(Divider)
    )
}

@Composable
private fun MiniAction(icon: String, title: String) {
    Column(
        Modifier
            .background(Color(0xD110151B), RoundedCornerShape(15.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 18.sp)
        Text(title, color = Color.White, fontSize = 10.sp)
    }
}

@Composable
private fun Reward(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
}
