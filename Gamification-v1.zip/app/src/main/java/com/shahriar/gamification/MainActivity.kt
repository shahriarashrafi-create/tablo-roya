package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFFFC83D)
private val Bg = Color(0xFF090B0F)
private val Card = Color(0xFF15191F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GamificationApp() }
    }
}

@Composable
fun GamificationApp() {
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101319)) {
                    listOf("خانه","کارها","آمار","تنظیمات").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = selected == i,
                            onClick = { selected = i },
                            icon = { Text(listOf("🎮","⚑","▥","⚙")[i], fontSize = 20.sp) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Color(0xFF25200F),
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            if (selected == 0) Home(Modifier.padding(padding))
            else Placeholder(listOf("کارها","آمار","تنظیمات")[selected-1], Modifier.padding(padding))
        }
    }
}

@Composable
fun Home(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF101722), Bg))
        ).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Stat("Lv 1", "0 / 200 XP")
            Stat("رنک 1", "تازه‌کار")
            Stat("0", "امتیاز امروز")
        }

        Box(
            Modifier.fillMaxWidth().weight(1f)
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF26384A), Color(0xFF10151B))),
                    RoundedCornerShape(28.dp)
                )
                .border(1.dp, Color(0x33FFC83D), RoundedCornerShape(28.dp))
                .padding(24.dp)
        ) {
            Column(
                Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("مسیر تو از همین‌جا شروع می‌شود", color = Color.White, fontSize = 24.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text("هر مأموریت، یک قدم به نسخه بهتر خودت", color = Color(0xFFCBD5E1),
                    fontSize = 15.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                Text("◆", color = Gold, fontSize = 52.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Card),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x55FFC83D), RoundedCornerShape(24.dp))
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("⚔  مأموریت بعدی", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("۲۵ دقیقه تمرکز", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                Text("بدون حواس‌پرتی روی مهم‌ترین کار فعلی تمرکز کن.", color = Color(0xFFB7BEC8))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("+50 XP", color = Gold, fontWeight = FontWeight.Bold)
                    Text("+20 امتیاز", color = Color.White)
                    Text("25 دقیقه", color = Color.White)
                }
                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF201700)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("▶  شروع مأموریت", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun Stat(main: String, sub: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(main, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(sub, color = Color(0xFFB7BEC8), fontSize = 11.sp)
    }
}

@Composable
fun Placeholder(title: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Text("$title\nدر نسخه‌های بعدی تکمیل می‌شود", color = Color.White,
            textAlign = TextAlign.Center, fontSize = 22.sp)
    }
}
