# Gamification v46 Progress

- Reworked Dreamboard into one unified board with no Explore, Assets, year tabs, or achievement checkmarks.
- Dream cards show image with bottom overlay: title right, year center, price left.
- Added Dream add/edit/delete flow, persistent gallery image URI, and selectable display position.
- Dreamboard launcher now uses a car-style icon and a smaller single-line label.
- Removed the Missions red notification dot.
- Reworked Personal Reward Shop to RTL with stronger field/text contrast.
- Reward action is now a large check button; edit/delete are compact icons.
- Added One-time vs Termless reward types and persistent checked/completed state.
- Completed rewards sort to the bottom and can be revealed with a Show checked toggle.
- Existing reward data migrates to the new reward schema.
- Backup schema bumped to v10; Dreamboard and rewards remain included in normal backup/restore.
- App version bumped to 0.46 / versionCode 46.
