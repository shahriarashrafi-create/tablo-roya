package com.shahriar.gamify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B10)
private val Panel = Color(0xFF11161D)
private val Gold = Color(0xFFFFC83D)
private val GoldSoft = Color(0xFFFFE08A)
private val Soft = Color(0xFFB7C0CC)
private val Blue = Color(0xFF58A6FF)
private val Divider = Color(0xFF2A2F37)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

data class PlayerState(
    val level: Int = 37,
    val currentXp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val rank: Int = 8,
    val coins: Int = 1320,
    val combo: Int = 2
)

data class RankTier(
    val start: Int,
    val end: Int,
    val title: String,
    val emblem: String,
    val primary: Color,
    val secondary: Color
)

data class LevelTier(
    val start: Int,
    val end: Int,
    val title: String,
    val emblem: String,
    val ringColors: List<Color>
)

private val rankTiers = listOf(
    RankTier(1, 5, "تازه‌کار", "✦", Color(0xFF8B5E3C), Color(0xFFE4B26E)),
    RankTier(6, 10, "کاوشگر", "★", Color(0xFF7A1F1B), Color(0xFFFFC83D)),
    RankTier(11, 15, "رهرو", "◆", Color(0xFF455A64), Color(0xFFC6D4E1)),
    RankTier(16, 20, "پیشرو", "⬟", Color(0xFF14532D), Color(0xFF7EE787)),
    RankTier(21, 25, "مبارز", "⚔", Color(0xFF7F1D1D), Color(0xFFFDA4AF)),
    RankTier(26, 30, "فرمانده", "♛", Color(0xFF1E3A8A), Color(0xFF93C5FD)),
    RankTier(31, 35, "قهرمان", "✹", Color(0xFF7C2D12), Color(0xFFF9A86B)),
    RankTier(36, 40, "استاد", "✪", Color(0xFF4C1D95), Color(0xFFC4B5FD)),
    RankTier(41, 45, "نگهبان", "🛡", Color(0xFF0F766E), Color(0xFF99F6E4)),
    RankTier(46, 50, "فاتح", "☀", Color(0xFF854D0E), Color(0xFFFDE68A)),
    RankTier(51, 55, "استراتژیست", "⌘", Color(0xFF374151), Color(0xFFD1D5DB)),
    RankTier(56, 60, "افسانه‌جو", "✷", Color(0xFFBE185D), Color(0xFFF9A8D4)),
    RankTier(61, 65, "ژنرال", "⚜", Color(0xFF0F766E), Color(0xFF5EEAD4)),
    RankTier(66, 70, "حاکم", "♚", Color(0xFF5B21B6), Color(0xFFDDD6FE)),
    RankTier(71, 75, "اسطوره", "✴", Color(0xFF92400E), Color(0xFFFCD34D)),
    RankTier(76, 80, "جاودانه", "∞", Color(0xFF164E63), Color(0xFF67E8F9)),
    RankTier(81, 85, "شهاب", "☄", Color(0xFF9A3412), Color(0xFFFDA4AF)),
    RankTier(86, 90, "کیهانی", "✺", Color(0xFF312E81), Color(0xFFA5B4FC)),
    RankTier(91, 95, "ابدی", "✵", Color(0xFF14532D), Color(0xFFBBF7D0)),
    RankTier(96, 100, "آرکِین", "☬", Color(0xFF7E22CE), Color(0xFFE9D5FF))
)

private val levelTiers = listOf(
    LevelTier(1, 10, "نوآموز", "◉", listOf(Color(0xFF6E4A1B), Color(0xFFFFC83D), Color(0xFFFFF1C1))),
    LevelTier(11, 20, "شاگرد", "✦", listOf(Color(0xFF6B7280), Color(0xFFE5E7EB), Color(0xFFFFFFFF))),
    LevelTier(21, 30, "جوینده", "✧", listOf(Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFF3C4))),
    LevelTier(31, 40, "رهرو", "✶", listOf(Color(0xFF1D4ED8), Color(0xFF60A5FA), Color(0xFFE0F2FE))),
    LevelTier(41, 50, "سازنده", "◆", listOf(Color(0xFF166534), Color(0xFF4ADE80), Color(0xFFDCFCE7))),
    LevelTier(51, 60, "استوار", "⬟", listOf(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFFFEDD5))),
    LevelTier(61, 70, "پیشتاز", "✪", listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFFF3E8FF))),
    LevelTier(71, 80, "قهرمان", "✹", listOf(Color(0xFFBE123C), Color(0xFFFB7185), Color(0xFFFFE4E6))),
    LevelTier(81, 90, "فرهمند", "✴", listOf(Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFFCCFBF1))),
    LevelTier(91, 100, "اسطوره", "☼", listOf(Color(0xFF92400E), Color(0xFFFACC15), Color(0xFFFFFBEB)))
)

private fun currentRankTier(rank: Int): RankTier =
    rankTiers.firstOrNull { rank in it.start..it.end } ?: rankTiers.last()

private fun currentLevelTier(level: Int): LevelTier =
    levelTiers.firstOrNull { level in it.start..it.end } ?: levelTiers.last()

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val player = remember { PlayerState() }

    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0E1218)) {
                    listOf("خانه","کارها","آمار","تنظیمات").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("🎮","☑","▥","⚙")[i], fontSize = 19.sp) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Color(0xFF2A2412),
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            )
                        )
                    }
                }
            }
        ) { pad ->
            if (tab == 0) {
                GameHome(player, Modifier.padding(pad))
            } else {
                Box(
                    Modifier
                        .padding(pad)
                        .fillMaxSize()
                        .background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        listOf("","کارها","آمار","تنظیمات")[tab],
                        color = Color.White,
                        fontSize = 24.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GameHome(player: PlayerState, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF101722), Bg)))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TopGameHud(player)

        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(26.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF263B55), Color(0xFF152638), Color(0xFF0D151D))
                    )
                )
                .border(1.dp, Color(0x44FFC83D), RoundedCornerShape(26.dp))
        ) {
            Box(
                Modifier
                    .size(210.dp)
                    .align(Alignment.BottomCenter)
                    .clip(CircleShape)
                    .background(Color(0x2238BDF8))
            )
            Text("✦", color = Gold, fontSize = 72.sp, modifier = Modifier.align(Alignment.Center))
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 34.dp, start = 22.dp, end = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "نسخه بهتر تو در حال ساخته‌شدن است",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(7.dp))
                Text("هر مأموریت، یک قدم جلوتر", color = Soft, fontSize = 14.sp)
            }
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(18.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                MiniAction("⚔", "مأموریت‌ها")
                MiniAction("⌖", "مسیر")
                MiniAction("🎁", "جوایز")
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x66FFC83D), RoundedCornerShape(23.dp)),
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(23.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚔  مأموریت بعدی", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Surface(color = Color(0xFF18243A), shape = RoundedCornerShape(50)) {
                        Text("کلاسیک", color = Blue, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp))
                    }
                }
                Text("۲۵ دقیقه تمرکز", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("روی مهم‌ترین کار فعلی تمرکز کن؛ بدون حواس‌پرتی.", color = Soft, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Reward("+50 XP", Gold)
                    Reward("+20 سکه", Color.White)
                    Reward("◷ 25 دقیقه", Soft)
                }
                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("▶   شروع مأموریت", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun TopGameHud(player: PlayerState) {
    val rankTier = currentRankTier(player.rank)
    val levelTier = currentLevelTier(player.level)
    val progress = (player.currentXp.toFloat() / player.nextLevelXp.toFloat()).coerceIn(0f, 1f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(108.dp)
            .background(
                Brush.verticalGradient(listOf(Color(0xF60A0D11), Color(0xF611151B))),
                RoundedCornerShape(22.dp)
            )
            .border(1.dp, Color(0x55D9B55B), RoundedCornerShape(22.dp))
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Level & XP
        Row(
            modifier = Modifier.weight(1.78f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LevelBadge(level = player.level, tier = levelTier)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                XpBar(progress)
                Spacer(Modifier.height(8.dp))
                Text(
                    "${player.currentXp} / ${player.nextLevelXp} XP",
                    color = Color(0xFFE7E9EC),
                    fontSize = 11.sp,
                    maxLines = 1
                )
                Text(
                    levelTier.title,
                    color = Color(0xFFFFD76A),
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }

        HudDivider()

        // Rank
        Row(
            modifier = Modifier.weight(1.25f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            RankBadge(rankTier)
            Spacer(Modifier.width(6.dp))
            Column {
                Text("رنک ${player.rank}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(rankTier.title, color = rankTier.secondary, fontSize = 10.sp, maxLines = 1)
            }
        }

        HudDivider()

        // Coins
        Row(
            modifier = Modifier.weight(1.05f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            CoinBadge()
            Spacer(Modifier.width(6.dp))
            Column {
                Text(player.coins.toString(), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                Text("سکه", color = Color(0xFFE1C36A), fontSize = 10.sp)
            }
        }

        HudDivider()

        // Combo
        Row(
            modifier = Modifier.weight(1.00f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text("🔥", fontSize = 30.sp)
            Spacer(Modifier.width(5.dp))
            Column {
                Text("x${player.combo}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("کمبو", color = Color(0xFFE1C36A), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, tier: LevelTier) {
    Box(modifier = Modifier.size(72.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 5.5.dp.toPx()
            val ringSize = size.minDimension - stroke
            drawCircle(
                brush = Brush.sweepGradient(tier.ringColors),
                radius = ringSize / 2f,
                style = Stroke(width = stroke)
            )
            drawArc(
                color = Color(0x66FFFFFF),
                startAngle = 220f,
                sweepAngle = 42f,
                useCenter = false,
                topLeft = Offset(stroke / 2f, stroke / 2f),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
            )
            drawCircle(
                color = Color(0xFF131820),
                radius = size.minDimension * 0.38f
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Lv", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(level.toString(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(
            tier.emblem,
            color = GoldSoft,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.TopCenter).offset(y = (-2).dp)
        )
    }
}

@Composable
private fun XpBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(16.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF232932))
            .border(1.dp, Color(0xFF7B6330), RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFFFFED9A), Color(0xFFFFC83D), Color(0xFFE9A61D))
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(6.dp)
                .align(Alignment.TopStart)
                .clip(RoundedCornerShape(50))
                .background(Color(0x33FFFFFF))
        )
    }
}

@Composable
private fun RankBadge(tier: RankTier) {
    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val path = Path().apply {
                moveTo(w * 0.50f, h * 0.05f)
                lineTo(w * 0.88f, h * 0.20f)
                lineTo(w * 0.82f, h * 0.68f)
                quadraticBezierTo(w * 0.66f, h * 0.90f, w * 0.50f, h * 0.97f)
                quadraticBezierTo(w * 0.34f, h * 0.90f, w * 0.18f, h * 0.68f)
                lineTo(w * 0.12f, h * 0.20f)
                close()
            }
            drawPath(path, tier.primary)
            drawPath(path, tier.secondary, style = Stroke(width = 3.0f))
            drawLine(
                color = Color(0x22FFFFFF),
                start = Offset(w * 0.25f, h * 0.28f),
                end = Offset(w * 0.75f, h * 0.28f),
                strokeWidth = 1.5f
            )
        }
        Text(tier.emblem, color = tier.secondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CoinBadge() {
    Box(
        Modifier
            .size(38.dp)
            .background(
                Brush.radialGradient(listOf(Color(0xFFFFE08A), Color(0xFFFFC83D), Color(0xFFC98211))),
                CircleShape
            )
            .border(2.dp, Color(0xFFF7E4A2), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text("★", color = Color(0xFF6D4B00), fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HudDivider() {
    Box(
        Modifier
            .width(1.dp)
            .height(58.dp)
            .background(Divider)
    )
}

@Composable
private fun MiniAction(icon: String, title: String) {
    Column(
        Modifier
            .background(Color(0xCC10151B), RoundedCornerShape(15.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 19.sp)
        Text(title, color = Color.White, fontSize = 10.sp)
    }
}

@Composable
private fun Reward(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
}
