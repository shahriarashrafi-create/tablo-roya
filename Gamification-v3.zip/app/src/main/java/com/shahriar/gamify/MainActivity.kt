package com.shahriar.gamify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B10)
private val Panel = Color(0xFF11161D)
private val Panel2 = Color(0xFF171D25)
private val Gold = Color(0xFFFFC83D)
private val Soft = Color(0xFFB7C0CC)
private val Blue = Color(0xFF58A6FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0E1218)) {
                    listOf("خانه","کارها","آمار","تنظیمات").forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("🎮","☑","▥","⚙")[i], fontSize = 19.sp) },
                            label = { Text(title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Color(0xFF2A2412),
                                unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray
                            )
                        )
                    }
                }
            }
        ) { pad ->
            if (tab == 0) GameHome(Modifier.padding(pad))
            else Box(Modifier.padding(pad).fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
                Text(listOf("","کارها","آمار","تنظیمات")[tab], color = Color.White, fontSize = 24.sp)
            }
        }
    }
}

@Composable
private fun GameHome(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF111B28), Bg)))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Compact game HUD
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Hud("Lv 1", "0 / 200 XP", Modifier.weight(1f))
            Hud("رنک 1", "تازه‌کار", Modifier.weight(1f))
            Hud("0", "امروز", Modifier.weight(1f))
            Hud("🔥 0", "کمبو", Modifier.weight(1f))
        }

        // Living world / main visual zone
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .clip(RoundedCornerShape(26.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF263B55), Color(0xFF152638), Color(0xFF0D151D))
                    )
                )
                .border(1.dp, Color(0x44FFC83D), RoundedCornerShape(26.dp))
        ) {
            // Decorative "world" made natively, so v3 has no external assets.
            Box(
                Modifier.size(210.dp).align(Alignment.BottomCenter)
                    .clip(CircleShape)
                    .background(Color(0x2238BDF8))
            )
            Text("✦", color = Gold, fontSize = 72.sp, modifier = Modifier.align(Alignment.Center))
            Column(
                Modifier.align(Alignment.TopCenter).padding(top = 34.dp, start = 22.dp, end = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("نسخه بهتر تو در حال ساخته‌شدن است", color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(7.dp))
                Text("هر مأموریت، یک قدم جلوتر", color = Soft, fontSize = 14.sp)
            }
            Row(
                Modifier.align(Alignment.BottomCenter).padding(18.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                MiniAction("⚔", "مأموریت‌ها")
                MiniAction("⌖", "مسیر")
                MiniAction("🎁", "جوایز")
            }
        }

        // Current mission
        Card(
            modifier = Modifier.fillMaxWidth()
                .border(1.dp, Color(0x66FFC83D), RoundedCornerShape(23.dp)),
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(23.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("⚔  مأموریت بعدی", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Surface(color = Color(0xFF18243A), shape = RoundedCornerShape(50)) {
                        Text("کلاسیک", color = Blue, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp))
                    }
                }
                Text("۲۵ دقیقه تمرکز", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("روی مهم‌ترین کار فعلی تمرکز کن؛ بدون حواس‌پرتی.", color = Soft, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Reward("+50 XP", Gold)
                    Reward("+20 امتیاز", Color.White)
                    Reward("◷ 25 دقیقه", Soft)
                }
                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF211800))
                ) {
                    Text("▶   شروع مأموریت", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun Hud(main: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Panel, RoundedCornerShape(15.dp)).padding(vertical = 9.dp, horizontal = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(main, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(sub, color = Soft, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun MiniAction(icon: String, title: String) {
    Column(
        Modifier.background(Color(0xCC10151B), RoundedCornerShape(15.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 19.sp)
        Text(title, color = Color.White, fontSize = 10.sp)
    }
}

@Composable
private fun Reward(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
}
