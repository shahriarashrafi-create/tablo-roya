package com.shahriar.gamify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/*
 * TimeSheet rewrite - version 6 / coordinate-system fix.
 *
 * Final pass keeps the synchronized sticky-header pan/zoom engine, merged multi-hour
 * blocks, and board-level touch arbitration. Gesture callbacks/events are read through
 * updated state so editing or changing weeks never leaves the touch engine with stale
 * hit-test data. One-finger pan, two-finger pinch/pan, and sticky headers stay isolated.
 */

private const val KEY_TIMESHEET_STATE = "timesheet_state_v1"
private const val TS_MIN_HOUR = 7
private const val TS_MAX_HOUR = 24
private const val TS_MAX_WEEK_OFFSET = 10
private const val TS_REMINDER_PREF_KEY = "timesheet_reminder_keys"
internal const val EXTRA_TIMESHEET_REMINDER_TITLE = "timesheet_reminder_title"
internal const val EXTRA_TIMESHEET_REMINDER_TIME = "timesheet_reminder_time"

private val TS_DAYS = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
private val TS_HOURS_DESC = (TS_MIN_HOUR until TS_MAX_HOUR).toList().reversed()

private val TsBg = Color(0xFF07101A)
private val TsPanel = Color(0xFF0C1825)
private val TsPanel2 = Color(0xFF102238)
private val TsGrid = Color(0xFF20384C)
private val TsText = Color(0xFFEAF0F6)
private val TsMuted = Color(0xFF8FA0B2)
private val TsGold = Color(0xFFE8C65D)
private val TsBlue = Color(0xFF2D78B7)
private val TsGreen = Color(0xFF43B889)
private val TsRed = Color(0xFFD96666)

private data class TimeSheetEvent(
    val id: Long,
    val day: Int,
    val startHour: Int,
    val endHour: Int,
    val title: String,
    val status: String = "planned",
    val recurring: Boolean = false,
    val reminder: Boolean = false,
    val templateId: Long = 0L
)

private data class TimeSheetState(
    val weekOffset: Int = 0,
    val zoom: Float = 1f,
    val weeks: Map<String, List<TimeSheetEvent>> = emptyMap(),
    val templates: List<TimeSheetEvent> = emptyList(),
    val nextId: Long = 1L
)

private data class TsJalaliDate(val year: Int, val month: Int, val day: Int)

private val tsJalaliMonthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

private fun tsGregorianToJalali(date: LocalDate): TsJalaliDate {
    var gy = date.year - 1600
    val gm = date.monthValue - 1
    val gd = date.dayOfMonth - 1
    val gDays = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    val jDays = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
    for (i in 0 until gm) gDayNo += gDays[i]
    val originalYear = date.year
    val leap = originalYear % 400 == 0 || (originalYear % 4 == 0 && originalYear % 100 != 0)
    if (gm > 1 && leap) gDayNo++
    gDayNo += gd

    var jDayNo = gDayNo - 79
    val jNp = jDayNo / 12053
    jDayNo %= 12053
    var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
    jDayNo %= 1461
    if (jDayNo >= 366) {
        jy += (jDayNo - 1) / 365
        jDayNo = (jDayNo - 1) % 365
    }
    var jm = 0
    while (jm < 11 && jDayNo >= jDays[jm]) {
        jDayNo -= jDays[jm]
        jm++
    }
    return TsJalaliDate(jy, jm + 1, jDayNo + 1)
}

private fun tsPersianDigits(text: String): String {
    val latin = "0123456789"
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    return buildString(text.length) {
        text.forEach { ch -> append(if (ch in latin) persian[latin.indexOf(ch)] else ch) }
    }
}

private fun tsDateShort(date: LocalDate): String {
    val j = tsGregorianToJalali(date)
    return tsPersianDigits(String.format(Locale.US, "%02d/%02d", j.month, j.day))
}

private fun tsWeekLabel(start: LocalDate): String {
    val end = start.plusDays(6)
    val a = tsGregorianToJalali(start)
    val b = tsGregorianToJalali(end)
    return if (a.year == b.year && a.month == b.month) {
        "${tsPersianDigits(a.day.toString())} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[a.month - 1]} ${tsPersianDigits(a.year.toString())}"
    } else {
        "${tsPersianDigits(a.day.toString())} ${tsJalaliMonthNames[a.month - 1]} تا ${tsPersianDigits(b.day.toString())} ${tsJalaliMonthNames[b.month - 1]}"
    }
}

private fun tsBaseSaturday(today: LocalDate = LocalDate.now()): LocalDate {
    val daysBack = (today.dayOfWeek.value - 6 + 7) % 7
    return today.minusDays(daysBack.toLong())
}

private fun tsWeekStart(offset: Int): LocalDate = tsBaseSaturday().plusWeeks(offset.toLong())
private fun tsWeekKey(start: LocalDate): String = start.toString()

private fun timeSheetEventToJson(event: TimeSheetEvent) = JSONObject()
    .put("id", event.id)
    .put("day", event.day)
    .put("startHour", event.startHour)
    .put("endHour", event.endHour)
    .put("title", event.title)
    .put("status", event.status)
    .put("recurring", event.recurring)
    .put("reminder", event.reminder)
    .put("templateId", event.templateId)

private fun timeSheetStateToJson(state: TimeSheetState): String {
    val weeksObject = JSONObject()
    state.weeks.forEach { (key, events) ->
        weeksObject.put(key, JSONArray().also { array -> events.forEach { array.put(timeSheetEventToJson(it)) } })
    }
    val templates = JSONArray().also { array -> state.templates.forEach { array.put(timeSheetEventToJson(it)) } }
    return JSONObject()
        .put("formatVersion", 2)
        .put("weekOffset", state.weekOffset)
        .put("zoom", state.zoom.toDouble())
        .put("weeks", weeksObject)
        .put("templates", templates)
        .put("nextId", state.nextId)
        .toString()
}

private fun parseTimeSheetEvent(obj: JSONObject): TimeSheetEvent? {
    val title = obj.optString("title").trim()
    if (title.isBlank()) return null
    val start = obj.optInt("startHour", TS_MIN_HOUR).coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)
    val end = obj.optInt("endHour", start + 1).coerceIn(start + 1, TS_MAX_HOUR)
    return TimeSheetEvent(
        id = obj.optLong("id", 0L).takeIf { it > 0L } ?: System.currentTimeMillis(),
        day = obj.optInt("day", 0).coerceIn(0, 6),
        startHour = start,
        endHour = end,
        title = title,
        status = obj.optString("status", "planned").takeIf { it in setOf("planned", "done", "missed") } ?: "planned",
        recurring = obj.optBoolean("recurring", false),
        reminder = obj.optBoolean("reminder", false),
        templateId = obj.optLong("templateId", 0L)
    )
}

private fun parseTimeSheetArray(array: JSONArray?): List<TimeSheetEvent> = buildList {
    if (array == null) return@buildList
    for (i in 0 until array.length()) {
        val event = array.optJSONObject(i)?.let(::parseTimeSheetEvent) ?: continue
        add(event)
    }
}

private fun loadTimeSheetState(context: Context): TimeSheetState = runCatching {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TIMESHEET_STATE, null)
        ?: return@runCatching TimeSheetState()
    val root = JSONObject(raw)
    val weeksObj = root.optJSONObject("weeks")
    val weeks = linkedMapOf<String, List<TimeSheetEvent>>()
    if (weeksObj != null) {
        val keys = weeksObj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            weeks[key] = parseTimeSheetArray(weeksObj.optJSONArray(key))
        }
    }
    TimeSheetState(
        weekOffset = root.optInt("weekOffset", 0).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET),
        zoom = root.optDouble("zoom", 1.0).toFloat(),
        weeks = weeks,
        templates = parseTimeSheetArray(root.optJSONArray("templates")),
        nextId = root.optLong("nextId", 1L).coerceAtLeast(1L)
    )
}.getOrDefault(TimeSheetState())

private fun saveTimeSheetState(context: Context, state: TimeSheetState) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(KEY_TIMESHEET_STATE, timeSheetStateToJson(state))
        .apply()
}

private fun tsDisplayedEvents(state: TimeSheetState, weekStart: LocalDate): List<TimeSheetEvent> {
    val weekEvents = state.weeks[tsWeekKey(weekStart)].orEmpty()
    val overriddenTemplateIds = weekEvents.mapNotNull { it.templateId.takeIf { id -> id > 0L } }.toSet()
    val fixed = state.templates
        .filterNot { it.id in overriddenTemplateIds }
        .map { template ->
            template.copy(
                id = -template.id,
                recurring = true,
                templateId = template.id,
                status = "planned"
            )
        }
    return (fixed + weekEvents)
        .sortedWith(compareBy<TimeSheetEvent> { it.day }.thenBy { it.startHour }.thenBy { it.endHour })
}

private fun tsOverlaps(aDay: Int, aStart: Int, aEnd: Int, event: TimeSheetEvent): Boolean =
    aDay == event.day && aStart < event.endHour && aEnd > event.startHour

private fun tsHasConflict(
    state: TimeSheetState,
    weekStart: LocalDate,
    day: Int,
    startHour: Int,
    endHour: Int,
    recurring: Boolean,
    editing: TimeSheetEvent?
): Boolean {
    val editingTemplateId = editing?.templateId?.takeIf { it > 0L }
        ?: editing?.takeIf { it.recurring && it.id != 0L }?.id?.let { kotlin.math.abs(it) }
    val editingExplicitId = editing?.takeIf { !it.recurring && it.id > 0L }?.id

    fun sameLogical(event: TimeSheetEvent): Boolean {
        if (editingTemplateId != null) {
            val eventTemplateId = event.templateId.takeIf { it > 0L }
                ?: event.takeIf { it.recurring }?.id?.let { kotlin.math.abs(it) }
            return eventTemplateId == editingTemplateId
        }
        if (editingExplicitId != null) return event.id == editingExplicitId
        return false
    }

    if (recurring) {
        if (state.templates.any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }) return true
        return state.weeks.values.flatten().any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }
    }
    return tsDisplayedEvents(state, weekStart).any { !sameLogical(it) && tsOverlaps(day, startHour, endHour, it) }
}

@Composable
internal fun TimeSheetDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current.applicationContext
    var state by remember { mutableStateOf(loadTimeSheetState(context)) }
    var editorSeed by remember { mutableStateOf<TimeSheetEvent?>(null) }

    fun commit(next: TimeSheetState) {
        state = next
        saveTimeSheetState(context, next)
        rescheduleTimeSheetReminders(context, next)
    }

    val weekStart = tsWeekStart(state.weekOffset)
    val events = tsDisplayedEvents(state, weekStart)

    LaunchedEffect(Unit) { rescheduleTimeSheetReminders(context, state) }
    BackHandler(onBack = onDismiss)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = TsBg) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(TsBg, Color(0xFF0A1623), Color(0xFF060B12))))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TimeSheetV1Header(onDismiss = onDismiss)
                TimeSheetV1WeekBar(
                    weekStart = weekStart,
                    weekOffset = state.weekOffset,
                    onPrevious = {
                        val next = (state.weekOffset - 1).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET)
                        if (next != state.weekOffset) commit(state.copy(weekOffset = next))
                    },
                    onCurrent = { if (state.weekOffset != 0) commit(state.copy(weekOffset = 0)) },
                    onNext = {
                        val next = (state.weekOffset + 1).coerceIn(-TS_MAX_WEEK_OFFSET, TS_MAX_WEEK_OFFSET)
                        if (next != state.weekOffset) commit(state.copy(weekOffset = next))
                    }
                )
                TimeSheetV1Stats(events)
                TimeSheetV1Board(
                    weekStart = weekStart,
                    events = events,
                    zoom = state.zoom,
                    onZoomSettled = { settledZoom ->
                        if (kotlin.math.abs(state.zoom - settledZoom) > 0.001f) {
                            commit(state.copy(zoom = settledZoom))
                        }
                    },
                    modifier = Modifier.weight(1f),
                    onCellClick = { day, hour, event ->
                        editorSeed = event ?: TimeSheetEvent(
                            id = 0L,
                            day = day,
                            startHour = hour,
                            endHour = (hour + 1).coerceAtMost(TS_MAX_HOUR),
                            title = ""
                        )
                    }
                )
            }
        }
    }

    editorSeed?.let { seed ->
        TimeSheetV1Editor(
            seed = seed,
            state = state,
            weekStart = weekStart,
            onDismiss = { editorSeed = null },
            onDelete = {
                val templateId = seed.templateId.takeIf { it > 0L }
                    ?: seed.takeIf { it.recurring && it.id != 0L }?.id?.let { kotlin.math.abs(it) }
                val next = if (templateId != null) {
                    val cleanedWeeks = state.weeks.mapValues { (_, list) -> list.filterNot { it.templateId == templateId } }
                    state.copy(
                        templates = state.templates.filterNot { it.id == templateId },
                        weeks = cleanedWeeks
                    )
                } else {
                    val key = tsWeekKey(weekStart)
                    state.copy(weeks = state.weeks + (key to state.weeks[key].orEmpty().filterNot { it.id == seed.id }))
                }
                commit(next)
                editorSeed = null
            },
            onSave = { title, day, startHour, endHour, recurring, reminder, status ->
                val key = tsWeekKey(weekStart)
                val editing = seed.takeIf { it.id != 0L }
                val oldTemplateId = editing?.templateId?.takeIf { it > 0L }
                    ?: editing?.takeIf { it.recurring }?.id?.let { kotlin.math.abs(it) }

                if (recurring) {
                    val templateId = oldTemplateId ?: state.nextId
                    val template = TimeSheetEvent(
                        id = templateId,
                        day = day,
                        startHour = startHour,
                        endHour = endHour,
                        title = title,
                        status = "planned",
                        recurring = true,
                        reminder = reminder
                    )
                    val templates = if (oldTemplateId != null) {
                        state.templates.map { if (it.id == oldTemplateId) template else it }
                    } else state.templates + template
                    var weekList = state.weeks[key].orEmpty().filterNot { stored ->
                        (editing != null && !editing.recurring && stored.id == editing.id) ||
                            (oldTemplateId != null && stored.templateId == oldTemplateId)
                    }
                    var nextId = if (oldTemplateId == null) state.nextId + 1 else state.nextId
                    if (status != "planned") {
                        weekList = weekList + template.copy(
                            id = nextId,
                            status = status,
                            templateId = templateId
                        )
                        nextId++
                    }
                    commit(
                        state.copy(
                            templates = templates,
                            weeks = state.weeks + (key to weekList),
                            nextId = nextId
                        )
                    )
                } else {
                    val id = editing?.takeIf { !it.recurring && it.id > 0L }?.id ?: state.nextId
                    val event = TimeSheetEvent(
                        id = id,
                        day = day,
                        startHour = startHour,
                        endHour = endHour,
                        title = title,
                        status = status,
                        recurring = false,
                        reminder = reminder
                    )
                    var weekList = state.weeks[key].orEmpty().filterNot { stored ->
                        (editing != null && !editing.recurring && stored.id == editing.id) ||
                            (oldTemplateId != null && stored.templateId == oldTemplateId)
                    }
                    weekList = weekList + event
                    val cleanedTemplates = if (oldTemplateId != null) state.templates.filterNot { it.id == oldTemplateId } else state.templates
                    commit(
                        state.copy(
                            templates = cleanedTemplates,
                            weeks = state.weeks + (key to weekList),
                            nextId = if (editing == null || editing.recurring) state.nextId + 1 else state.nextId
                        )
                    )
                }
                editorSeed = null
            }
        )
    }
}

@Composable
private fun TimeSheetV1Header(onDismiss: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth().height(42.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onDismiss) { Text("×", color = TsText, fontSize = 26.sp) }
            Text("TimeSheet", color = TsText, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun TimeSheetV1WeekBar(
    weekStart: LocalDate,
    weekOffset: Int,
    onPrevious: () -> Unit,
    onCurrent: () -> Unit,
    onNext: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = TsPanel,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, TsGrid)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TextButton(onClick = onPrevious, enabled = weekOffset > -TS_MAX_WEEK_OFFSET) {
                    Text("‹ هفته قبل", color = if (weekOffset > -TS_MAX_WEEK_OFFSET) TsText else TsMuted, fontSize = 10.sp)
                }
                TextButton(onClick = onCurrent, modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (weekOffset == 0) "این هفته" else "بازگشت به این هفته", color = TsGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text(tsWeekLabel(weekStart), color = TsMuted, fontSize = 8.sp)
                    }
                }
                TextButton(onClick = onNext, enabled = weekOffset < TS_MAX_WEEK_OFFSET) {
                    Text("هفته بعد ›", color = if (weekOffset < TS_MAX_WEEK_OFFSET) TsText else TsMuted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun TimeSheetV1Stats(events: List<TimeSheetEvent>) {
    val planned = events.filter { it.status == "planned" }.sumOf { it.endHour - it.startHour }
    val done = events.filter { it.status == "done" }.sumOf { it.endHour - it.startHour }
    val missed = events.filter { it.status == "missed" }.sumOf { it.endHour - it.startHour }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            TimeSheetV1Stat("برنامه", "${planned}h", TsGold, Modifier.weight(1f))
            TimeSheetV1Stat("انجام شد", "${done}h", TsGreen, Modifier.weight(1f))
            TimeSheetV1Stat("انجام نشد", "${missed}h", TsRed, Modifier.weight(1f))
        }
    }
}

@Composable
private fun TimeSheetV1Stat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.height(56.dp),
        color = TsPanel,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, TsGrid)
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = accent, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = TsMuted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun TimeSheetV1Board(
    weekStart: LocalDate,
    events: List<TimeSheetEvent>,
    zoom: Float,
    onZoomSettled: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onCellClick: (day: Int, hour: Int, event: TimeSheetEvent?) -> Unit
) {
    val density = LocalDensity.current

    // The grid and the two sticky headers deliberately use different geometry:
    // the body cells zoom, while the day column / hour header remain readable and fixed.
    val baseHourCellWidth = 74.dp
    val fixedDayColumnWidth = 82.dp
    val fixedHeaderHeight = 46.dp
    val baseDayRowHeight = 68.dp

    val baseHourCellWidthPx = with(density) { baseHourCellWidth.toPx() }
    val fixedDayColumnWidthPx = with(density) { fixedDayColumnWidth.toPx() }
    val fixedHeaderHeightPx = with(density) { fixedHeaderHeight.toPx() }
    val baseDayRowHeightPx = with(density) { baseDayRowHeight.toPx() }
    val baseBodyWidthPx = baseHourCellWidthPx * TS_HOURS_DESC.size
    val baseBodyHeightPx = baseDayRowHeightPx * 7f

    var boardZoom by remember { mutableStateOf(zoom.coerceIn(0.50f, 1.50f)) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var initialPositioned by remember { mutableStateOf(false) }
    var showZoomIndicator by remember { mutableStateOf(false) }
    val currentEvents by rememberUpdatedState(events)
    val currentOnCellClick by rememberUpdatedState(onCellClick)

    fun bodyViewportWidth(): Float =
        (viewportSize.width.toFloat() - fixedDayColumnWidthPx).coerceAtLeast(0f)

    fun bodyViewportHeight(): Float =
        (viewportSize.height.toFloat() - fixedHeaderHeightPx).coerceAtLeast(0f)

    fun scaledBodyWidth(scale: Float): Float = baseBodyWidthPx * scale
    fun scaledBodyHeight(scale: Float): Float = baseBodyHeightPx * scale

    fun clampPan(raw: Offset, scale: Float): Offset {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return raw

        val viewportW = bodyViewportWidth()
        val viewportH = bodyViewportHeight()
        val contentW = scaledBodyWidth(scale)
        val contentH = scaledBodyHeight(scale)

        // Horizontal content is RTL-facing: when it is smaller than the viewport it
        // stays attached to the fixed day column, never floating away from it.
        val x = if (contentW <= viewportW) {
            viewportW - contentW
        } else {
            raw.x.coerceIn(viewportW - contentW, 0f)
        }

        // Vertical content starts below the fixed hour header. If it fits, keep it at top.
        val y = if (contentH <= viewportH) {
            0f
        } else {
            raw.y.coerceIn(viewportH - contentH, 0f)
        }
        return Offset(x, y)
    }

    fun applyTransform(centroid: Offset, panChange: Offset, zoomChange: Float) {
        val oldZoom = boardZoom
        val newZoom = (oldZoom * zoomChange).coerceIn(0.50f, 1.50f)
        val bodyRight = bodyViewportWidth()
        val bodyBottom = fixedHeaderHeightPx + bodyViewportHeight()

        // Keep the content under the fingers stable while zooming. The sticky headers
        // are excluded from this coordinate system, so they never scale or drift.
        val focusX = centroid.x.coerceIn(0f, bodyRight)
        val focusY = centroid.y.coerceIn(fixedHeaderHeightPx, bodyBottom)
        val contentBaseX = (focusX - pan.x) / oldZoom
        val contentBaseY = (focusY - fixedHeaderHeightPx - pan.y) / oldZoom

        val transformed = Offset(
            x = focusX - contentBaseX * newZoom + panChange.x,
            y = (focusY - fixedHeaderHeightPx) - contentBaseY * newZoom + panChange.y
        )

        boardZoom = newZoom
        pan = clampPan(transformed, newZoom)
        if (kotlin.math.abs(zoomChange - 1f) > 0.002f) showZoomIndicator = true
    }

    fun openAt(screenPosition: Offset) {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return
        val bodyRight = bodyViewportWidth()
        if (
            screenPosition.x !in 0f..bodyRight ||
            screenPosition.y < fixedHeaderHeightPx ||
            screenPosition.y >= viewportSize.height.toFloat()
        ) return

        val contentX = (screenPosition.x - pan.x) / boardZoom
        val contentY = (screenPosition.y - fixedHeaderHeightPx - pan.y) / boardZoom
        if (contentX < 0f || contentY < 0f || contentX >= baseBodyWidthPx || contentY >= baseBodyHeightPx) return

        val hourIndex = (contentX / baseHourCellWidthPx).toInt()
        val day = (contentY / baseDayRowHeightPx).toInt()
        if (day !in 0..6 || hourIndex !in TS_HOURS_DESC.indices) return

        val hour = TS_HOURS_DESC[hourIndex]
        val event = currentEvents.firstOrNull { it.day == day && hour >= it.startHour && hour < it.endHour }
        currentOnCellClick(day, hour, event)
    }

    LaunchedEffect(viewportSize, weekStart) {
        if (viewportSize.width > 0 && viewportSize.height > 0) {
            // Always enter a week with the early-day hours touching the fixed day column.
            // This is the canonical RTL start position of the TimeSheet.
            val rightAlignedX = bodyViewportWidth() - scaledBodyWidth(boardZoom)
            pan = clampPan(Offset(rightAlignedX, 0f), boardZoom)
            initialPositioned = true
        }
    }

    LaunchedEffect(boardZoom) {
        if (!initialPositioned) return@LaunchedEffect
        delay(280L)
        onZoomSettled(boardZoom)
        showZoomIndicator = false
    }

    val scaledHourCellWidth = baseHourCellWidth * boardZoom
    val scaledDayRowHeight = baseDayRowHeight * boardZoom
    val scaledBodyWidth = scaledHourCellWidth * TS_HOURS_DESC.size
    val scaledBodyHeight = scaledDayRowHeight * 7

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xC9081521),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, TsGrid)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
                .onSizeChanged { newSize ->
                    viewportSize = newSize
                    if (initialPositioned) pan = clampPan(pan, boardZoom)
                }
                .pointerInput(weekStart, viewportSize) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val tapPosition = down.position
                        var totalSingleDrag = Offset.Zero
                        var previousSinglePosition: Offset? = down.position
                        var transforming = false
                        var usedMultiplePointers = false

                        while (true) {
                            val pointerEvent = awaitPointerEvent()
                            val pressed = pointerEvent.changes.filter { it.pressed }
                            if (pressed.isEmpty()) {
                                if (!transforming && !usedMultiplePointers) openAt(tapPosition)
                                break
                            }

                            if (pressed.size >= 2) {
                                usedMultiplePointers = true
                                transforming = true
                                previousSinglePosition = null
                                val centroid = pointerEvent.calculateCentroid(useCurrent = true)
                                val panChange = pointerEvent.calculatePan()
                                val zoomChange = pointerEvent.calculateZoom()
                                applyTransform(centroid, panChange, zoomChange)
                                pointerEvent.changes.forEach { if (it.pressed) it.consume() }
                            } else {
                                val current = pressed.first().position
                                val previous = previousSinglePosition
                                previousSinglePosition = current
                                val delta = if (previous == null) Offset.Zero else current - previous
                                if (!transforming) {
                                    totalSingleDrag += delta
                                    if (totalSingleDrag.getDistance() > viewConfiguration.touchSlop) {
                                        transforming = true
                                        applyTransform(current, totalSingleDrag, 1f)
                                        totalSingleDrag = Offset.Zero
                                        pressed.first().consume()
                                    }
                                } else {
                                    applyTransform(current, delta, 1f)
                                    pressed.first().consume()
                                }
                            }
                        }
                    }
                }
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                // 1) BODY: zooms in both axes and pans in both axes.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = fixedHeaderHeight, end = fixedDayColumnWidth)
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .requiredWidth(scaledBodyWidth)
                            .requiredHeight(scaledBodyHeight)
                            .graphicsLayer {
                                translationX = pan.x
                                translationY = pan.y
                            }
                    ) {
                        for (day in 0..6) {
                            TimeSheetV5BodyRow(
                                day = day,
                                date = weekStart.plusDays(day.toLong()),
                                events = events,
                                hourCellWidth = scaledHourCellWidth,
                                rowHeight = scaledDayRowHeight
                            )
                        }
                    }
                }

                // 2) HOURS: fixed at the top; follows only horizontal pan and cell widths.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(fixedHeaderHeight)
                        .padding(end = fixedDayColumnWidth)
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .requiredWidth(scaledBodyWidth)
                            .height(fixedHeaderHeight)
                            .graphicsLayer { translationX = pan.x }
                    ) {
                        TS_HOURS_DESC.forEach { hour ->
                            Surface(
                                modifier = Modifier.width(scaledHourCellWidth).height(fixedHeaderHeight),
                                color = TsPanel,
                                border = BorderStroke(0.5.dp, TsGrid)
                            ) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        "${hour}-${hour + 1}",
                                        color = TsMuted,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // 3) DAYS: fixed on the right; follows only vertical pan and row heights.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = fixedHeaderHeight)
                        .width(fixedDayColumnWidth)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(0.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .width(fixedDayColumnWidth)
                            .requiredHeight(scaledBodyHeight)
                            .graphicsLayer { translationY = pan.y }
                    ) {
                        for (day in 0..6) {
                            TimeSheetV5DayHeader(
                                day = day,
                                date = weekStart.plusDays(day.toLong()),
                                width = fixedDayColumnWidth,
                                height = scaledDayRowHeight
                            )
                        }
                    }
                }

                // 4) CORNER: never moves or scales.
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .width(fixedDayColumnWidth)
                        .height(fixedHeaderHeight),
                    color = TsPanel2,
                    border = BorderStroke(0.7.dp, TsGrid)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("روز", color = TsMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (showZoomIndicator) {
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
                    color = Color(0xDD08121D),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, TsBlue.copy(alpha = 0.7f))
                ) {
                    Text(
                        "${(boardZoom * 100f).toInt()}%",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        color = TsText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

@Composable
private fun TimeSheetV5BodyRow(
    day: Int,
    date: LocalDate,
    events: List<TimeSheetEvent>,
    hourCellWidth: androidx.compose.ui.unit.Dp,
    rowHeight: androidx.compose.ui.unit.Dp
) {
    val isToday = date == LocalDate.now()
    Box(
        modifier = Modifier
            .requiredWidth(hourCellWidth * TS_HOURS_DESC.size)
            .height(rowHeight)
    ) {
        Row(Modifier.fillMaxSize()) {
            TS_HOURS_DESC.forEach { _ ->
                Surface(
                    modifier = Modifier.width(hourCellWidth).height(rowHeight),
                    color = if (isToday) Color(0x181E79B3) else Color(0x260C1825),
                    border = BorderStroke(0.5.dp, TsGrid)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("+", color = Color(0x4053677A), fontSize = 9.sp)
                    }
                }
            }
        }

        events
            .filter { it.day == day }
            .forEach { event ->
                val firstDisplayedHour = (event.endHour - 1).coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)
                val leftIndex = TS_HOURS_DESC.indexOf(firstDisplayedHour)
                val span = (event.endHour - event.startHour).coerceAtLeast(1)
                if (leftIndex >= 0) {
                    val accent = when (event.status) {
                        "done" -> TsGreen
                        "missed" -> TsRed
                        else -> TsBlue
                    }
                    Surface(
                        modifier = Modifier
                            .offset(x = hourCellWidth * leftIndex, y = 0.dp)
                            .width(hourCellWidth * span)
                            .height(rowHeight)
                            .padding(2.dp),
                        color = accent.copy(alpha = 0.34f),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.82f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 3.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                event.title,
                                color = TsText,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (rowHeight >= 40.dp) {
                                Text(
                                    "${tsPersianDigits(event.startHour.toString())}:۰۰–${tsPersianDigits(event.endHour.toString())}:۰۰",
                                    color = accent,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
    }
}

@Composable
private fun TimeSheetV5DayHeader(
    day: Int,
    date: LocalDate,
    width: androidx.compose.ui.unit.Dp,
    height: androidx.compose.ui.unit.Dp
) {
    val today = LocalDate.now()
    Surface(
        modifier = Modifier.width(width).height(height),
        color = if (date == today) Color(0xFF123F61) else TsPanel2,
        border = BorderStroke(0.7.dp, if (date == today) Color(0xFF3185C5) else TsGrid)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    TS_DAYS[day],
                    color = TsText,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (height >= 36.dp) {
                    Spacer(Modifier.height(2.dp))
                    Text(tsDateShort(date), color = TsMuted, fontSize = 8.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun TimeSheetV1Editor(
    seed: TimeSheetEvent,
    state: TimeSheetState,
    weekStart: LocalDate,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onSave: (String, Int, Int, Int, Boolean, Boolean, String) -> Unit
) {
    var title by remember(seed.id) { mutableStateOf(seed.title) }
    var day by remember(seed.id) { mutableStateOf(seed.day.coerceIn(0, 6)) }
    var start by remember(seed.id) { mutableStateOf(seed.startHour.coerceIn(TS_MIN_HOUR, TS_MAX_HOUR - 1)) }
    var end by remember(seed.id) { mutableStateOf(seed.endHour.coerceIn(start + 1, TS_MAX_HOUR)) }
    var recurring by remember(seed.id) { mutableStateOf(if (seed.id == 0L) true else seed.recurring) }
    var reminder by remember(seed.id) { mutableStateOf(seed.reminder) }
    var status by remember(seed.id) { mutableStateOf(seed.status) }

    val cleanTitle = title.trim()
    val conflict = cleanTitle.isNotBlank() && tsHasConflict(
        state = state,
        weekStart = weekStart,
        day = day,
        startHour = start,
        endHour = end,
        recurring = recurring,
        editing = seed.takeIf { it.id != 0L }
    )
    val canSave = cleanTitle.isNotBlank() && end > start && !conflict

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0B1723),
        shape = RoundedCornerShape(22.dp),
        title = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Text(
                    if (seed.id == 0L) "برنامه جدید" else "ویرایش برنامه",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right,
                    color = TsText,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        },
        text = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("عنوان برنامه") }
                    )

                    TimeSheetV1Stepper(
                        label = "روز",
                        value = "${TS_DAYS[day]} • ${tsDateShort(weekStart.plusDays(day.toLong()))}",
                        onMinus = { day = (day - 1).coerceAtLeast(0) },
                        onPlus = { day = (day + 1).coerceAtMost(6) }
                    )
                    TimeSheetV1Stepper(
                        label = "شروع",
                        value = "${tsPersianDigits(start.toString())}:۰۰",
                        onMinus = {
                            start = (start - 1).coerceAtLeast(TS_MIN_HOUR)
                            if (end <= start) end = (start + 1).coerceAtMost(TS_MAX_HOUR)
                        },
                        onPlus = {
                            start = (start + 1).coerceAtMost(TS_MAX_HOUR - 1)
                            if (end <= start) end = (start + 1).coerceAtMost(TS_MAX_HOUR)
                        }
                    )
                    TimeSheetV1Stepper(
                        label = "پایان",
                        value = "${tsPersianDigits(end.toString())}:۰۰",
                        onMinus = { end = (end - 1).coerceAtLeast(start + 1) },
                        onPlus = { end = (end + 1).coerceAtMost(TS_MAX_HOUR) }
                    )

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = recurring, onCheckedChange = { recurring = it })
                        Text("برنامه ثابت هفتگی", color = TsText, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = reminder, onCheckedChange = { reminder = it })
                        Text("یادآوری ۵ دقیقه قبل", color = TsText, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
                    }

                    if (seed.id != 0L) {
                        Text("وضعیت", color = TsMuted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("planned" to "برنامه", "done" to "انجام شد", "missed" to "انجام نشد").forEach { (value, label) ->
                                val selected = status == value
                                val accent = when (value) {
                                    "done" -> TsGreen
                                    "missed" -> TsRed
                                    else -> TsGold
                                }
                                Surface(
                                    modifier = Modifier.weight(1f).height(38.dp).clickable { status = value },
                                    color = if (selected) accent.copy(alpha = 0.22f) else TsPanel,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (selected) accent else TsGrid)
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(label, color = if (selected) accent else TsMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    if (conflict) {
                        Text("این بازه با یک برنامه دیگر تداخل دارد.", color = TsRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(cleanTitle, day, start, end, recurring, reminder, status) },
                enabled = canSave,
                colors = ButtonDefaults.buttonColors(containerColor = TsGold, contentColor = Color(0xFF211800))
            ) {
                Text("ذخیره", fontWeight = FontWeight.ExtraBold)
            }
        },
        dismissButton = {
            Row {
                if (seed.id != 0L) {
                    TextButton(onClick = onDelete) { Text("حذف", color = TsRed) }
                }
                TextButton(onClick = onDismiss) { Text("انصراف", color = TsMuted) }
            }
        }
    )
}

@Composable
private fun TimeSheetV1Stepper(
    label: String,
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = TsPanel,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, TsGrid)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onMinus) { Text("−", color = TsText, fontSize = 20.sp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label, color = TsMuted, fontSize = 8.sp)
                    Text(value, color = TsText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onPlus) { Text("+", color = TsText, fontSize = 18.sp) }
            }
        }
    }
}

private fun timeSheetReminderPendingIntent(
    context: Context,
    occurrenceKey: String,
    title: String,
    timeLabel: String
): PendingIntent {
    val intent = Intent(context, TimeSheetReminderReceiver::class.java).apply {
        data = Uri.parse("gamify://timesheet-reminder/${Uri.encode(occurrenceKey)}")
        putExtra(EXTRA_TIMESHEET_REMINDER_TITLE, title)
        putExtra(EXTRA_TIMESHEET_REMINDER_TIME, timeLabel)
    }
    return PendingIntent.getBroadcast(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun cancelTimeSheetReminder(context: Context, occurrenceKey: String) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(timeSheetReminderPendingIntent(context, occurrenceKey, "", ""))
}

internal fun rescheduleTimeSheetReminders(context: Context) {
    rescheduleTimeSheetReminders(context, loadTimeSheetState(context))
}

private fun rescheduleTimeSheetReminders(
    context: Context,
    state: TimeSheetState,
    nowMillis: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault()
) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val oldKeys = prefs.getStringSet(TS_REMINDER_PREF_KEY, emptySet()).orEmpty().toSet()
    oldKeys.forEach { cancelTimeSheetReminder(context, it) }

    val settings = loadSettings(context)
    if (!settings.notificationsEnabled) {
        prefs.edit().remove(TS_REMINDER_PREF_KEY).apply()
        return
    }

    val scheduled = linkedSetOf<String>()
    fun schedule(event: TimeSheetEvent, date: LocalDate, logicalId: Long) {
        if (!event.reminder || event.status != "planned") return
        val start = ZonedDateTime.of(date, LocalTime.of(event.startHour, 0), zone)
        val triggerAt = start.minusMinutes(5).toInstant().toEpochMilli()
        if (triggerAt <= nowMillis) return
        val key = "$logicalId@$date"
        val timeLabel = "${TS_DAYS[event.day]} ${tsDateShort(date)} • ${tsPersianDigits(event.startHour.toString())}:۰۰"
        scheduleReliableAlarm(context, triggerAt, timeSheetReminderPendingIntent(context, key, event.title, timeLabel))
        scheduled += key
    }

    state.weeks.forEach { (weekKey, entries) ->
        val weekStart = runCatching { LocalDate.parse(weekKey) }.getOrNull() ?: return@forEach
        entries.filter { !it.recurring && it.templateId == 0L }.forEach { event ->
            schedule(event, weekStart.plusDays(event.day.toLong()), event.id)
        }
    }

    val base = tsBaseSaturday()
    for (weekOffset in 0..TS_MAX_WEEK_OFFSET) {
        val weekStart = base.plusWeeks(weekOffset.toLong())
        val key = tsWeekKey(weekStart)
        val overrides = state.weeks[key].orEmpty()
        state.templates.forEach { template ->
            if (!template.reminder) return@forEach
            val override = overrides.firstOrNull { it.templateId == template.id }
            val occurrence = if (override != null) template.copy(status = override.status) else template
            schedule(occurrence, weekStart.plusDays(template.day.toLong()), template.id)
        }
    }

    prefs.edit().putStringSet(TS_REMINDER_PREF_KEY, scheduled).apply()
}
