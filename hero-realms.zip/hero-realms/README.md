# Hero Realms 3D ⚔️

یک نمونه‌ی حرفه‌ای بازی سوم‌شخص سه‌بعدی برای مرورگر، ساخته‌شده با **Three.js + Vite** و آماده‌ی قرار گرفتن روی GitHub.

![Three.js](https://img.shields.io/badge/Three.js-3D-black)
![Vite](https://img.shields.io/badge/Vite-Web-646CFF)
![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Ready-2ea44f)

## داخل بازی چه چیزهایی هست؟

- هیروی سه‌بعدی با زره، شمشیر و سپر
- حرکت سوم‌شخص با دوربین قابل چرخش
- راه رفتن، دویدن، حمله و Dash
- دشمن‌های دارای AI و یک Boss
- سیستم جان، استقامت، امتیاز و Level
- جمع‌آوری 10 کریستال
- محیط سه‌بعدی بزرگ با تپه، دریاچه، درخت، سنگ، چمن و خرابه‌های باستانی
- نور و سایه‌ی پویا، Fog، Tone Mapping و حالت روز/شب
- افکت‌های محیطی و HUD کامل
- GitHub Actions آماده برای انتشار خودکار روی GitHub Pages

> مدل‌ها و محیط فعلاً به‌صورت procedural داخل کد ساخته می‌شوند؛ بنابراین پروژه بدون استفاده از Asset کپی‌رایت‌شده قابل انتشار است.

## کنترل‌ها

| کلید | کار |
|---|---|
| `W A S D` | حرکت |
| `Shift` | دویدن |
| `Space` | حمله با شمشیر |
| `Q` | Dash |
| نگه داشتن راست‌کلیک + Drag | چرخاندن دوربین |
| Mouse Wheel | نزدیک/دور کردن دوربین |
| `N` | تغییر روز / شب |

## ساده‌ترین روش اجرا روی کامپیوتر

اگر Node.js نصب است:

```bash
npm install
npm run dev
```

بعد لینکی که Vite نشان می‌دهد را در Chrome یا Edge باز کنید.

## گذاشتن روی GitHub Pages بدون تغییر کد

1. در GitHub یک Repository جدید بسازید.
2. همه فایل‌های همین پوشه را داخل Repository آپلود کنید.
3. Branch اصلی را `main` نگه دارید.
4. در Repository بروید به **Settings → Pages**.
5. در قسمت **Build and deployment** گزینه **GitHub Actions** را انتخاب کنید.
6. با Push بعدی، Workflow موجود در `.github/workflows/deploy.yml` بازی را Build و منتشر می‌کند.

## ساختار پروژه

```text
hero-realms/
├── .github/workflows/deploy.yml
├── src/
│   ├── main.js
│   └── style.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## نکته درباره گرافیک

این نسخه یک **High-quality browser prototype** است، نه یک بازی AAA با مدل‌های چند گیگابایتی. ساختار پروژه طوری آماده شده که بعداً بتوانید مدل‌های GLB/GLTF، انیمیشن Motion Capture، تکسچرهای 2K/4K، صدا و Mapهای بزرگ‌تر را به آن اضافه کنید.

## License

MIT
