# Gamification v48 Progress

- Unified Home world buttons so Dreamboard, Map, Missions, and Shop use the same outer dimensions.
- Kept Dreamboard label compact enough to remain on one line.
- Refined Dream properties UI and removed the properties heading.
- Dream title entry now starts clean and uses a disappearing placeholder.
- Dream price is numeric and displayed with a trailing dollar sign.
- Dream year is displayed as `سال <year>` on the image.
- Display position remains a simple dropdown selector.
- Removed the Shop title and duplicate current-coin text so the Home HUD remains the primary coin display.
- Shop copy and default reward names are Persian.
- Reusable/نامحدود rewards remain immediately available after redemption; one-time rewards move to completed state.
- Improved Shop right-to-left layout and retained high-contrast text fields.
