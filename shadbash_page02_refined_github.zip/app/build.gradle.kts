plugins {
    id("com.android.application")
}

android {
    namespace = "com.shahriar.nextbeat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shahriar.shadbash"
        minSdk = 24
        targetSdk = 35
        versionCode = 5
        versionName = "0.4.0-shadbash-page02-refined"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
