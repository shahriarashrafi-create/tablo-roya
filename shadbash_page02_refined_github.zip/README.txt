shadbash - Page 02 refined

Changes in this ZIP:
- Page 2 redesigned without scroll.
- Removed step text and progress bar.
- Removed helper subtitle under heading.
- Reduced size of the heading.
- Team-count cards 2/3/4/5/6 are smaller and placed in one line.
- Inline team-name placeholders/inputs added in one line.
- Removed preview title and color legend; app uses built-in styling.
- Added round-count selection in one line: 3 / 5 / 10 / custom.
- Category section removed.
- Compatible with the existing ZIP-based workflow.
