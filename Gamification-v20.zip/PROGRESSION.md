# Gamification v20

Upper-half final-tuning pass:
- Removed the extra rounded hero frame so everything below the HUD is pure world background
- Moved the central headline upward to match the reference composition
- Refined the motivational quote hierarchy and readability
- Repositioned Knowledge, Freedom, Health, Discipline and Wealth labels onto visible landmarks
- Tightened and polished Quests / Map / Inbox / Shop button spacing and sizing
- Moved slider dots below the mission card instead of overlaying the card
- Made the mission card slightly more compact to reveal more of the world above it
- Kept Combo in the top-right HUD
- Bumped app version to 0.20 / versionCode 20
